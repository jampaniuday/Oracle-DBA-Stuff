SELECT username, logoff_time, logoff_lread, logoff_pread,
    logoff_lwrite, logoff_dlock
    FROM sys.dba_audit_session;

