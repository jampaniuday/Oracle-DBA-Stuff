SELECT
  df.tablespace_name "TableSpace",
  df.file_name "FileName",
  trunc(df.bytes/1024/1024) "Size(m)",
  round(e.used_bytes/1024/1024,1) "Used",
  round(f.free_bytes/1024/1024,1) "Available",
  RPAD(' '|| RPAD ('X',ROUND(e.used_bytes*10/df.bytes,0), 'X'),11,'-') "PCT Used"
FROM DBA_DATA_FILES DF,
     (SELECT file_id, SUM(DECODE(bytes,NULL,0,bytes)) used_bytes
      FROM dba_extents GROUP by file_id) E,
     (SELECT MAX(bytes) free_bytes, file_id
      FROM dba_free_space    GROUP BY file_id) f
WHERE e.file_id (+) = df.file_id AND df.file_id  = f.file_id (+)
ORDER BY df.tablespace_name,df.file_name;
--ORDER BY f.free_bytes;
