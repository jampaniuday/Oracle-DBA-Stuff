select substr(lf.member,1,instr(lf.member,'/',1,2)-1) "Redo Logs",sum(l.bytes)/1024/1024 "Size(m)"
from v$log l, v$logfile lf
where l.group#=lf.group#
group by substr(lf.member,1,instr(lf.member,'/',1,2)-1);

select substr(lf.member,1,instr(lf.member,'/ORACLE',1,1)-1) "Redo Logs",sum(l.bytes)/1024/1024 "Size(m)"
from v$log l, v$logfile lf
where l.group#=lf.group#
group by substr(lf.member,1,instr(lf.member,'/ORACLE',1,1)-1);
