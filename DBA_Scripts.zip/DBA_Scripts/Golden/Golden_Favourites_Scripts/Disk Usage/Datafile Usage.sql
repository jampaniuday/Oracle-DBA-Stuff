SELECT db.name "Database",
       ts.name "TableSpace",
       substr(vf.name,1,instr(vf.name,'/',instr(vf.name,'/u',1,1),2)-1) "Mount Point",
       vf.name "File",
       f.blocks*ts.blocksize/1024/1024 "Size(m)",
       nvl(ceil(e.used_blocks*ts.blocksize/1024/1024),0) "Used(m)",
       nvl(floor(fb.free_blocks*ts.blocksize/1024/1024),0) "Free(m)",
       nvl(ceil((fb.first_block_abovehwm-1)*ts.blocksize/1024/1024),
           ceil(e.used_blocks*ts.blocksize/1024/1024)) "HWM(m)",
       nvl(floor((f.blocks-fb.first_block_abovehwm+1)*ts.blocksize/1024/1024),0) "AboveHWM(m)"
from sys.file$ f, sys.ts$ ts, sys.v_$dbfile vf,
     (select decode(max(block#),2,1,max(block#)) first_block_abovehwm,
      decode(max(block#),2,sum(length)+1,sum(length)) free_blocks, file# file#
      from sys.fet$ group by file#) fb,
     (select file#, sum(length) used_blocks from sys.uet$ group by file#) E,
     v$database db
where f.ts# = ts.ts#
  and vf.file# = f.file#
  and e.file# (+) = f.file#
  and f.file# = fb.file#(+)
ORDER BY ts.name,vf.file#;
