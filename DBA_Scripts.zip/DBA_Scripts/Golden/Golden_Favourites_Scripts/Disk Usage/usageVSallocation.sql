select d.tablespace_name "Tablespace",sum(d.bytes)/1024/1024 "Allocated(m)",
nvl(round(sum(s.bytes)/1024/1024),0) "Used(m)"
from dba_segments s,dba_data_files d
where d.tablespace_name=s.tablespace_name(+)
group by d.tablespace_name
