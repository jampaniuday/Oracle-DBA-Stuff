select substr(file_name,1,instr(file_name,'/',instr(file_name,'/u',1,1),2)-1) "Mount Point",tablespace_name "TableSpace",sum(bytes)/1024/1024 "MB Used"
from dba_data_files
group by substr(file_name,1,instr(file_name,'/',instr(file_name,'/u',1,1),2)-1),tablespace_name
