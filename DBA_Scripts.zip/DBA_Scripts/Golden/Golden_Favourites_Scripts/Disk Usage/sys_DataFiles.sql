connect sys
select file_id, fecrc_tim creation_date, dba.tablespace_name, file_name, bytes/1024/1024 "Size(m)"
from x$kccfe int, dba_data_files dba
where dba.file_id = int.indx + 1
--order by creation_date;
--order by dba.tablespace_name;
order by file_id desc;
