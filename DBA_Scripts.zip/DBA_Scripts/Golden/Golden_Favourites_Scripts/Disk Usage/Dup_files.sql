
select  substr(name,instr(name,'/',-1,1) + 1) file_name
from v$controlfile
group by substr(name,instr(name,'/',-1,1) + 1)
having count(*) > 1
union all
select  substr(member,instr(member,'/',-1,1) + 1) file_name
from v$logfile
group by substr(member,instr(member,'/',-1,1) + 1)
having count(*) > 1
union all
select  substr(file_name,instr(file_name,'/',-1,1) + 1) file_name
from dba_data_files
group by substr(file_name,instr(file_name,'/',-1,1) + 1)
having count(*) > 1;

