select tablespace_name "TableSpace",file_name "File",bytes/1024/1024 "Size(m)",file_id
from dba_data_files
--where tablespace_name=upper('ts_pco01_ix1gms_summary')
--where tablespace_name in (select distinct tablespace_name from dba_segments where segment_type='INDEX')
order by tablespace_name,substr(file_name,instr(file_name, '/', -1)+1 );
--order by file_id desc;
--order by file_name;
