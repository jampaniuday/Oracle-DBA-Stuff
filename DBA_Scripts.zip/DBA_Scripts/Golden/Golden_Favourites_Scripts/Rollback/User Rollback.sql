select r.name "Name",
       t.extents "Extents",
       round(t.rssize/1024/1024,0) "Size(m)",
       s.username "Oracle ID",
       s.sid "SID",
       s.serial# "Serial#",
       spid "OSPID",
       osuser "OS UserID",
       substr(machine,1,10) "Client",
       substr(s.program,1,20) "Program"
  from v$lock l, v$process p, v$rollname r, v$session s, v$rollstat t
  where p.addr (+) = s.paddr
    and r.usn = t.usn
    and l.sid = s.sid (+)
    and trunc(l.id1(+)/65536)=r.usn
    and l.type(+)='TX'
    and l.lmode(+)=6
   order by r.name;
