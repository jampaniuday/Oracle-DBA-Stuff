select r.name rname,
       rs.extents "RBS Extents",
       u.username,
       u.sid,
       t.used_ublk "RBS Blocks",
       t.start_uext "Starting Extent",
       t.log_io "Transaction I/O",
       t.start_time,
       sa.sql_text "SQL"
from v$rollname r
   , v$session u
   , v$transaction t
   , v$rollstat rs
   , v$sqlarea sa
where r.usn=t.xidusn(+)
  and u.taddr(+)=t.addr
  and rs.usn=r.usn
  and u.sql_address = sa.address(+)
order by r.name;
