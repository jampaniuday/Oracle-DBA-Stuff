select a.segment_name "Segment",
a.tablespace_name "Tablespace",
a.initial_extent/1024 "Init(K)",
a.next_extent/1024 "Next(K)",
a.min_extents "Min_Ext",
a.max_extents "Max_Ext",
--c.optsize/1024/1024 "Optimal(M)"
a.status "Status"
from dba_rollback_segs a,dba_segments b
where a.segment_name=b.segment_name
order by a.segment_name
