SELECT name,
extends,
wraps,
shrinks
FROM v$rollstat r,
v$rollname n
WHERE r.usn = n.usn;
