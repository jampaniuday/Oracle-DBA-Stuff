select  a.tablespace_name "Tablespace", a.segment_name "Segment",c.status "Status",
c.xacts "Trans", round(c.rssize/1024/1024,0) "Size(m)", c.extents "Extents",
a.initial_extent/1024 "Init(k)", a.next_extent/1024 "Next(k)", a.min_extents "Min_Ext",
a.max_extents "Max_Ext", c.optsize/1024/1024 "OPT(m)", round(c.hwmsize/1024/1024,0) "HWM(m)",
c.shrinks "Shrinks", c.wraps "Wraps", round(c.aveshrink/1024/1024,0) "AveShrinks(m)"
from dba_rollback_segs a,v$rollname b,v$rollstat c
where b.usn=c.usn
and a.segment_name=b.name;