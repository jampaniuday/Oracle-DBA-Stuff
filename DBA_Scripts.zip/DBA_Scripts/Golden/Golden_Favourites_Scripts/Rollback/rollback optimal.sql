SELECT segment_name,
optsize "Optimal"
FROM v$rollstat,
dba_rollback_segs
WHERE usn = segment_id;
