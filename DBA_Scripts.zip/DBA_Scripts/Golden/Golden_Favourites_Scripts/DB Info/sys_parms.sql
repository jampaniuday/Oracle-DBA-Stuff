connect sys
select 3 class, ksppinm name, ksppdesc description, ksppstvl value
  from sys.x$ksppi x, sys.x$ksppcv y
 where x.indx=y.indx
UNION
select 1 class, kviitag,kviidsc,to_char(kviival) from sys.x$kvii
UNION
select 2 class, kvittag,kvitdsc,to_char(kvitval) from sys.x$kvit
order by 1,2
