select instance_name "SID", host_name "Server",
version "Version", Startup_time "Started",
status "Status", archiver "Archiver",
logins "Logins", shutdown_pending "Shutting down?"
from v$instance;
