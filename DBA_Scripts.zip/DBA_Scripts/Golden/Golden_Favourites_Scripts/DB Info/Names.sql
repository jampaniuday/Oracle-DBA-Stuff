connect netman@g008p_shrdw001
select * from netman.onrs_region
order by name_p;
