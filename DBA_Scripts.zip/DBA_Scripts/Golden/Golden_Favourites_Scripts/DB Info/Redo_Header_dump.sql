alter session set events 'immediate trace name redohdr level 10';
