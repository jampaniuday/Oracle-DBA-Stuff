alter session set events 'immediate trace name controlf level 10';


