select l.group# "Group", l.thread# "Thread", l.Sequence# "Sequence",
       lf.member "Member", l.bytes/1024/1024 "Size(m)", l.archived "Archived",
       l.status "Status", l.first_change# "Low SCN", l.first_time "First Write"
from v$log l, v$logfile lf
where l.group#=lf.group#;
