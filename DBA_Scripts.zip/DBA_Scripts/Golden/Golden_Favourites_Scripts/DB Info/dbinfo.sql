select 'Database:' "Database Info",name "Value" from v$database
union all
select 'Version:',banner from v$version where rownum=1
union all
select 'Global Name:',global_name from global_name
union all
select 'Archive mode:',log_mode from v$database
union all
select 'SGA -- '||name||':',round(value/1024)||'k' from v$sga
union all
select 'Total SGA:',round(sum(value/1024/1024))||'m' from v$sga
union all
select distinct 'Redo Log Size:',bytes/1024/1024||'m' from v$log
union all
select 'Total RedoLogs:',to_char(count(*)) from v$logfile
union all
select 'Space used by Datafiles:',sum(bytes)/1024/1024||'m' from dba_data_files
union all
select 'Total of Segments:',round(sum(bytes)/1024/1024,0)||'m' from dba_segments
;
