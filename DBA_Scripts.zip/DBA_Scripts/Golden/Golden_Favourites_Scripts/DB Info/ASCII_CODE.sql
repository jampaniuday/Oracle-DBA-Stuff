select ascii('&character') from dual;
