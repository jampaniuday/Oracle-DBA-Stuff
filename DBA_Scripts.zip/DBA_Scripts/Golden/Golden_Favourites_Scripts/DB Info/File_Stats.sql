select substr(name,1,instr(name, '/', -1)-1 ) "Path", 
       substr(name,instr(name, '/', -1)+1 ) "FileName", 
       0 "Size(m)", 
       0 "Physical Reads", 
       0 "Physical Writes" 
  from v$controlfile 
UNION ALL
select substr(lgf.member,1,instr(lgf.member,'/', -1)-1) "Path", 
       substr(lgf.member,instr(lgf.member, '/', -1)+1 ) "FileName", 
       lg.bytes/1048576 "Size(m)", 
       0 "Physical Reads", 
       0 "Physical Writes" 
  from v$logfile lgf, v$log lg 
 where lgf.group# = lg.group# 
UNION ALL
select substr(name,1,instr(name, '/', -1)-1 ) "Path",   
       substr(name,instr(name, '/', -1)+1 )  "FileName", 
       bytes/1048576  "Size(m)", 
       phyrds "Physical Reads",  
       phywrts "Physical Writes" 
  from v$datafile df, v$filestat fs 
 where df.file# = fs.file#
 order by 5 desc