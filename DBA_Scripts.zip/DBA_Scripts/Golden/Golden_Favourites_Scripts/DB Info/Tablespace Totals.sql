select tablespace_name "TableSpace",round(sum(bytes)/1024/1024) "MB Allocated"
from dba_data_files
group by tablespace_name
