connect gim04@g008p_shrdw001
select * from gim04.gim04_backup_history
where sid=lower('&SID')
and server=lower('&Server')
order by stopped desc;
