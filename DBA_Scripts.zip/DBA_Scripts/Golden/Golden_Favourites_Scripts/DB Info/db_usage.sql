SELECT vd.name "Database", sum_files "Size (gb)", sum_segments + sum_overhead "Used (gb)"
FROM v$database vd,
     (select round(sum(df.bytes)/1024/1024/1024,0) sum_files from dba_data_files df),
     (select round(sum(ds.bytes)/1024/1024/1024,0) sum_segments from dba_segments ds
      where tablespace_name not in ('TEMP','RBS')),
     (select round(sum(dov.bytes)/1024/1024/1024,0) sum_overhead from dba_data_files dov
      where tablespace_name in ('TEMP','RBS'))
;
