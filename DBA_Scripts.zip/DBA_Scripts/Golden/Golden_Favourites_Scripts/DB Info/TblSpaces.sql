select TABLESPACE_NAME "TableSpace",round(INITIAL_EXTENT/1024,0) "Initial(k)",
round(NEXT_EXTENT/1024,0) "Next",MIN_EXTENTS "MinExt",MAX_EXTENTS "MaxExt",
PCT_INCREASE "PCTinc",STATUS "Status"
from dba_tablespaces
order by status, tablespace_name;
