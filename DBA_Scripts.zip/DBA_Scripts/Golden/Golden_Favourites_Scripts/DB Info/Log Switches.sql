select * from v$log_history
order by time desc;
