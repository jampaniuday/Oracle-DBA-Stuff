connect gim04@g008p_shrdw001
select * from gim04.gim04_instance
where sid like lower('&SID%')
and server like lower('&Server%')
order by sid,server;
