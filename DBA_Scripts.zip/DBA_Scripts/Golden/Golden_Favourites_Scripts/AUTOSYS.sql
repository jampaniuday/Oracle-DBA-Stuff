select  nvl(machine,' ') MACHINE,
nvl(job_name,' ') JOB_NAME, nvl(description,' ') DESCRIPTION,
decode(job_type,'f','file_watch','c','command','b','box','unknown') JOB_TYPE,
decode(b.status,1,'RUNNING',
3,'STARTING',
4,'SUCCESS',
5,'FAILURE',
6,'TERMINATED',
7,'ON_ICE',
8,'INACTIVE',
9,'ACTIVATED',
10,'RESTART',
11,'ON_HOLD',
12,'QUE_WAIT',
b.status) LAST_STATUS,
to_char(to_date('19691231200000','yyyymmddhh24miss')+(trunc(status_time/86400))
        +((status_time - (trunc(status_time/86400)*86400))/86400),'yyyy/mm/dd hh24:mi:ss') STATUS_TIME,
to_char(to_date('19691231200000','yyyymmddhh24miss')+(trunc(last_start/86400))
        +((last_start - (trunc(last_start/86400)*86400))/86400),'yyyy/mm/dd hh24:mi:ss') LAST_START,
to_char(to_date('19691231200000','yyyymmddhh24miss')+(trunc(last_end/86400))
        +((last_end - (trunc(last_end/86400)*86400))/86400),'yyyy/mm/dd hh24:mi:ss') LAST_END,
to_char(to_date('19691231200000','yyyymmddhh24miss')+(trunc(next_start/86400))
        +((next_start - (trunc(next_start/86400)*86400))/86400),'yyyy/mm/dd hh24:mi:ss') NEXT_START,
nvl(permission,' ') PERMISSION,
nvl(owner,' ') OWNER,
nvl(command,' ') COMMAND,
nvl(condition,' ') CONDITION,
nvl(days_of_week,' ') DAYS_OF_WEEK,
nvl(start_times,' ') START_TIMES,
nvl(start_mins,' ') START_MINS,
nvl(timezone,' ') TIMEZONE,
nvl(run_calendar,' ') RUN_CALENDAR,
nvl(watch_file,' ') WATCH_FILE,
a.joid, box_joid
from autosys.job a, autosys.job_status b, autosys.job2 c
where a.joid=b.joid
and a.joid=c.joid
and (machine in ('essdb002'))
order by machine,job_name

