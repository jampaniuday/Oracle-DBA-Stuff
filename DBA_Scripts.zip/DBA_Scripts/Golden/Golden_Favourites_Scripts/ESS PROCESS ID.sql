select spid, process from v$session , v$process where paddr=addr
and sid=&SID