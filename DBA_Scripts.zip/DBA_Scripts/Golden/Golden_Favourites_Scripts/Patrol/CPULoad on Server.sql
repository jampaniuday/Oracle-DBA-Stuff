SELECT
   /*+ index(p_history_data xpkp_history_data ) */ GIM03.P_NODES.NODE_NAME "Server",
   /*+ index(p_history_data xpkp_history_data ) */ to_date(to_char(GIM03.P_HISTORY_DATA.TIME_STAMP,'DD-MON-YYYY'),'DD-MON-YYYY') "Day",
   /*+ index(p_history_data xpkp_history_data ) */ to_number(to_char(GIM03.P_HISTORY_DATA.TIME_STAMP,'HH24')) "Hour",
   /*+ index(p_history_data xpkp_history_data ) */ round(avg(GIM03.P_HISTORY_DATA.VALUE),2) "CPULoad"
FROM
  GIM03.P_NODES,
  GIM03.P_HISTORY_DATA,
  GIM03.P_PARAMETERS,
  GIM03.P_HISTORY,
  GIM03.P_APPS
WHERE
  ( GIM03.P_HISTORY_DATA.HISTORY_ID=GIM03.P_HISTORY.HISTORY_ID  )
  AND  ( GIM03.P_APPS.APP_ID=GIM03.P_HISTORY.APP_ID  )
  AND  ( GIM03.P_NODES.NODE_ID=GIM03.P_APPS.NODE_ID  )
  AND  ( GIM03.P_HISTORY_DATA.PARAMETER_ID=GIM03.P_PARAMETERS.PARAMETER_ID  )
  AND  (
   /*+ index(p_history_data xpkp_history_data ) */ GIM03.P_NODES.NODE_NAME  =  '&Server'
  AND   /*+ index(p_history_data xpkp_history_data ) */ GIM03.P_PARAMETERS.PARAMETER_NAME  =  'CPULoad'
  AND   /*+ index(p_history_data xpkp_history_data ) */ to_date(to_char(GIM03.P_HISTORY_DATA.TIME_STAMP,'DD-MON-YYYY'),'DD-MON-YYYY')  >=  to_date('&Start_Date','MM/DD/YYYY')
  )
GROUP BY
   /*+ index(p_history_data xpkp_history_data ) */ GIM03.P_NODES.NODE_NAME, 
   /*+ index(p_history_data xpkp_history_data ) */ to_date(to_char(GIM03.P_HISTORY_DATA.TIME_STAMP,'DD-MON-YYYY'),'DD-MON-YYYY'), 
   /*+ index(p_history_data xpkp_history_data ) */ to_number(to_char(GIM03.P_HISTORY_DATA.TIME_STAMP,'HH24'))
ORDER BY
  2, 
  3;
