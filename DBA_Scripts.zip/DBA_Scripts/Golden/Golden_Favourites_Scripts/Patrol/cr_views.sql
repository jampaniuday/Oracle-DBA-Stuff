create or replace view v$bh as
select DBAFIL                     file#,
       DBABLK                    block#,
       decode(state, 0, 'FREE',       /* not currently is use */
                     1, 'XCUR',       /* held exclusive by this instance */
                     2, 'SCUR',       /* held shared by this instance */
                     3, 'CR',         /* only valid for consistent read */
                     4, 'READ',       /* is being read from disk */
                     5, 'MREC',       /* in media recovery mode */
                     6, 'IREC')       /* in instance (crash) recovery mode*/
	     status,
         x_to_null                xnc, /* count of ping outs */
         le_addr                  lock_element_addr
         from x$bh;

grant select on v$bh to patrol;

