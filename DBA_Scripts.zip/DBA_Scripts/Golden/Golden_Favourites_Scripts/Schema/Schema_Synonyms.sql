select do.owner "Object Owner",do.object_name "Object_name",
       do.object_id "ObjectID", do.object_type "Type",
       ds.owner "Synonym Owner", ds.synonym_name "Synonym"
from dba_objects do, dba_synonyms ds
where do.owner=ds.table_owner(+)
and do.object_name=ds.table_name(+)
and do.owner=upper('&USER')
and do.object_type in ('PACKAGE','PROCEDURE','FUNCTION','TABLE','VIEW','SEQUENCE')
order by 1,2;
