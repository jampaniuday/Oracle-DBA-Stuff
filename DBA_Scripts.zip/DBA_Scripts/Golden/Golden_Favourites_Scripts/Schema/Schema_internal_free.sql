declare
v_segment_owner                    varchar2( 30 ) := upper('&OWNER');
v_segment_name                     varchar2( 81 ) := upper('&Segment');
v_segment_type                     varchar2( 17 ) := upper('&Type');
v_total_blocks                     number         := 0;
v_total_bytes                      number         := 0;
v_unused_blocks                    number         := 0;
v_unused_bytes                     number         := 0;
v_last_used_extent_file_id         number         := 0;
v_last_used_extent_block_id        number         := 0;
v_last_used_block                  number         := 0;  
cursor c
BEGIN
sys.dbms_space.unused_space( v_segment_owner , v_segment_name , v_segment_type ,
                         v_total_blocks , v_total_bytes ,
                         v_unused_blocks , v_unused_bytes , v_last_used_extent_file_id ,
                         v_last_used_extent_block_id , v_last_used_block );
dbms_output.put_line('*****');
dbms_output.put_line('Total Blocks: ' || v_total_blocks);
dbms_output.put_line('Total Bytes: '  || v_total_bytes);
dbms_output.put_line('Total Unused Blocks: ' || v_unused_blocks);
dbms_output.put_line('Total Unused Bytes: ' || v_unused_bytes);
END;
/
