select * from dba_objects
where owner=upper('&Schema')
order by object_type, object_name;
