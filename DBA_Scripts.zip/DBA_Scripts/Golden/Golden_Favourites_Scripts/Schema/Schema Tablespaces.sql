select distinct tablespace_name from dba_segments
where owner like upper('&Schema') and segment_type in ('TABLE','INDEX');