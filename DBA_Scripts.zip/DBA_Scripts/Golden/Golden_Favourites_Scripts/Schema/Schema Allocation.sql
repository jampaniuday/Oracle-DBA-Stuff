select round(sum(bytes)/1024/1024) "MB Allocated"
from dba_data_files
where tablespace_name in (select distinct tablespace_name from dba_segments
                          where owner like upper('&Schema') and segment_type in ('TABLE','INDEX'));
