select username "User",tablespace_name "TableSpace",round(bytes/1024/1024) "Used(m)",
decode(max_bytes,-1,'UNLIMITED',max_bytes/1024) "Quota(k)"
from DBA_TS_QUOTAS
order by username,tablespace_name;
