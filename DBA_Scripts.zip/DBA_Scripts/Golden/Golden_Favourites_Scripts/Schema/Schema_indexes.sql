select dba_indexes.table_name,dba_indexes.index_name,
       uniqueness
from dba_indexes
where owner=upper('&USER')
order by dba_indexes.table_name,dba_indexes.index_name;
