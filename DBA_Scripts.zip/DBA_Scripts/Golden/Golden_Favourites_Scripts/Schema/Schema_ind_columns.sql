select dba_indexes.index_name,dba_indexes.table_name,
       uniqueness,column_name,dba_ind_columns.column_position 
from dba_indexes,dba_ind_columns 
where dba_indexes.index_name=dba_ind_columns.index_name
and owner=upper('&USER') 
order by dba_indexes.table_name,dba_indexes.index_name,dba_ind_columns.column_position;
