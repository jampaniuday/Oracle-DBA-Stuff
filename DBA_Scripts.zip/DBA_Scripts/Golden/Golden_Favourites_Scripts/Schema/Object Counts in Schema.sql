select object_type,count(*) from dba_objects
where owner=upper('&Schema')
group by object_type;
