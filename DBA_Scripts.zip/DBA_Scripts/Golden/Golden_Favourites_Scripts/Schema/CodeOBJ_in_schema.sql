select * 
from dba_objects
where object_type in ('PACKAGE','PROCEDURE','FUNCTION','TRIGGER')
AND owner=upper('&SCHEMA')
order by object_type,object_name;
