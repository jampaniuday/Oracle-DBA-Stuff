select vd.name,upper('&Schema') "Schema", fs.file_sum "File Sum (mb)",ts.temp_sum "TEMP Sum",
       rs.rbs_sum "Rollback Sum"
from (select round(sum(df.bytes/1024/1024),0) file_sum
      from dba_data_files df where lower(file_name) like lower('%&Schema%')) fs,
     v$database vd,
     (select sum(df.bytes/1024/1024) temp_sum
      from dba_data_files df where tablespace_name='TEMP') ts,
     (select sum(df.bytes/1024/1024) rbs_sum
      from dba_data_files df where tablespace_name='RBS') rs;

undefine schema
