select owner, table_name, tablespace_name, num_rows, blocks, empty_blocks, avg_space, 
       chain_cnt, avg_row_len
from dba_tables
where table_name in (
  'GSR01_PURCHASING_PO_ITEM',
  'GSR01_PURCHASING_PO_HEADER',
  'GSR01_PURCHASING_PO_DESCRIPT',
  'GSR01_PURCHASING_VENDOR',
  'GSR01_PURCHASING_RECEIPTS',
  'GSR01_PURCHASING_VEND_BUY');
