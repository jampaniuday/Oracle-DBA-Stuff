select * from dba_ind_columns
where index_name in
  (select constraint_name from dba_constraints
   where owner=upper('&Owner')
   and constraint_type='P')
order by table_owner,table_name,column_position;
