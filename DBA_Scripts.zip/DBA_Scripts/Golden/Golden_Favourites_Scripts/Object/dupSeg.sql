col owner format a15
col Segment format a30
col tablespace format a30
col type format a10

select a.owner "Owner",a.SEGMENT_NAME "Segment",a.tablespace_name "TableSpace",
a.SEGMENT_TYPE "Type",a.BYTES/1024/1024 "Allocated(m)",a.EXTENTS "Extents",a.NEXT_EXTENT "Next"
from dba_segments a
where a.segment_name=(select b.segment_name from dba_segments b
			where a.segment_name=b.segment_name
			group by b.segment_name
			having count(*)>1)
order by a.SEGMENT_NAME;
