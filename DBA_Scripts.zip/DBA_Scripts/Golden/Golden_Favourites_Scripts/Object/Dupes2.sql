select count(distinct INDEXCOLUMNS),INDEXCOLUMNS
from TABLE
group by INDEXCOLUMNS
order by 1 desc;
