SELECT DECODE(referenced_type, 'NON-EXISTENT', '.....', referenced_type) Type
, referenced_owner,referenced_name Object, name referenced_by, owner, type,
' Referenced Link: ' || DECODE(referenced_link_name, null, 'none', referenced_link_name) r_link
FROM sys.dba_dependencies
WHERE owner = upper('&Schema')
ORDER BY 1,2,3;
