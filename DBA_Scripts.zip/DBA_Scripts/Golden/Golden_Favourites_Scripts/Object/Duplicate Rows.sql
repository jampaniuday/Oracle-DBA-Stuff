SELECT * FROM &table_name
     WHERE ROWID NOT IN (SELECT MIN (ROWID)
                       FROM &table_name
                      GROUP BY &column_list
                     HAVING COUNT (*) > 1);
