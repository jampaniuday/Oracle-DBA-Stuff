SELECT * FROM DBA_SOURCE
WHERE NAME=upper('&Name')
order by type,line;
