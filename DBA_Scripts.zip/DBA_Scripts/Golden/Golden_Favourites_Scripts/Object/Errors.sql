select * from dba_errors where owner='PATROL';
--select * from dba_source where name='P$UTIL';
---select * from dba_objects where object_name='P$EXTENT_MAP';
