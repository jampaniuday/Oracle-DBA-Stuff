select v.owner,v.view_name,v.text_length,v.text from dba_views v,dba_objects o
where v.view_name=o.object_name
and o.status='INVALID'
and v.owner not in ('PATROL');