col owner format a10
col Segment format a25
col tablespace format a25
col type format a10

select a.owner "Owner",a.SEGMENT_NAME "Segment",a.tablespace_name "TableSpace",
a.SEGMENT_TYPE "Type",a.BYTES/1024/1024 "Allocated(m)"
from dba_segments a
where a.segment_name=(select b.segment_name from dba_segments b
			where a.segment_name=b.segment_name
			group by b.segment_name
			having count(*)>1)
order by a.SEGMENT_NAME;
