select * from dba_objects
where object_name in (select name from dba_dependencies 
where referenced_name=upper('&Object_Name'))
order by 6 desc,4;
