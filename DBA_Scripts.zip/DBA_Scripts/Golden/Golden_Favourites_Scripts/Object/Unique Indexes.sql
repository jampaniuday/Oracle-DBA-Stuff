select index_name,column_name,column_position from all_ind_columns where table_name in
				(select table_name from all_indexes
				 where owner=upper('&Owner') and table_name=upper('&TableName') and uniqueness='UNIQUE')
				 order by index_name,column_position;
