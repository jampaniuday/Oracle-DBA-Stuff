select ds.OWNER "Schema",ds.SEGMENT_NAME "Segment",ds.SEGMENT_TYPE "Type",
ds.BYTES/1024 "Allocated(k)",ds.EXTENTS "Extents",ds.INITIAL_EXTENT/1024 "Initial(k)",
ds.NEXT_EXTENT/1024 "Next(k)",ds.PCT_INCREASE "PCTincr"
from dba_segments ds
where ds.segment_name in
  (select table_name from dba_constraints dc
   where dc.constraint_type='P')
and ds.owner=upper('&Owner');
