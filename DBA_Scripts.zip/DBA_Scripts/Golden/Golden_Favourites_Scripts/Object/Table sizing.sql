select dt.owner,dt.TABLE_NAME,dt.NUM_ROWS,dt.AVG_ROW_LEN,dt.pct_free,dt.ini_trans,
       dt.TABLESPACE_NAME,ds.bytes/1024 "SIZE (k)", ds.extents,
       ds.INITIAL_EXTENT/1024 "Initial(k)", ds.NEXT_EXTENT/1024 "Next(k)",ds.PCT_INCREASE "PCTincr",
       dt.BLOCKS,dt.EMPTY_BLOCKS,dt.AVG_SPACE
from dba_tables dt, dba_segments ds
where dt.table_name=ds.segment_name
and dt.tablespace_name=upper('&TableSpace')
order by 1,2;
