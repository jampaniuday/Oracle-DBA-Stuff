select * from dba_objects where object_name=upper('&Object');
