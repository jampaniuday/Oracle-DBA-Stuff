select * from dba_objects
where object_name in (select SEGMENT_NAME
                      from dba_segments
                      where tablespace_name=upper('&TableSpace'))
order by object_type;
--order by object_name;
