SELECT name,owner,object_name,object_type,do.created FROM dba_objects do,v$database db
WHERE status = 'INVALID'
order by owner,object_name,object_type;

