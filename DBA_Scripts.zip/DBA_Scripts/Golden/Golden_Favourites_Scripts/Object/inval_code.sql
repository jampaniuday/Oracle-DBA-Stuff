select S.OWNER,S.NAME,S.TYPE,S.LINE,S.TEXT from dba_source s,dba_objects o
where s.name=o.object_name
and o.status='INVALID'
and s.owner not in ('PATROL');