select 'kill -9 '||p.spid
from v$session s,v$process p
where S.PADDR = P.ADDR
-- and s.status='INACTIVE'
and s.username='SYSTEM'
