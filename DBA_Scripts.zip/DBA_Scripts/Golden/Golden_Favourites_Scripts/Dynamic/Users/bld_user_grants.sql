select username "User",'1' "Item", 'CREATE USER '||username||' IDENTIFIED BY '||username||
       ' DEFAULT TABLESPACE '||default_tablespace||
       ' TEMPORARY TABLESPACE '||temporary_tablespace||';' "Statement"
from dba_users
where username like upper('%&&user')
union
select upper('&&user') "User",'2' "Item", 'GRANT ' "Priv/Role" from dual
union
select grantee "User",'3' "Item",granted_role "Priv/Role" from DBA_ROLE_PRIVS
where grantee not in (select role from dba_roles)
and grantee like upper('%&&user')and rownum<2
union
select grantee "User",'4' "Item",','||granted_role "Priv/Role" from DBA_ROLE_PRIVS
where grantee not in (select role from dba_roles)
and grantee like upper('%&&user')
union
select grantee "User",'5' "Item",','||privilege "Priv/Role" from DBA_SYS_PRIVS
where grantee not in (select role from dba_roles)
and grantee like upper('%&&user')
union
select '&&user' "User",'6' "Item", 'to &&user;' "Statement" from dual
order by 1,2;
undefine user
