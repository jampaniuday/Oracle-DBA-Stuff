select username "OldUser",'1' "Item", 'CREATE USER &&NewUser IDENTIFIED BY &&NewUser DEFAULT TABLESPACE '
       ||default_tablespace||
       ' TEMPORARY TABLESPACE '||temporary_tablespace||';' "Statement"
from dba_users
where username like upper('%&&OldUser')
union
select upper('&&OldUser') "OldUser",'2' "Item", 'GRANT ' "Priv/Role" from dual
union
select grantee "OldUser",'3' "Item",granted_role "Priv/Role" from DBA_ROLE_PRIVS
where grantee not in (select role from dba_roles)
and grantee = upper('&&OldUser')and rownum<2
union
select grantee "OldUser",'4' "Item",','||granted_role "Priv/Role" from DBA_ROLE_PRIVS
where grantee not in (select role from dba_roles)
and grantee = upper('&&OldUser')
union
select grantee "OldUser",'5' "Item",','||privilege "Priv/Role" from DBA_SYS_PRIVS
where grantee not in (select role from dba_roles)
and grantee = upper('&&OldUser')
union
select upper('&&OldUser') "User",'6' "Item", 'to &&NewUser;' "Statement" from dual
union
select grantee "OldUser",'7' "Item",'GRANT '||privilege||' ON '||owner||'.'||table_name||' TO '||UPPER('&NewUser')||';'
from DBA_TAB_PRIVS
where grantee=UPPER('&OldUser')
order by 1,2;
undefine OldUser
undefine NewUser
