select 'alter system kill session '||CHR(39)||s.sid||','||s.serial#||CHR(39)||';'
from v$session s
where status='INACTIVE'
and username='&User'
