create user &userid identified by &userid
default tablespace users
temporary tablespace temp
quota unlimited on users;
grant create session, create synonym, hazems_access to &userid;
UPDATE hazems.KEYTABLE SET ID = ID + 1 WHERE NAME = 'UPROFILE';
INSERT INTO hazems.UPROFILE (USID, USERID, USERNAME, USDISABLED, USGROUP)
SELECT K.ID, '&userid', '&name', 'N', 'N'
FROM hazems.UPROFILE U, hazems.KEYTABLE K
WHERE K.NAME = 'UPROFILE' AND U.USERID = 'HAZEMS';