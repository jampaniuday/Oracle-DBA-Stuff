select 'FOR TABLESPACE '||tablespace_name||' USE remove='||chr(39)||file_name||chr(39)||' delete,' "Tablespace Action",
       substr(file_name,instr(file_name, '/', -1)+1 ),'remove'
from dba_data_files
where tablespace_name=upper('&&TableSpace')
union all
select 'FOR TABLESPACE '||tablespace_name||' USE resize='||chr(39)||file_name||chr(39)||' size 500m,',
       substr(file_name,instr(file_name, '/', -1)+1 ),'resize'
from dba_data_files
where tablespace_name=upper('&&TableSpace')
union all
select 'FOR TABLESPACE '||tablespace_name||' USE add='||chr(39)||file_name||chr(39)||' size 500m,',
       substr(file_name,instr(file_name, '/', -1)+1 ),'add'
from dba_data_files
where tablespace_name=upper('&&TableSpace')
order by 3,2,1;
undefine tablespace
