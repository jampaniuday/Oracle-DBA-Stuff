select 'CREATE TABLESPACE '||tablespace_name||chr(13)||chr(10)||chr(9)||
'datafile '||chr(39)||'/uxx/ORACLE/@/'||tablespace_name||
'_01.dbf'||chr(39)||' size '||round(sum(bytes)/1024/1024)||'m'||chr(13)||chr(10)||chr(9)||
'default storage(initial 40k next 40k minextents 1 maxextents 495 pctincrease 1);'||chr(13)||chr(10)
from dba_segments
where segment_type in ('TABLE','INDEX')
group by tablespace_name;
