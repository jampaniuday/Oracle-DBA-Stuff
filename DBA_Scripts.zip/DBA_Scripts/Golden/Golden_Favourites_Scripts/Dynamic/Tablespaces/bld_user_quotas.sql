select 'alter user &USER quota unlimited on '||tablespace_name||';'
from dba_tablespaces
order by tablespace_name;
