select a.tablespace_name "TSN", 0 "SEQ",
  'CREATE TABLESPACE ' || a.tablespace_name || '  DATAFILE' "TS_FILE"
  from sys.dba_data_files a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'
  group by a.tablespace_name, 0
union
select a.tablespace_name, 1,
  min('     ''' || a.file_name || ''''||' SIZE ' || a.bytes/1024/1024 || 'M')
  from sys.dba_data_files a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'
  group by
  a.tablespace_name, 1
union
select a.tablespace_name, 2,
  '    ,''' || a.file_name || '''' || ' SIZE ' || a.bytes/1024/1024 || 'M'
  from sys.dba_data_files a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'
  and (a.tablespace_name, a.file_name) not in
    (select b.tablespace_name, min(b.file_name)
      from sys.dba_data_files b
      group by b.tablespace_name)
union
select a.tablespace_name, 3,
  '    DEFAULT STORAGE  ('
  from sys.dba_tablespaces a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'
union
select a.tablespace_name, 4,
  '          initial          ' || initial_extent/1024 || 'K'
  from sys.dba_tablespaces a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'
union
select a.tablespace_name, 5,
  '          next             ' || next_extent/1024 || 'K'
  from sys.dba_tablespaces a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'
union
select a.tablespace_name, 6,
  '          minextents       ' || min_extents
  from sys.dba_tablespaces a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'
union
select a.tablespace_name, 7,
  '          maxextents       ' || max_extents
  from sys.dba_tablespaces a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'
union
select a.tablespace_name, 8,
  '          pctincrease      ' || pct_increase
  from sys.dba_tablespaces a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'
union
select a.tablespace_name, 9,
  '          );'
  from sys.dba_tablespaces a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'

union
select a.tablespace_name, 10,
  '----------------------------------------'
  from sys.dba_tablespaces a
  where a.tablespace_name <> 'SYSTEM'
  and   a.status <> 'INVALID'

order by 1,2,3;