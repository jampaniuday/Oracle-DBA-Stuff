-- bld_kill_db.sql
select 'cat /dev/null > '||name "Command" from v$controlfile union all
select 'cat /dev/null > '||member from v$logfile union all
select 'cat /dev/null > '||file_name from dba_data_files union all
select 'rm '||name from v$controlfile union all
select 'rm '||member from v$logfile union all
select 'rm '||file_name from dba_data_files
--where tablespace_name='TS_PCO01_IX1INVENTORY_TX';
