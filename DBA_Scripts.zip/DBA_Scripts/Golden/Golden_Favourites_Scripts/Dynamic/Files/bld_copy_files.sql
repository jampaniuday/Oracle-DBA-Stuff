select 'cp '||member||' '||substr(member,1,instr(member,'/',1,3))||
'p160d'||substr(member,instr(member,'/',-1))
from v$logfile
union all
select 'cp '||name||' '||substr(name,1,instr(name,'/',1,3))||
'p160d'||substr(name,instr(name,'/',-1))
from v$datafile
