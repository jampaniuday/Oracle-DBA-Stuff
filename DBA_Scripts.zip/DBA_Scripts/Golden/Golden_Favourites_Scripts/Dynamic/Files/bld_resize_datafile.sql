SELECT 'alter database datafile '||chr(39)||vf.name||chr(39)||' resize '||
       ceil((fb.first_block_abovehwm-1)*ts.blocksize/1024/1024)||'m;'
from sys.file$ f, sys.ts$ ts, sys.v_$dbfile vf,
     (select decode(max(block#),2,1,max(block#)) first_block_abovehwm,
      decode(max(block#),2,sum(length)+1,sum(length)) free_blocks, file# file#
      from sys.fet$ group by file#) fb,
     (select file#, sum(length) used_blocks from sys.uet$ group by file#) E,
     v$database db
where f.ts# = ts.ts#
  and vf.file# = f.file#
  and e.file# (+) = f.file#
  and f.file# = fb.file#(+)
--  and substr(vf.name,1,instr(vf.name,'/',instr(vf.name,'/u',1,1),2)-1) in ('/u110','/u111','/u112')
  and ts.name not in ('SYSTEM','RBS', 'TEMP', 'USERS', 'TOOLS')
ORDER BY ts.name,vf.file#;
