select 'uncompress -c \'||chr(13)||chr(10)||'/dbback/erp002/PROD/data/'||
substr(file_name,instr(file_name, '/', -1)+1 )||'.Z > \'||chr(13)||chr(10)||file_name||chr(13)||chr(10)
from dba_data_files
order by substr(file_name,instr(file_name, '/', -1)+1 );
