select 'ALTER DATABASE RENAME FILE '||CHR(39)||member||CHR(39)||' to '||
CHR(39)||substr(member,1,instr(member,'/',1,3))||'p160d'||substr(member,instr(member,'/',-1))||CHR(39)||';'
from v$logfile
union all
select 'ALTER DATABASE RENAME FILE '||CHR(39)||name||CHR(39)||' to '||
CHR(39)||substr(name,1,instr(name,'/',1,3))||'p160d'||substr(name,instr(name,'/',-1))||CHR(39)||';'
from v$datafile
