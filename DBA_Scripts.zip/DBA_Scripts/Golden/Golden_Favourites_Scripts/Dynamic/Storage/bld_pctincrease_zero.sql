select 'alter '||segment_type||' '||owner||'.'||segment_name||' storage(pctincrease 0);'
from DBA_SEGMENTS
where pct_increase>0
and owner not in ('SYS','SYSTEM','PATROL')
--and owner='GEMMS'
and segment_type in ('TABLE','INDEX')
order by segment_name;
