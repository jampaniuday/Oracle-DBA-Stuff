select 'alter '||segment_type||' '||owner||'.'||segment_name||' storage(maxextents 400);'
from dba_segments
where segment_type in ('TABLE','INDEX')
and owner not in ('SYS','SYSTEM','PATROL')
and max_extents<400
