select 'alter '||segment_type||' '||owner||'.'||segment_name||' storage(next '
||least(  101376,greatest(round(bytes/1024*.2),40))||'k);'
from DBA_SEGMENTS
where next_extent/1024<least(101376,greatest(round(bytes/1024*.2),40))
and owner not in ('SYSTEM','SYS','PATROL')
and segment_type in ('TABLE','INDEX')
order by bytes desc,segment_name;
