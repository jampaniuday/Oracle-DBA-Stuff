select 'alter '||segment_type||' '||owner||'.'||segment_name||' storage(next 256k);'
from DBA_SEGMENTS
where next_extent/1024<256
--and owner not in ('SYS','SYSTEM','PATROL')
and owner='GEMMS'
and segment_type in ('TABLE','INDEX')
order by segment_name desc;
