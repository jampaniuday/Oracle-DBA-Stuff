select 'AVG(NVL(VSIZE('||column_name||'),0))+' from dba_tab_columns
where owner=UPPER('&Owner') and table_name=UPPER('&Table');
