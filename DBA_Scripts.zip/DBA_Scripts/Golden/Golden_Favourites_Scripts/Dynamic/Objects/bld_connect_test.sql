select 'connect system/dragon34@'||connection_string||chr(13)||
'select vd.name "Database",banner "Current Version" from v$version,v$database vd where rownum=1;'
from GIM04_INSTANCE
where server in ('acdp017p','udpkb003','autog023p','ancdw002','shrdw001','shrdw002',
                 'udpkb010','sildw001','udpkb008','udpkb002');
