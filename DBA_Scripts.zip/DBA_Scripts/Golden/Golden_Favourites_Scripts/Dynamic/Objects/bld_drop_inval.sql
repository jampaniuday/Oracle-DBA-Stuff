SELECT 'drop '||decode(object_type, 'PACKAGE BODY', 'PACKAGE',object_type) || ' ' ||
owner||'.'||object_name||' ;'
      FROM dba_objects WHERE status = 'INVALID'
      and object_type in (  'PACKAGE',
                            'PACKAGE BODY',
                            'PROCEDURE',
                            'FUNCTION',
                            'VIEW',
                            'TRIGGER' )
--and owner=upper('&User')
;

