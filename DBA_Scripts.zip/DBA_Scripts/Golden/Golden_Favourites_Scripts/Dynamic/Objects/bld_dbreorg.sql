select 'for &object '||owner||'.'||segment_name||' USE TARGET_TS=&tablespace, initial='||round(bytes/1024)||'k, next='||round((bytes/1024)*.2)||'k;'
from dba_segments
where owner = upper('&owner')
and segment_type = upper('&object')
order by round(bytes/1024) desc;
