select 'CREATE PUBLIC SYNONYM '||object_name||' for '||owner||'.'||object_name||';'
from dba_objects where owner=upper('&Schema')
and object_type in ('TABLE','PACKAGE','FUNCTION','PROCEDURE','VIEW','SEQUENCE');
