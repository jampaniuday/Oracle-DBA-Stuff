select 'NOAUDIT SELECT, INSERT, UPDATE, DELETE ON '||owner||'.'||table_name||' BY SESSION;'
from dba_tables where owner=upper('&Schema');
