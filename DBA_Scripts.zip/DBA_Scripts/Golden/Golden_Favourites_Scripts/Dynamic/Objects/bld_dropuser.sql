select 'drop user '||username||' cascade;'
from dba_users
where username not in ('SYS','SYSTEM','PATROL');
