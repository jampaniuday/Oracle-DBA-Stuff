select a.segment_name "RSNOPRINT", 0 "SEQ",
  'CREATE ' || decode(owner,'PUBLIC',owner,' ') ||
  ' ROLLBACK SEGMENT ' || a.segment_name "RS_SEG",
  ' ' "SIZE"
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
union
select a.segment_name, 1,
  '   TABLESPACE ' || tablespace_name,
  ' ' "SIZE"
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
union
select a.segment_name, 2,
  '      STORAGE  (',
  ' '
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
union
select a.segment_name, 3,
  '          initial          ' || initial_extent/&&KILO || 'K',
  ' '
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
union
select a.segment_name, 4,
  '          next             ' || next_extent/1024 || 'K',
  ' '
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
union
select a.segment_name, 6,
  '          minextents       ' || min_extents,
  ' '
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
union
select a.segment_name, 7,
  '          maxextents       ' || max_extents,
  ' '
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
/* Don't know how to deal with optimal as yet ! This is a try */
   union
   select a.segment_name, 7.1,
     '          optimal          ' ||
     decode(c.optsize, NULL, initial_extent * min_extents/1024,
     c.optsize/1024) || 'K',
     ' '
     from sys.dba_rollback_segs a, sys.v_$rollname b, sys.v_$rollstat c
     where a.segment_name not in ('SYSTEM', 'R000')
     and   a.segment_name = b.name
     and   b.usn   = c.usn
union
select a.segment_name, 8,
  '          );',
  ' '
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
union
select a.segment_name, 9,
  'ALTER ROLLBACK SEGMENT ' || a.segment_name || ' ' ||
  status || ';', ' '
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
union

select a.segment_name, 11,
  '----------------------------------------', ' '
  from sys.dba_rollback_segs a
  where a.segment_name not in ('SYSTEM', 'R000')
order by 1,2,3
