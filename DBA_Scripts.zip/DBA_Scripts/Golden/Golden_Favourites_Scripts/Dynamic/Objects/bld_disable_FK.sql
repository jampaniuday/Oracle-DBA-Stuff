select 'alter table '||owner||'.'||table_name||' disable constraint '||constraint_name||';'
from dba_constraints where owner=upper('&Schema')
and constraint_type='R';
