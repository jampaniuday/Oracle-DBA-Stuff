select 'TRUNCATE TABLE '||owner||'.'||table_name||' drop storage;'
from dba_tables where owner=upper('&Schema');
