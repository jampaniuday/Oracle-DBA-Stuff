select 'select count(*) from '||owner||'.'||table_name||';'
from dba_tables
where owner=upper('&USER');
