select 'DROP TABLE '||owner||'.'||table_name||' CASCADE CONSTRAINTS;'
from dba_tables
where owner=upper('&Schema');
