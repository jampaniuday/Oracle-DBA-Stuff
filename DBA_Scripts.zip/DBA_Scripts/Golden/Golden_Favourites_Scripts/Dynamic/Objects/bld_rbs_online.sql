select segment_name,'alter rollback segment '||segment_name||' online;'
from dba_rollback_segs
where segment_name <> 'SYSTEM'
and status='OFFLINE'
