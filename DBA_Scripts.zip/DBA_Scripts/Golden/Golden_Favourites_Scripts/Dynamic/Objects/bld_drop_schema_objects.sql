select 'DROP '||decode(object_type, 'PACKAGE BODY', 'PACKAGE',object_type)||
       ' '||owner||'.'||object_name||
       decode(object_type,'TABLE',' CASCADE CONSTRAINTS;',';')
from dba_objects
where owner=upper('&Schema')
and object_type not in ('INDEX','PACKAGE BODY','TRIGGER');
