select segment_name,'alter rollback segment '||segment_name||' offline;'
from dba_rollback_segs
where segment_name <> 'SYSTEM'
and status='ONLINE'
union all
select segment_name,'drop rollback segment '||segment_name||';'
from dba_rollback_segs
where segment_name <> 'SYSTEM'
and status='ONLINE'
order by 1;
