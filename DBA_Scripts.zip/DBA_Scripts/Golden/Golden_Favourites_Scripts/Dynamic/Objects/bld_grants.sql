-- run generated script as schema owner
select owner||'_SEL' "Grantee" ,'TABLE' "Type",
       'GRANT SELECT ON '||table_name||' to '||owner||'_sel;' "Statement"
from dba_tables
where owner=upper('&&Schema')
union all
select owner||'_UPD' "Grantee" ,object_type,
       'GRANT SELECT,INSERT,UPDATE,DELETE ON '||object_name||' to '||owner||'_upd;'
from dba_objects
where owner=upper('&&Schema')
and object_type in ('TABLE','VIEW')
union all
select owner||'_UPD' "Grantee" ,object_type,
       'GRANT SELECT,ALTER ON '||object_name||' to '||owner||'_upd;'
from dba_objects
where owner=upper('&&Schema')
and object_type='SEQUENCE'
union all
select owner||'_UPD' "Grantee" ,object_type,
       'GRANT EXECUTE ON '||object_name||' to '||owner||'_upd;'
from dba_objects
where owner=upper('&&Schema')
and object_type in ('PROCEDURE','PACKAGE','FUNCTION')
order by 1,2,3;
undefine Schema
