select 1,'################'||chr(10)||'# Filename......: tnsnames.ora'||chr(10)||
         '# Comment.......: Generated from gim04.gim04_instance'||chr(10)||
         '# Date..........: '||sysdate||chr(10)||
         '################' entry
from dual
union all
select 2,gi.connection_string||'=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(COMMUNITY=gep.ge.com)'||
         chr(10)||' (PROTOCOL=TCP)(Host='||server||')(Port=1521)))(CONNECT_DATA=(SID='||
         sid||')))' Entry
from gim04.gim04_instance gi
where supported=1
order by 1,2;

