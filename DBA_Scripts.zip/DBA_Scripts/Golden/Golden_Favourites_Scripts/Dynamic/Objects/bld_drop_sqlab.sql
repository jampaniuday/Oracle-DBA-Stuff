SELECT 'DROP '||DECODE(OBJECT_TYPE,'SYNONYM',
                       DECODE(OWNER,'PUBLIC','PUBLIC SYNONYM ',OWNER||'.'),OBJECT_TYPE||' '||OWNER||'.')
                       ||OBJECT_NAME||';'
from dba_objects where object_name like 'SQLAB%';
