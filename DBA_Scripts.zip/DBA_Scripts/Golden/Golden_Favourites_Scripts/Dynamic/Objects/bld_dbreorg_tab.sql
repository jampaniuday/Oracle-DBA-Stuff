select 'for '||segment_type||' '||owner||'.'||segment_name||' USE TARGET_TS=&&tablespace, pctfree=5, initial='
||least(round(bytes/1024),510976)||'k, next='||least(round((bytes/1024)*.2),101376)||'k;'
from dba_segments
where tablespace_name=upper('&&TableSpace')
order by round(bytes/1024) desc;
undefine TableSpace
