select grantee "User",granted_role "Priv/Role" from DBA_ROLE_PRIVS
where grantee in (select role from dba_roles)
union all
select grantee "User",privilege "Priv/Role" from DBA_SYS_PRIVS
where grantee in (select role from dba_roles)
order by 1;
