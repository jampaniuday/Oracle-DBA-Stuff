select * from DBA_USERS
where username not between 'P000000' and 'P9ZZZZZ'
and username not in ('PATROL','SYS','SYSTEM','DBSNMP','DBMONITOR','DBADMIN','BOADM','DESKTOPDBA')
and username not like 'V0%'
order by username;
