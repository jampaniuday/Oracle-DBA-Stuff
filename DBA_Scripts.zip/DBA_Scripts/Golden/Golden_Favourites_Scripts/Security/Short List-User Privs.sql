select grantee "User",granted_role "Priv/Role" from DBA_ROLE_PRIVS
where grantee not in (select role from dba_roles)
and grantee not between 'P000000' and 'P9ZZZZZ'
and grantee not in ('PATROL','SYS','SYSTEM','DBSNMP','DBMONITOR','DBADMIN','BOADM','DESKTOPDBA')
and grantee not like 'V0%'
union all
select grantee "User",privilege "Priv/Role" from DBA_SYS_PRIVS
where grantee not in (select role from dba_roles)
and grantee not between 'P000000' and 'P9ZZZZZ'
and grantee not in ('PATROL','SYS','SYSTEM','DBSNMP','DBMONITOR','DBADMIN','BOADM','DESKTOPDBA')
and grantee not like 'V0%'
order by 1;
