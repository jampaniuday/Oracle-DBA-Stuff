select grantee "User",granted_role||',' "Priv/Role" from DBA_ROLE_PRIVS
where grantee not in (select role from dba_roles)
and grantee like upper('%&&user')
union all
select grantee "User",privilege||','
"Priv/Role" from DBA_SYS_PRIVS
where grantee not in (select role from dba_roles)
and grantee like upper('%&&user')
order by 1;
undefine user
