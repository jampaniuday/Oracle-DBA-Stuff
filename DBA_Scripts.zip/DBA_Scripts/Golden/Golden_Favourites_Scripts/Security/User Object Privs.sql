select grantee "User",privilege "Privilege",grantor "Owner", table_name "Table"
from DBA_TAB_PRIVS
where grantee=UPPER('&User')
order by table_name;
