select * from dba_users
order by username;