select grantee,owner,table_name object,privilege from dba_TAB_PRIVS
where grantee in (select role from dba_roles)
and grantee='&Role'
--and privilege='EXECUTE';
