select name,value
  from v$sysstat
 order by name
