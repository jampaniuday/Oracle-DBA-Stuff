select SEGMENT_NAME "Segment",TABLESPACE_NAME "TableSpace",SEGMENT_TYPE "Type",
BYTES/1024/1024 "Allocated(m)",EXTENTS "Extents",INITIAL_EXTENT/1024 "Initial(k)",
NEXT_EXTENT/1024 "Next(k)",MAX_EXTENTS "Max",PCT_INCREASE "PCTincr"
from dba_segments
where extents>=max_extents-20
and segment_type in ('TABLE','INDEX')
