select sa.buffer_gets,
       st.sql_text
  from v$sqlarea sa,
       v$sqltext st
 where st.address=sa.address
   and st.hash_value =sa.hash_value
 order by sa.buffer_gets desc ,sa.address,sa.hash_value,st.piece
