select  s.username         "User",
        s.OSUSER           "Opsy User",
        s.PROCESS          "PID",
        name               "Statistic",
        value              "Value"
        from    v$sesstat vs1,
                v$statname vs2,
                v$session vs3,
                v$session s,
                v$process p
        where   vs1.statistic#=vs2.statistic#
        and     vs3.sid=vs1.sid
        and     name like '%memory%'
        and     p.addr=s.paddr
        and     s.sid=vs1.sid
        order by s.sid;
