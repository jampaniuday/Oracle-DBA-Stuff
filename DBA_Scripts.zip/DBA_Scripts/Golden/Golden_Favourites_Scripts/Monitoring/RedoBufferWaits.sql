SELECT sum(value) "Redo Buffer Waits"
FROM v$sysstat
WHERE name = 'redo log space wait time'
