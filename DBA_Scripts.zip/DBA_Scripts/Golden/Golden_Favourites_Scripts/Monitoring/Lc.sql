select l.sid
   ,l.type "Tran Type"
   ,o.object_name "Object Name"
   ,decode(l.lmode,
           0,'NONE',
           1,'NULL',
           2,'Row-SELECT (SS)',
           3,'Row-X (SX)',
           4,'SHARE',
           5,'SELECT/Row-X (SSX)',
           6,'EXCLUSIVE') "Mode"
   ,l.request "Request"
   ,s.type "Type"
 from dba_objects o
   ,v$session s
   ,v$lock l
 where l.id1=o.object_id and
   s.sid=l.sid and
   l.type != 'MR'
 order by l.sid
