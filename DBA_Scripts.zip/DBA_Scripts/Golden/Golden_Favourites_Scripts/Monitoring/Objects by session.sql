select  a.sid "Session Number",
        s.username "User",
        a.owner "Owner",
        a.object "Object Being Accessed",
        decode(ob_typ, 0, 'NEXT OBJECT',
                       1, 'INDEX',
                       2, 'TABLE',
                       3, 'CLUSTER',
                       4, 'VIEW',
                       5, 'SYNONYM',
                       6, 'SEQUENCE',
                       7, 'PROCEDURE',
                       8, 'FUNCTION',
                       9, 'PACKAGE',
                       11, 'PACKAGE BODY',
                       12, 'TRIGGER',
                       'UNDEFINED') "Type"
from v$access a, v$session s
where a.sid = s.sid
order by a.sid,a.owner,a.object;
