prompt ****************************************************
prompt Hit Ratio Section
prompt ****************************************************
prompt
prompt  =========================
prompt  BUFFER HIT RATIO
prompt  =========================
prompt (should be > 70, else increase db_block_buffers in init.ora)
select a.value + b.value "logical_reads",
                c.value   "phys_reads",
                d.value   "phy_writes",
                round(100 * ((a.value+b.value)-c.value) /
(a.value+b.value))
                "BUFFER HIT RATIO"
from v$sysstat a, v$sysstat b, v$sysstat c, v$sysstat d
where
        a.statistic# = 37
and
        b.statistic# = 38
and
        c.statistic# = 39
and
        d.statistic# = 40;

prompt  =========================
prompt  DATA DICT HIT RATIO
prompt  =========================
prompt (should be higher than 90 else increase shared_pool_size in init.ora)

select sum(gets) "Data Dict. Gets",
      sum(getmisses) "Data Dict. cache misses",
      trunc((1-(sum(getmisses)/sum(gets)))*100)
      "DATA DICT CACHE HIT RATIO"
from v$rowcache;

prompt  =========================
prompt  LIBRARY CACHE MISS RATIO
prompt  =========================
prompt (If > .1, i.e., more than 1% of the pins resulted in reloads, then
prompt increase the shared_pool_size in init.ora)
prompt
select sum(pins) "executions", sum(reloads) "Cache misses while executing",
                (((sum(reloads)/sum(pins)))) "LIBRARY CACHE MISS RATIO"
from v$librarycache;

prompt  =========================
prompt  Library Cache Section
prompt  =========================
prompt hit ratio should be > 70, and pin ratio > 70 ...
prompt
select namespace, trunc(gethitratio * 100) "Hit ratio",
trunc(pinhitratio * 100) "pin hit ratio", reloads "reloads"
from v$librarycache;

prompt  =========================
prompt  REDO LOG BUFFER
prompt  =========================
prompt
select substr(name,1,30),
                value
from v$sysstat where name = 'redo log space requests';

select name, bytes from v$sgastat where name = 'free memory';

prompt ****************************************************
prompt SQL Summary Section
prompt ****************************************************
prompt
select sum(executions) "Tot SQL run since startup",
                sum(users_executing) "SQL executing now"
                from v$sqlarea;

prompt ****************************************************
prompt Latch Section
prompt ****************************************************
prompt if miss_ratio or immediate_miss_ratio > 1 then latch
prompt contention exists, decrease LOG_SMALL_ENTRY_MAX_SIZE in init.ora
prompt
select substr(l.name,1,30) name,
        (misses/(gets+.001))*100 "miss_ratio",
        (immediate_misses/(immediate_gets+.001))*100
        "immediate_miss_ratio"
        from v$latch l, v$latchname ln
where l.latch# = ln.latch#
        and (
        (misses/(gets+.001))*100 > .2
or
        (immediate_misses/(immediate_gets+.001))*100 > .2
)
order by l.name;

prompt ****************************************************
prompt Rollback Segment Section
prompt ****************************************************
prompt if any count below is > 1% of the total number of requests for data
prompt then more rollback segments are needed
select class, count
        from v$waitstat
where class in ('free list','system undo header','system undo block',
                        'undo header','undo block')
group by class,count;

select sum(value) "Tot # of Requests for Data" from v$sysstat where
name in ('db block gets', 'consistent gets');

prompt  =========================
prompt  ROLLBACK SEGMENT CONTENTION
prompt  =========================
prompt
prompt   If any ratio is > .01 then more rollback segments are needed

select name, waits, gets, waits/gets "Ratio"
        from v$rollstat a, v$rollname b
where a.usn = b.usn;

prompt ****************************************************
prompt Session Event Section
prompt ****************************************************
prompt if average-wait > 0 then contention exists
prompt
        select substr(event,1,30) event,
                total_waits, total_timeouts, average_wait
 from v$session_event
where average_wait > 0 ;



prompt ****************************************************
prompt Queue Section
prompt ****************************************************
prompt average wait for queues should be near zero ...
prompt
select paddr, type "Queue type", queued "# queued", wait, totalq,
decode(totalq,0,0,wait/totalq) "AVG WAIT" from v$queue;
