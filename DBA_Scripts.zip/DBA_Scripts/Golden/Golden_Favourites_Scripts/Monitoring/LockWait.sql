select b.username username,
       c.sid sid,
       c.owner object_owner,
       c.object object,
       c.type,
       b.lockwait,
       a.sql_text sql
from v$sqltext a, v$session b, v$access c
where
  a.address=b.sql_address and
  a.hash_value = b.sql_hash_value and
  b.sid = c.sid and
  c.owner != 'SYS'
order by c.sid,c.owner,c.object,a.piece
/
