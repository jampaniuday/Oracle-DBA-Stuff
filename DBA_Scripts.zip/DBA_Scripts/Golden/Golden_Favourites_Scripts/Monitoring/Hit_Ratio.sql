select 
SUM(DECODE(Name, 'consistent gets',Value,0)) Consistent,
SUM(DECODE(Name, 'db block gets',Value,0)) Dbblockgets,
SUM(DECODE(Name, 'physical reads',Value,0)) Physrds,
ROUND(((SUM(DECODE(Name, 'consistent gets', Value, 0))+
SUM(DECODE(Name, 'db block gets', Value, 0)) -
SUM(DECODE(Name, 'physical reads', Value, 0)) )/
(SUM(DECODE(Name, 'consistent gets',Value,0))+
SUM(DECODE(Name, 'db block gets', Value, 0)))) *100,2) Hitratio
from V$SYSSTAT;