select s.sid,
       s.serial#,
       s.username OraUser,
       s.osuser OSUser,
       s.process ClientPID,
       p.spid ServerPID,
       s.machine Machine,
       p.program "Cli Proc",
       s.program "Serv Proc",
       s.status,
       s.type
  from v$session s,
       v$process p
 where sid=&sid
   and s.paddr=p.addr;
select event "Waiting on",
       '         '||p1text||': '||p1||' '||p2text||': '||p2||' '
                  ||p3text||': '||p3 "Info"
  from v$session_wait
 where sid = &sid;

select sql_text
  from v$sqltext
 where (address,hash_value) =
       (select sql_address,sql_hash_value
          from v$session where sid=&sid)
 order by piece;

select consistent_gets "consistent gets",
       block_gets "db blk gets",
       physical_reads "Phys gets",
       round((((block_gets+consistent_gets-physical_reads)*100)/
                 (block_gets+consistent_gets)),2) "Hit Ratio",
       block_changes "Blk Changes",
       consistent_changes "Con Changes"
   from v$sess_io
 where sid=&sid;

select event,total_waits,time_waited,average_wait
  from v$session_event
 where sid=&sid
 order by average_wait desc;
select sn.name statistic,ss.value
  from v$sesstat ss,
       v$statname sn
 where ss.statistic#=sn.statistic#
   and ss.sid=&sid
 order by sn.name;
