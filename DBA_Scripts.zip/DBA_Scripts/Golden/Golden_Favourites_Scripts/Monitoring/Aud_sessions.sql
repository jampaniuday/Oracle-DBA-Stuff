--	sessions.sql
--	reports on the audit records for user connections.
--
select
	os_username "O/S User",        /*Operating system username used.*/
	username "User",               /*Oracle username of the account used.*/
	terminal "Terminal",           /*Terminal ID used.*/
	decode(returncode,'0','Connected',
			'1005','FailedNull',
			'1017','Failed',returncode) "Status",         /*Failure check*/
	to_char(timestamp,'DD-MON-YY HH24:MI:SS') "Login",    /*Login time*/
	to_char(logoff_time,'DD-MON-YY HH24:MI:SS') "Logoff"  /*Logoff time*/
from dba_audit_session;

