#!/bin/ksh
. $HOME/bin/$1
TARGET_SID=$1 
if [ ! -f $HOME/bin/$1 ];then
 echo "Target environment script not found in server"
 echo "Usage SCM_install.sh SID"
 echo "Script exiting"
 exit 1;
fi
HNAME="/`hostname | cut -c5-8`"
JAVA=`echo $JAVA_HOME`
if [  -z `grep JAVA_HOME $HOME/bin/$1` ]; then
echo "Setting env variable for SCM Installation"
echo "################## Added Parameters for SCM #################" >> $HOME/bin/$1
echo "JAVA_HOME=/$ORACLE_HOME/jdk" >> $HOME/bin/$1
echo "export JAVA_HOME" >> $HOME/bin/$1
fi 
if [  -z `grep ORACLE_CONFIG_HOME $HOME/bin/$1` ]; then
echo "Setting env variable for SCM Installation1"
echo "ORACLE_CONFIG_HOME=$HNAME/oracle/product/cfg/$TARGET_SID" >> $HOME/bin/$1
echo "export ORACLE_CONFIG_HOME" >> $HOME/bin/$1
fi

. $HOME/bin/$1

#if [ $JAVA_HOME = "/usr/java" ] 
#then 
#echo "JAVA_HOME  set : $JAVA_HOME "
#echo "Checking version for Java"
#java -version
#else
#echo "JAVA_HOME  not properly set.... Exiting Installation"
#exit 1;
#fi

if [ $ORACLE_CONFIG_HOME = "$HNAME/oracle/product/cfg/$TARGET_SID" ] ; then
echo "ORACLE_CONFIG_HOME set : $HNAME/oracle/product/cfg/$TARGET_SID "
mkdir -p $HNAME/oracle/product/cfg/$TARGET_SID
else 
echo "ORACLE_CONFIG_HOME not properly set... Exiting Installaton"
exit 1;
fi

echo "Istalling the configuration for $1"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
sleep 2;

$ORACLE_HOME/ccr/bin/configCCR -a -s -p cinext11.proxy.corporate.ge.com 2861153 nico.ciaschetti@ge.com US

echo "Disabling GE password verification function"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
sleep 2;

PSWD=`tellme system`
sqlplus -s system/$PSWD@$1 <<END
Begin
for profile in ( select unique profile from dba_profiles where profile != 'DEFAULT')
loop
execute immediate 'alter profile '|| profile.profile ||' LIMIT 	PASSWORD_VERIFY_FUNCTION default';
end loop;
END;
/
alter profile default limit password_verify_function null
/
exit;
END

echo "Instaling the collector software client for the instance"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
sleep 2;

$ORACLE_HOME/ccr/admin/scripts/installCCRSQL.sh collectconfig -s $TARGET_SID

echo "Executing automatic SCM update off"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
sleep 2;
$ORACLE_HOME/ccr/bin/emCCR automatic_update off

echo "Enabling GE password verification function"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
sleep 2;
sqlplus -s system/$PSWD@$1 <<END
Begin
for profile in ( select unique profile from dba_profiles )
loop
execute immediate 'alter profile '|| profile.profile ||' LIMIT PASSWORD_VERIFY_FUNCTION F_GE_PASSWORD_VERIFY';
end loop;
END;
/
exit;
END

echo "Scheduling the collection and upload for SCM, This may take a few mins..."
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
sleep 100;

$ORACLE_HOME/ccr/bin/emCCR collect
