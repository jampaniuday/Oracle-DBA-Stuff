#!/bin/ksh
##############################################################################
# utility.sh
#   Purpose: To submit all dba utilities included in control file, utility.ctl
#     that are scheduled to run for the current fiscal week and day.
#     The schedule day tested to determine if a utility is to be
#     executed is the fiscal week and day of the system date at
#     the scheduled start time of utility.sh unless overridden by a
#     mm/dd/yy input parameter.
#   Utility.ctl records are formatted as:
#     backup:wwwwwddddddd[:AlternateBackupCtl]
#         where w(fiscal week)=0(skip),1(run); d(day)=0(skip),c(cold),h(hot)
#     tape_copy:wwwwwddddddd:domain[:AltBackupCtl:AltMgmtClass]
#         where w(fiscal week)=0(skip),1(run); d(day)=0(skip),1(run)
#           domain=backup(to archive the Oracle backup and archive log dirs),
#                  export(to archive the Oracle export dir), or
#                  all   (to archive all of the above)
#     validate:wwwwwddddddd:SchemaName
#         where w(fiscal week)=0(skip),1(run); d(day)=0(skip),1(run)
#     statistics:wwwwwddddddd:SchemaName:%[:AlternateExceptionCtl]
#         where w(fiscal week)=0(skip),1(run); d(day)=0(skip),1(run);
#               %=100,0-30
#     YourScript:wwwwwddddddd[:YourParameter:...:YourParameter]
#   Usage:
#     $DBA_HOME/admin/utility.sh sid [ProcessDate] [ControlFile] [RecordRange]
#        > $DBA_HOME/audit/utility.audit 2>&1
#        where [ ] denotes optional parameters which can be input in any order
#        Defaults for optional parameters not supplied are:
#          ProcessDate = system date at the start time of utility.sh
#          ControlFile = $SID_HOME/admin/utility.ctl
#          RecordRange = all records in ControlFile will be considered for
#                        execution
#     Note: Add utility.audit to the purge.ctl file with a retention parameter
#       of 30 to automatically remove utility.sh audit trails after 30 days
#   Restart: The ProcessDate parameter (format mm/dd/yy) is provided to
#            override use of the system date on restart in cases where the
#            normal start time and restart time overlap midnight. Failure to
#            set the ProcessDate to the previous day would result in using
#            today's schedule day when you are actually
#            finishing yesterday's utility schedule.
#
#            The RecordRange parameter (format n-m) is provided to declare a
#            range of records to process within control file, utility.ctl.
#            A common use for this parameter would be to restart at the
#            abending utility within utility.ctl without reprocessing any
#            normally terminated utilities which preceed it. A RecordRange
#            of n- will process from record #n thru EOF (the dash is required
#            to identify this parameter as a RecordRange paramter);
#            a  RecordRange of n-n will only process record #n;
#            a RecordRange of n-m will process record #n thru record #m.
#
#            The ControlFile parameter is provided to override use of the
#            default utility.ctl file with an alternate control file that
#            must exist under the $SID_HOME/admin directory. Systems with two
#            distinct utility schedules such as a pre-batch and post-batch
#            process would require use of this parameter.
#
#            An alternative to command line input is provided via a fixed
#            parameter filename of $SID_HOME/admin/utility.restart. Any of
#            the optional parameter inputs (ProcessDate, ControlFile,
#            RecordRange but not sid) can be entered as one parameter per line
#            in this file. Utility.sh will use this file if it exists and
#            immediately delete it to avoid reuse. Parameter file input will
#            override any duplicate command line inputs. Systems where
#            scheduling is controlled by an external scheduling
#            product can use this feature to set script parameters without
#            the need to change the external scheduling environment.
#   Output:
#     $SID_HOME/audit/SidName[_SchemaName]_UtilityName.auditMMDD[_HHMMSS]
#        where MMDD is the month and day of ProcessDate
#          and the optional time extension is used only if a duplicate audit
#          trail exists as would be the case for restarts
#     Note: Add UtilityName.audit to the purge.ctl file with a retention
#        parameter of 30 to automatically remove UtilityName audit trails
#        after 30 days
#   Notification:
#     Output will always be emailed to the primary dba for the instance;
#     abends only for all instances will be emailed to the duty dba.
#     Control file, notify.ctl, will identify contacts with entries formatted
#     as follows:
#       ServerName:SidName||all:EmailName
#         where a SidName in field 2 will designate the primary DBA and the
#         constant, all, in field 2 will designate the duty DBA and where
#         EmailName should be the name used in the @corporate.ge.com address
#
#   Modifications:
#   Date        Name         Description
#   ----------  -----------  -------------------------------------------------
#   02/27/1998  S Kalkowski  Added a new utility for ccmgr for the Oracle HR
#                            Concurrent Manager start/stop/show script.
#
##############################################################################
utility_sid=$1
# Verify sid input
if [ -z "$utility_sid" ]
then
  echo "Error====>Required parameter is missing"
  echo "          Usage is utility.sh sid"
  echo "          Script is terminating!"
  exit 1
fi
# Set the instance environment
if [ ! -f $HOME/bin/$utility_sid ]
then
  echo "Error====>No environment script found for instance \"$utility_sid\""
  echo "          Script is terminating!"
  exit 1
fi
. $HOME/bin/$utility_sid
##############################################################################
# Process optional command line arguments which can include an alternate
# utility control file, a start and end utility control file record number
# (format n-m), and/or a processing date to override the system
# date(format mm/dd/yy). Optional parameters may be input in any order.
##############################################################################
if [ ! -z "$2" ]
then
  echo $2 | grep "-" >/dev/null
  if [ $? -eq 0 ]
  then
    record_parm=$2
  else
    echo $2 | grep "/" >/dev/null
    if [ $? -eq 0 ]
    then
      date_parm=$2
    else
      if [ -f $SID_HOME/admin/$2 ]
      then
        utility_ctl=$2
      else
        echo "Error====>Invalid command line argument \"$2\""
        echo "          Script is terminating!"
        exit 1
      fi
    fi
  fi
fi
if [ ! -z "$3" ]
then
  echo $3 | grep "-" >/dev/null
  if [ $? -eq 0 ]
  then
    record_parm=$3
  else
    echo $3 | grep "/" >/dev/null
    if [ $? -eq 0 ]
    then
      date_parm=$3
    else
      if [ -f $SID_HOME/admin/$3 ]
      then
        utility_ctl=$3
      else
        echo "Error====>Invalid command line argument \"$3\""
        echo "          Script is terminating!"
        exit 1
      fi
    fi
  fi
fi
if [ ! -z "$4" ]
then
  echo $4 | grep "-" >/dev/null
  if [ $? -eq 0 ]
  then
    record_parm=$4
  else
    echo $4 | grep "/" >/dev/null
    if [ $? -eq 0 ]
    then
      date_parm=$4
    else
      if [ -f $SID_HOME/admin/$4 ]
      then
        utility_ctl=$4
      else
        echo "Error====>Invalid command line argument \"$4\""
        echo "          Script is terminating!"
        exit 1
      fi
    fi
  fi
fi
##############################################################################
# Check for the existence of a utility.restart file and override any
# command line arguments with any parameter values it contains.
##############################################################################
if [ -f $SID_HOME/admin/utility.restart ]
then
  while read restart_parm
  do
    echo $restart_parm | grep "-" >/dev/null
    if [ $? -eq 0 ]
    then
      record_parm=$restart_parm
    else
      echo $restart_parm | grep "/" >/dev/null
      if [ $? -eq 0 ]
      then
        date_parm=$restart_parm
      else
        if [ -f $SID_HOME/admin/$restart_parm ]
        then
          utility_ctl=$restart_parm
        else
          echo "Error====>Invalid parameter file argument \"$restart_parm\""
          echo "          Script is terminating!"
          exit 1
        fi
      fi
    fi
  done <$SID_HOME/admin/utility.restart
fi
##############################################################################
# Remove the utility restart file to avoid reuse by the next production run
##############################################################################
rm $SID_HOME/admin/utility.restart >/dev/null 2>&1
##############################################################################
# Set script control variables to the input values extracted from the command
# line or from the restart parameter file or to the defaults if no parameter
# input was supplied.
##############################################################################
if [ -z "$utility_ctl" ]
then
  utility_ctl=utility.ctl
fi
if [ -z "$record_parm" ]
then
  start_record=1
  end_record=`cat $SID_HOME/admin/$utility_ctl | wc -l`
else
  start_record=`echo $record_parm | cut -d- -f1`
  end_record=`echo $record_parm | cut -d- -f2`
  if [ -z "$end_record" ]
  then
    end_record=`cat $SID_HOME/admin/$utility_ctl | wc -l`
  fi
fi
if [ -z "$date_parm" ]
then
  month=`date +%m`
  day=`date +%d`
  year=`date +%y`
else
  month=`echo $date_parm | cut -d/ -f1`
  day=`echo $date_parm | cut -d/ -f2`
  year=`echo $date_parm | cut -d/ -f3`
fi
##############################################################################
# Determine the fiscal week of the month and the day of the week
##############################################################################
export month day year
$DBA_HOME/admin/fiscal.sh
fiscal_week=`awk '{print $1}' $SID_HOME/audit/fiscal.out`
fiscal_day=`awk '{print $2}' $SID_HOME/audit/fiscal.out`
export fiscal_day
rm $SID_HOME/audit/fiscal.out
echo
echo "######################################################################"
echo "Utility.sh Processing Scope is:"
echo "  $utility_ctl records $start_record thru $end_record that are"
echo "  scheduled to execute on fiscal week $fiscal_week day $fiscal_day"
echo "######################################################################"
##############################################################################
# Loop over $utility_ctl
##############################################################################
charset=us-ascii; export charset
record_cnt=$start_record
#while read utility_line
while [ "$record_cnt" -ge "$start_record" -a "$record_cnt" -le "$end_record" ]
do
  utility_line=`sed -n "$record_cnt p" $SID_HOME/admin/$utility_ctl`
  record_cnt=`expr $record_cnt + 1`
  echo
  echo "######################################################################"
  echo "====>Processing $utility_ctl record: $utility_line"
  echo "######################################################################"
  utility_type=`echo $utility_line | cut -d: -f1`
  utility_dir=`dirname $utility_type`
  if [ "$utility_dir" = "." ]
  then
    # no directory in utility_type --- normal processing
    utility_dir=""
  else
    utility_dir="/${utility_dir}"
    utility_type=`basename $utility_type`
  fi
  if [ -z "$utility_type" ] || [ "`echo $utility_type | cut -c1`" = "#" ] || [ "`echo $utility_dir | cut -c2`" = "#" ]
  then
    continue
  fi
  utility_schedule=`echo $utility_line | cut -d: -f2`
  utility_parm3=`echo $utility_line | cut -d: -f3`
  sched_day=`expr $fiscal_day + 6`
  do_week=`echo $utility_schedule | cut -c$fiscal_week`
  do_day=`echo $utility_schedule | cut -c$sched_day`
  if [ "$do_week" = "0" -o "$do_day" = "0" ]
  then
    echo $utility_type utility is NOT SCHEDULED to run
    continue
  fi
  script_path=$DBA_HOME/admin${utility_dir}
  audit_path=$SID_HOME/audit
  begin_parms=$utility_sid
  if [ "$utility_type" = "backup" -o "$utility_type" = "test_backup" -o "$utility_type" = "backup_rman" ]
  then
    rm ${audit_path}/default.dir >/dev/null 2>&1
    script_name=$utility_type.sh
    if [ "$do_day" = "h" ]
    then
      begin_parms=${begin_parms}" hot"
    else
      if [ "$do_day" = "c" ]
      then
        begin_parms=${begin_parms}" cold"
      else
        if [ "$do_day" = "a" ]
        then
          begin_parms=${begin_parms}" arch"
        else
        echo "Error====>Invalid schedule for $utility_type utility"
        echo "          $utility_type will not be run"
        continue
        fi
      fi
    fi
  else
    case ${utility_type} in
        'validate'|'statistics') script_name=${utility_type}.sh ;;
        'export') script_name=${utility_type}.sh ;;
        'tape_copy') script_name=${utility_type}.sh ;;
        'tape_coldbackup') script_name=${utility_type}.sh ;;
        'ccmgr'|'oamgr_db') script_name=${utility_type}.sh ;;
        'psappmgr') script_name=${utility_type}.sh ;;
        'flushsharedpool') script_name=${utility_type}.sh ;;
        'db_csscan') script_name=${utility_type}.sh ;;
	'backup_rman') script_name=${utility_type}.sh ;;
        'tcopy_rman') script_name=${utility_type}.sh ;;
        *)
          if [ -x $SID_HOME/admin/$utility_type ]
          then
            script_path=$SID_HOME/admin
            script_name=${utility_type}
          else
            echo "Error====>Cannot locate script ${utility_type}"
            echo "          ${utility_type} will not be run"
            continue
          fi
          ;;
    esac
  fi
  script_parms=`echo "$utility_line" | \
  awk -v script_parms="$begin_parms" '{
  parm_cnt=split($0, parm, ":")
  for (i = 3; i <= parm_cnt; i++)
    if (parm[i] != "NotifyAlways" ) {
      {script_parms = script_parms " " parm[i]} }
  print script_parms
  }'`
  notify_always=`echo "$utility_line" |
    awk 'BEGIN{notify="false"}
      { parm_cnt=split($0, parm, ":")
        for (i = 3; i <= parm_cnt; i++)
          if (parm[i] == "NotifyAlways" ) {notify="true"}
        print notify
       }'`
# Set the audit filename where script output will be directed
  audit_name=`echo $script_name | awk '{
    if (substr($1,length($1)-2,length($1)) == ".sh") {
       print substr($1,1,length($1)-3)} else {print $1}}'`
  if [ "$utility_type" = "validate" -o "$utility_type" = "statistics" ]
  then
    utility_schema=`echo $utility_line | cut -d: -f3`
    audit_name=`echo ${utility_sid}_${utility_schema}_${audit_name}.audit`$month$day
  else
    audit_name=`echo ${utility_sid}_${audit_name}.audit`$month$day
  fi
  if [ -f $audit_path/$audit_name ]
  then
    audit_name=${audit_name}_`date +%H%M%S`
  fi
  echo
  echo "Submitting the following command line on " `date`
  echo "$script_path/$script_name $script_parms > $audit_path/$audit_name 2>&1"
  if [ `echo $utility_line | grep "^backup:"` ]
  then
    ctlfile=`echo "$utility_line" | cut -d: -f3`
    if [ -z $ctlfile ]
    then
      bkploc=`grep "DEFAULT" $SID_HOME/admin/backup.ctl |grep -v "PSDEFAULT"| cut -d: -f2`
    else
      bkploc=`grep "DEFAULT" $SID_HOME/admin/$ctlfile |grep -v "PSDEFAULT"| cut -d: -f2`
    fi
    echo "$audit_path/$audit_name" > $bkploc/backup_audit_file_name
  fi
  eval $script_path/$script_name $script_parms > $audit_path/$audit_name 2>&1
  script_return=$?
  if [ $script_return -eq 0 -o $script_return -eq 2 ]
  then
    echo "$script_name TERMINATED SUCCESSFULLY on " `date`
    if [ "$notify_always" = "true" ]; then
      #utility.ctl line included NotifyAlways
      $DBA_HOME/admin/notify.sh -s "$utility_type SUCCESS" -f ${audit_path}/${audit_name} -w sid
    fi
    if [ "`echo $APP|cut -c1-4`" = "cics" ]
    then
      if [ $utility_type = "backup" ]
      then
        process_state=`cat ${audit_path}/process_state`
        rm ${audit_path}/${process_state}_state*
        echo ${process_state}-batch backup is complete > ${audit_path}/${process_state}_state02
      else
        if [ $utility_type = "tape_copy" -a "$utility_parm3" != "export" ]
        then
          process_state=`cat ${audit_path}/process_state`
          rm ${audit_path}/${process_state}_state*
          echo ${process_state}-batch tape processing is complete > ${audit_path}/${process_state}_state04
          if [ "${process_state}" = "post" ]
          then
            if [ ! -f ${audit_path}/pre_state04 ]
            then
              rm ${audit_path}/pre_state*
              echo post-batch tape processing is complete > ${audit_path}/pre_state04
            fi
          fi
        fi
      fi
    fi
  else
    echo "$script_name TERMINATED ABNORMALLY on " `date`
    if [ "`echo $APP|cut -c1-4`" = "cics" ]
    then
      if [ $utility_type = "backup" ]
      then
        process_state=`cat ${audit_path}/process_state`
        rm ${audit_path}/${process_state}_state*
        echo ${process_state}-batch backup abended > ${audit_path}/${process_state}_state99
        rm $PATROL/$ORACLE_SID >/dev/null 2>&1
      else
        if [ $utility_type = "tape_copy" -a "$utility_parm3" != "export" ]
        then
          process_state=`cat ${audit_path}/process_state`
          rm ${audit_path}/${process_state}_state*
          echo ${process_state}-batch tape processing abended > ${audit_path}/${process_state}_state98
        fi
      fi
    fi
  fi
  #tape_process=`echo $utility_type|grep -c tape`
  tape_process=`echo $utility_type|egrep -c '(tape)|(tcopy)'`
  echo
#  echo "Script output will be emailed to the following DBAs:"

# Email the primary DBA, oncall DBA and server rep only if the script abended
# or produced warnings; always email backup and tape_copy script output to the
# primary DBA regardless of script termination status.
### Old Logic Without Notify.sh script Begin ###
#  oncall=`grep "all:all" $HOME/bin/notify.ctl | cut -d: -f3`
#  emailsw=1
#  egrep "^`hostname`:((all)|($utility_sid)):" $HOME/bin/notify.ctl | while read notify_line
#  #while read notify_line
#  do
#    notify_host=`echo $notify_line | cut -d: -f1`
#    notify_sid=`echo $notify_line | cut -d: -f2`
#    notify_who=`echo $notify_line | cut -d: -f3`
#    if [ "$notify_host" = "`hostname`" ]
#    then
#      if [ $script_return -ne 0 -a "$notify_sid" = "all" ]
#      then
#        notify_support=`echo $notify_line | cut -d: -f4`
#        grep "${notify_host}:${utility_sid}:${notify_who}" $HOME/bin/notify.ctl >/dev/null 2>&1
#        if [ $? -ne 0 ]
#        then
#          echo $notify_who
#          mailx -s "$notify_host $utility_sid $utility_type ABEND" $notify_who@corporate.ge.com < ${audit_path}/${audit_name}
#          if [ "$oncall" = "$notify_who" ]
#          then
#            emailsw=0
#          fi
#        fi
#      fi
#      if [ "$notify_sid" = "$utility_sid" ]
#      then
#        if [ $script_return -ne 0 ]
#        then
#          echo $notify_who
#          mailx -s "$notify_host $utility_sid $utility_type ABEND" $notify_who@corporate.ge.com < ${audit_path}/${audit_name}
#        else
#          #tape_process=0
#          #if [ "`echo $utility_type|grep tape`" ]
#          #then
#          #  tape_process=1
#          #fi
##          if [ "$utility_type" = "backup" -o "$tape_process" -eq 1 ]
#          then
#            echo $notify_who
#            mailx -s "$notify_host $utility_sid $utility_type" $notify_who@corporate.ge.com < ${audit_path}/${audit_name}
#          fi
#        fi
#        if [ "$oncall" = "$notify_who" ]
#        then
#          emailsw=0
#        fi
#      fi
#    fi
#  #done <$HOME/bin/notify.ctl
#  done
#  if [ $script_return -ne 0 ]
#  then
#    if [ ! -z "$oncall" ]
#    then
#      if [ "$notify_support" = "gold" -o "$notify_support" = "silver" ]
#      then
#        notify_pager=`grep "#$oncall" $HOME/bin/notify.ctl | cut -d: -f2`
#        if [ ! -z "$notify_pager" -a "$tape_process" -eq 0 ]
#        then
#          echo "`hostname`-$utility_sid\n$utility_type abended" | mailx $notify_pager
#        fi
#      fi
#      if [ $emailsw -eq 1 ]
#      then
#        echo $oncall
#        mailx -s "`hostname` $utility_sid $utility_type ABEND" $oncall@corporate.ge.com < ${audit_path}/${audit_name}
#      fi
#    fi
#  fi
### Old Logic Without Notify.sh script End ###

# Email the primary DBA, oncall DBA and server rep only if the script abended
# or produced warnings; always email backup and tape_copy script output to the
# primary DBA regardless of script termination status.
### New Logic With Notify.sh script Begin ###

if [ $script_return -ne 0 ]
then
   $DBA_HOME/admin/notify.sh -s "$utility_type ABEND" -f ${audit_path}/${audit_name} -w sid
   if [ $tape_process -eq 0 -o "$notify_always" = "true" ]
   then
      pagertext="$utility_type abended"
      if [ "$utility_type" = "backup"  -o "$utility_type" = "backup_rman" ]; then
         $DBA_HOME/admin/notify.sh -p "$pagertext" -w sid -L gold,silver,bronze
      else 
         $DBA_HOME/admin/notify.sh -p "$pagertext" -w sid
      fi
   fi
fi

### New Logic With Notify.sh script End ###

# Copy backup audit trails to the default backup directory
  if [ "$utility_type" = "backup" ] && [ -f ${audit_path}/default.dir ]
  then
    default_dir=`cat ${audit_path}/default.dir`
    rm $default_dir/${utility_sid}_backup.audit* >/dev/null 2>&1
    cp ${audit_path}/${utility_sid}_backup.audit$month$day* ${default_dir}
    rm ${audit_path}/default.dir
  fi
  if [ $script_return -ne 0 -a $script_return -ne 2 ]
  then
    error_switch=1
    echo
    # record_cnt was already incremented above, so subtract one to reflect
    # current record
    record_cnt=`expr $record_cnt - 1`
    echo "====>Utility processing suspended at record $record_cnt due to errors"
    break
  else
    error_switch=0
  fi
#done <$SID_HOME/admin/$utility_ctl
done
exit $error_switch
