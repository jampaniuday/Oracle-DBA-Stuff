#!/bin/ksh

# Created By: Satyen Jadia
# Created Date: November 25th 2003
# Purppose: Script to get database size
# Usage: dbsize


#oratab_loc=/var/opt/oracle/oratab
oratab_loc=/etc/oratab
audit_path=$DBA_HOME/audit
audit_file_name=`hostname`".dbsize"
echo "Database size report for Server `hostname`" > $audit_path/$audit_file_name
echo "--------------------------------------------" >> $audit_path/$audit_file_name
echo "" >> $audit_path/$audit_file_name
echo "DB Name	-	DB Size (GB)" >> $audit_path/$audit_file_name
echo "------------------------------" >> $audit_path/$audit_file_name

if [ ! -f $oratab_loc ]
then
  echo "Oratab file not found."
  exit 1
fi

while read oratab_line
do
  dbname=`echo $oratab_line| awk -F":" '{print $1}'`
  if [ ! -z "$dbname" ]
  then
  # Check database is up
  dbup=`ps -ef | grep "$dbname" | grep pmon | grep -v grep`
  if [ ! -z "$dbup" ]
  then
    # Check database environment file
    if [ ! -f $HOME/bin/$dbname ]
    then
      echo "Database environment file does not exists for $dbname."
    else
      # Setup environment & calculate space
      . $HOME/bin/$dbname
      # Get System Password
      syspswd=`$HOME/bin/tellme system`
      if [ ! -z "$syspswd" ]
      then
sqlplus -s system/$syspswd << EOF > $audit_path/ora.error
set heading off pages 0
set numf 9,999,999.99
spool $audit_path/dbsize.lst
select sum(bytes)/(1024*1024*1024) from dba_data_files;
spool off
exit
EOF
        err=`grep "$ORA-" $audit_path/ora.error`
        if [ ! -z "$err" ]
        then
          echo "Error selecting database size for $dbname." >> $audit_path/$audit_file_name
        else
          dbsize=`cat $audit_path/dbsize.lst`
          echo $dbname"	-	"$dbsize >> $audit_path/$audit_file_name
        fi
      else
        echo "Invalid system password for $dbname." >> $audit_path/$audit_file_name
      fi
    fi
  fi
  fi
done < $oratab_loc

exit 0
