#!/bin/ksh
##############################################################################
#                                               _
#                                              | |    
# ___  ___ _ __ ___    _ __ ___   __ _ _ __ ___| |__  
#/ __|/ __| '_ ` _ \  | '_ ` _ \ / _` | '__/ __| '_ \ 
#\__ \ (__| | | | | | | | | | | | (_| | | _\__ \ | | |
#|___/\___|_| |_| |_| |_| |_| |_|\__, |_|(_)___/_| |_|
#                 ______          __/ |               
#                |______|        |___/                
#
# scm_mgr.sh V. 0.1 by Jason Meller and Dave DeClercq
# ==================================================================
# Version 0.1 - Script created 
# =================================================================
# DESCRIPTION: Depending on it's usage this script involes the Oracle 
#              SCM collector agent for all servers defined in oratab as 
#              "Y"
#  
#
#       USAGE:
#		-s 
#               	Output SCM status of all instances 
#               -a [on/off]
#	                enable/disable automatic updates
#	        -u [patch_location zip file]
#                   	ie: /t227/oraaru/patch.zip
#		-v 
#			shows verbose output on all commands
#               -h
#                       shows usage information 
##############################################################################

scriptName=`basename $0`

###################################
# Define Functions                #
###################################

function usage { #print usage information
    echo "Usage: $scriptName [-s -v -a <on/off> -u <path to patch>]"
    echo "For more detail see $scriptName -h"   
}

function detailedUsage { #print info about flags
	 echo "Usage: $scriptName [-s -v -a <on/off> -u <path to patch>]"
	echo "
       USAGE:
               -s
                       Output SCM status of all instances
               -a [on/off]
                       enable/disable automatic updates
               -u [patch_location zip file]
                       ie: /t227/oraaru/patch.zip
               -v
                       shows verbose output on all commands
               -h
                       shows usage information"
}

function sysinfo { #Print out run-time information
	verbose ====================================
	verbose "Server: `hostname`"
	verbose "OS: `uname`"
	verbose "Date: `date`"
	verbose "Current User: `whoami`"
	verbose
}

function verbose { #only print info when V_FLAG is set TRUE
	if [ $V_FLAG = "TRUE" ] ; then
		echo $1
	fi
}

###################################
# Process Arguments               #
###################################

S_FLAG="FALSE"
A_FLAG="FALSE"
U_FLAG="FALSE"
V_FLAG="FALSE"

# Check for command line options. If none is found, show usage info
if [ -z $1 ];then
	usage
	exit 1;
fi


while getopts "sa:u:hv" OPTION
do
  case $OPTION in
      s )
           S_FLAG="TRUE"
           ;;
      a ) 
	   #check to see if "-a" flag has correct syntax
	   if [ $OPTARG = "on" -o $OPTARG = "off" ] ; then
		A_VALUE=$OPTARG
                A_FLAG="TRUE"
           else
		usage
		exit 1
	   fi
           ;;
      u ) 
	   if [ ! -f $OPTARG ] ; then
		echo "ERROR: Patch directory does not exist"
		exit 1
	   else
		   U_VALUE=$OPTARG
        	   U_FLAG="TRUE"
	   fi
           ;;
     v ) 
	   V_FLAG="TRUE"
	   ;;
	
     h )
	   detailedUsage
           exit 1
	   ;;
     * ) 
           usage
	   exit 1
           ;;
   esac
done


###################################
# Begin Script                    #
###################################

sysinfo
totalCount=0
badCount=0

###################################
# Determine Location of Oratab    #
###################################

if [ -f /etc/oratab ]; then
	ORATAB=/etc/oratab
	verbose "ORATAB found at /etc/oratab!"
elif [ -f /var/opt/oracle/oratab ]; then
	ORATAB=/var/opt/oracle/oratab
	echo "ORATAB found at /var/opt/oracle/oratab!"
else
	echo "ERROR: Could not find ORATAB file."
	exit 1
fi

###################################
# Check current user is Oracle    #
###################################

currentUser=`whoami`
if [ $currentUser != "oracle" ] ; then
	echo "ERROR: This script must be run as oracle"
	exit 1
else
	verbose "Current user is oracle"
fi
verbose

#################################
# Loop through oratab and ignore#
# commented lines and do work on#
# instances that have "Y"       #
#################################

for LINE in `grep -v '^#' $ORATAB`
do

    case $LINE in
        \#*)            ;;      # ignore comment-line in oratab
	  *)
		
		#unset all the variables we are going to use in this loop
		unset ORACLE_CONFIG_HOME
		unset CCR_CONFIG_HOME
		unset ORACLE_SID
		
		if [ "`echo $LINE | awk -F: '{print $3}' -`" = "Y" ] 
		then # check if line has "Y"
			totalCount=`expr $totalCount + 1` 
			ORACLE_SID=`echo $LINE | awk -F: '{print $1}' -`

			if [ -f "$HOME/bin/$ORACLE_SID" ] ; then
				. $HOME/bin/$ORACLE_SID #set env vars
				verbose "SSID: $ORACLE_SID"
				verbose "-------------------------------"
			else
				echo "ERROR: Could not find environment file for $ORACLE_SID"
				badCount=`expr $badCount + 1`
				verbose
				continue
			fi


			if [ ! -d ${ORACLE_HOME}/ccr ] ; then
				echo "ERROR: The CCR collector is not installed	in $ORACLE_HOME"
                                badCount=`expr $badCount + 1`
				verbose
                                continue
			else
				CCR_HOST_NAME=`hostname`
				CCR_HOME=${ORACLE_HOME}/ccr
				verbose "CCR_HOME=$CCR_HOME"
			fi
			
			if [ -z "${ORACLE_CONFIG_HOME}" ] ; then
				#check if it's a shared OEM install
				if [ -d ${CCR_HOME}/hosts ] ; then
					CCR_CONFIG_HOME="${CCR_HOME}/hosts/${CCR_HOST_NAME}"
					verbose "CCR_CONFIG_HOME = $CCR_CONFIG_HOME"
				else
					CCR_CONFIG_HOME=${CCR_HOME}
					verbose "CCR_CONFIG_HOME = $CCR_CONFIG_HOME"
				fi
			elif [ -d ${ORACLE_CONFIG_HOME} ] ; then
				CCR_CONFIG_HOME="${ORACLE_CONFIG_HOME}/ccr"
				verbose "CCR_CONFIG_HOME = $CCR_CONFIG_HOME"

			else
				echo "ERROR: $ORACLE_CONFIG_HOME should point to the directory containing OCM configurations for the host."				
                                badCount=`expr $badCount + 1`
				verbose
                                continue

			fi
		else
			continue
		fi

##############################################
# Phew... finally let's execute the commands #
##############################################
		verbose

		if [ $S_FLAG = "TRUE" ] ; then
	
			if [ $V_FLAG = "FALSE" ] ; then
				$CCR_HOME/bin/emCCR status > /dev/null 2> /dev/null
				if [ $? != 0 ] ; then
					echo "ERROR: emCCR is not functioning on $ORACLE_SID"
					badCount=`expr $badCount + 1`
				fi
			else
				$CCR_HOME/bin/emCCR status 2> /dev/null
				if [ $? != 0 ] ; then
					echo "ERROR: emCCR is not functioning on $ORACLE_SID"
                                        badCount=`expr $badCount + 1`
                                fi

			fi

		fi

		if [ $A_FLAG = "TRUE" ] ; then
			echo $CCR_HOME/bin/emCCR automatic_update $A_VALUE
			verbose "Successfully changed $ORACLE_SID to $A_VALUE"
		fi

		if [ $U_FLAG = "TRUE" ] ; then
			$CCR_HOME/bin/emCCR update_components -distribution=$U_VALUE
			verbose "Successfully updated componets on $ORACLE_SID using $U_VALUE"
		fi
	
		verbose
		verbose
		verbose
		;;			
    	esac

done

pct_broke=`echo "scale=2; $badCount / $totalCount * 100" | bc`

##########################################
# Print Summary Report                   #
##########################################
verbose
verbose
echo
echo "###########################################################################"
echo "SUMMARY REPORT for `hostname` on `date`"
echo "--------------------------------------------------"
echo "Total instances: $totalCount"
echo "Instances w/ confirmed working SCM: `expr $totalCount - $badCount`"
# echo "Percentage broken: `echo "scale=2; $badCount / $totalCount * 100" | bc`"
echo "Percentage broken: $pct_broke %"
echo "###########################################################################"
echo ""

