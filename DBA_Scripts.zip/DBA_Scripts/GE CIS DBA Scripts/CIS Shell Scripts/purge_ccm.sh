#!/bin/ksh
########################################################################
##
## purge.sh - To purge specified directories of files older than
##            the defined purge period.
##            A file named purge.ctl must first be defined under
##            the $DBA_HOME/admin directory.  Entries in this file
##            must be formatted as follows:
##            path:purgeperiod:mask:owner
##            The path and purge period fields are required;
##            The mask field can be omitted if all files under the
##            specified path are candidates for removal.
##            A literal "recursive" can be provided to recursively remove
##            directories whose name contains the string supplied in the mask
##            parameter (mask is required for recursive processing!)
##
##            With the following sample purge.ctl file:
##
##            /dump01/oracle/asst/bdump:10:.trc
##            /arch01/oracle/asst:10
##            /users/oracle/rdbms/audit:0
##            /dump01/oracle/asst/cdump:7:core:recursive
##            /var/tmp/:7::faxmgr
##
##            the script will remove all files containing the string
##            .trc and older than 10 days from the bdump directory;
##            all files older than 10 days from the asst archive log
##            directory; all files from Oracle's audit directory; and
##            all files and directories containing the string core and
##            older than 7 days from the cdump directory; all files 
##            older than 7 days and owned by faxmgr from the /var/tmp directory.
##
##            NOTE: For instances using tape_copy.sh to save archive logs
##                  to tape, additional logic is applied before removing any
##                  archive log. The log name must first exist in the
##                  log_to_tape.list file under the log archive directory thus
##                  signifying that it was previously saved to tape.
##
## Author : Linda Slyer
## Date   : Dec 13, 1996
## 
########################################################################
echo $0
if [ "`uname -a | cut -c1-3`" = "Sun" ]
then
  PATH=/usr/xpg4/bin:$PATH:/usr/ucb; export PATH
  ORATAB=/var/opt/oracle/oratab
else
  ORATAB=/etc/oratab
fi

rval=0
currmonth=`date +%m`
##########################################################################
# Determine who to notify in case of subsequent abend
##########################################################################
charset=us-ascii; export charset
ohost=`hostname`
#if [ -f $HOME/bin/notify.ctl ]
#then
#  ooncall=`cat $HOME/bin/notify.ctl | awk -F: '
#    BEGIN {firstsw = 1}
#    {if (firstsw == 1 && $1 == "all" && $2 == "all" && NF > 2) {
#       print $3; firstsw = 0}}'`
#  oserver_rep=`cat $HOME/bin/notify.ctl | awk -F: -v host="$ohost" '
#    BEGIN {firstsw = 1}
#    {if (firstsw == 1 && $1 == host && $2 == "all" && NF > 2) {
#       print $3; firstsw = 0}}'`
#else
#  ooncall=linda.slyer
#  oserver_rep=linda.slyer
#fi

rmsg="purge.sh abended - check \$DBA_HOME/audit/purge.audit"

##########################################################################
# run any Oracle environment script, to set DBA_HOME
##########################################################################
sid_sw=0
for sid in `grep '^.*:.*:Y[ ]*$' $ORATAB |cut -d: -f1`; do
  if [ -f $HOME/bin/$sid ]; then
    if ( . $HOME/bin/$sid >/dev/null 2>&1 ); then
      . $HOME/bin/$sid
      sid_sw=1
      break
    fi
  fi
done


if [ $sid_sw -eq 0 ]
then
  # try to derive DBA_HOME from location of this file
  currdir=`dirname $0`
  if [ "$currdir" = "." ]; then
    currdir=`pwd`
  fi
  DBA_HOME=`dirname $currdir`
  if [ ! -d $DBA_HOME/admin -o ! -d $DBA_HOME/audit -o -z "$DBA_HOME" ]; then
    rval=1
    echo "Could not find an Oracle environment to set DBA_HOME"
    echo "Script is terminating"
    $DBA_HOME/admin/notify.sh -s "$ohost purge" -b "$rmsg" -w server
    #echo $rmsg | mailx -s "$ohost purge" $ooncall@corporate.ge.com
    #if [ "$oserver_rep" != "$ooncall" ]
    #then
    #  echo $rmsg | mailx -s "$ohost purge" $oserver_rep@corporate.ge.com
    #fi
    exit $rval
  fi
fi
if [ -z "$DBA_HOME" ]
then
  rval=1
  echo "DBA_HOME not set by environment script $sid"
  echo "Script is terminating"
 /t027/dba01/oracle/admin/notify.sh -s "$ohost purge" -b "$rmsg" -w server
  #echo $rmsg | mailx -s "$ohost purge" $ooncall@corporate.ge.com
  #if [ "$oserver_rep" != "$ooncall" ]
  #then
  #  echo $rmsg | mailx -s "$ohost purge" $oserver_rep@corporate.ge.com
  #fi
  exit $rval
fi
tmpfile=$DBA_HOME/audit/purge.filelist.$$

##########################################################################
# Loop over the entries in file, purge.ctl
##########################################################################
while read -r purge_control
do
  nextdir=`echo ${purge_control} | awk -F: '{print $1}'`
  if [ -z "$nextdir" ] || [ "`echo $nextdir|cut -c1`" = "#" ]
  then
    continue
  fi
  purge_period=`echo ${purge_control} | awk -F: '{print $2}'`
  mask_sw=0
  purge_mask=
  recursive_sw=0
  opt3=`echo ${purge_control} | cut -d: -f3`
  opt4=`echo ${purge_control} | cut -d: -f4`
  opt5=`echo ${purge_control} | cut -d: -f5`
  file_owner=
  if [ ! -z "$opt3" ]
  then
    if [ "$opt3" = "recursive" ]
    then
      if [ -z "$opt4" ]
      then
	echo "Syntax error: ${purge_control} - line ignored"
	rval=1
	continue
      else
	mask_sw=1
	recursive_sw=1
	purge_mask=$opt4
	if [ ! -z "$opt5" ]
        then
	  file_owner=$opt5
        fi
      fi
    else
      mask_sw=1
      purge_mask=$opt3
      if [ "$opt4" = "recursive" ]
      then
	recursive_sw=1
        if [ ! -z "$opt5" ]
	then
	  file_owner=$opt5
	fi
      else
	if [ ! -z "$opt4" ]
	then
	  file_owner=$opt4
	fi
	if [ ! -z "$opt5" ]
	then
	  echo "Syntax error: ${purge_control} - line ignored"
	  rval=1
	  continue
        fi
      fi
    fi
  else
    if [ ! -z "$opt4" ]
    then
      file_owner=$opt4
    fi
    if [ ! -z "$opt5" ]
    then
      echo "Syntax error: ${purge_control} - line ignored"
      rval=1
      continue
    fi
  fi
  if [ ! -z "$file_owner" ]
  then
    grep -s "^${file_owner}:" /etc/passwd > /dev/null
    if [ $? -ne 0 ]
    then
      echo "Syntax error: ${purge_control} - user $file_owner not found in /etc/passwd - line ignored"
      continue
    fi
  fi
  
  removectr=0
  filectr=0
  for cleandir in $nextdir; do
    if [ ! -d "$cleandir" ]; then
      continue
    fi
    cd $cleandir
  ##########################################################################
  # Loop over the files in the current purge.ctl directory being processed
  ##########################################################################
    #for filename in `ls`
    #ls -1tr | while read  filename
    if [ -f $tmpfile ]; then
      rm -f $tmpfile
    fi  
    ls -1tr > $tmpfile
    if [ $? -ne 0 ]; then
      echo Error creating temporary file $tmpfile
      rval=1
      continue
    fi
    while read -r filename
    do
      if [ $mask_sw -eq 1 ]
      then
        echo $filename | egrep "$purge_mask" >/dev/null 2>&1
        if [ $? -eq 1 ]
        then
          # check whether we should break out because this file is newer
	  # than purge period
          not2new=`find "$filename" -mtime +$purge_period -name "$filename"` 
	  if [ $? -ne 0 -o -n "$not2new" ]; then
            continue
          else
	    break 
          fi
        fi
      fi
      filectr=`expr $filectr + 1`
      echo $cleandir | grep "arch" >/dev/null
      if [ $? -eq 0 ]
      then
        if [ -f log_to_tape.list ]
        then
          grep "$filename" log_to_tape.list >/dev/null
          if [ $? -eq 1 ]
          then
            continue
          fi
        fi
      fi
      if [ ! -z "$file_owner" ] 
      then
        deletable_files=`find "$filename" -user $file_owner -mtime +$purge_period -name "$filename" | wc -l` 
      else
        deletable_files=`find "$filename" -mtime +$purge_period -name "$filename" | wc -l` 
      fi 
      if [ $deletable_files -gt 0 ]
      then
        if [ -d "$filename" ]
        then
          if [ $recursive_sw -eq 1 ]
          then
            rm -rf "$filename"
            # Added by Stampalia to capture rm failures
            if [ $? -ne 0 ] 
            then rval=1
            fi
            removectr=`expr $removectr + 1`
          fi
        else
          rm -f "$filename"
          # Added by Stampalia to capture rm failures
          if [ $? -ne 0 ] 
          then rval=1
          fi
          removectr=`expr $removectr + 1`
        fi
      else
        # file did not match file_owner and/or purge_period
        # break out if purge_period is too old
        if [ ! -z "$file_owner" ]
        then
          deletable_files=`find "$filename" -mtime +$purge_period -name "$filename"` 
          if [ $? -eq 0 -a -z "$deletable_files" ]; then
            break
          fi
        else
          break
        fi
      fi
    done < $tmpfile
  done
  echo $nextdir":" $removectr "of" $filectr $purge_mask "files removed" 
done < $DBA_HOME/admin/purge.ctl.ccm
rm -f $tmpfile 
if [ $rval -ne 0 ]
then
  echo "Errors encountered"
  echo "Not all candidate files may have been purged"
  $DBA_HOME/admin/notify.sh -s "$ohost purge" -b "$rmsg" -w server
  #echo $rmsg | mailx -s "$ohost purge" $ooncall@corporate.ge.com
  #if [ "$oserver_rep" != "$ooncall" ]
  #then
  #  echo $rmsg | mailx -s "$ohost purge" $oserver_rep@corporate.ge.com
  #fi
fi
exit $rval
