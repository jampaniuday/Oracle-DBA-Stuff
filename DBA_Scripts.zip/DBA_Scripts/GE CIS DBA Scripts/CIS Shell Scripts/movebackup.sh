#!/bin/ksh

## Script Name: movebackup.sh

sourcedir=/p078/copy50/hrp1
targetdir=/p078/copy51/hrp1

##sourcedir=/p078/oracle50/sjadia/refresh
##targetdir=/p078/oracle50/sjadia/copytemp

## Copy backup files to alternate backup directory

/usr/bin/cp -pr $sourcedir/* $targetdir/.

cpstatus=$?

if [ $? -eq 0 ]
then
  echo "Backup files copied successfully to alternate directory."
else
  echo "Error coping files to alternate directory."
fi

exit
