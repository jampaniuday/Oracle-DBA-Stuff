#!/bin/ksh
################################################################################
# usermod.sh
# This script is used to change the comments of the unix user accounts in the
# etc/passwd section by parsing a file containing the unix accounts names and
# the respective comments delimited by the :
# Make sure that the filename called as file.ctl exists in /tmp which has the
# pattern of accountid:New Comment. No tabs or spaces allowed as shown below.
# For eg: raod:GTS DBA
#
#  Arguments: Its an one time script, hence made standalone with filenames& path
#  Usage    : usermod.sh and should be run as root
#
# Deevith Rao - 09/09/2008 - Initial Code.
#
################################################################################
# Define the File path locations and the corresponding file names .
export PATH=/usr/xpg4/bin:$PATH

user=`id|cut -d"(" -f2|cut -d")" -f1`
user=`echo $user|cut -c1-7`
if [ "$user" != "root" ]
then
   echo "Error: You should be logged in as root to run this script"
   exit 1
fi
USER_FILE_LIST_PATH=/tmp
FILE_LIST=/etc/passwd
file=file.ctl
USER_FILE_LIST=$USER_FILE_LIST_PATH/$file

# Get the count of records which needs updation.
FILE_CNT=0
FILE_CNT=`cat "${USER_FILE_LIST}" | wc -l`

# Start Loop
while [ "${FILE_CNT}" -gt 0 ] ; do
echo "Number of records which needs to be updated is ${FILE_CNT}"

USER_ACCOUNT_NAME=`tail -n ${FILE_CNT} ${USER_FILE_LIST} | head -1 |cat |awk -F: {'print $1'}`

USER_ACCOUNT_COMMENTS=`tail -n ${FILE_CNT} ${USER_FILE_LIST} | head -1 |cat |awk -F: {'print $2'}`

# Check whether the account name present in the User File is Present in /etc/passwd
temp=`strings -a "${FILE_LIST}" | grep "${USER_ACCOUNT_NAME}" | cut -d':' -f1`
#echo "$temp"

if [ ! -n "$temp" ]; then
 echo "$USER_ACCOUNT_NAME not present in /etc/passwd and hence would not be updated"
else
 usermod -c "$USER_ACCOUNT_COMMENTS" $USER_ACCOUNT_NAME
 if [ "$?" -eq 0 ]; then
   echo $USER_ACCOUNT_NAME 'is now updated to have new comments per SOX compliance as"' $USER_ACCOUNT_COMMENTS'"'
 else
   echo "$USER_ACCOUNT_NAME not present in /etc/passwd and hence would not be updated"
 fi
fi
FILE_CNT=`expr ${FILE_CNT} - 1`
done

