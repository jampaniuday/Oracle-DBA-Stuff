#!/bin/ksh
## Purpose    : Gathers schema Tables / Indexes with 10% sample, to make best use of CBO
##              on the specified instance.
## Usage      : ohrschemas.sh <SID>
## Parameter  : Oracle SID
## Created by : Mugunthan

## Notify Information ##
sid=$1
notify_who="gtsohrdba@corporate.ge.com"
notify_host=`hostname`
notify_sid=$sid
notify_type="Gather Schema"

## Check for SID parameter ##
if [ -z "$sid" ]
then
  echo
  echo "Invalid Parameter input"
  echo "Usage is ohrschemas.sh sid"
  echo
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who < $SID_HOME/audit/ohrschemas.audit
  exit
fi

## Check for $HOME/bin/SID Environment ##
if [ ! -f $HOME/bin/$sid ]
then
  echo "Error====>No environment script found for instance \"$sid\""
  echo "          Script is terminating!"
  exit
fi

## Set Environment ##
. $HOME/bin/$sid

## Check SID_HOME/audit directory exists or not  ##
if [ ! $SID_HOME/audit ]
then
echo "SID_HOME/audit directory doesnt exists"
  echo "please create it and rerun the script"
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who < $SID_HOME/audit/ohrschemas.audit
  exit
fi


echo "###############################################################"
echo "##    Script ohrschemas.sh starting on " `date` for $sid
echo "###############################################################"

## Check for Instance ##
inst=`ps -ef | grep ora_smon_$sid | grep -v grep`
if [ -z "$inst" ]
then
  echo "Oracle instance, $sid is not available."
  echo "Script is terminating."
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who < $SID_HOME/audit/ohrschemas.audit
  exit
fi

## Pick up apps password from tellme ##
PWD=`$HOME/bin/tellme apps`
if [ -z "$PWD" ]
then
  echo "Error : No password selected for APPS"
  echo "Script is termianting"
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who < $SID_HOME/audit/ohrschemas.audit
  exit
fi

  sqlplus -s apps/${PWD}@$sid <<EOF >$SID_HOME/audit/ohr_analyzed.log
  set head off;
  select 'APPS schema is being submitted with 10%' from dual;
  exec fnd_stats.gather_schema_statistics('APPS','10');
  select 'APPLSYS schema is being submitted with 10%' from dual;
  exec fnd_stats.gather_schema_statistics('APPLSYS','10');
  select 'HR schema is being submitted with 10%' from dual;
  exec fnd_stats.gather_schema_statistics('HR','10');
  select 'GEHR schema is being submitted with 10%' from dual;
  exec fnd_stats.gather_schema_statistics('GEHR','10');
  select 'AR schema is being submitted with 10%' from dual;
  exec fnd_stats.gather_schema_statistics('AR','10');
  select 'ICX schema is being submited with 10%' from dual;
  exec fnd_stats.gather_schema_statistics('ICX','10');
  select 'Check to see any non-analyzed schemas as of today' from dual;
  select table_name,last_analyzed,sample_size from dba_tables where owner in ('APPS','APPLSYS','HR','GEHR','AR') and to_char(last_analyzed,'MM-DD-YYYY') < to_char(SYSDATE,'MM-DD-YYYY');
  !mailx -s ANALYZED_${sid}_Weekly_10% ${notify_who} < $SID_HOME/audit/ohr_analyzed.log
  exit;
