#!/bin/sh
 # **********
 # Author - N.T.Rao
 # ********
 # ********
#set -x
audit_file=/tmp/DB_CHECH_LST.log
clear
# --------------- #
echo ##--------------------------------------##
echo FILE SYSTEM SPACE CHEKING FOR NEW INSTANCE
echo ==========================================
echo ##--------------------------------------##
space_check()
{
df -k|grep $2|awk -F" " '{print $1" "$4}' >/tmp/exspace.input
while read fsys tspace; do
	file_sys=`echo $fsys |awk -F"^" '{print $1}'`
	tv_space=`echo $tspace |awk -F" " '{print $1}'`
	av_space=`expr $tv_space \/ 1024 `
	if [ $av_space -gt $1 ]
	then
  	echo ""
	echo $file_sys "- has sufficient space for $2: "$av_space 
	touch /tmp/p.fil
	exit
	fi
done < /tmp/exspace.input
}
# --------------- #
check_data()
{
fbk=1
DFV=$1
REDV=0
IV=$2
AC=$3
    while [ $fbk -eq 1 ]
    do
  	echo
	echo "Enter $IV ::(Default=$DFV) \c" 
	read REDV
	if [ -z "$REDV" ]
	then
	echo Default $DFV taken for your New Instance 
	fbk=0
	else
	DFV=$REDV
	fbk=0
	fi
    done
}
# ------------------- #
check_data "9.2.0" "ORACLE VERSION" || ACT=1
check_data "ORAI1" "DATABASE NAME " || ACT=1
# --------COLD BACKUP------#
check_data  3000 "DB Size in MB" || ACT=1
DB_SIZ=$DFV
bkup_sp=`expr  $DB_SIZ \/ 2 ` 
echo ''
echo SPACE REQUIRED FOR REGULAR HOT/COLD BACKUP = $bkup_sp
space_check $bkup_sp "copy"
if [ ! -f /tmp/p.fil ]
then
	echo ''
	echo "None of the COPY Filesystem has sufficient space for BACKUP" 
fi
if [  -f /tmp/p.fil ]
then
rm /tmp/p.fil
fi
# --------EXPORT BACKUP------#
DB_SIZ=$DFV
exp_sz=`expr  $DB_SIZ \/ 2 ` 
echo ''
echo SPACE REQUIRED FOR REGULAR EXPORT BACKUP = $exp_sz
space_check $exp_sz "export0"
if [ ! -f /tmp/p.fil ]
then
	echo ''
	echo "None of the EXPORT File system has sufficient space." 
fi
if [  -f /tmp/p.fil ]
then
rm /tmp/p.fil
fi
#----ARCHIVE----#
check_data "Y" "Archive Mode(Y/N)" || ACT=1
#
if [ "$DFV" = "Y" -o "$DFV" = "y" ]
then
	check_data 20 "Redo Log Size in MB" A || ACT=1
	lg_sz=`echo $DFV |cut -c1-2`
	check_data 200 "Avg. # Redo Logs/Day" Z || ACT=1
	no_lg=`echo $DFV |cut -c1-3`
	fp=`expr $lg_sz \/ 2 `
	arch_sp=`expr $no_lg \* $fp `
	echo ''
	echo SPACE REQUIRED FOR ARCHIVE LOGS PER DAY IS =  $arch_sp
	space_check $arch_sp "arch"
	if [ ! -f /tmp/p.fil ]
	then
	echo ''
	echo "None of the ARCH Filesystem has sufficient space for Archiving" 
	fi
	if [  -f /tmp/p.fil ]
	then
	rm /tmp/p.fil
	fi
fi
echo                                                                
echo "============================================================="
echo "ABOVE SPECIFIED VALUE SPACE IS UNDER ARCH, COPY & EXPORT FILE"
echo "SYSTEMS FOR THE NEWDATABASE YOU ARE  PLANNING  ON THIS SERVER"
echo "Please Make sure   of having  sufficient space, and configure"
echo "Archive LOG_COMPRESS & PURGE for the New Database - THNX "    
echo "============================================================="
exit 0
