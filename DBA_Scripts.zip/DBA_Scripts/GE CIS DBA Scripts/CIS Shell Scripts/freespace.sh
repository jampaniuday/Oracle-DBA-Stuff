#!/bin/ksh
#Name    : freespace.sh
#Author  : Muthukumar Ponnambalam
#Date    : 12-10-1999
#Purpose : To run the chkfree.sql at an interval specified by crontab
#          and notify the oncall DBAs
#Usage   : freespace.sh <all|Oracle_Sid>
#
if [ $# -ne 1 ]
then
   echo "Usage : $0 <all|Oracle_Sid>"
   exit 1
fi
Scope=`echo $1 | tr [:upper:] [:lower:]`
if [ $Scope = "all" ]
then
   SidList=`ps -ef | grep pmon | grep -v grep | awk '{ print substr($0,length($0)-3,4) }'`
else
   SidList=$1
   if [ ! -f $HOME/bin/$SidList ]
   then
      echo "Invalid ORACLE_SID. Try again"
      exit 1
   fi
fi
Rv=`tput smso`
Nv=`tput rmso`
Uname=system
echo "Spooling free extent status report for Sid(s) : $Scope"
for Sid in $SidList
do
    #Cstr=d1${Sid}s
    #Passwd=`grep "$Sid:$Uname:" $HOME/bin/oratask.lst | awk -F: '{ print $3 }'`
    #Fcnt=`grep "$Sid:$Uname:" $HOME/bin/oratask.lst | awk -F: '{ print NF }'`
    #if [ $Fcnt -eq 3 ]
    #then
    #   Char=`cat $HOME/bin/charm.file | awk -F: '{ print $1 }'`
    #   Pos=`cat $HOME/bin/charm.file | awk -F: '{ print $2 }'`
    #   Passwd=`echo $Passwd | awk '{ print substr($1,1,'"$Pos"'-1) '"$Char"' substr($1,'"$Pos"') }'`
    #fi
    Audit_Name=$DBA_HOME/$Sid/audit/chkfree.lst
    echo
    echo
    echo ======================================================================================
    echo Tablespaces without freespace for Oracle_SID $Sid on `hostname`
    . $HOME/bin/$Sid
    Passwd=`$HOME/bin/tellme $Uname`
    sqlplus -s $Uname/$Passwd <<EOF
spool $Audit_Name
Rem **********************************************************************
Rem Name     : chkfree.sql
Rem Purpose  : to compare the available free space to the next extent size
Rem Date     : sep/10/95
Rem Revision :
Rem     Name : Muthukumar Ponnambalam [12/10/1999]
Rem            Modified this to be a generic one making it instance and
Rem            machine independent.
Rem **********************************************************************
set pagesize 66 
set linesize 80
break On Tsname skip 1
Rem
column Tsname  format a15 head 'Tablespace Name'
column Table_Name format a30 head 'Table Name'
column Index_Name format a30 head 'Index Name'
column Next_Ext format 9990.90 head 'Next|Extent'
column Max_Mb format 9990.90 head 'Maximum|Free MB'
set termout off
Rem
prompt Tablespaces without enough Free Space for 2 more Extents
prompt *********************************************************
set pagesize 50 
set linesize 110
select a.tablespace_name as Tsname, 
       substr(a.owner,1,12) as Owner,
       'Table' as Type,
       a.table_name as Table_Name, 
       a.next_extent/1024/1024*2  as Next_2_Exts,
       max(d.bytes)/1024/1024 as Max_Mb
  from sys.dba_tables a,
       sys.dba_free_space d
 where a.tablespace_name = d.tablespace_name
   and a.next_extent * 2 >
       (select max(b.bytes)  
          from sys.dba_free_space b
         where b.tablespace_name = a.tablespace_name)
 group by a.tablespace_name,
          a.owner,
          3,
          a.table_name,
          a.next_extent
union
select c.tablespace_name as Tsname,
       substr(c.owner,1,12) as Owner,
       'Index' as Type,
       c.index_name as Index_Name, 
       c.next_extent/1024/1024*2 as Next_2_Exts,
       max(e.bytes)/1024/1024 as Max_Mb
  from sys.dba_indexes c,
       sys.dba_free_space e
 where c.tablespace_name = e.tablespace_name
   and c.next_extent * 2 >
       (select max(d.bytes)
          from sys.dba_free_space d
         where d.tablespace_name = c.tablespace_name)
 group by c.tablespace_name,
          c.owner,  
          3,
          c.index_name,
          c.next_extent
order by 1,2;
Rem
Rem Now check for tablespaces with no free space
Rem
prompt Tablespaces with No Freespace
prompt *****************************
select a.tablespace_name
  from sys.dba_tablespaces a
 where a.tablespace_name not like 'ROLL%'
   and not exists
       (select b.tablespace_name
          from sys.dba_free_space b
         where a.tablespace_name = b.tablespace_name);
exit
spool off
EOF
done
Oncall=`grep "all:all" $HOME/bin/notify.ctl | cut -d: -f3`
Pager_No=`grep "#$Oncall" $HOME/bin/notify.ctl | cut -d: -f2`
if [ ! -z "$Pager_No" ]
then
   for Sid in $SidList
   do
       Audit_Name=$DBA_HOME/$Sid/audit/chkfree.lst
       Rows_Found=`grep -c 'no rows selected' $Audit_Name`
       # Following if condition is to avoid mailing the DBAs if no rows
       # returned by the SQL script
       if [ $Rows_Found -lt 2 ]
       then
          echo "Test : Not Mailing $Oncall@corporate.ge.com < ${Audit_Name}"
          #mailx -s "`hostname` $Sid Next_Ext size problem " $Oncall@corporate.ge.com < ${Audit_Name}
          #mailx -s "`hostname` $Sid Next_Ext size problem " mike.bickel@corporate.ge.com < ${Audit_Name}
	  $DBA_HOME/admin/notify.sh -s "$Sid Next_Ext size problem " -f ${Audit_Name} -w sid
       fi
   if [ $Rows_Found -lt 2 ]
   then
      echo "Test : Not paging $Pager_No"
      #echo "`hostname`-$Sid Next_Ext size problem - See mail" | mailx $Pager_No
      #echo "`hostname`-$Sid Next_Ext size problem - See mail" | mailx 5184845881@alphapage.airtouch.com
	$DBA_HOME/admin/notify.sh -p "$Sid Next_Ext size problem " -w sid
   fi
   done
fi
