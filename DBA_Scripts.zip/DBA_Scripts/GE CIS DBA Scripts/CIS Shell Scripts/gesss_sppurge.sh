#!/bin/ksh
################################################################################
# gesss_sppurge.sh 
# This script is used to  purge the statspack tables 
#
#  Arguments: ORACLE_SID 
#  Arguments: Number of snap ids to keep
#  Usage    : gesss_sppurge.sh <sid> <1000>
#   
# Carl Infiesto 3/20/03
# Paul Krempa 12/08/2005
# 	Added Check and logic to get low_id, and pass that into the purge
# Paul Krempa 02/17/2006
# 	Added delete commit procedure so that script could purge rows
#       in stats$sqltext  the delete_commit.sql file must 
#       be located in $DBA_HOME/admin directory
###############################################################################
#DBA_HOME/admin/stats_notify.ctl|grep ^$ssid:APP|awk -F: '{print $3}'` maildba=`cat $DBA_HOME/admin/stats_notify.ctl|grep ^$ssid:DBA| awk -F: '{print $3}'`


function checkconnect {
######################################
# checkconnect()
#   Ensure that we can connect to the database
# Arguments: $1, user
#            $2, password
# Returns: 0, if we can connect
#          1, if we cannot connect
#
sqlplus -s $1/$2 << EOF > /dev/null
exit 255;
EOF
   if [ $? -ne 255 ]; then
    return 1
   else
    return 0
   fi
} ################## checkconnect() ##

######################################################
# Source the correct environment set variables
#####################################################
. $HOME/bin/$1
echo $1
USERNAME=perfstat
PASSWD=`$HOME/bin/tellme $USERNAME`
#echo $PASSWD
MAXSNAPIDS=$2
#echo $MAXSNAPIDS
STATSTABLE='stats$snapshot'
#echo "STATSTABLE is $STATSTABLE"

######################################################
# Set the mailer list
#####################################################
MAILLIST="paul_krempa@ge.com"

########################################################
# Check for database availabilty and if available 
# check for username and password combination
########################################################## 
SMON=`ps -ef | grep ora_smon_"$SID" | grep -v grep | awk '{print $1}'|uniq`
if [ ! -z "$SMON" ];then
    checkconnect $USERNAME $PASSWD 
    if [ "$?" -eq 0 ] ;then
    HIGHSNAPID=`sqlplus -s $USERNAME/$PASSWD  <<EOF
    set heading off
    select max(snap_id) - $MAXSNAPIDS
    from $STATSTABLE;
EOF`

    LOWSNAPID=`sqlplus -s $USERNAME/$PASSWD  <<EOF
    set heading off
    select min(snap_id)
    from $STATSTABLE;
EOF`
    echo LOWSNAPID is $LOWSNAPID
    echo HIGHSNAPID is $HIGHSNAPID
    echo MAXSNAPIDS is $MAXSNAPIDS

	if [ $LOWSNAPID -gt $HIGHSNAPID ] ;then
	   echo	 "LOWSNAPID is larger than HIGHSNAPID!!! CANNOT PROCEED"
#	   return 1 Changed for Autosys failures
	   return 0
	   exit
	else
echo HIGHSNAPID is $HIGHSNAPID
sqlplus -s $USERNAME/$PASSWD @$DBA_HOME/admin/gesss_sppurge.sql 0 $HIGHSNAPID <<EOF
EOF
	fi 
else 
$DBA_HOME/admin/notify.sh -s "$USERNAME password is NOT correct" -b "Correct $USERNAME password"
    fi
fi
###############################################################################
# End of gesss_sppurge.sh
###############################################################################
