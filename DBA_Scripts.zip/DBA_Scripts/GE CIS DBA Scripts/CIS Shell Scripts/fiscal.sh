#!/bin/ksh
##########################################################################
# This script takes the calendar date and turns it into a GE fiscal date
##########################################################################
#
ws_month=$month
ws_year=$year
#
######################################################################
#
#	It then determines if this is a leap year, and assigns the
#	correct number of days for each month accordingly
#
######################################################################
#
remainder=`expr $ws_year % 4`
#
if [ "$remainder" -eq 0 ]
then
	leap=1
else
	leap=0
fi
#
ws_year=`expr $ws_year + 1`
#
if [ "$leap" -eq 0 ]
then
	case "$month"
	in
		01) days_in_year=000;; 
		02) days_in_year=031;; 		
		03) days_in_year=059;; 
		04) days_in_year=090;; 
		05) days_in_year=120;; 
		06) days_in_year=151;; 
		07) days_in_year=181;; 
		08) days_in_year=212;; 		
		09) days_in_year=243;; 
		10) days_in_year=273;;
		11) days_in_year=304;;
		12) days_in_year=334;;
	esac
else
	case "$month"	
	in
		01) days_in_year=000;; 
		02) days_in_year=031;; 		
		03) days_in_year=060;; 
		04) days_in_year=091;; 
		05) days_in_year=121;; 
		06) days_in_year=152;; 
		07) days_in_year=182;; 
		08) days_in_year=213;; 		
		09) days_in_year=244;; 
		10) days_in_year=274;;
		11) days_in_year=305;;
		12) days_in_year=335;;
	esac
fi
#
###########################################################################
#
#	This is the year table.  It contains one row for each year
#	1950 - 2049 where the format for each row is:
#
#		wwxyznnnn
#
#	ww =	fiscal year
#	x  =	0 if the year has 52 fiscal weeks
#	x  =	1 if the year has 53 fiscal weeks
#	y  =	0 if Jan 1st of the year falls in fiscal week one of
#		the same year
#	y  =	1 if Jan 1st of the year falls in fiscal week 53 of
#		the previous week
#	z  =	day of the week that Jan 1st of the year falls on 
#		(1=Mon,2=Tue...)
#	nnnnn = # of cumulative days in all years (starting at 1950)
#		up to but not including the given year
#
##############################################################################
#
case "$ws_year"
in
	1)  ws_yr=0001618262;;                            
     	2)  ws_yr=0100118628;;                             
  	3)  ws_yr=0200218993;;                             
     	4)  ws_yr=0300319358;;                             
     	5)  ws_yr=0410419723;;                             
     	6)  ws_yr=0501620089;;                            
     	7)  ws_yr=0601720454;;                            
     	8)  ws_yr=0700120819;;                             
     	9)  ws_yr=0800221184;;                             
     	10) ws_yr=0900421550;;                             
     	11) ws_yr=1010521915;;                             
     	12) ws_yr=1101622280;;                             
     	13) ws_yr=1201722654;;                             
     	14) ws_yr=1300223011;;                             
     	15) ws_yr=1400323376;;                             
     	16) ws_yr=1500423714;;                            
     	17) ws_yr=1610524106;;                             
     	18) ws_yr=1701724472;;                             
     	19) ws_yr=1800124837;;                             
    	20) ws_yr=1900225202;;                             
     	21) ws_yr=2000325567;;                             
     	22) ws_yr=2110525933;;                             
     	23) ws_yr=2201626298;;                             
     	24) ws_yr=2301726663;;                             
     	25) ws_yr=2400127028;;                             
     	26) ws_yr=2500327394;;                             
     	26) ws_yr=2600427759;;                             
     	28) ws_yr=2710528124;;                             
     	29) ws_yr=2801628489;;                             
     	30) ws_yr=2900128855;;                             
     	31) ws_yr=3000229220;;                            
     	32) ws_yr=3100329585;;                            
     	33) ws_yr=3210429950;;                             
     	34) ws_yr=3301630316;;                             
     	35) ws_yr=3401730681;;                             
     	36) ws_yr=3500131046;;                                 
 	37) ws_yr=3600231411;;                             
     	38) ws_yr=3700431777;;                             
    	39) ws_yr=3810532142;;                             
     	40) ws_yr=3901632507;;                             
     	41) ws_yr=4001732872;;                             
	42) ws_yr=4100233238;;                             
     	43) ws_yr=4200333603;;                             
     	44) ws_yr=4300433968;;                            
    	45) ws_yr=4410534333;;                            
     	46) ws_yr=4501734699;;                           
     	47) ws_yr=4600135064;;                             
     	48) ws_yr=4700235429;;                             
     	49) ws_yr=4800335794;;                             
     	50) ws_yr=4910536160;;                             
     	51) ws_yr=5010700000;;                             
 	52) ws_yr=5100100365;;                             
     	53) ws_yr=5200200730;;                         
     	54) ws_yr=5300401096;;                             
     	55) ws_yr=5410501461;;                             
     	56) ws_yr=5501601826;;                             
     	57) ws_yr=5601702191;;                             
     	58) ws_yr=5700202557;;                             
     	59) ws_yr=5800302922;;                             
     	60) ws_yr=5900403287;;                             
     	61) ws_yr=6010503652;;                             
     	62) ws_yr=6101704018;;                             
     	63) ws_yr=6200104383;;                             
     	64) ws_yr=6300204748;;                             
     	65) ws_yr=6400305113;;                             
     	66) ws_yr=6500505479;;                             
     	67) ws_yr=6610605844;;                             
     	68) ws_yr=6701706209;;                             
     	69) ws_yr=6800106574;;                             
     	70) ws_yr=6900306940;;                             
     	71) ws_yr=7000407305;;                             
     	72) ws_yr=7100507670;;                             
     	73) ws_yr=7210608035;;                             
     	74) ws_yr=7300108401;;                             
     	75) ws_yr=7400208766;;                             
     	76) ws_yr=7500309131;;                             
     	77) ws_yr=7610409496;;                             
     	78) ws_yr=7701609862;;                             
     	79) ws_yr=7801710227;;                             
     	80) ws_yr=7900110592;;                             
     	81) ws_yr=8000210957;;                             
     	82) ws_yr=8100411323;;                             
     	83) ws_yr=8210511688;;                             
     	84) ws_yr=8301612053;;                            
     	85) ws_yr=8401712418;;                             
     	86) ws_yr=8500212784;;                             
     	87) ws_yr=8600313149;;                             
     	88) ws_yr=8700413514;;                             
     	89) ws_yr=8810513879;;                             
     	90) ws_yr=8901714245;;                             
     	91) ws_yr=9000114610;;                             
     	92) ws_yr=9100214975;;                             
     	93) ws_yr=9200315340;;                             
     	94) ws_yr=9310515706;;                             
     	95) ws_yr=9401616071;;                             
     	96) ws_yr=9501716436;;                             
     	97) ws_yr=9600116801;;                             
     	98) ws_yr=9700317167;;                             
     	99) ws_yr=9800417532;;                             
     	100) ws_yr=9910517897;;
esac  
#
######################################################################
#
#	Equations for determining the fiscals
#
######################################################################
#                           
fiscal_year=`echo $ws_yr | cut -c1-2`                                     
fiscal_week_sw=`echo $ws_yr | cut -c3`                                    
jan_1st_sw=`echo $ws_yr | cut -c4`                                          
jan_1st_day=`echo $ws_yr | cut -c5`                                           
cum_day_count=`echo $ws_yr | cut -c6-10` 
#
temp=`expr $day + $days_in_year`
#
intermediate=`expr $temp + $jan_1st_day + 5`
int2=`expr $intermediate / 7`
fiscal_week=`expr $int2 - $jan_1st_sw`
#
temp=`expr $temp + $jan_1st_day + 5`
#
#
fiscal_day=`expr $temp % 7 + 1`
#
fiscal_year=$year
#
if [ "$fiscal_week" -eq 0 ]
then
	if [ "$fiscal_year" -eq 0 ]
	then
		fiscal_year=99
	else
		fiscal_year=`expr $fiscal_year - 1`
	fi
#
	ws_year=`expr $fiscal_year + 1 `
	case "$ws_year"
	in
	1)  ws_yr=0001618262;;                            
     	2)  ws_yr=0100118628;;                             
  	3)  ws_yr=0200218993;;                             
     	4)  ws_yr=0300319358;;                             
     	5)  ws_yr=0410419723;;                             
     	6)  ws_yr=0501620089;;                            
     	7)  ws_yr=0601720454;;                            
     	8)  ws_yr=0700120819;;                             
     	9)  ws_yr=0800221184;;                             
     	10) ws_yr=0900421550;;                             
     	11) ws_yr=1010521915;;                             
     	12) ws_yr=1101622280;;                             
     	13) ws_yr=1201722654;;                             
     	14) ws_yr=1300223011;;                             
     	15) ws_yr=1400323376;;                             
     	16) ws_yr=1500423714;;                            
     	17) ws_yr=1610524106;;                             
     	18) ws_yr=1701724472;;                             
     	19) ws_yr=1800124837;;                             
    	20) ws_yr=1900225202;;                             
     	21) ws_yr=2000325567;;                             
     	22) ws_yr=2110525933;;                             
     	23) ws_yr=2201626298;;                             
     	24) ws_yr=2301726663;;                             
     	25) ws_yr=2400127028;;                             
     	26) ws_yr=2500327394;;                             
     	26) ws_yr=2600427759;;                             
     	28) ws_yr=2710528124;;                             
     	29) ws_yr=2801628489;;                             
     	30) ws_yr=2900128855;;                             
     	31) ws_yr=3000229220;;                            
     	32) ws_yr=3100329585;;                            
     	33) ws_yr=3210429950;;                             
     	34) ws_yr=3301630316;;                             
     	35) ws_yr=3401730681;;                             
     	36) ws_yr=3500131046;;                                 
 	37) ws_yr=3600231411;;                             
     	38) ws_yr=3700431777;;                             
    	39) ws_yr=3810532142;;                             
     	40) ws_yr=3901632507;;                             
     	41) ws_yr=4001732872;;                             
	42) ws_yr=4100233238;;                             
     	43) ws_yr=4200333603;;                             
     	44) ws_yr=4300433968;;                            
    	45) ws_yr=4410534333;;                            
     	46) ws_yr=4501734699;;                           
     	47) ws_yr=4600135064;;                             
     	48) ws_yr=4700235429;;                             
     	49) ws_yr=4800335794;;                             
     	50) ws_yr=4910536160;;                             
     	51) ws_yr=5010700000;;                             
 	52) ws_yr=5100100365;;                             
     	53) ws_yr=5200200730;;                         
     	54) ws_yr=5300401096;;                             
     	55) ws_yr=5410501461;;                             
     	56) ws_yr=5501601826;;                             
     	57) ws_yr=5601702191;;                             
     	58) ws_yr=5700202557;;                             
     	59) ws_yr=5800302922;;                             
     	60) ws_yr=5900403287;;                             
     	61) ws_yr=6010503652;;                             
     	62) ws_yr=6101704018;;                             
     	63) ws_yr=6200104383;;                             
     	64) ws_yr=6300204748;;                             
     	65) ws_yr=6400305113;;                             
     	66) ws_yr=6500505479;;                             
     	67) ws_yr=6610605844;;                             
     	68) ws_yr=6701706209;;                             
     	69) ws_yr=6800106574;;                             
     	70) ws_yr=6900306940;;                             
     	71) ws_yr=7000407305;;                             
     	72) ws_yr=7100507670;;                             
     	73) ws_yr=7210608035;;                             
     	74) ws_yr=7300108401;;                             
     	75) ws_yr=7400208766;;                             
     	76) ws_yr=7500309131;;                             
     	77) ws_yr=7610409496;;                             
     	78) ws_yr=7701609862;;                             
     	79) ws_yr=7801710227;;                             
     	80) ws_yr=7900110592;;                             
     	81) ws_yr=8000210957;;                             
     	82) ws_yr=8100411323;;                             
     	83) ws_yr=8210511688;;                             
     	84) ws_yr=8301612053;;                            
     	85) ws_yr=8401712418;;                             
     	86) ws_yr=8500212784;;                             
     	87) ws_yr=8600313149;;                             
     	88) ws_yr=8700413514;;                             
     	89) ws_yr=8810513879;;                             
     	90) ws_yr=8901714245;;                             
     	91) ws_yr=9000114610;;                             
     	92) ws_yr=9100214975;;                             
     	93) ws_yr=9200315340;;                             
     	94) ws_yr=9310515706;;                             
     	95) ws_yr=9401616071;;                             
     	96) ws_yr=9501716436;;                             
     	97) ws_yr=9600116801;;                             
     	98) ws_yr=9700317167;;                             
     	99) ws_yr=9800417532;;                             
     	100) ws_yr=9910517897;;
	esac  
	fiscal_week_sw=`echo $ws_yr | cut -c3` 
#
	if [ "$fiscal_week_sw" -eq 1 ]
	then
		fiscal_week=53
	else
		fiscal_week=52
	fi
else
	if [ "$fiscal_week" -lt 53 ]
	then
		nothing=0
	else
		if [ "$fiscal_week" -eq 53 -a "$fiscal_week_sw" -eq 1 ]
		then
			nothing=0
		else
			fiscal_week=1
			if [ "$fiscal_year" -eq 99 ]
			then
				fiscal_year=0
			else
				fiscal_year=`expr $fiscal_year + 1`
			fi
		fi
	fi
fi
week_table="12345123412341234512341234123451234123412345123412345"
week_of_month=`echo $week_table | cut -c$fiscal_week`
fiscal_week=$week_of_month
if [ $fiscal_day -eq 7 ]
then
  fiscal_day=0
fi
echo $fiscal_week $fiscal_day >$SID_HOME/audit/fiscal.out
exit
