#!/bin/ksh 
#
# Script Name: lstnmgr.sh
# Language   : Tcl/Tk, binary distribution from ActiveState
# Purpose    : Manage Oracle Listeners, and password protect them
# Author     : Shirdivas Dharmabhotla
# Company    : General Electric, GECIS Software
# Date       : August 2004
# 
#\
ORACLE_SID=$1 ; export ORACLE_SID
#\
LSNR_NAME=$2 ; export LSNR_NAME
#\
OPERATION=$3 ; export OPERATION
#\
NEW_PASS=$4 ; export NEW_PASS
#\
GREP=`which grep` ; export GREP

#\
if [ -z "${ORACLE_SID}" ] || [ -z "${LSNR_NAME}" ] || [ -z "${OPERATION}" ];then
#\
 echo "Usage: lstnmgr.sh <ORA_SID> <listener_name> <operation> <newpasswd>"
#\
  echo "        <operation>: start, stop, status, encrypt"
#\
  echo " Examples:"
#\
  echo " lstnmgr.sh ssd9 lstnssd9 status"
#\
  echo " lstnmgr.sh ssd9 lstnssd9 start"
#\
  echo " lstnmgr.sh ssd9 lstnssd9 stop"
#\
  echo " lstnmgr.sh ssd9 lstnssd9 encrypt c0rp0rate"
#\
  echo ""
#\
  exit 1
#\
   echo "Instance Name, Listener Name, and Operation are Mandatory Inputs"
#\
   exit 1
#\
fi
#\
## Set Oracle's HOME directory
#\
oracle_id=`ls -l $0 | awk '{ print $3 }'` ; export oracle_id
#\
ohome=`grep "^${oracle_id}:" /etc/passwd | cut -f6 -d:` ; export ohome
#\
if [ "${oracle_id}" == "oracle" ] || [ "${oracle_id}" == "oracle9" ] || [ "${oracle_id}" == "oracle50" ] ; then
#\
if [ -x $ohome/bin/tellme ] ; then
#\
PRESENT_PASS=`$ohome/bin/tellme $LSNR_NAME` ; export PRESENT_PASS
#\
else
#\
echo "Owner Executing this Script is not authorised. Exiting"
#\
fi
#\
else
#\
echo "User ${oracle_id} is NOT in Access Control List. Exiting the Shell"
#\
exit 1
#\
fi
#\
if [ ! -f "$ohome/bin/$ORACLE_SID" ]; then
#\
  echo "$ORACLE_SID is not a Valid Instance. Exiting."
#\
  exit 1
#\
else
#\
. $ohome/bin/$ORACLE_SID
#\
fi
#\
PATH=$TCL_HOME/bin:${PATH}:/usr/bin:/bin:$ORACLE_HOME/bin:/usr/sbin
#\
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:$ORACLE_HOME/lib:$TCL_HOME/lib
#\
export PATH LD_LIBRARY_PATH
#\
V_STATUS=`ps -ef|$GREP -i tnslsnr |$GREP $LSNR_NAME |$GREP -v grep|wc -l`
#\
export V_STATUS
#\
exec tclsh "$0" "$@"
package require Expect
#
# Sourcing the Variables
# ----------------------

set ORA_SID   [lindex $argv 0]
set lsnr_name [lindex $argv 1]
set operation [lindex $argv 2]
set new_pass  [lindex $argv 3]
set newpass $new_pass
set send_slow {1024 10}
set v_status $env(V_STATUS)

# Begin of TCL Procedures
# ========================      
#
# Procedure to Stop the Listener
# ------------------------------
#
proc stop_listener {lsnr_name presentpass}  {

  if { $presentpass == "" }  {
 puts "Listener is Not Protected\n"
 spawn lsnrctl
 send "\n"
 send -s "set current_listener $lsnr_name\n"
 expect "Current Listener is $lsnr_name"
 send -s "stop\r"
 expect "The command completed successfully"
 send -s "exit\r"
     } else {
  spawn lsnrctl
  send "\n"
  send -s "set current_listener $lsnr_name\n"
  expect "Current Listener is $lsnr_name"
  send -s "set password\r"
  expect "Password: "
  sleep 1
  send -s "$presentpass\r"
  expect "The command completed successfully"
  send -s "stop\r"
  expect "The command completed successfully"
  send -s "exit\r"
 }
}
       
# Procedure to Encrypt the Listener 
# ---------------------------------
#
proc encrypt_listener {HOME ORA_SID ORACLE_HOME lsnr_name presentpass new_pass } {
  if { $presentpass == "" }  {
     puts "New Entry"
     exec cp $HOME/bin/oratask.lst $HOME/bin/oratask.$lsnr_name
     exec echo $ORA_SID:$lsnr_name:$presentpass:asis >> $HOME/bin/oratask.lst
     }

 exec cp $ORACLE_HOME/network/admin/listener.ora $ORACLE_HOME/network/admin/listener.ora.preencrypt
 exec sed "/PASSWORDS_$lsnr_name/d" < $ORACLE_HOME/network/admin/listener.ora > $ORACLE_HOME/network/admin/listener.tmp1
 exec sed "/PASSWORDS_$lsnr_name/d" < $ORACLE_HOME/network/admin/listener.tmp1 > $ORACLE_HOME/network/admin/listener.tmp
 exec mv $ORACLE_HOME/network/admin/listener.tmp $ORACLE_HOME/network/admin/listener.ora
 exec rm $ORACLE_HOME/network/admin/listener.tmp1

 spawn lsnrctl
 send -s "\n"
 send -s "set current_listener $lsnr_name\n"
 expect "Current Listener is $lsnr_name"
 send -s "set password\r"
 expect "Password: "
 sleep 1
 send -s "$presentpass\r"
 expect "The command completed successfully"
 send -s "change_password\r"
 expect "Old password: "
 send -s "$presentpass\r"
 expect "New password: "
 send -s "$new_pass\r"
 expect "Reenter new password: "
 send -s "$new_pass\r"
 expect "The command completed successfully"
 send -s "set password\r"
 expect "Password: "
 sleep 1
 send -s "$new_pass\r"
 expect "The command completed successfully"
 send -s "save_config\r"
 expect "The command completed successfully"
 send -s "exit\r"

 exec cp $HOME/bin/oratask.lst $HOME/bin/oratask.bak
 exec cp $HOME/bin/oratask.lst $HOME/bin/oratask.tmp
 find_replace $ORA_SID:$lsnr_name:$presentpass $ORA_SID:$lsnr_name:$new_pass  $HOME/bin/oratask.tmp  $HOME/bin/oratask.lst
 puts " "
 puts "Password Changed for Listener $lsnr_name"
}

# Procedure to Start the Listener Services
#------------------------------------------
#
proc start_listener {lsnr_name} {
 spawn lsnrctl
 send "\n"
 send -s "set current_listener $lsnr_name\r"
 expect "Current Listener is $lsnr_name"
 send -s "start\r"
 expect "The command completed successfully"
 send -s "exit\r"
}                                                         

#   
#Procedure to verify the status of the listener
#-----------------------------------------------
#
proc status_listener {ORACLE_HOME ORA_SID lsnr_name presentpass} {

 if { $presentpass == "" }  {
   puts "Listener is not Password Protected\n"
    spawn lsnrctl
 send "\n"
 send -s "set current_listener $lsnr_name\r"
 expect "Current Listener is $lsnr_name"
 send -s "status\r"
 expect "The command completed successfully"
 send -s "exit\r"
     } else {
 spawn lsnrctl
 send "\n"
 send -s "set current_listener $lsnr_name\r"
 expect "Current Listener is $lsnr_name"
 exp_send "set password\n"
 expect "Password: "
 sleep 1
 send -s "$presentpass\r"
 expect "The command completed successfully"
 send -s "status\r"
 expect "The command completed successfully"
 send -s "exit\r"
 } 
}

# Procedure to find and replace a string pattern
# ----------------------------------------------

proc find_replace {regexp replacement inputFile outputFile} {
   set fin [open $inputFile r]
   set fout [open $outputFile w]
   while {[gets $fin linein] >= 0} {
       regsub -all $regexp $linein $replacement lineout
       puts $fout $lineout
      }
   close $fin
   close $fout
  } 


#
# Procedure to assist the user
# ----------------------------
#
proc help_listener {ORA_SID} {
  puts ""
  puts "stderr Usage: lstnmgr.sh <ORA_SID> <listener_name> <operation> <newpasswd>"
  puts "        <operation>: start, stop, status, encrypt"
  puts " Examples:"
  puts " lstnmgr.sh ssd9 lstnssd9 status"
  puts " lstnmgr.sh ssd9 lstnssd9 start"
  puts " lstnmgr.sh ssd9 lstnssd9 stop"
  puts " lstnmgr.sh ssd9 lstnssd9 encrypt c0rp0rate"
  puts ""
exit 1
}

# End of TCL Procedures
# ===================

set WHOAMI [exec /usr/bin/whoami]

if { $WHOAMI == "oracle" } {
   puts "User $WHOAMI is in Access Control List. Proceeding Further\n"
   } elseif { $WHOAMI == "oracle50" } {
   puts "User $WHOAMI is in Access Control List. Proceeding Further\n"
   } elseif { $WHOAMI == "oracle9" } {
   puts "User $WHOAMI is in Access Control List. Proceeding Further\n"
   } else {
   puts "User $WHOAMI is NOT in Access Control List. Exiting the program\n"
   exit 1
 } 

puts "PLEASE NOTE: lstnmgr.sh waits for lsnrctl RESPONSE at each stage for ACTION\n"
global env

set HOME $env(ohome)
set ORACLE_HOME $env(ORACLE_HOME)

if { $ORACLE_HOME == "" } {
  puts "The ORACLE_HOME env variable has no value. Exiting\n"
  help_listener $ORA_SID
}                   
if { $argc < 2 } {
 help_listener $ORA_SID
} 

if { $ORA_SID == "" } {
  puts "The ORA_SID env variable has no value. Exiting\n"
  exit 1
} else {
   puts "ORACLE SID is $ORA_SID"
}


if { $HOME == "" } {
  puts "The HOME env variable has no value. Exiting\n"
  help_listener $ORA_SID
}

set PRESENT_PASS $env(PRESENT_PASS)
set presentpass $PRESENT_PASS
set present_pass $presentpass

puts "Environment $ORA_SID is Sourced\n"
#\
PATH=${PATH}:$ORACLE_HOME/bin
#\
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:$ORACLE_HOME/lib
#\
export PATH LD_LIBRARY_PATH
#\


# Perform the Operations designed for
# ------------------------------------
#
switch $operation {
   stop {
    if { $argc < 3 } {
       puts stderr "Script Syntax:"
       puts "$argv0 $ORA_SID $lsnr_name stop"
       exit 1
         }           
     if { $v_status == 0 } {
        puts "Listener $lsnr_name is either not configured or already down"
        exit 1
        } else  {             
       stop_listener $lsnr_name $present_pass
                 }
       } 

  status {
    if { $argc < 3 } {
       puts stderr "Script Syntax:"
       puts "$argv0 $ORA_SID $lsnr_name status"
       exit 1
       }
        if { $v_status == 0 } {
           puts "Listener $lsnr_name is either not configured or already down"
           exit 1
                } else  {                       
       status_listener $ORACLE_HOME $ORA_SID $lsnr_name $presentpass
                        }
         }  

  start  {
    if { $argc < 3 } {
       puts stderr "Script Syntax:"
       puts "$argv0 $ORA_SID $lsnr_name start"
       exit 1
        }             
    if { $v_status == 1 } {
       puts "Listener $lsnr_name is already Running."
       exit 1
         } else { 
            start_listener $lsnr_name
                }
       }
  encrypt {
     if { $argc != 4 } {
       puts stderr "Usage: $argv0 $ORA_SID $lsnr_name encrypt <newpasswd>"
       exit 1
            }                 
     if { $v_status == 0 } {
       puts "Listener $lsnr_name must be Running for the encrypt operation"
       exit 1
         } else  {
         encrypt_listener $HOME $ORA_SID $ORACLE_HOME $lsnr_name $present_pass $new_pass
                 }
       } 
 default {
     puts " There is no Operation called $operation. Please check\n"
     exit 1
        }         
} 

# Summarising the Script Execution
# ---------------------------------
puts " "
puts "Completed Executing $operation with $argv0 on $lsnr_name. Please verify\n"
puts ""
#
# End of Script
