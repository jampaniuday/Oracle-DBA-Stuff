#! /bin/ksh
. $HOME/bin/pocd
ddate=`date +%D`
PASSWD=`$HOME/bin/tellme system`
echo " Database Name $ORACLE_SID "
sqlplus -s system/${PASSWD} << END >> $SID_HOME/audit/ora.error
set verify off termout off feedback off recsep off;
set pagesize 100
set linesize 120
comp sum of nfrags totsiz avasiz on report
break on report
column sumb format 999,999,999
column extents format 9999
column bytes format 999,999,999
column largest format 999,999,999
column Tot_Size format 999,999,999
column Tot_Size format a9 trunc
column Tot_Free format 999,999,999
column Tot_Free format a10 trunc
column Pct_Free format 999,999,999
column Pct_Free format a9 trunc
column Chunks_Free format 999,999,999
column Max_Free format 999,999,999
column Tablespace_name format a16 trunc
column LOCATION format a10 trunc

#tti 'Database Space Summary Report '$1 skip 1 'Tablespace Report as on '$ddate skip 1
column Tablespace_name format a35
column LOCATION format a10
col today new_value v_date noprint
col db_name new_value db_sid noprint
select to_char(SYSDATE,'Month DD, YYYY:HH:MM:SS') today from dual;
select name db_name from v\$database ;
ttitle LEFT db_sid ' - Daily Tablespace Usage Report' RIGHT v_date SKIP 2

spool $SID_HOME/audit/tablespace_report.log
rem select ' Total Size of $ORACLE_SID : ' ||Sum(bytes/1048576) from dba_data_files;
select a.tablespace_name Tablespace_name,
substr(sum(a.tots),1,9) Tot_Size,   substr(sum(a.sumb),1,13) Tot_Free,
substr((sum(a.sumb)*100/sum(a.tots)),1,5) Pct_Free
 from  ( select tablespace_name,0 tots,round(sum(bytes/1024/1024)) sumb              from dba_free_space a
        group by tablespace_name                                                        union
                                                select tablespace_name,sum(bytes/1024/1024) tots,0
        from  dba_data_files                                                            group by tablespace_name) a
                                                group by a.tablespace_name
        order by substr((sum(a.sumb)*100/sum(a.tots)),1,5);
prompt
ttiTLE LEFT db_sid ' - Daily Temp Tablespace Usage Report' RIGHT v_date SKIP 2
select tablespace_name,current_users,max_used_size,max_size from V\$sort_segment;
spool off
END
echo "** --- Database Size in MB --- ** " >>$SID_HOME/audit/tablespace_report.log
echo "** --- Mount points utilization Report- ** " >>$SID_HOME/audit/tablespace_report.log
echo *********Total kbytes  used    avail       %used      Mounted on >>$SID_HOME/audit/tablespace_report.log
`df -k | grep vc01 | sort -n > r.lst;tail -11 r.lst >>$SID_HOME/audit/tablespace_report.log`
echo NOTE :-  >>$SID_HOME/audit/tablespace_report.log
echo If any U* mount point  or Archive mountpoint  Reached 95% Pls take actions to fix the issue >>$SID_HOME/audit/tablespace_report.log
echo * | mailx -s "SPACE REPORT OF POCD" gtsshrd.ortm@ge.com gts.gecisnotifydba@corporate.ge.com victor.esparza@ge.com <$SID_HOME/audit/tablespace_report.log

