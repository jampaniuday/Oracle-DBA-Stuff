#!/bin/ksh
#
# Script Name: ssomgr.sh 
# Author     : Shirdivas Dharmabhotla, GECIS Software, GE Corporate
# Description: To start,stop,status and monitor OracleAS_10g Infrastructure and MiddleTier Services
# Start Date : 13-Oct-2004
# End Date   : 21-Mar-2005

# Begin of Functions
#====================

clear_cache() {
  echo ""
  echo "Clearing cache under $ORACLE_HOME/Apache/modplsql/cache ..."
  for cache_dir in `ls $ORACLE_HOME/Apache/modplsql/cache`; do
    if [ -d $ORACLE_HOME/Apache/modplsql/cache/$cache_dir ]; then
      echo "  Clearing $ORACLE_HOME/Apache/modplsql/cache/$cache_dir"
      #echo would rm -rf $ORACLE_HOME/Apache/modplsql/cache/$cache_dir/*
      find $ORACLE_HOME/Apache/modplsql/cache/$cache_dir -type d -depth | while read nxtdir; do
        if [ "$nxtdir" != "$ORACLE_HOME/Apache/modplsql/cache/$cache_dir" ]; then
          rm -rf $nxtdir
        fi
      done
    fi
  done
  echo ""
}

check_connect() {
  if [ -x $ORACLE_HOME/bin/sqlplus ] ; then
    if [ "$server_type" = "db" ]; then    
      PASSCODE=`$ohome/bin/tellme system` 
    else
      PASSCODE=""
      db_status=NoPassword
      db_host=`tnsping $sid | tr '()' '\n\n' | grep -i ^host= | cut -d= -f2`
      if [ -z "$db_host" ]; then
        echo "\nUnable To Determine Database Host ... not checking connectivity\n"
      else
        if [ -f $HOME/.ssh/batch_config ]; then
          ssh_config_file="-F $HOME/.ssh/batch_config"
        else
          ssh_config_file=""
        fi
        #ssh $ssh_config_file $db_host "bin/$sid; bin/tellme system" 
        PASSCODE=`ssh $ssh_config_file $db_host ". bin/$sid; bin/tellme system" 2>/dev/null`
        if [ -z "$PASSCODE" ]; then
          echo "Unable to determine connection information for $db_host $sid"
          ssh $ssh_config_file $db_host ". bin/$sid"
        fi
      fi
    fi
    if [ -n "$PASSCODE" ]; then
      db_output=`$ORACLE_HOME/bin/sqlplus -S /nolog <<EOF 2>/dev/null
      set feedback off
      connect system@$sid/${PASSCODE}
      set heading off
      select status from v\\$instance;
      exit;
EOF`
      db_status=`echo $db_output| sed 's/Connected\.[ ]*//'` 
      if [ $? -ne 0 ]; then
         db_status=$db_output
      fi
    else
      # don't know password
      echo "Unable to determine password for database $sid"
      db_status=NoPassword
    fi
  else
    db_status=NoExec
  fi
}


roll_logs() {
  svc_name=`echo $1 | cut -c1-4`
  touch_list=""
  log_list=""
  if [ "$svc_name" = "OC4J" -o "$svc_name" = "all" ]; then
    roll_logs_ts=`find $SID_HOME/audit/.roll_logs.j2ee.ts -mtime -1 2>/dev/null`
    if [ -z "$roll_logs_ts" ]
    then
        log_list="`ls $ORACLE_HOME/j2ee/*/application-deployments/*/*/*.log 2>/dev/null` $log_list"
        touch_list="$SID_HOME/audit/.roll_logs.j2ee.ts"
    fi
  fi
  
  if [ "$svc_name" = "HTTP" -o "$svc_name" = "all" ]; then
    roll_logs_ts=`find $SID_HOME/audit/.roll_logs.http.ts -mtime -1 2>/dev/null`
    if [ -z "$roll_logs_ts" ]
    then
        log_list="`ls $ORACLE_HOME/Apache/modplsql/logs/log.xml $ORACLE_HOME/Apache/logs/sm*.log 2>/dev/null` $log_list"
        touch_list="$SID_HOME/audit/.roll_logs.http.ts $touch_list"
    fi
  fi
    
  if [ "$svc_name" = "WebC" -o "$svc_name" = "all" ]; then
    if [ "$1" != "WebCacheAdmin" -a -d "$ORACLE_HOME/webcache/logs" ]; then
      #can't roll logs unless all WebCache is down, not just Admin
      roll_logs_ts=`find $SID_HOME/audit/.roll_logs.webcache.ts -mtime -1 2>/dev/null`
      if [ -z "$roll_logs_ts" ]
      then
        log_list="`ls $ORACLE_HOME/webcache/logs/*log 2>/dev/null` $log_list"
        touch_list="$SID_HOME/audit/.roll_logs.webcache.ts $touch_list"
      fi
    fi
  fi
  
  if [ "$svc_name" = "all" ]; then
    roll_logs_ts=`find $SID_HOME/audit/.roll_logs.opmn.ts -mtime -1 2>/dev/null`
    if [ -z "$roll_logs_ts" ]
    then
      for fname in `ls -d $ORACLE_HOME/opmn/logs/*`; do
       if [ -f "$fname" -a "`echo $fname | grep -c '\.[0-9][0-9]*$'`" -eq 0 ]; then
          log_list="$log_list $fname"
        fi
      done
      touch_list="$SID_HOME/audit/.roll_logs.opmn.ts $touch_list"
    fi
  fi
      
  if [ "$svc_name" = "oem" ]; then
    roll_logs_ts=`find $SID_HOME/audit/.roll_logs.oem.ts -mtime -1 2>/dev/null`
    if [ -z "$roll_logs_ts" ]
    then
        log_list="`ls $ORACLE_HOME/sysman/log/*.log $ORACLE_HOME/sysman/log/*.trc $ORACLE_HOME/sysman/log/*.nohup 2>/dev/null` $log_list"
        touch_list="$SID_HOME/audit/.roll_logs.oem.ts $touch_list"
    fi
  fi

  for logname in $log_list
  do
    highest_version=`ls ${logname}.* 2>/dev/null \
        | awk -F. '/\.[0-9][0-9]?[0-9]?$/ {print $NF}' | sort -n | tail -1`
    if [ ! -z "$highest_version" ]
    then
      # found $logname.[0-9]+  --- rename each file increasing version number
      # by 1 (access_log.3 will become access_log.4 )
      version=$highest_version
      while [ $version -gt 0 ]
      do
        new_version=`expr $version + 1`
        if [ -f "${logname}.${version}" ] 
        then
          mv ${logname}.${version} $logname.${new_version}
          chmod g+w $logname.${new_version}
	fi
        version=`expr $version - 1`
      done
    fi
    mv ${logname} ${logname}.1
    chmod g+w ${logname}.1
  done
  if [ -n "$touch_list" ]; then
    touch $touch_list
  fi
}

status_services() {
s_type=$1
echo "Status $upper_tier for $upper_sid $scope"
echo ""
check_connect
if [ "$db_status" != "OPEN" -a "$db_status" != "NoPassword" ]; then
  echo "$sid database is unavailable at `date`"
  echo "$db_status"
  echo ""
else
echo DB status is $db_status
fi
if [ "$scope" != "oem" ]; then
  $ORACLE_HOME/opmn/bin/opmnctl ping >/dev/null
  if [ $? -eq 0 ]; then
    echo opmnctl is Alive
  fi
  $ORACLE_HOME/opmn/bin/opmnctl status
fi
echo "OEM Status:"
if [ -z "$scope" ]; then
  oem_up=`$ORACLE_HOME/bin/emctl status iasconsole | grep ' Control is running.'`
  if [ -n "$oem_up" ]; then
    echo "$oem_up"
    # otherwise, "not running" message gets written to stdout, so already seen
  fi
  echo ""
else
  if [ "$scope" = "oem" ]; then
    $ORACLE_HOME/bin/emctl status iasconsole 
    echo ""
  fi
fi
if [ -z "$scope" -o "$scope" = "oid" ]; then
  if [ "$s_type" = "db" ]; then
    $ORACLE_HOME/ldap/bin/ldapcheck
  fi
fi

if [ -x $ORACLE_HOME/bin/ldapbind -a "$scope" != "oem" ]; then
  echo "\nChecking OID Connectivity..."
  oid_pwd=`$HOME/bin/tellme orcladmin`
  #oid_port=`grep '^port:' $ORACLE_HOME/ldap/oidadmin/osdadmin.ini  | cut -d: -f2`
  #oid_host=`grep '^host:' $ORACLE_HOME/ldap/oidadmin/osdadmin.ini  | cut -d: -f2`
  oid_host=`grep '^OIDhost=' $ORACLE_HOME/config/ias.properties | cut -d= -f2`
  oid_port=`grep '^OIDport=' $ORACLE_HOME/config/ias.properties | cut -d= -f2`
  if [ -n "$oid_pwd" ]; then
    $ORACLE_HOME/bin/ldapbind -h "$oid_host" -p $oid_port -D "cn=orcladmin"\
       -w "$oid_pwd" 
  else
    $ORACLE_HOME/bin/ldapbind -h "$oid_host" -p $oid_port 
  fi
  echo ""
fi
echo "Completed Verifying $upper_tier Services Status for $upper_sid"

}

start_services() {

check_connect
if [ "$db_status" != "OPEN" -a "$db_status" != "NoPassword" ]; then
  echo "$sid database is unavailable at `date`"
  echo "$db_status"
  echo ""
  echo "Skipping Starting $upper_tier $scope for $upper_sid"
  tmp_status=1
  return $tmp_status
fi
echo "Starting $upper_tier $scope for $upper_sid at `date` ..."
if [ -z "$scope" ]; then
  aged_cache="`find \
     $ORACLE_HOME/Apache/modplsql/cache \
       -type f -mtime +1 -print | head -1 2>/dev/null`"
else
  aged_cache=""
fi

if [ "$clearcache" = "true" -o -n "$aged_cache" ]; then
  clear_cache
fi
export tmp_status
tmp_status=0
if [ "$scope" != "oem" ]; then
  echo ""
  if [ -z "$comp_name" ]; then
    echo "Starting $nxt_tier OPMN Services..."
    if [ -f $SID_HOME/audit/opmn.blackout ]; then 
      rm -f $SID_HOME/audit/opmn.blackout
    fi
    if [ -f $SID_HOME/audit/opmn.blackout ]; then 
      echo ""
      echo "!!! WARNING ... Unable to delete $SID_HOME/audit/opmn.blackout"
      echo ""
   fi

    # make sure opmn is down before rolling logs
    $ORACLE_HOME/opmn/bin/opmnctl ping >/dev/null 2>&1
    if [ $? -eq 1 ]; then
      roll_logs all
    fi
    $ORACLE_HOME/opmn/bin/opmnctl startall
    tmp_status=$?
   else
    is_running=`$ORACLE_HOME/opmn/bin/opmnctl status 2>/dev/null |\
      grep "$comp_name" | grep -c 'Alive'`
    if [ "$is_running" -eq 0 ]; then
      if [ "$comp_name" = "WebCacheAdmin" ]; then
        $ORACLE_HOME/opmn/bin/opmnctl startproc process-type=WebCacheAdmin
        tmp_status=$?
      else
        $ORACLE_HOME/opmn/bin/opmnctl startproc ias-component=$comp_name
        tmp_status=$?
      fi
    else
      echo "$comp_name is already running"
    fi
  fi
  echo "" 
  echo "Gathering DCM state"
  echo ""
  $ORACLE_HOME/dcm/bin/dcmctl getstate -v
  status=$?
  tmp_status=`expr ${tmp_status} \| $status`
  echo ""
  echo "OPMN Status"
  $ORACLE_HOME/opmn/bin/opmnctl status
  status=$?
  tmp_status=`expr ${tmp_status} \| $status`
  echo ""
fi

if [ -z "$scope" -o "$scope" = "oem" ]; then
  echo "Starting $ORACLE_HOME EM Website..."
  echo ""
  oem_up=`$ORACLE_HOME/bin/emctl status iasconsole 2>/dev/null | grep ' Control is running.'`
  if [ -z "$oem_up" ]; then
    roll_logs oem
    # $ORACLE_HOME/bin/emctl startifdown iasconsole
    echo Y | $ORACLE_HOME/bin/emctl start iasconsole
    status=$?
    tmp_status=`expr ${tmp_status} \| $status`
  else
     echo "EM Website is already running."
     tmp_status=0
  fi
  echo "" 
fi
echo "Completed Starting $upper_tier Services for $upper_sid $scope - return code is $tmp_status"
echo ""
return $tmp_status
}
       
stop_services() {

check_connect
if [ "$db_status" != "OPEN" -a "$db_status" != "NoPassword" ]; then
  echo "$sid database is unavailable at `date`"
  echo $db_status
  echo ""
  if [ "force_it" = "true" ]; then
    echo ""
    echo "Will attempt to stop services ... -force was specified"
    echo "Press Ctrl-C to stop"
    sleep 10
  else
    echo "Skipping Stopping $upper_tier $scope for $upper_sid"
    tmp_status=1
    return $tmp_status
  fi
fi

echo "Stopping $upper_tier $scope for $upper_sid at `date` ..."
tmp_status=0
if [ "$scope" != "oem" ]; then
  if [ -z "$comp_name" ]; then
    if [ -n "$SID_HOME" -a -d $SID_HOME/audit ]; then 
      touch $SID_HOME/audit/opmn.blackout
    fi
    $ORACLE_HOME/opmn/bin/opmnctl stopall
    tmp_status=$?
    $ORACLE_HOME/opmn/bin/opmnctl ping >/dev/null
    if [ "$?" -eq 0 ]; then
      #OPMN is down - ignore error
      tmp_status=0
    fi
  else
    if [ "$comp_name" = "WebCacheAdmin" ]; then
      $ORACLE_HOME/opmn/bin/opmnctl stopproc process-type=WebCacheAdmin
      tmp_status=$?
    else
      $ORACLE_HOME/opmn/bin/opmnctl stopproc ias-component=$comp_name
      tmp_status=$?
    fi
    is_running=`$ORACLE_HOME/opmn/bin/opmnctl status 2>/dev/null |\
      grep "$comp_name" | grep -c 'Alive'`
    if [ "$is_running" -eq 0 ]; then
      tmp_status=0
    fi
  fi
fi
if [ "$clearcache" = "true" ]; then
  clear_cache
fi
echo
if [ -z "$scope" -o "$scope" = "oem" ]; then
  echo "Stopping $ORACLE_HOME EM Website..."
  echo ""
  $ORACLE_HOME/bin/emctl stop iasconsole
  status=$?
  tmp_status=`expr ${tmp_status} \| $status`
  oem_up=`$ORACLE_HOME/bin/emctl status iasconsole 2>/dev/null| grep ' Control is running.'`
  if [ -z "$oem_up" ]; then
    # assume OEM already down
    tmp_status=0
  fi
  echo "" 
fi

#echo "Gathering Components Status"
#$ORACLE_HOME/opmn/bin/opmnctl status
#status=$?
#tmp_status=`expr ${tmp_status} \| $status`
echo ""
echo "$nxt_tier $scope Services Stopped for $sid - return code is $tmp_status"
echo ""
return $tmp_status
}

helpme() {
   echo ""
 action=$1
 dbsid=$2
 tier=$3
   echo "Usage: $0 <action> <dbsid> <tier> <scope> [-clearcache] [-force]"
   echo "Example: $0 start ssos infra"
   echo "         $0 stop ssos midtier"
   echo "         $0 status ssos all"
   echo "         $0 start all all"
   echo "         $0 monitor"
   echo ""         
   echo "  all is assumed for dbsid and tier unless specified"
   echo ""
   #echo "Note: Please stop mid-tier services first, and then Infra services"
   #echo "Note: Please Start Infra Services first and then Mid-tier services"
   #echo ""
}

########################################################################
## notify() function
########################################################################
notify() {
what_failed=$1
pager_msg=$2
## 
## get oncall info
##
if [ -f $ohome/bin/notify.ctl ]
then
  ooncall=`cat $ohome/bin/notify.ctl | awk -F: '
    BEGIN {firstsw = 1}
    {if (firstsw == 1 && $1 == "all" && $2 == "all" && NF > 2) {
       print $3; firstsw = 0}}'`
  if [ -z "$ooncall" ]
  then
    ooncall=linda.slyer
  fi
  oncall_numbers=`grep "#$ooncall" $ohome/bin/notify.ctl`
  if [ ! -z "$oncall_numbers" ]
  then
    opager=`echo $oncall_numbers | cut -d: -f2`
    owork_phone=`echo $oncall_numbers | cut -d: -f3`
    ohome_phone=`echo $oncall_numbers | cut -d: -f4`
  else
    ooncall=linda.slyer
    opager=5184846581
    owork_phone=8*5647533
    ohome_phone=5182726757
  fi

  oserver=`cat $ohome/bin/notify.ctl | awk -F: -v host="$host" '
    BEGIN {firstsw = 1}
    {if (firstsw == 1 && $1 == host && $2 == "all" && NF > 3) {
       print $0; firstsw = 0}}'`
  if [ -z "$oserver" ]
  then
    oserver_rep=linda.slyer
    osupport_level=bronze
  else
    oserver_rep=`echo $oserver | cut -d: -f3`
    osupport_level=`echo $oserver | cut -d: -f4`
  fi
else
  ooncall=linda.slyer
  opager=5184846581
  owork_phone=8*5647533
  ohome_phone=5182726757
  oserver_rep=linda.slyer
  osupport_level=bronze
fi

ooncall=GTSOHR.LeadDBAs
osupport_level=ohr
echo "On call: $ooncall support: $osupport_level"
## 
## end of oncall setup
##

  echo ""
  echo " !!! Error occurred trying to $action $upper_tier $upper_sid process $scope"
  echo "     on $host"
  echo ""
  #echo "Unable to $action $what_failed on $host" | $MAIL_EXE -s "$host $sid $nxt_tier abended" $ooncall@corporate.ge.com
  $DBA_HOME/admin/notify.sh -s "$host $sid $nxt_tier abended" -b "Unable to $action $what_failed on $host" -w sid
  #if [ "$oserver_rep" != "$ooncall" ]
  #then
  #  echo "Unable to $action $what_failed on $host" | $MAIL_EXE -s "$host $sid $nxt_tier abended" $oserver_rep@corporate.ge.com
  #fi
  #if [ "$osupport_level" = "bronze" ]
  #then
  #  echo "     Contact ORACLE DBA 8AM next workday"
  #  echo "     $ooncall work: $owork_phone "
  #  echo ""
  #else
  #  echo "     Contact ORACLE DBA IMMEDIATELY "
  #  echo "     $ooncall home: $ohome_phone pager: $opager "
  #  echo ""
  #  echo "$ohost $pager_msg \n $ssomgr abended" | $MAIL_EXE $opager
  #fi
  $DBA_HOME/admin/notify.sh -p "$ohost $pager_msg $ssomgr abended" -L gold -w sid
}
##
##  end of notify()
##

# End of Functions
#==================

# Begin of Main Logic
#=====================
#
 user=`id|cut -d"(" -f2|cut -d")" -f1`
 if [ "$user" = "root" ]; then
   echo "${1}ing Oracle Application Server."
   echo "This will take several minutes"
   su oracle -c "$0 $*"
   exit $?
 fi
 if [ "$user" != "oracle" ]; then
   echo "You must be oracle to run this script"
   exit 1
 fi
 num_params=$#
 clearcache=false
 force_it=false
 typeset -i param_cnt=1
 next_param=action
 while [ $param_cnt -le $num_params ]; do
   case $1 in
     -clearcache) clearcache=true
                  ;;
     -force) force_it=true
             ;;
     *) 
        case $next_param in 
          action) action=$1
                  next_param=dbsid
                  ;;
          dbsid) dbsid=$1
                 next_param=tier
                 ;;
          tier) tier=$1
                next_param=scope
                ;;
          scope) scope=$1
                 next_param=alldone
                 ;;
          *) helpme
             exit 0
             ;;
        esac
   esac
   shift       
   param_cnt=param_cnt+1
 done
# action=$1
# dbsid=$2
# tier=$3
# scope=$4

 if [ $clearcache = "true" -a -n "$scope" ]; then
   echo "$0: -clearcache is incompatible with specifying a scope"
   exit 0
 fi
 if [ $clearcache = "true" ]; then
   if [ "$action" != "start" -a "$action" != "stop" ]; then
     echo "$0: -clearcache can only be used with stop or start"
     exit 0
   fi
 fi
 if [ "$force_it" = "true" -a "$action" != "stop" ]; then
   echo "$0: -force can only be used with stop"
   exit 0
 fi

 if [ "$action" != "start" -a "$action" != "stop" -a "$action" != "status" -a "$action" != "monitor" ]; then
   helpme
   exit 0
 fi
 ts=`date +%m%d_%H%M%S`
 audit_file="/dev/null"
 if [ -z "$dbsid" ]; then
   dbsid=all
   tmp_audit_file=/tmp/ssomgr.audit$ts
   audit_file=$tmp_audit_file
 fi
 if [ -z "$tier" ]; then
   tier=all
 fi

 GREP=/usr/xpg4/bin/grep
 host=`hostname`
 export dbsid
 export tier
 export action 
 export GREP
 server_name=`uname -a | awk '{print $2}'`
 export server_name
 DISPLAY=$server_name:0.0; export DISPLAY
 ohome=`grep '^oracle:' /etc/passwd | cut -d: -f6`
 ctlfile=${ohome}/bin/ssomgr.ctl
 if [ ! -f "$ctlfile" ]; then
   echo "$0: controlfile not found"
   exit 1
 fi
 tmp_status=0

 if [ "$tier" = "all" ]; then
   if [ "$action" = "stop" ]; then
     tier="midtier infra"
   else
     tier="infra midtier"
   fi
 fi

echo ""
tier=`echo ${tier} | tr "[:upper:]" "[:lower:]"`
action=`echo ${action} | tr "[:upper:]" "[:lower:]"`

if [ "$dbsid" = "" ] || [ "$tier"  = "" ] || [ "$action" = "" ] ; then
   echo "Instance Name, Tier and Option are mandatory Inputs. Exiting the Program now"
   helpme
   exit 1
fi      

OS_TYPE=`uname`

if [ "$OS_TYPE" = "SunOS" ] || [ "$OS_TYPE" = "OSF1" ]; then
  MAIL_EXE=mailx
else
  if [ "$OS_TYPE" = "Linux" ] ; then
     MAIL_EXE=mail
   else
     echo "Script Not Ported for this OS"
     exit 1
   fi
fi

if [ "$dbsid" = "all" ]; then
  dbsid=`grep -E "^((localhost)|(${host})):" $ctlfile | cut -d: -f2 | sort -u`
fi

exit_code=0
for sid  in ${dbsid}; do
  for nxt_tier in $tier; do

  instance=`sed 's/#.*$//' $ctlfile | grep -E "^((localhost)|(${host})):${sid}:${nxt_tier}:"  | cut -d: -f4`
  if [ -z "$instance" ]; then
     continue
  fi
   
  if [ ! -f $ohome/bin/$instance ] ; then
       echo "$ohome/bin/$instance not found. Skipping "
       echo "$ohome/bin/$instance not found. Skipping " >> $audit_file
       echo "" >> $audit_file
       exit_code=1
       continue
  else
   . $ohome/bin/$instance
  fi
  if [ -n "$DBA_HOME" -a "$audit_file" != "/dev/null" -a  "$tmp_audit_file" = "$audit_file" ]; then
     audit_file=/$DBA_HOME/audit/ssomgr.audit$ts
     if [ -f "$tmp_audit_file" ]; then
       mv $tmp_audit_file $audit_file
     fi
  fi
  if [ -n "$scope" -a "$scope" != "oem" ]; then
    if [ `echo $scope | tr [:upper:] [:lower:]` = "webcacheadmin" ]; then
      comp_name="WebCacheAdmin"
    else
      comp_name=`$ORACLE_HOME/opmn/bin/opmnctl status | awk '{
           if ( $1 !~ /----/ && $1 != "Processes" && $1 != "ias-component" ) 
              {print $1}}' \
         | grep -i "$scope" | sort -u`
     fi
     if [ -z "$comp_name" ]; then
       echo component not found in $nxt_tier $sid for $scope --- skipping
       continue
     fi
  else
    comp_name=""
  fi

  upper_tier=`echo $nxt_tier | tr "[:lower:]" "[:upper:]"` 
  upper_sid=`echo $sid | tr "[:lower:]" "[:upper:]"` 
  echo ""
  echo ""

   if [ "$action" = "infra" ] ; then
     # note --valid actions are start,stop,status,monitor. so code will never be executed

     if  [ ! "`ps -ef|$GREP pmon_$instance|grep -v grep`" ]; then
          echo "Instance $instance is Down."
          exit 1
     else
          echo "Instance $instance is Active"
     fi
   else
      echo ""
   fi


   server_type=`sed 's/#.*$//' $ctlfile |
       grep -E "^((localhost)|(${host})):${sid}:${nxt_tier}:"  | cut -d: -f5 `
   case $action in
      start) if [ "$audit_file" = "/dev/null" ]; then
	       start_services 
               status=$?
             else
	       start_services >>$audit_file 2>&1
               status=$?
             fi
             exit_code=`expr $status \| $exit_code ` 
             ;;
       stop) if [ "$audit_file" = "/dev/null" ]; then
               stop_services 
	       status=$?
             else
               stop_services >>$audit_file 2>&1 
	       status=$?
             fi  
             exit_code=`expr $status \| $exit_code `
             ;;
     status) status_services $server_type 
             status=0
             ;;
     monitor) 
opmn_infra=`awk -F: '{ if ($2 == "infra" && $4 == "db") {print $3}}' $ohome/bin/ssomgr.ctl`
opmn_midtier=`awk -F: '{ if ($2 == "midtier" && $4 == "db") {print $3}}' $ohome/bin/ssomgr.ctl`

 if [ "$opmn_infra" != "" ] ; then
   . $ohome/bin/$opmn_infra
   $ORACLE_HOME/opmn/bin/opmnctl ping >/dev/null
   if [ $? -eq 0 ]; then
       echo 0
    else
       echo 1
    fi
 fi

 if [ "$opmn_midtier" != "" ] ; then
   . $ohome/bin/$opmn_midtier
     $ORACLE_HOME/opmn/bin/opmnctl ping >/dev/null
     if [ $? -eq 0 ]; then
        echo 0
     else
       echo 1
     fi
 fi
   exit 0
   ;;
          *) echo "This Option $action is Not Valid. Please check. Exiting the Program now"
              helpme
              exit 1
          ;;
   esac             
   if [ "$status" -ne 0 ]; then
     notify "SSO/OID $instance" "SSO/OID $nxt_tier $sid"
   fi
 done
done

echo ""
echo "$0 exiting with status of $exit_code"
if [ "$audit_file" != "/dev/null" -a -f "$audit_file" ]; then
  cat $audit_file
  echo "" >> $audit_file
  echo "`date`: $0 exiting with status of $exit_code" >> $audit_file
fi
exit $exit_code
