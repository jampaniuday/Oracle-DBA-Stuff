#!/bin/bash
#
# blackout.sh

# Niyi Oshinowo GE Database Technology Services 01/20/2009
#
# To start and stop blackout.
#
# Params:
# 1: DB_SID; required
# 2: DB_BLK_TYPE; required: (start or stop)
# 3: DB_MAINTENANCE_TYPE; required
# 4: DB_BLK_DURATION; required

#set -x  # turn on debug
#set +x  # turn off debug

. $HOME/bin/$1
. ${HOME}/bin/oemagent

Blackout1=1
Blackout2=2

 # check supplied parameters
if [ ${1} ] && [ ${2} ] && [ ${3} ]
then
 # handle parameter
  DB_SID=${1}
  DB_BLK_TYPE=${2}
  DB_MAINTENANCE_TYPE=${3}
  DB_BLK_DURATION=${4}

 # check for oemagent Environmental variables

if [ ! -f $HOME/bin/oemagent ]; then
  echo "Environment script does not exists for OEM Agent." >$SID_HOME/audit/err_
message
  $DBA_HOME/admin/notify.sh -s "Environment script does not exists for OEM Agent
" > -f $SID_HOME/audit/err_message -w sid
  exit 1
fi
else
echo "supplied parameter not complete!"
echo " "
echo "See usage below"
echo "DB_SID (required)"
echo "Blackout type (required);1 to start and 0 to stop "
echo "Maintenance reason (required); 0 for db log recovery,1 for db cold backup and 2 for db shutdown "
echo "Blackout Duration (not required); blackout duration in minutes otherwise blackout duration will be set for forever!"
 exit 1
fi


# check DB_MAINTENANCE_TYPE
case $DB_MAINTENANCE_TYPE
#case "$3"
in
0) DB_MAINTENANCE_USE="Db Log Recovery"
;;

1) DB_MAINTENANCE_USE="Db cold Backup"
;;

2) DB_MAINTENANCE_USE="Db Shutdown"
;;

*) echo "Bad argument; please specify a 0=db log recovery,1=db cold backup,2=db shutdown"
exit 1

esac


# check DB_BLK_DURATION

if [ $DB_BLK_DURATION -gt 0 ]
then
DB_BLK_DURATION_USE="$DB_BLK_DURATION"
##echo "DB_BLK_DURATION use in 1st loop isb" $DB_BLK_DURATION
##elif ["$DB_BLK_DURATION_CHECK" = "$DB_BLK_DURATION"]
##then
##echo "null _DURATION "

#[ "$count" -ge 0   -a   "$count" -lt 10 ]
else
DB_BLK_DURATION_USE=null
fi

if [ $DB_BLK_DURATION -gt 0 ]; then
DB_BLK_DURATION_USE=$DB_BLK_DURATION
##  echo "DB_BLK_DURATION is positive"
elif [ -z "$DB_BLK_DURATION" ]
then
DB_BLK_DURATION_USE=$DB_BLK_DURATION
##  echo "DB_BLK_DURdddddddddddddATION is null"
else
DB_BLK_DURATION_USE=$DB_BLK_DURATION
##  echo "Opps! DB_BLK_DURATION is not number, give number"
fi

if [ \( "$DB_BLK_DURATION" -gt 0 \)  -o \( -z "$DB_BLK_DURATION" \) ]; then
DB_BLK_DURATION_USE=$DB_BLK_DURATION
##  echo "DB_BLK_DURATION is positive or null"

fi

# id the target for blackout


use_target1="`echo`emctl config agent listtargets|grep $1|grep oracle_database ` `|awk -F\, {'print $"$Blackout1"'} ` `|awk -F\[ {'print $"$Blackout2"'} `` "
use_target="`$use_target1 |grep $1`"
use_blackout_name="`echo $1 $DB_MAINTENANCE_USE Scheduled Maintenance `"

##echo "Input"
##echo "DB_SID" $DB_SID
##echo "DB_BLK_TYPE" $DB_BLK_TYPE
##echo "DB_MAINTENANCE_TYPE" $DB_MAINTENANCE_USE
##echo "DB_BLK_DURATION" $DB_BLK_DURATION
##echo "use_target"$use_target1
##echo "use_blackout_name" $use_blackout_name

# check DB_BLK_TYPE
case $DB_BLK_TYPE
#case "$1"
in
0) echo "Ending Blackout..."
    emctl stop blackout "$use_blackout_name";;

1) if [ "$DB_BLK_DURATION" -gt 0 ]; then
echo "Starting Blackout..."
emctl start blackout "$use_blackout_name" $use_target:oracle_database -d $DB_BLK_DURATION;
else
echo "Starting Blackout forever ..."
emctl start blackout "$use_blackout_name" $use_target:oracle_database;
fi
;;
*) echo "Bad argument; please specify a 0= stop blackout or 1=Strat Balackout"
exit 1
esac
# check targets in blackout
echo "Targets in blackout :"
emctl status blackout
#exit 0
