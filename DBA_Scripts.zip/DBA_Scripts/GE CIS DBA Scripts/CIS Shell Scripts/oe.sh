#!/bin/ksh
##############################################################################################
# This script is ment to help DBA's for auditing Operation Excellence check on the databases.#
# Script will check existence of Database users as per our standard in instance and in       #
# oratask.list file. Also provide following information Entry in Purge.ctl, Entry in oratab, #
# Job scheduled in Autosys, Archive log mode status, Archive log destination, Validate the   #
# perfstat userid/pwd found in oratask, Location listed in backup.ctl, Dump (bdump, cdump,   #
# udump) destinations for the instance, Rman.ctl if database is configured in RMAN, Entry in #
# Inventory Application Portal. Also provide the information regarding size of the REDO Log  #
# files if size is set below 100M.                                                                                                #
# Moreover it will give ue cumulative report when we provide "all" as a parameter.               #
# The script can be run for one instance or for all the instances that are up and running.   #
# Output of the script will be emailed to the concerned persons and team.                    #
##############################################################################################
# Output:                                                                                        #
# Output will get generate in the form of mail and it depends upon the parameter passed      #
# 1) Detailed report if "SID" is passed as a parameter.                                          #
# 2) Cumulative report at server level if "all" is passed as a parameter                     #
# 3) The script must be executed from the Oracle OS user who is the owner for that instance. #
# In Cumulative report information will generate in the form of YES/NO format,NO if there  #
# is any miss and YES when database is configured fine in a particular category.           #
##############################################################################################
# Usage  : oe_check.sh {sid|all}                                                             #
# Author : Anjul Agarwal                                                                     #
##############################################################################################
AUDIT_FILE="all_instances_`date +%B:%d,%Y`"
FILEPATH="/tmp"
# rm $FILEPATH/$AUDIT_FILE
touch $FILEPATH/$AUDIT_FILE
ssh cisdwp006 ". ~/bin/patr; sh /patrp006/dba01/oracle/patr/admin/dbinfo.sh"
scp -p oracle@cisdwp006:/tmp/dbinfo.ctl /tmp
ssh cisdwp006 "rm /tmp/dbinfo.ctl"

echo "##################################OPERATION EXCELLENCE CHECK ON `hostname`##########################################\n" >> $FILEPATH/$AUDIT_FILE
#######################################################Main calling Block###########################################
echo "####################################################################################################################">> $FILEPATH/$AUDIT_FILE
echo "|Sno.|Instance Name|                                  Entries for                                                       ">> $FILEPATH/$AUDIT_FILE
echo "|                  |------------------------------------------------------------------------------------------------">> $FILEPATH/$AUDIT_FILE
echo "|                  | Schema(BB,PERF,NG,QUA)| Oratask.lst | Oratab | Purge.ctl |  Autosys  |  LOG MODE  |  Inventory |                 ">> $FILEPATH/$AUDIT_FILE
echo "####################################################################################################################">> $FILEPATH/$AUDIT_FILE

if [ -z "$1" ]
then
   echo "Usage is : oe_check.sh {sid|all} "
   exit 1
fi

if [ $1 = "all" ]
then
#   allsid=`ps -eo comm | grep pmon | cut -d_ -f3|xargs echo`
    allsid=`ps -ef | grep pmon | grep -v grep | awk '{print $8}' | cut -d_ -f3 | xargs echo`
parameterpassed="all"
    else
   ps -ef | grep pmon | grep $1 > /dev/null 2>&1
   if [ $? -eq 0 ]
   then
      allsid=$1
   else
      echo "Please check the SID, The instance must be up."
      exit 1
   fi
fi
CNT=1;

for ALLS in $allsid
do
                os_user=`ps -ef | grep pmon | grep $ALLS | awk '{print $1}'`
                if [ -f $HOME/bin/$ALLS -a "$os_user" = "$LOGNAME" ]
                then
                . $HOME/bin/$ALLS
                        if [ "$ORACLE_SID" = "$ALLS" ]
                        then
                                #PASSWD=`$HOME/bin/tellme system`
                                #sqlplus -s  system/${PASSWD} <<EOF
sqlplus /nolog <<EOF >$FILEPATH/$ALLS.log
set head off
conn / as sysdba;
set pagesize 100
set linesize 120
                                #spool $FILEPATH/$ALLS.log
archive log list
select username from dba_users where username in ('BBMON','QUESTADMIN','PERFSTAT','NGSSQUIRREL');

select a.GROUP\#, b.MEMBER, (a.bytes)/1024/1024 MB from v\$log a, V\$LOGFILE b where a.GROUP\#=b.GROUP\# and a.bytes/1024/1024<=200;

show parameter dump
#                               spool off
exit;
EOF
                        fi
                fi
echo "\t-----------------------------------------------------------"    >$FILEPATH/$ALLS.out
echo "\t-----------------------------------------------------------">>$FILEPATH/$ALLS.out
echo "\tOPERATION EXCELLENCE CHECK for $ALLS INSTANCE ON : `uname -a | cut -c7-15`"     >>$FILEPATH/$ALLS.out
echo "\t-----------------------------------------------------------" >>$FILEPATH/$ALLS.out
echo "\t-----------------------------------------------------------\n" >>$FILEPATH/$ALLS.out
echo " Schema Present in $ALLS" >> $FILEPATH/$ALLS.out
echo "-------------------------\n" >> $FILEPATH/$ALLS.out

###SCHEMA CHECK AT INSTANCE LEVEL

                for schemauser in  "BBMON" "QUESTADMIN" "PERFSTAT"  "NGSSQUIRREL"
                do
                        user_check="`cat $FILEPATH/$ALLS.log|grep $schemauser`"
                        if [ -z $user_check ];then
                        echo "User Name :$schemauser Does Not Exist" >>$FILEPATH/$ALLS.out
                        else
                                echo "User Name :$schemauser Exist" >>$FILEPATH/$ALLS.out
                        fi
                done
                instanceschemastatus="YES"
                for instanceschemauser in  "BBMON" "QUESTADMIN" "PERFSTAT"  "NGSSQUIRREL"
                do
                        user_check="`cat $FILEPATH/$ALLS.log|grep $instanceschemauser`"
                        if [ -z $user_check ];then
                        echo "User Name :$instanceschemauser Does Not Exist"
                        instanceschemastatus="NO"
                        else
                                echo "User Name :$instanceschemauser Exist"
                        fi
                done

### PERFSTAT VALIDATION

sqlplus perfstat/`tellme perfstat`  <<EOF > $FILEPATH/$ALLS_perfstat.log
show user
exit;
EOF
                perfstat_user="`cat $FILEPATH/$ALLS_perfstat.log|grep -i perfstat`"

                echo "\n" >>$FILEPATH/$ALLS.out
                echo " Perfstat Validation in Oratask.lst">>$FILEPATH/$ALLS.out
                echo "------------------------------------\n" >> $FILEPATH/$ALLS.out
                echo $perfstat_user
                if [ -z $perfstat_user ]
                then
                echo " Not Able To Login: Entry in oratask.lst is not valid"
                echo " Not Able To Login: Entry in oratask.lst is not valid" >>$FILEPATH/$ALLS.out
                else
                echo " Entry in oratask.lst is valid">>$FILEPATH/$ALLS.out
                fi

###INVENTORY CHECK



                echo "\n" >>$FILEPATH/$ALLS.out
                echo " Inventory Check" >> $FILEPATH/$ALLS.out
                echo "------------------\n" >> $FILEPATH/$ALLS.out

                servernamentry=`hostname`
                inventory="`cat /tmp/dbinfo.ctl|grep -e $ALLS|grep -e $servernamentry`"
                echo $inventory

                if [ -z $inventory ]
                        then
                                echo "Entry Does Not Exist.. Plz Update Inventory Portal" >> $FILEPATH/$ALLS.out
                        invetorystatus="NO"
                else
                                echo "Entry Exist ">> $FILEPATH/$ALLS.out
                        invetorystatus="YES"
                fi

### LOG MODE CHECK
                echo "\n" >>$FILEPATH/$ALLS.out
                echo " Database Log Mode" >> $FILEPATH/$ALLS.out
                echo "-------------------\n" >> $FILEPATH/$ALLS.out

                        arch_destination="`cat $FILEPATH/$ALLS.log|grep destination`"
                        echo "$arch_destination"
                        arch_check="`cat $FILEPATH/$ALLS.log|grep Archive|grep No`"
                        if [ -z $arch_check ];then
                        echo "User Name : DB in ARCHIVE MODE ............"
                        echo "Database log mode              Archive Mode">>$FILEPATH/$ALLS.out
                        echo  " $arch_destination " >>$FILEPATH/$ALLS.out
                        echo "\n" >>$FILEPATH/$ALLS.out
                        echo " Dump Destination" >>$FILEPATH/$ALLS.out
                        echo "------------------\n" >> $FILEPATH/$ALLS.out
                                for i in `cat $FILEPATH/$ALLS.log|grep -e dest|grep -e dump|awk '{print $1$2$3}'`
                                        do
                                                echo $i |sed -e s/"string"/=/g>>$FILEPATH/$ALLS.out
                                        done

                        instancearchivetatus="YES"
                        else
                        echo "User Name : DB IN NO ARCHIVE MODE.........."
                        echo " $arch_check">>$FILEPATH/$ALLS.out
                        echo  " $arch_destination " >>$FILEPATH/$ALLS.out
                        echo "\n" >>$FILEPATH/$ALLS.out
                        echo " Dump Destination" >>$FILEPATH/$ALLS.out
                        echo "------------------\n" >> $FILEPATH/$ALLS.out
                                for i in `cat $FILEPATH/$ALLS.log|grep -e dest|grep -e dump|awk '{print $1$2$3}'`
                                do
                                        echo $i |sed -e s/"string"/=/g>>$FILEPATH/$ALLS.out
                                done
                        instancearchivetatus="NO"
                        fi

##REDO LOGFILE CHECK
sqlplus /nolog <<EOF
set head off
conn / as sysdba;
set pagesize 100
set linesize 120
spool $FILEPATH/$ALLS.logfile
select archived, members ,bytes/1024/1024 from v\$log where bytes/1024/1024<100;
spool off
exit;
EOF

logmember="`cat $FILEPATH/$ALLS.logfile |grep -e NO -e YES`"
echo "$logmember ################"

if [ -z $logmember ]
then
echo " Size of the File is Adequate"
else
echo "\n" >>$FILEPATH/$ALLS.out
echo " Redo Log File Size Check ">>$FILEPATH/$ALLS.out
echo "--------------------------\n" >> $FILEPATH/$ALLS.out
echo " Size of the Log File is below 100M" >>$FILEPATH/$ALLS.out
fi
####BACKUP LOCATION

                        . $HOME/bin/$ALLS
                        backup_location="`cat $SID_HOME/admin/backup.ctl`"
                        rman_file="`cat $SID_HOME/admin/rman.ctl`"
                        echo "\n" >>$FILEPATH/$ALLS.out
                        echo " Backup Location" >>$FILEPATH/$ALLS.out
                        echo "-----------------\n" >> $FILEPATH/$ALLS.out

                        if [ -z $backup_location ]
                        then
                        echo "Backup.ctl Does Not Exist\n" >>$FILEPATH/$ALLS.out
                        echo " RMAN Backup Configured">>$FILEPATH/$ALLS.out
                        echo "------------------------\n">>$FILEPATH/$ALLS.out
                        echo "$rman_file">>$FILEPATH/$ALLS.out
                        else
                        echo "$backup_location">>$FILEPATH/$ALLS.out
                        echo "\n" >>$FILEPATH/$ALLS.out
                        echo " RMAN Backup Configured">>$FILEPATH/$ALLS.out
                        echo "------------------------\n">>$FILEPATH/$ALLS.out
                        echo "$rman_file">>$FILEPATH/$ALLS.out

                        fi
###ORATASK CHECK

   echo "step2"
                echo "\n" >>$FILEPATH/$ALLS.out
                echo " Entry Present in oratask.lst" >> $FILEPATH/$ALLS.out
                echo "------------------------------\n" >> $FILEPATH/$ALLS.out
                for orataskuser in  "bbmon" "questadmin" "perfstat"  "ngssquirrel" "system" "sys" "lstn$ALLS"
                do
                        user_check="` cat $HOME/bin/oratask.lst|grep -i $ALLS | grep -i $orataskuser |awk -F: '{print$2}'`"
                        if [ -z $user_check ];then
                        echo "User Name :$orataskuser Does Not exist" >>$FILEPATH/$ALLS.out
                        else
                        echo "User Name :$orataskuser Exist" >>$FILEPATH/$ALLS.out
                        fi
                        done

                userstatusoratask="YES"
                for orataskuserstatus in  "bbmon" "perfstat" "ngssquirrel" "system" "sys" "lstn$ALLS"
                do
                        user_check="` cat $HOME/bin/oratask.lst|grep -i $ALLS | grep -i $orataskuserstatus |awk -F: '{print$2}'`"
                        if [ -z $user_check ];then
                        echo "User Name :$orataskuserstatus Does Not exist"
                        userstatusoratask="NO"
                        else
                        echo "User Name :$orataskuserstatus Exist"
                        fi
                        done
###ORATAB CHECK
                if [ "`uname`" = "SunOS" ]
                        then
                oratab=/var/opt/oracle/oratab
                else
                oratab=/etc/oratab
                fi

                        oraentry=`cat $oratab|grep -v "^#" |grep $ALLS`

                        echo "\n" >>$FILEPATH/$ALLS.out
                        echo " Entry present in oratab" >> $FILEPATH/$ALLS.out
                        echo "------------------------\n" >> $FILEPATH/$ALLS.out

                        if [ -z $oraentry ]
                then
                        echo "Entry in Oratab Does Not Exists" >> $FILEPATH/$ALLS.out
                        oratabstatus=" NO"
                else
                        oratabstatus="YES"
                        echo "$oraentry" >> $FILEPATH/$ALLS.out
                fi

### PURGE.CTL CHECK
                echo "\n" >>$FILEPATH/$ALLS.out
                echo " Entry Present in Purge.ctl" >>$FILEPATH/$ALLS.out
                echo "----------------------------\n" >> $FILEPATH/$ALLS.out

                cat $HOME/bin/purge.ctl|grep $ALLS >> $FILEPATH/$ALLS.out

                purgentry=`cat $HOME/bin/purge.ctl|grep $ALLS`

                if [ -z $purgentry ]
                then
                echo "Entry Not Present!! Plz update purge.ctl " >>$FILEPATH/$ALLS.out
                purgestatus="NO"
                else
                purgestatus="YES"
                fi

###AUTOSYS CHECK
if [ "`uname`" = "SunOS" ]
                then
                        echo "This is Sun Box "
                echo "\n">>     $FILEPATH/$ALLS.out
                echo " Job Scheduled in Autosys" >> $FILEPATH/$ALLS.out
                echo "--------------------------\n" >> $FILEPATH/$ALLS.out
                . $HOME/bin/$ALLS
                host_name1="`echo $DBA_HOME|awk -F/ '{print $2}'`"
                . /tools/autotree/autouser/autosys.ksh.`hostname`
                sleep 2
                autorep -J SO_%$host_name1_`echo $ORACLE_SID`_% -q > $FILEPATH/bkp_`echo $ORACLE_SID`.jil
                sleep 2
                cat $FILEPATH/bkp_$ALLS.jil|grep -e command -e days_of_week -e start_times -e condition>> $FILEPATH/$ALLS.out

                autosyset=`cat $FILEPATH/bkp_$ALLS.jil`
                if [ -z $autosyset ]
                then
                echo "Jobs not scheduled" >> $FILEPATH/$ALLS.out
                autosysentry="NO"
                else
                autosysentry=" YES"
                fi

                else
                echo "\n">>     $FILEPATH/$ALLS.out
                echo " Job Scheduled in Autosys" >> $FILEPATH/$ALLS.out
                echo "--------------------------\n" >> $FILEPATH/$ALLS.out

                . $HOME/bin/$ALLS
                host_name1="`echo $DBA_HOME|awk -F/ '{print $2}'`"
                . /usr/autotree/autouser/autosys.ksh.`hostname`
                sleep 2
                autorep -J SO_%$host_name1_`echo $ORACLE_SID`_% -q > $FILEPATH/bkp_`echo $ORACLE_SID`.jil
                sleep 2
                cat $FILEPATH/bkp_$ALLS.jil|grep -e command -e days_of_week -e start_times -e condition>> $FILEPATH/$ALLS.out

                autosyset=`cat $FILEPATH/bkp_$ALLS.jil`
                if [ -z $autosyset ]
                then
                echo "Jobs not scheduled" >> $FILEPATH/$ALLS.out
                autosysentry="NO"
                else
                autosysentry=" YES"
                fi
 fi


###MAIL FORMAT

printf "%-6s %-10s\t  %+13s\t %+13s %+13s %+9s %+12s %+12s %+10s \n" "$CNT" "${ALLS}" "$instanceschemastatus" "$userstatusoratask" "$oratabstatus" "$purgestatus" "$autosysentry" "$instancearchivetatus" "$invetorystatus" >>$FILEPATH/$AUDIT_FILE
let CNT=$CNT+1
if [ $parameterpassed = "all" ]
then
echo " Server level audit"
else
echo "instance level check"
mailx -s "Operation Excellence Check On Server : `hostname` for instance $ALLS" syed.kaleemuddin@ge.com <$FILEPATH/$ALLS.out
fi
# mailx -s "Operation Check On Server : `hostname` " anjul1.agarwal@ge.com <$FILEPATH/$ALLS.out
# rm $FILEPATH/$ALLS.out
# rm $FILEPATH/$ALLS.log
# rm $FILEPATH/$ALLS.logfile
# rm $FILEPATH/bkp_$ALLS.jil
# rm $FILEPATH/$ALLS_perfstat.log
done
#mailx -s "Operation Check On Server : `hostname` " syed.kaleemuddin@ge.com <$FILEPATH/$AUDIT_FILE
if [ $1 = "all" ]
        then
        mailx -s "Operation Excellence Check On Server : `hostname` " syed.kaleemuddin@ge.com <$FILEPATH/$AUDIT_FILE
        else
                echo "ONLY SID is passed"
fi

