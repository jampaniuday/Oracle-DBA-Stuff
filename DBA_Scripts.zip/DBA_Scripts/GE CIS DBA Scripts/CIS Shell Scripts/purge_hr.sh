#!/usr/bin/ksh 
# Name : purge_hr.sh
# Date : 08-Nov-2002
# Desc : To purge hr related files depending on the retention period specified 
#	 in days . The control file is purge_hr.ctl . the format is 
#        
#        Directory:<Retention Period>:<file_type>
#
#        A email will send to the respective group every week informing about 
#        file deletion and will be deleted on the next run of script  
##############################################################################
bpath=`hostname|cut -c5-8`
Email_grp="jadia.satyen@corporate.ge.com"
DBA_HOME=/${bpath}/dba50/oracle50
#exclude_dir="/t030/hrapp/ftp_top/CorpTools/HRINTERPAY /t030/hrapp/test"


#####

#if [ -f $DBA_HOME/admin/hr_files_for_delete.sh ]
#then
#	echo " Deleing files "
#        . $DBA_HOME/admin/hr_files_for_delete.sh
#	rm $DBA_HOME/admin/hr_files_for_delete.sh
#fi
# Create the List 
if [ -f $DBA_HOME/admin/purge_hr.ctl ]
then
cat $DBA_HOME/admin/purge_hr.ctl |grep -v \^#|grep ^\/ >$DBA_HOME/audit/purge_hr.lst
else
	echo " $DBA_HOME/admin/purge_hr.ctl file doesnot exist "
	exit 0
fi
rm $DBA_HOME/audit/files_to_purge.lst >/dev/null 2>&1
while read line 
do
DIRN=`echo $line |awk -F: '{print $1}'`
RETP=`echo $line |awk -F: '{print $2}'`
FILET=`echo $line |awk -F: '{print $3}'`
fpar="-name"
if [ "$FILET" = "*" -o "$FILET" = "*.*" ]
then
#	echo "deleting all files older than retention period"
FILET=""
fpar=""
fi
if [ -z "$RETP" ]
then
	echo "Using standard retention period of 30 Days "
	RETP=30
fi
if [ ! -d $DIRN ]
then 
	echo " Directory $DIRN doesnot exists "
	continue;
fi
echo "find $DIRN $fpar $FILET -mtime +$RETP -type f -print"
find $DIRN $fpar $FILET -mtime +$RETP -type f -print  >>$DBA_HOME/audit/files_to_purge.lst


done <$DBA_HOME/audit/purge_hr.lst
cat $DBA_HOME/audit/files_to_purge.lst|sort -u >$DBA_HOME/audit/files_to_purge1.lst
rm $DBA_HOME/audit/hr_purge_email1.lst >/dev/null 2>&1
rm $DBA_HOME/audit/hr_purge_email.lst >/dev/null 2>&1
rm $DBA_HOME/audit/files_to_purge.sh >/dev/null 2>&1
#### Directory excluded ####
if [ ! -z "$exclude_dir" ]
then
exdir=`echo $exclude_dir`
for xdir in $exdir
do
cat $DBA_HOME/audit/files_to_purge1.lst |grep -v $xdir >$DBA_HOME/audit/files_to_purge1.tmp
cp $DBA_HOME/audit/files_to_purge1.tmp $DBA_HOME/audit/files_to_purge1.lst
done
fi

tsize=1
while read filen
do
if [ -z "$filen" ]
then
 	echo "Script error file_name null  ....!!!!! exiting "  
	exit 1                                  
fi
if [ -f "$filen" ]
then
	ls -l "$filen" >/dev/null 2>&1
	if [ $? -ne 0 ]
	then
	echo " Junk file name please delete it manually :$filen"
	continue;
	fi
	bname=`basename "$filen"|cut -c1-1`
	if [ "$bname" = "." ]
	then
	#	echo $filen
		continue;
	fi 
	echo $filen		
#	pbrun chmod 777 "'$filen'"
else
	echo "Script error  :$filen file not exists....!!!!! exiting "
	exit 1
fi
fdet=`ls -l "$filen"`
fown=`echo $fdet|awk '{print $3}'`
fdate=`echo $fdet|awk '{print $6" "$7}'`
fsize=`echo $fdet|awk '{print $5}'`
fsize1=`expr $fsize / 1024` 
if [ $fsize1 -eq 0 ]
then 
	fsize1=$fsize
	suff=Bytes
else
	suff=KB
fi
echo "$filen - $fown - $fdate - $fsize1 $suff " >>$DBA_HOME/audit/hr_purge_email1.lst
tsize=`expr $tsize + $fsize`
echo "rm -f \"${filen}\"" >>$DBA_HOME/audit/files_to_purge.sh
done <$DBA_HOME/audit/files_to_purge1.lst
tsize=`expr $tsize / 1024`
echo Total Filesize to Purge : $tsize  KB
cat $DBA_HOME/audit/hr_purge_email1.lst|sort -k5M >$DBA_HOME/audit/hr_purge_email.lst
rm $DBA_HOME/audit/files_to_purge1.lst >/dev/null 2>&1
rm $DBA_HOME/audit/files_to_purge.lst >/dev/null 2>&1
##chmod 755 $DBA_HOME/audit/files_to_purge.sh
rm $DBA_HOME/audit/purge_hr.lst >/dev/null 2>&1
rm $DBA_HOME/audit/hr_purge_email1.lst >/dev/null 2>&1
echo " Please check the file $DBA_HOME/audit/files_to_purge.sh and execute to delete the files"
