#!/usr/bin/ksh 
# Name :regsso.sh 
# Date : 14-Apr-2005 
# Created : Ranjit Mhatre 
# This script uses the controlfile <sid>_sso.ctl from $SID_HOME/admin
# Note : This script will re-register partner app with the TARGET instance 
#        after refresh from SSO enabled Application instance.
#        This script will also modify sso related profiles
#        prerequisite:
#        The password for orasso and ssosdk should be in oratask file
#        ssh should be enabled from application_db server to SSO 
#        repository server 
#        <SID>_sso.ctl file should be exist in $SID_HOME/admin This file has 
#          source_db and source_server entry should be edited to correct value
#          depending on from which instance you have refreshed the database
##################################################
if [ $# -ne 2 ]
then
	echo "USAGE : $0 <TARGET_SID> <SSO_ENV>"
		   echo "     SSO_ENV = In which you want to register "
		echo "	  values =<PROD/DEV/STAGE>"
	exit 1
fi
dsid=$1
sso_env=$2
iss=`echo $sso_env|grep "[a-z]"`
if [ ! -z "$iss" ]
then
	echo "Please put the SSO_ENV like PROD/DEV/STAGE (all caps)"
	exit 1;
fi

. $HOME/bin/$dsid
if [ ! -f $SID_HOME/admin/${dsid}_sso.ctl ]
then
	echo " Control file doesnot exists $SID_HOME/admin/${dsid}_sso.ctl"
	exit 1;
fi
#get the SSO Details from SSO Repository
SSO_DB=`cat $SID_HOME/admin/${dsid}_sso.ctl|grep ^other|grep SSO_${sso_env}|awk -F"==" '{print $3}'`
SSO_SER=`cat $SID_HOME/admin/${dsid}_sso.ctl|grep ^other|grep SSO_${sso_env}|awk -F"==" '{print $4}'`
SID=`echo $dsid|tr '[:lower:]' '[:upper:]'`
# Get the orasso password 
ssopass=`ssh $SSO_SER -l oracle "(. \\$HOME/bin/${SSO_DB};\\$HOME/bin/tellme orasso)"`
#echo $SSO_DB
#echo ssopas :$ssopass
if [ -z "$ssopass" ]
then
	echo "Can not able to get the password for orasso for ${SSO_DB}@${SSO_SER}"
	exit 1;
fi
#ssopass=To9pC7dE
sqlplus -s orasso/$ssopass@${SSO_DB} <<EOF >$SID_HOME/audit/sso_ora.err
set head off linesize 200 feedback off echo off
spool parta_${dsid}.lst
select 'Site name=='||SITE_NAME||'
'||'Success_URL=='||SUCCESS_URL||'
'||'Home_URL=='|| HOME_URL||'
'||'Logout_URL=='|| LOGOUT_URL||'
'||'Site_ID=='||SITE_ID||'
'||'Site_Token=='||SITE_TOKEN||'
'||'Encryption_key=='||ENCRYPTION_KEY
from orasso.WWSSO_PAPP_CONFIGURATION_INFO\$ 
where upper(SITE_NAME) like '%${SID}%';
EOF

###select 'Login_URL=='||LS_LOGIN_URL from orasso.wwsec_enabler_config_info\$ where site_id = (select site_id from orasso.WWSSO_PAPP_CONFIGURATION_INFO$ where upper(SITE_NAME) like '%${SID}%';

oerr=`cat $SID_HOME/audit/sso_ora.err|grep -e "SP2-" -e "ORA-"`
if [ ! -z "$oerr" ]
then
	echo "error getting the sso parameters from sso ${sso_env} repository $SSO_DB "
	echo "Please check connection : sqlplus -s orasso/$ssopass@${SSO_DB}"
	exit 1;
fi
### MODIFY the regapp.sql syntax and run 
### regapp.sql is modified to automate .
appspass=`$HOME/bin/tellme apps`
#appspass=l0b5ter
V_SITE_ID=`cat parta_${dsid}.lst|grep ^Site_ID|awk -F"==" '{print $2}'|xargs echo`
V_SITE_TOKEN=`cat parta_${dsid}.lst|grep ^Site_Token|awk -F"==" '{print $2}'|xargs echo`
V_ENCRIPTION_KEY=`cat parta_${dsid}.lst|grep ^Encryption_key|awk -F"==" '{print $2}'|xargs echo`
#V_LOGIN_URL=`cat parta_${dsid}.lst|grep ^Login_URL|awk -F"==" '{print $2}'`
V_IP_CHECK=N
sqlplus  -s apps/$appspass <<EOF >ora.err
spool list_t.txt 
set head off linesize 132 feedback off echo off
select fnd_web_config.database_id from dual;
EOF

V_LISTENER_TOKEN=`cat list_t.txt|awk '{print $1}'|xargs echo` 
V_LOGIN_URL=`cat $SID_HOME/admin/${dsid}_sso.ctl|grep ^other|grep SSO_${sso_env}|awk -F"==" '{print $5}'|xargs echo`

echo site_id  $V_SITE_ID
echo site_token $V_SITE_TOKEN
echo encryption_key $V_ENCRIPTION_KEY
echo login_url $V_LOGIN_URL
echo ip_check $V_IP_CHECK
echo listener_token $V_LISTENER_TOKEN

echo "Running regapp.sql"
##########################
#echo '@$DBA_HOME/admin/regapp_ge.sql "'$V_LISTENER_TOKEN'" "'$V_SITE_TOKEN'" "'$V_SITE_ID'" "'$V_LOGIN_URL'" "'$V_ENCRIPTION_KEY'" "'$V_IP_CHECK'"'

sqlplus -s ssosdk/ssosdk <<EOF >$SID_HOME/audit/sso_ora.err
@$DBA_HOME/admin/regapp_ge.sql "'$V_LISTENER_TOKEN'" "'$V_SITE_TOKEN'" "'$V_SITE_ID'" "'$V_LOGIN_URL'" "'$V_ENCRIPTION_KEY'" "'$V_IP_CHECK'"
EOF

oerr=`cat $SID_HOME/audit/sso_ora.err|grep -e "SP2-" -e "ORA-"`
if [ ! -z "$oerr" ]
then
	echo "error running regapp_ge.sql "
	exit 1;
else
	echo " Success"  
	cat $SID_HOME/audit/sso_ora.err
fi

### Delete the old registration 
ssid=`cat $SID_HOME/admin/${dsid}_sso.ctl|grep ^other|grep SOURCE_SID|awk -F"==" '{print $3}'`
sser=`cat $SID_HOME/admin/${dsid}_sso.ctl|grep ^other|grep SOURCE_SERVER|awk -F"==" '{print $3}'`
source_lstn_token="${sser}_${ssid}"
echo "Deleting old registration ${source_lstn_token}'"
sqlplus -s ssosdk/ssosdk <<EOF >$SID_HOME/audit/sso_ora.err
set serveroutput on
begin
  wwsec_sso_enabler.delete_enabler_config
   (
    p_lsnr_token => '${source_lstn_token}'
   ); 
dbms_output.put_line(' Deleted  registration  ${source_lstn_token}');
exception
  when others then null;
end;
/
EOF
cat $SID_HOME/audit/sso_ora.err
##### SET THE GUID/UID to NULL 
sqlplus -s apps/${appspass} <<EOF >$SID_HOME/audit/sso_ora.err
update fnd_user
set user_guid = null
where user_guid is not null;
commit;
EOF
oerr=`cat $SID_HOME/audit/sso_ora.err|grep -e "SP2-" -e "ORA-"`
if [ ! -z "$oerr" ]
then
	echo "error updating guid/uid "
	exit 1;
fi

# Update the sso related profiles 

pctlfile=${SID_HOME}/admin/${dsid}_sso.ctl
appspass=`$HOME/bin/tellme apps`
cat $pctlfile|grep -v ^# |grep ^profile >${dsid}_p.lst
echo "changing the Profiles for $dsid .." 
rm ${SID_HOME}/audit/upd_profile_${dsid}.sql >/dev/null 2>&1
touch ${SID_HOME}/audit/upd_profile_${dsid}.sql
while read line 
do
pname=`echo $line|awk -F"==" '{print $2}'`
pvalue=`echo $line|awk -F"==" '{print $3}'`

sqlplus -s  apps/$appspass <<EOF >>${SID_HOME}/audit/upd_profile_${dsid}.sql
set head off pagesize 200 linesize 300 echo off feedback off
select 'prompt Changing profile for $pname' from dual;
select 'prompt old value :'||profile_option_value 
from fnd_profile_options o, fnd_profile_option_values v,
   fnd_profile_options_tl t
where o.profile_option_id = v.profile_option_id
   and o.application_id = v.application_id
   and start_date_active <= SYSDATE
   and nvl(end_date_active,SYSDATE) >= SYSDATE
   and o.profile_option_name = t.profile_option_name
   and level_id=10001
   and t.language in
       (select language_code from fnd_languages where installed_flag='B'
       union
       select nls_language from fnd_languages where installed_flag='B')
   and t.user_profile_option_name='$pname'; 

select 'prompt New Value : $pvalue' from dual;
select 'update fnd_profile_option_values set profile_option_value = '||CHR(39)||'$pvalue'||chr(39)||' where profile_option_id='||v.profile_option_id||';'
from fnd_profile_options o, fnd_profile_option_values v,
   fnd_profile_options_tl t
where o.profile_option_id = v.profile_option_id
   and o.application_id = v.application_id
   and start_date_active <= SYSDATE
   and nvl(end_date_active,SYSDATE) >= SYSDATE
   and o.profile_option_name = t.profile_option_name
   and level_id=10001
   and t.language in
       (select language_code from fnd_languages where installed_flag='B'
       union
       select nls_language from fnd_languages where installed_flag='B')
   and t.user_profile_option_name='$pname'; 

EOF

done < ${dsid}_p.lst 

echo "Updating SSO related profiles" 
sqlplus -s apps/${appspass} <<EOF >$SID_HOME/audit/sso_ora.err
@${SID_HOME}/audit/upd_profile_${dsid}.sql
EOF
oerr=`cat $SID_HOME/audit/sso_ora.err|grep -e "SP2-" -e "ORA-"`
if [ ! -z "$oerr" ]
then
	echo "error running ${SID_HOME}/audit/upd_profile_${dsid}.sql "
	exit 1;
fi


### Verify the  Application DATABASE config for regapp  
sqlplus  -s apps/$appspass <<EOF
REM START OF SQL
REM Script to check values defined in Apps for the SSO Server 
REM Run as APPS or SSOSDK database user on the Apps 11i database
REM 
set pagesize 132;
set serveroutput on
declare
l_listener_token varchar2(255);
l_site_token varchar2(255); 
l_site_id varchar2(255);
l_login_url varchar2(2000);
l_logout_url varchar2(2000);
l_cookie_version varchar2(80);
l_encryption_key varchar2(1000);
l_ip_check varchar2(10);
begin

select apps.fnd_web_config.database_id into l_listener_token from dual; 

wwsec_sso_enabler.get_enabler_config
(
l_listener_token
,l_site_token
,l_site_id
,l_login_url
,l_logout_url
,l_cookie_version
,l_encryption_key
,l_ip_check
);
dbms_output.put_line('------------------------------------------------ ');
dbms_output.put_line('Values from Apps 11i Server ');
dbms_output.put_line('------------------------------------------------ ');
dbms_output.put_line('Host_SID Identifier: ' || l_listener_token);
dbms_output.put_line('Site id : ' || l_site_id);
dbms_output.put_line('Site token : ' || l_site_token);
dbms_output.put_line('Encryption key : ' || l_encryption_key);
dbms_output.put_line('Login URL : ' || l_login_url);
dbms_output.put_line('Logout URL : ' || l_logout_url);
dbms_output.put_line('IP check : ' || l_ip_check);
dbms_output.put_line('------------------------------------------------ ');
exception
when others then
dbms_output.put_line('------------------------------------------------ ');
dbms_output.put_line('ERROR....');
dbms_output.put_line('Exception: ' || sqlerrm);
dbms_output.put_line('l_listener_token: ' || l_listener_token);
dbms_output.put_line('------------------------------------------------ ');
end;
/

EOF

# End of regsso.sh
