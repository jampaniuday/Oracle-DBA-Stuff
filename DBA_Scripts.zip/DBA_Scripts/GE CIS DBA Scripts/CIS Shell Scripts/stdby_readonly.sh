#!/usr/bin/sh 
if [ $# -ne 1 ]                                          
then                                                     
   echo "Usage: $0 ORACLE_SID "                     
   exit 1                                           
else                                                     
   ORACLE_SID=$1                                    
fi                                                       
                                                         
if [ ! -f $HOME/bin/${1} ]                               
then                                                     
  echo "Environment script does not exist for \"${1}\"." 
  echo "Script is terminating."                          
  exit 1                                                 
fi

## Set environment 

. $HOME/bin/${1}

sqlplus -s /nolog <<EOF> /dev/null
connect / as SYSDBA
startup nomount;
alter database mount standby database;
recover standby database until cancel;
exit
EOF
sqlplus -s /nolog <<EOF> /dev/null
connect / as SYSDBA
alter database open read only; 
exit 
EOF 
