#!/bin/ksh
#################################################################################################
# notify.sh                                                                                     #
#################################################################################################
# The script will Prepare the Mailing list,Subject and Mail Body from the parameters  passed to #
# the script and will send the mail to the mailing list. Mailing list is prepared from          #
# notify.ctl file. Subject and Body of the mail are made as mandatory parameters along with the #
# -w option and the rest of the parameters are optional. The mails will be sent when the support#
# levels match the ones mentioned in the controlfile.                                           #
#                                                                                               #
# The Body of the email can be a simple text (with option -s) or it can be a file               #
# (with option -f). If needed all the options can be used at same time.                         #
#                                                                                               #
# The script will send a pager only whent the support level are set to gold or silver and the   #
# pager text is mentioned as parameter (-p).                                                    #
#                                                                                               #
# If no matching entries were found in notify.ctl file then default mail id will be taken from  #
# all:all entry in notify.ctl file.                                                             #
#                                                                                               #
# The control file by default is taken as $HOME/bin/notify.ctl file.                            #
#                                                                                               #
# The domain id for the mail will be taken from the notify.ctl file, if no value is set         #
# for domain id in notify.ctl file then the default value is set to corporate.ge.com.           #
#                                                                                               #
# The script will send mails and pages to the mail id's of users mentioned in option -w.        #
#  1) On Call DBA.                                                                              #
#  2) Server Owner.                                                                             #
#  3) Primary DBA.                                                                              #
#  4) Pager id.                                                                                 #
#                                                                                               #
# After preparing the mail id list for the above users, Logic is written for not to send        #
# the duplicate mails and pagers to the same id's.                                              #
#                                                                                               #
# Here are the sample entries of notify.ctl file, I have added the domain name at the end.      #
#                                                                                               #
# #ramesh.putumbaka:ramesh.putumbaka@gecis.ge.com:8*216-7404:91-9885170605:local:gecis.ge.com   #
# all:all:ramesh.putumbaka                                                                      #
# corpt227:all:ramesh.putumbaka:gold                                                            #
# corpt227:sscm:ramesh.putumbaka:gold                                                           #
#                                                                                               #
# Here are the options that can be specified with the script.                                   #
#                                                                                               #
# notify.sh -s <"Mail Subject">         # Mail Subject.         [Mandatory parameter]           #
#                                                                                               #
# notify.sh -b <"Mail Body">            # Mail Body. (Text)     [Mandatory parameter]           #
#                                                                                               #
# notify.sh -f <"File name with path">  # File name whose contents are to sent as Mail body     #
#                                                                                               #
# notify.sh -p <"Pager Text">           # Pager Text to be paged.                               #
#                                                                                               #
# notify.sh -w <"Whom to Notify">       # Values oncall,server,sid. Default is all, means mail  #
#                                       # will be sent to all the above 3 mail id's.            #
#                                                                                               #
# notify.sh -L <"Support Level">        # Support Levels. Values gold,silver,bronze             #
#                                                                                               #
# notify.sh -v                          # Verbose, will out put the scripts exec process.       #
#                                                                                               #
# notify.sh -q                          # Query, will echo to stdout support level, contacts, etc. 
# Example:                                                                                      #
#                                                                                               #
# Sample entry with mandatory parameters.                                                       #
#                                                                                               #
# notify.sh -s "Test Mail" -b "Test Mail Body"                                                  #
#                                                                                               #
# Sample entry with parameters.                                                                 #
#                                                                                               #
# notify.sh -s "Test Mail" -b "Test Mail Body" -w oncall,server,sid -v                          #
#                                                                                               #
# The above script execution will send mails to the mailing list prepared from the control .    #
#                                                                                               #
#################################################################################################
#                                                                                               #
# Author                : Ramesh.P                                                              #
# Date of Creation      : 05-29-05                                                              #
# Last Modification Date: 11-01-05                                                              #
#                                                                                               #
#################################################################################################


################################################################################################
# Script Usage Help.
################################################################################################

usage () {
  echo " "
  echo "Usage: notify.sh [-s \"Subject\"] [-b \"mail body\"] [-f filename] [-w \"oncall,server,sid\"] [-L \"gold,silver,bronze\"] [-p \"Page Message\"] [-v]"
  echo " "
  echo "notify.sh -s <\"Mail Subject\">                 # Mail Subject.         [Mandatory parameter]"
  echo "notify.sh -b <\"Mail Body\">                    # Mail Body. (Text)     [Mandatory parameter]"
  echo "notify.sh -f <\"File name with path\">          # File name whose contents are to sent as Mail body"
  echo "notify.sh -p <\"Pager T#xt\">                   # Pager Text to be paged." [Mandatory parameter if pager is to be sent]
  echo "notify.sh -w <\"Whom to Notify\">               # Values <oncall,server,sid>. Default is set to server, sid." [Mandatory Parameter with -p option]
  echo "notify.sh -L <\"Support Level\">                # Support levels. Values <gold,silver,bronze>."
  echo "notify.sh -v                                    # Verbose, will out put the scripts exec process."
  echo "notify.sh -q                                    # Query, will output who would be contacted, support level,etc."
  echo " "
  echo "Example:"
  echo " "
  echo "Sample entry for mail."
  echo " "
  echo "notify.sh -s \"Test Mail\" -b \"Test Mail Body\" -f $HOME/gecis/rameshp/mailbody.txt -v"
  echo " "
  echo "Sample entry for page."
  echo " "
  echo "notify.sh -p \"Page text\" -w oncall,ser,sid"
  echo " "
}

################################################################################################
# Condition to check for minimum No of Parameters
################################################################################################

if [ $# -lt 4 ]; then
  if [ $# -ne 1 -o "$1" != "-q" ]; then
    usage
    exit 1
  fi
fi

################################################################################################
# Script Variables set to Default Values
################################################################################################

oracle_id=`ls -l $0 | awk '{print $3}'`
ohome=`grep "^${oracle_id}:" /etc/passwd | cut -d: -f6`
ctl_file="$ohome/bin/notify.ctl"
# testing control file#ctl_file=/t067/dba01/oracle/admin/tmp.ctl
ohost=`hostname`
OS_TYPE=`uname`
default_mailid=`grep ^"all:all" $ctl_file | cut -d: -f3`
default_domain=corporate.ge.com
default_pager=`grep ^"all:all" $ctl_file | cut -d: -f4`
tmpfile=/tmp/mailbody.tmp.$$
sid=$ORACLE_SID

################################################################################################
# Parsing commandline arguments And validation for any invalid option/missing parameters
################################################################################################

while getopts s:b:f:p:w:L:vq option
do
 [ "$optname" = "?" ] && usage
 case $option in
 (s)
        sub="$OPTARG"
 ;;
 (b)
        body="$OPTARG"
 ;;
 (f)
        file="$OPTARG"
 ;;
 (p)
        pagetext="$OPTARG"
 ;;
 (q)
	verbose="T"
	query="T"
	sub="(Query)"
	body="(Query)"
 ;;
 (w)
        whom_to_notify="$OPTARG"
 ;;
 (L)
        support_level="$OPTARG"
 ;;
 (v)
        verbose="T"
 ;;
 [?])
        usage
        exit 1
 ;;
 esac
done

shift `expr $OPTIND - 1`



################################################################################################
# Setting Oratab file location, and Mail/Mailx depending on OS.
################################################################################################

if [ "$OS_TYPE" = "SunOS" ] || [ "$OS_TYPE" = "OSF1" ]; then
  MAIL_EXE=mailx
  oratab="/var/opt/oracle/oratab"
else
   if [ "$OS_TYPE" = "Linux" ]|| [ "$OS_TYPE" = "HP-UX" ]; then
     MAIL_EXE=mail
    if [ "$OS_TYPE" = "HP-UX" ]; then
          MAIL_EXE=mailx
    fi
     oratab="/etc/oratab"
   else
     echo "Script Not Ported for this OS"
     exit 1
   fi
fi

################################################################################################
# Validating Command line parameter values
################################################################################################

if [ ! -z "$pagetext" ]; then
  if [ -z "$whom_to_notify" ]; then
     echo "Please provide values for -w option [oncall,server,sid]."
     usage
     exit 1
  fi
elif [ -z "$body" -a -z "$file" -o -z "$sub" ]; then
  echo "Make sure that the values for Mandatory parameters -s and one of [-b/-f] are mentioned to send mail successfully."
  usage
  exit 1
fi

if [ ! -z "$file" -a ! -f "$file" ]; then
  echo "Couldn't find the file $file, Enter correct file name with path."
  exit 1
fi

if [ ! -z "$whom_to_notify" ]; then
 count=1
 for i in `echo $whom_to_notify | sed 's/,/ /g'`
 do
  if [ "$i" != "oncall" -a "$i" != "server" -a "$i" != "sid" ] || [ $count -gt 3 ]; then
   echo "Please enter correct values for -w <whom to notify> Valid values are [oncall,server,sid]."
   exit 1
  fi
  count=`expr $count + 1`
 done
fi

if [ ! -z "$support_level" ]; then
 count=1
 for i in `echo $support_level | sed 's/,/ /g'`
 do
  if [ "$i" != "gold" -a "$i" != "silver" -a "$i" != "bronze" ] || [ $count -gt 3 ]; then
   echo "Please enter correct values for -L <Support Level> Valid values are [gold,silver,bronze]."
   exit 1
  fi
  count=`expr $count + 1`
 done
fi

if [ -z "$support_level" ]; then
  support_level="gold,silver"
fi

if [ -z "$whom_to_notify" ]; then
  whom_to_notify="server,sid"
fi

################################################################################################
# Mail id and Pager id list preperation from control file.
################################################################################################

if [ ! -z "$sid" ]; then
   grep ^"$ohost:$sid" $ctl_file >/dev/null
   if [ $? -eq 0 ]; then
      sid_app_domain=`grep ^"$ohost:$sid" $ctl_file | cut -d: -f4`
   fi
fi

server_entries=`grep ^"$ohost:all" $ctl_file | xargs echo`
if [ ! -z "$server_entries" ]; then
 for entry in `echo $server_entries`
 do
  server_rep_mail=`echo $entry | cut -d: -f3`
  server_app_domain=`echo $entry | cut -d: -f4`
  server_support=`echo $entry | cut -d: -f5`
  if [ -z "$server_support" ]; then
     server_support=bronze
  fi
  server_mail_list="$server_mail_list $server_rep_mail `grep ^"$server_app_domain:all" $ctl_file | cut -d: -f3 | xargs echo`"
  echo "$support_level" | grep "$server_support" >/dev/null
  if [ $? -eq 0 ]; then
    server_page_list="$server_page_list `grep ^"$server_app_domain:all" $ctl_file | cut -d: -f4 | xargs echo`"
  fi

  if [ "$sid_app_domain" = "$server_app_domain" ]; then
     sid_server_rep_mail="$server_rep_mail"
  fi

 done
else
  server_mail_list="$default_mailid"
  server_page_list="$default_pager"
fi

if [ ! -z "$sid" ]; then
   grep ^"$ohost:$sid" $ctl_file >/dev/null
   if [ $? -eq 0 ]; then
      sid_mail_list=`grep ^"$ohost:$sid" $ctl_file | cut -d: -f3`               # Primary DBA mail id
      oncall_app_domain=`grep ^"$ohost:$sid" $ctl_file | cut -d: -f4`
      sid_support=`grep ^"$ohost:$sid" $ctl_file | cut -d: -f5`                 # DB Support Level
      if [ -z oncall_app_domain ]; then
         oncall=server
      fi
   else
     oncall=server
   fi
else
   oncall=server
fi

if [ "$oncall" != "server" ]; then
   oncall_mail_list=`grep ^"$oncall_app_domain:all" $ctl_file | cut -d: -f3 | xargs echo`
   oncall_page_list=`grep ^"$oncall_app_domain:all" $ctl_file | cut -d: -f4 | xargs echo`
else
   oncall_mail_list="$server_mail_list"
   oncall_page_list="$server_page_list"
fi

if [ -z "$oncall_mail_list" ]; then
   oncall_mail_list="$server_mail_list"
fi

if [ -z "$oncall_page_list" ]; then
   oncall_page_list="$server_page_list"
fi

if [ -z "$sid_mail_list" ]; then
   sid_mail_list="$oncall_mail_list"
fi

echo "$support_level" | grep "$server_support" >/dev/null
if [ $? -ne 0 ]; then
  sid_page_list=""
elif [ -z "$sid_page_list" ]; then
   sid_page_list="$oncall_page_list"
fi
#else
#   sid_page_list=`grep ^"#$sid_mail_list" $ctl_file | cut -d: -f2`
#fi

for i in `echo $whom_to_notify | sed 's/,/ /g'`
 do
   if [ "$i" = "oncall" ]; then
        maillist="$maillist $oncall_mail_list"
        pagelist="$pagelist $oncall_page_list"
   fi
   if [ "$i" = "server" ]; then
        maillist="$maillist $server_mail_list"
        pagelist="$pagelist $server_page_list"
   fi
   if [ "$i" = "sid" ]; then
        maillist="$maillist $sid_mail_list $oncall_mail_list $sid_server_rep_mail"
        pagelist="$pagelist $sid_page_list"
   fi
done

if [ "$verbose" = "T" ]; then
 echo " "
 echo "Mail id's taken from the control file depending on the parameters provided with the script"
 echo "------------------------------------------------------------------------------------------"
 echo "Oncall Mail Id           :$oncall_mail_list"
 echo "Server Rep Mail Id       :$server_mail_list"
 echo "Primary DBA Mail Id      :$sid_mail_list"
 echo "Server Support Level     :$server_support"
fi


if [ "$verbose" = "T" ]; then
   echo " "
   echo "Mails Will be sent to $maillist"
   echo "Pager will be sent to $pagelist"
fi

################################################################################################
# Mail Body Preperation.
################################################################################################

echo "" > $tmpfile

if [ ! -z "$body" ]; then
  echo " "
  echo "$body" > $tmpfile
  echo " " >> $tmpfile
fi

if [ ! -z "$file" ]; then
  cat "$file" >> $tmpfile
fi

mail_body="$tmpfile"

if [ "$whom_to_notify" = "server" ]; then
  # don't display sid in subject line if only sending to server rep
  # assume that this is a server-level rather than sid-level message
  sid=""
fi

if [ "$verbose" = "T" ]; then
  echo " "
  echo "Email Subject : $ohost $sid $sub"
  echo " "
  echo "Email Body :"
  cat "$mail_body"
  echo " "
fi

################################################################################################
# Eliminating Duplicate mailid's and pager id's from mailid and pagerid lists prepared above.
################################################################################################

for mailid in `echo $maillist`
do 
  mail_domain=`grep ^"#$mailid" $ctl_file | cut -d: -f6 | xargs echo`
  if [ -z "$mail_domain" ]; then
     mail_domain="$default_domain"
  fi
  for domain_name_in in `echo $mail_domain`
  do
    if [ ! -z "$mail_to" ]; then
       echo "$mail_to" | grep "$mailid@$domain_name_in" >/dev/null
       if [ $? -ne 0 ]; then
          mail_to="$mail_to $mailid@$domain_name_in"
       fi
    else
       mail_to="$mailid@$domain_name_in"
    fi
  done
done

for pageid in `echo $pagelist`
do
  if [ ! -z "$page_to" ]; then
     echo "$page_to" | grep "$pageid" >/dev/null
     if [ $? -ne 0 ]; then
        page_to="$page_to $pageid"
     fi
  else
     page_to="$pageid"
  fi
done

################################################################################################
# Sending mails & pagers.
################################################################################################

if [ "$query" = "T" ]; then
  echo "Script output would be emailed to the following DBAs: $mail_to"
  echo "Pager would be sent to $page_to"
else
  if [ -z "$pagetext" ];then
   if [ ! -z "$mail_to" ]; then
        $MAIL_EXE -s "$ohost $sid $sub" $mail_to < "$mail_body"
        echo " "
        echo "Script output will be emailed to the following DBAs: $mail_to"
        echo " "
   fi
  fi
  
  ################################################################################################
  # Sending Pager
  ################################################################################################
  
  if [ ! -z "$pagetext" -a ! -z "$page_to" ]; then
     #echo "$ohost $sid $pagetext" | $MAIL_EXE $page_to
     #echo "" | $MAIL_EXE -s "$ohost $sid $pagetext"  $page_to
     echo "$pagetext" | $MAIL_EXE -s "$ohost $sid" $page_to
     echo " "
     echo "Pager sent to: $page_to"
     echo " "
  fi
  
  ############################################END#################################################
fi # if query != T
if [ -f "$tmpfile" ]; then
  rm -f $tmpfile
fi
