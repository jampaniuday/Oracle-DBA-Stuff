#!/bin/ksh
#####
# standby_close.ksh
# Purpose:     Close the Standby Database 
#############################################################
# Changes Log : Pl. put comments if any changes were made.
# Name            Date    Comments
# --------------- ------- ---------------------------
# Tirumal Rao     02/2001
#############################################################
# Environment Variables
ORAENV_ASK=NO
export ORACLE_SID ORAENV_ASK
PATH=$PATH:$DBA_HOME/admin
export PATH

# . oraenv
############################
#DBPROCS=`ps -ef | grep "ora_pmon_${ORACLE_SID}`
#if [ $DBPROCS ]
#then
#  echo "Database not started"
#  exit
#fi
#. $HOME/${ORACLE_SID}.sh
sqlplus -s /nolog <<EOF > /dev/null
connect / as SYSDBA
shutdown ;
EOF
echo "$0: Database Shutdown at `date`"
