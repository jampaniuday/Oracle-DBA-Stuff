while read sid
do
. $HOME/bin/$sid
echo "#########################################################"
echo $sid is being setup for the password verify function
sqlplus -s "/as sysdba" <<EOF
REM set termout off
set feedback off 
@ge_password_function_setup.sql
exit
EOF
echo $sid has been setup
echo "#########################################################"
done <sid_list


