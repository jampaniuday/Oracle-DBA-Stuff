#!/usr/bin/ksh 
# Name : check_pass.sh
# Date : 26-Oct-01
# Author : Ranjit Mhatre 
# Desc : Check if tellme gives correct password for specified user
#        for all available instance

Ouser=$1;export Ouser
if [ $# -ne 1 ]
then
	echo "Usage : check_pass.sh <Oracle_User>"
	echo "        It will check if tellme gives correct password for oracle_user"
exit 0
fi
asid=`ps -afe|grep _pmon|grep -v grep|awk -F"pmon_" '{print $2}'|xargs echo`
if [ ! -z "$asid" ]
then
	for avsid in $asid
	do
		. $HOME/bin/$avsid
		PASSWD=`tellme $Ouser`
		if [ ! -z "$PASSWD" ]
		then
                if [ "$Ouser" = "sys" ]
                then 
                 echo $Ouser $avsid
                        sqlplus -s "sys/$PASSWD as sysdba" << EOF >$SID_HOME/audit/cpora.err
			select global_name from global_name;
EOF
                else
			sqlplus -s $Ouser/$PASSWD <<EOF >$SID_HOME/audit/cpora.err
			select global_name from global_name;
EOF
                fi
			oerr=`cat $SID_HOME/audit/cpora.err|grep "ORA-"`
			if [ ! -z "$oerr" ]
			then     
				cat $SID_HOME/audit/cpora.err
				echo "\n Note :\n "  
				echo "\t Error while accessing Instance $avsid from user $Ouser"
				echo " \t Also Check the oratask.lst file for correct password"
			else
				echo "Correct entry in oratask.lst file for instance : $avsid"
			fi
		else
			echo "No pasword entry in oratask.lst file for instance $avsid user $Ouser"
		fi
	done
else
	echo "Not a single instance up or not database server "
fi
