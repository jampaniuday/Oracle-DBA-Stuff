#!/usr/bin/ksh 
## Name :statspack.sh
## date : Jun 4 2004
## Created : ranjit Mhatre 
## Usage
## staspack.sh <sid> <option> <parameters>
##
##  Options= del - delete  Parameters = <days_to_keep_stats>
##	     rep - Report             - <Start_time> <end_time> 
##	     run - Run stats	      
## eg.
## statspack.sh <sid> del 5 ( delete all stats keeping last 5 days)
## statspack.sh <sid> rep 'YYYYMMDD HH24:MI:SS' 'YYYYMMDD HH24:MI:SS'  
## statspack.sh <sid> rep 10:30 17:30 (today's report on given time ) 
## 
## statspack.sh <sid> run   (gather the stats depending on as schedule in cron) 
##
##
## Dependant scripts:
##			sppurge_ge.sql
##			spreport_ge.sql
##
##
###########################################################################

if [  $# -eq 3  -o  $# -eq 4 -o $# -eq 2 ] 
then
	echo "Starting stastspack ...."
else
	echo "USAGE :"
	cat $0|grep ^\##
	exit 1
fi
ssid=$1
case $2 in 
	del) retnum=$3;;
	rep) stime="$3";
	     etime="$4";;
 	run) continue;;
	*)echo "Check the syntax " ;
		exit 1;;
esac
. $HOME/bin/$ssid
scrpath="$DBA_HOME/admin"
export scrpath
passwd=`$HOME/bin/tellme perfstat`
if [ -z "$passwd" ]
then
	passwd="perfstat"
fi
#### Check Mailing List in stats_notify.ctl
#### format like 
#### <SID>:</APP/DBA>:<email address separeted by space>
mailapp=`cat $DBA_HOME/admin/stats_notify.ctl|grep ^$ssid:APP|awk -F: '{print $3}'`
maildba=`cat $DBA_HOME/admin/stats_notify.ctl|grep ^$ssid:DBA|awk -F: '{print $3}'`

if [ $2 = "del" ]
then 
	sqlplus perfstat/$passwd <<EOF >$SID_HOME/audit/perfstat_purge.audit
	@$scrpath/sppurge_ge.sql $retnum;
EOF

fi

if [ $2 = "rep" ]
then
	format1=`echo "$stime"|awk '{print $2}'`
	if [ -z "$format1" ]
	then
	yy=`date +%Y`
	mm=`date +%m`
	dd=`date +%d`
	param1="'${yy}${mm}${dd} ${stime}:00'"
	param2="'${yy}${mm}${dd} ${etime}:00'"
	else
	param1="'$stime'"
	param2="'$etime'"
	fi
	echo $param1 $param2  >>$SID_HOME/audit/perfstat_rep.audit


	sqlplus perfstat/$passwd <<EOF >>$SID_HOME/audit/perfstat_rep.audit
	@$scrpath/spreport_ge.sql $param1 $param2;
EOF
errs=`cat $SID_HOME/audit/perfstat_rep.audit|grep ^'End of Report'`
SSID=`echo $ssid|tr '[:lower:]' '[:upper:]'`
if [  -z "$errs" ]
then
	echo "Error Running the  stats report $1 "
	exit 1
else
	mailgrp="$mailapp $maildba"
	#mailx -s "Stats report for $1 from $3 between $4" <sprep_${SSID}.lst $mailgrp
	/poc01/dba01/oracle/admin/notify.sh -s "Stats report for $1 from $3 between $4" -f "sprep_${SSID}.lst" -w sid

fi
	
fi

if [ $2 = "run" ]
then
	echo "Running The stats pack for $1 on `date` "
	sqlplus perfstat/$passwd <<EOF >$SID_HOME/audit/perfstat_run.audit
	exec statspack.snap;
EOF

fi
