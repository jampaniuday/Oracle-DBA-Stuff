#!/bin/ksh

## Monitor temporary tablespace usage.
## Usage: sgausage.sh <SID>

## Verify usage

if [ -z "$1" ]
then
  echo "Error: Invalid usage."
  echo "Usage: sgausage.sh <SID>"
  exit 1
fi

## Verify environment script exists for the database

if [ ! -f "$HOME/bin/$1" ]
then
  echo "Environment script does not exists for database, $1."
  echo "Make sure script exists under $HOME/bin directory."
  exit 1
fi

## Setup environment

. $HOME/bin/$1

## Get system password

systempswd=`$HOME/bin/tellme system`

if [ -z "$systempswd" ]
then
  echo "Error: Cannot get system password for the database $1."
  echo "Update file $HOME/bin/oratask.lst with proper password."
  exit 1
fi

## Get Temp Space Usage for the database

sqlplus -s system/$systempswd << EOF > $SID_HOME/audit/sgausage.err
set pages 60 time on
REM select  machine, count(*) from v\$session
REM group   by machine ;
@$DBA_HOME/admin/sga.sql
exit
EOF

err=`grep "ORA-" $SID_HOME/audit/sgausage.err`

if [ ! -z "$err" ]
then
  echo "Error selecting temp usage for database, $1."
  echo "      $err"
  echo "Check for $SID_HOME/audit/sgausage.err file for"
  echo "more information."
  exit 1
fi

cat $SID_HOME/audit/sgausage.err >> $SID_HOME/audit/sgausage.history

## Remove error file

rm $SID_HOME/audit/sgausage.err

exit 0
