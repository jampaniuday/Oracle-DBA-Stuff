#!/bin/ksh
########################################################################
##
## tsmxfr.sh - To list TSM transfers in audit log
##
## usage     - tsmxfr.sh  
##
## The script loops over each instance found in ORATAB and get the 
## TSM transfer from audit logs
##
## 2002-11-26  wfb  original version
##
## 
##########################################################################

# setup environment

echo " "
echo "Begin TSM transfer analysis ---------------------"
echo " "
echo `uname -a`
date
echo
rval=0

machtyp=`uname -a | cut -c1-3`
case "$machtyp" in
("Win")
  ORATAB=$DBA_HOME/admin/orasid.list
;;
("Lin")
  ORATAB=/etc/oratab
;;
("Sun")
  ORATAB=/var/opt/oracle/oratab
;;
("HP-")
  ORATAB=/etc/oratab
;;
("OSF")
  ORATAB=/etc/oratab
;;
esac

export ORATAB 
echo "ORATAB = " $ORATAB

# check environment

if [ ! -f $ORATAB ]
then
  echo "Error==> $ORATAB does not exist"
  echo "script terminating"
  exit 1
fi

#####################################
# Loop over the entries in ORATAB   #
#####################################

while read ora_line
do

# filter out comment lines 
 
  char1=`echo $ora_line | cut -c1`
  if [[ "${char1}" != [A-Za-z] ]]
  then
    continue
  fi

# get sid

  ora_sid=`echo $ora_line | cut -d : -f 1`

#  set instance environment

  if [ ! -f $HOME/bin/$ora_sid ]
  then
    echo "Error ==> no environment script found for $ora_sid"
    rval=1
    continue
  fi

. $HOME/bin/$ora_sid

cd $SID_HOME/audit
echo " "
echo "now in directory: " `pwd`
grep -e 'transfer' -e 'Script' ${ora_sid}_tape_copy.audit12*
echo
echo "-----------------------------------------------------------"
echo

done < $ORATAB

echo " "

if [ $rval -ne 0 ]
then
  echo "Errors encountered"
  ohost=`uname -a`
  rmsg="Not all candidate instances were processed"
  echo $rmsg
fi
echo
date
echo "list TSM transferred bytes terminating" 

# clean up temporary files


exit $rval
