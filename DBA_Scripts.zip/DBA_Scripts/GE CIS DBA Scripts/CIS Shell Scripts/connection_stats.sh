#############################################################################
#Monitor the number of connections to the database 
#vmstat and measures swap 
#Executes once every 30 seconds 
#############################################################################
ORACLE_SID=apc1

X=0
while [ $X -lt 240 ]
do
  echo ======================================================================
  date
  echo 'ps -ef|grep $ORACLE_SID|grep LOCAL=NO|wc -l'
  ps -ef|grep $ORACLE_SID|grep LOCAL=no|wc -l
  echo 'vmstat 15 2'
  vmstat 15 2
  echo 'swap -s'
  swap -s
  echo ======================================================================
  X=`expr $X + 1`
done
exit         

