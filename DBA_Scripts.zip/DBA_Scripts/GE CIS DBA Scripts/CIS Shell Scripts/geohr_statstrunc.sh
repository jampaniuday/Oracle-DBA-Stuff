#!/bin/ksh
################################################################################
# monitor_mailer.sh 
# This script is used to notify the DBA of failure of Notification Mailer   
# This script intially checks to see if the Database is up and running. 
# It then checks to see if the internal concurrent manager is running 
# then the script checks to see if the Notification Mailer program is up 
# and running . In case the Notification mailer is not running then the   
# the script notifies  the oncall DBA. 
#
#  Arguments: ORACLE_SID
#  Usage    : monitor_mailer.sh <ORACLE_SID>
#   
# Rajesh Natarajan, 03/26/01
###############################################################################


function checkconnect {
######################################
# checkconnect()
#   Ensure that we can connect to the database
# Arguments: $1, user
#            $2, password
# Returns: 0, if we can connect
#          1, if we cannot connect
#
sqlplus -s $1/$2 << EOF > /dev/null
exit 255;
EOF
   if [ $? -ne 255 ]; then
    return 1
   else
    return 0
   fi
} ################## checkconnect() ##

######################################################
# Source the correct environment 
#####################################################
. $HOME/bin/$1
USERNAME=perfstat
PASSWD=perfstat
TBL="stats\$snapshot"
MAXTBLCNT=48

######################################################
# Set the mailer list
#####################################################
MAILLIST="GTSOHR.LeadDBAs@corporate.ge.com cis.ohrperformance@ge.com"

########################################################
# Check for database availabilty and if available 
# If yes then check for username and password combination
# If db connection is fine check if internal Manager is running
# If internal manager is running check for workflow mailer
########################################################## 
SMON=`ps -ef | grep ora_smon_"$SID" | grep -v grep | awk '{print $1}'|uniq`
if [ ! -z "$SMON" ];then
    checkconnect $USERNAME $PASSWD 
    if [ "$?" -eq 0 ] ;then
    TBL_CNT=`sqlplus -s $USERNAME/$PASSWD  <<EOF
    set head off feedback off
    set newpage none
    select count(*)
    from $TBL; 
EOF`
    if [ $MAXTBLCNT -gt $TBL_CNT ];then
    echo Table Size OK
    exit
    fi
    NXT_RPT=`sqlplus -s $USERNAME/$PASSWD  <<EOF
    select gs.rpt_next_run_dt 
    from perfstat.geohr_statsrep gs
    where 
    to_char(sysdate,'DD-MON-YYYY') = substr(gs.rpt_next_run_dt,1,11)
    and substr(rpt_next_run_dt,-2) - to_char(sysdate,'HH24') > 5 ;
EOF`
    if [ "`echo $NXT_RPT | grep no`" ]
    then
    echo Skip truncation for now
    exit
    fi
    exp userid=$USERNAME/$PASSWD parfile=$EXPORT_HOME/statsuexp.par
    WARNING=`tail -1  $EXPORT_HOME/statsuexp.log |awk -F" " '{print $4}'` 
     if [ "$WARNING" = "without" ] ;then
        FILE=`date '+%m%d%y-%H:%M'`
        mv $EXPORT_HOME/statsuexp.dmp $EXPORT_HOME/statsuexp.dmp$FILE 
        RC1=$?
        if [ "$RC1" -eq 0 ] ;then
        sqlplus /nolog <<EOF
           whenever sqlplus error exit 255
           whenevr oserror exit 255
           set echo off feedback off
           connect $USERNAME/$PASSWD
           @$DBA_HOME/admin/geohr_sptrunc.sql
EOF
fi
fi
fi
          RC2=$?
          if [ "$RC2" -eq 0 ]; then
          NEW_JOB_ID=`sqlplus -s $USERNAME/$PASSWD  <<EOF
                  set head off feedback off
                  set newpage none
                  select job  
                  from dba_jobs 
                  where schema_user='PERFSTAT'
                  and what='statspack.snap;';
EOF`
   fi
else
  echo " The database is down "
fi
###############################################################################
# End of monitor_mailer.sh 
###############################################################################
