#! /usr/bin/ksh 
#  Script to clean old sshd connections for Oracle
# created by Sumit Mondaiyka
# Ceration date Jan 10 2008
#
rm /tmp/sshd.out
rm /tmp/sshd_kill.sh
ps -e -o user,pid,stime,etime,comm | grep sshd|grep ^oracle > /tmp/sshd.out
ps -e -o user,pid,stime,etime,comm | grep su |grep -v dmp_errd_suspec >> /tmp/sshd.out
while read i
do
#  echo $i
  proc=`echo $i|awk '{print $4}'|grep - |cut -d- -f1`
#  echo $proc
  if [ -z "$proc" ]
     then
      echo $proc
   elif [ $proc -gt 10 ]
      then
         p_id=`echo $i|awk '{print $2}'`
         echo 'killing' $i
         echo 'pbrun kill -9' $p_id >> /tmp/sshd_kill.sh
  fi
done </tmp/sshd.out
