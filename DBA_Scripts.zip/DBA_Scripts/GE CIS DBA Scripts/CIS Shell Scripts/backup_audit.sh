#!/usr/bin/ksh

######################################################################
#  backup_audit.sh
#
#  Script to check utility.audit and individual audit trails for
#  backup and tape_copy commands, and report on success/failure.
#  Utilizes $DBA_HOME/admin/backup_audit.ctl (format is SID:OWNER:COMMENT)
#  for additional processing.
#
#  usage:
#    backup_audit.sh (without additional parameters) writes output to stdout
#    backup_audit.sh email  
#       will email the output (notify.sh is used for all teams except SSS
#         SSS sends to all DBAs on the  SSS team)
#
#   temporary file $DBA_HOME/audit/backup_audit_`hostname`_*.out
#   contains the output which is emailed or displayed
######################################################################

setenv()
{
if [ -f $HOME/bin/$sid ]; then
   # test that sid script won't blow up dbstart
   if ( . $HOME/bin/$sid > /tmp/$$.out 2>&1 )
   then
     rm /tmp/$$.out
     . $HOME/bin/$sid
     rval=0
   else
     echo "`date` : Error in Environment script for $sid"
     cat /tmp/$$.out
     echo "Bypassing audit for $sid "
     rm -f /tmp/$$.out
     rval=1
#     continue
   fi
else
echo "Env file for $sid is not found"
rval=1
fi
return $rval
}

UtilShortName() {
  util_ctl=$1
  cat $util_ctl | while read nxtline; do
    f1=`echo $nxtline | cut -d: -f1`
    shortname=`basename "$f1"`
if [ $? -ne 0 ]; then
  echo "$util_ctl - $nxtline - basename of $f1"  >&2
fi
    echo $shortname:$nxtline
  done
}

tapebkpstatus()
{
utlaud=$SID_HOME/audit/utility.audit
egrep '((tape_copy)|(tcopy_rman))\.sh' $utlaud > $utlaudtapebkuptmp
chmod 777 $utlaudbkuptmp
if [ `cat $utlaudtapebkuptmp|wc -l` -ge 2 ]; then
#sed -f $tsedfile $utlaudtapebkuptmp | awk -F\> '{ split($1,job," ") split($2,file," ") split($3,status," ")    
#printf("%s:%s:%s\n",toupper(job[3]),file[1],status[5]) }' > $utlaudtapebkup                                    
cat $utlaudtapebkuptmp | nawk '
  />/ { if ( length(job) != 0 ) {
          printf "%s:%s:%s\n", job, audfil, "KILLED";
        }
        job=toupper($3);
        for (x=4; x<NF; x++) {
          if ($x == ">" ) {
            x++;
            audfil=$x;
            break;
          }
        }
        status=""; }
  /TERMINATED/ { status=$3;
        if ( length(job) != 0 ) {
          printf "%s:%s:%s\n", job, audfil, status;
        }
        job="";}
' > $utlaudtapebkup

chmod 777 $utlaudtapebkup
if [ -z "$rman_sed_str" ]; then
  # set to a trivial no-op
  rman_sed_str='s:a:a:'
fi
for line in `cat $utlaudtapebkup`                   
do                                              
tapebackupstat=`echo $line |awk -F: '{ print $3 }'`  
tapebackupauditfile=`echo $line |awk -F: '{ print $2 }'`  
echo "$tapebackupauditfile" | grep -q 'tcopy_rman'
if [ $? -eq 0 ]; then
  # audit filename includes tcopy_rman --- change ARCH to verbose info
  tapebackupjob=`echo $line |awk -F: '{ print $1 }' |sed "$rman_sed_str;s/ARCH/BACKUPSET with ARCH DELETE/"`  
else
  tapebackupjob=`echo $line |awk -F: '{ print $1 }' |sed "$rman_sed_str"`
fi

if [ "$tapebackupstat" = "SUCCESSFULLY" ]; then                                                                                     
tapebackupstatus="**** SUCCESS ****"                                                                                                        
tstartstr=`egrep '====>Script ((tcopy_rman)|(tape_copy))\.sh [Ss]tarting on' $tapebackupauditfile | awk '{ printf("%s\/%s\/%s@%s\n", $6, $7, $10 ,$8)  }'` 
tendstr=`egrep '====>Script ((tcopy_rman)|(tape_copy))\.sh [Ee]nding on' $tapebackupauditfile  | awk '{ printf("%s\/%s\/%s@%s\n", $6, $7, $10 ,$8)  }'`    
elif [ "$tapebackupstat" = "ABNORMALLY" ]; then
tapebackupstatus="FAILURE"
tstartstr=`egrep '====>Script ((tcopy_rman)|(tape_copy))\.sh [Ss]tarting on' $tapebackupauditfile | awk '{ printf("%s\/%s\/%s@%s\n", $6, $7, $10 ,$8)  }'` 
tendstr=""
else
tapebackupstatus="$tapebackupstat"
tstartstr=`egrep '====>Script ((tcopy_rman)|(tape_copy))\.sh [Ss]tarting on' $tapebackupauditfile | awk '{ printf("%s\/%s\/%s@%s\n", $6, $7, $10 ,$8)  }'` 
tendstr=""
fi                                                                                                                            
#printf "%-10s %-40s TAPECOPY %-10s %-10s %-20s %-20s \n" $sid $tr $tapebackupjob $tapebackupstatus $tstartstr $tendstr  
echo "	TAPECOPY SCHEDULE         :      $tr"
echo "	TAPECOPY JOB              :      $tapebackupjob"
echo "	TAPECOPY STATUS           :      $tapebackupstatus"
echo "	TAPECOPY START TIME       :      $tstartstr"	
echo "	TAPECOPY END TIME         :      $tendstr"
done
else
tstartstr=""
tendstr=""
tapebackupjob="NS"
tapebackupstatus="NS"
#printf "%-10s %40s TAPECOPY %-10s %-10s %-20s %-20s \n" $sid $tr $tapebackupjob $tapebackupstatus $tstartstr $tendstr  
echo "	TAPECOPY SCHEDULE         :      $tr"
echo "	TAPECOPY JOB              :      $tapebackupjob"
echo "	TAPECOPY STATUS           :      $tapebackupstatus"
echo "	TAPECOPY START TIME       :      $tstartstr"	
echo "	TAPECOPY END TIME         :      $tendstr"
msg="$msg No tape_copy job in audit file . If tape_copy is scheduled to run then pls. crosscheck cron entries and controlfile."
fi
}
bkpstatus()
{
utlaud=$SID_HOME/audit/utility.audit
grep 'backup.*.sh' $utlaud > $utlaudbkuptmp
chmod 777 $utlaudbkuptmp
if [ `cat $utlaudbkuptmp|wc -l` -ge 2 ]; then
#sed -f $bsedfile $utlaudbkuptmp | awk -F\> '{ split($1,job," ") split($2,file," ") split($3,status," ") 
#printf("%s:%s:%s\n",toupper(job[3]),file[1],status[5]) }' > $utlaudbkup
cat $utlaudbkuptmp | nawk '
  />/ { if ( length(job) != 0 ) {
          printf "%s:%s:%s\n", job, audfil, "KILLED";
        }
        job=toupper($3);
        for (x=4; x<NF; x++) {
          if ($x == ">" ) {
            x++;
            audfil=$x;
            break;
          }
        }
        status=""; }
  /TERMINATED/ { status=$3;
        if ( length(job) != 0 ) {
          printf "%s:%s:%s\n", job, audfil, status;
        }
        job="";}
' > $utlaudbkup

chmod 777 $utlaudbkup
for line in `cat $utlaudbkup`
do
backupjob=`echo $line |awk -F: '{ print $1 }'`
if [ "$backupjob" = ">" ]; then
  backupjob="BACKUPSET"
fi
backupstat=`echo $line |awk -F: '{ print $3 }'`
if [ "$backupstat" = "SUCCESSFULLY" ]; then
backupstatus="**** SUCCESS ****"
backupauditfile=`echo $line|awk -F: '{ print $2 }'`
bstartstr=`grep "====>Script backup.*.sh [sS]tarting on" $backupauditfile | awk '{ printf("%s\/%s\/%s@%s\n", $6, $7, $10 ,$8)  }'`
bendstr=`grep "====>Script backup.*.sh [eE]nding on" $backupauditfile  | awk '{ printf("%s\/%s\/%s@%s\n", $6, $7, $10 ,$8)  }'`
elif [ "$backupstat" = "ABNORMALLY" ]; then
backupstatus="---------- FAILURE ----------"
fi
#printf "%-10s %-40s DBBACKUP %-10s %-10s %-20s %-20s \n" $sid $br $backupjob $backupstatus $bstartstr $bendstr 
echo "	BACKUP SCHEDULE           :      $br"
if [ -n "$rman_ctl_files" ]; then
  echo "	RMAN SCHEDULE             :      $rman_sched"
fi
echo "	BACKUP JOB                :      $backupjob"
echo "	BACKUP STATUS             :      $backupstatus"
echo "	BACKUP START TIME         :      $bstartstr"	
echo "	BACKUP END TIME           :      $bendstr"
done 
else
backupjob="NS"
backupstatus="NS"
bstartstr=""
bendstr=""
#printf "%-10s %-40s DBBACKUP %-10s %-10s %-20s %-20s \n" $sid $br $backupjob $backupstatus $bstartstr $bendstr
echo "	BACKUP SCHEDULE           :      $br"
if [ -n "$rman_ctl_files" ]; then
  echo "	RMAN SCHEDULE             :      $rman_sched"
fi
echo "	BACKUP JOB                :      $backupjob"
echo "	BACKUP STATUS             :      $backupstatus"
echo "	BACKUP START TIME         :      $bstartstr"	
echo "	BACKUP END TIME           :      $bendstr"
msg="$msg No backup job in audit file. If backup is scheduled to run then pls. verify cron entries and controlfile."
fi
}
chkutladmin()
{
bc=
tc=
msg=
br=
tr=
if [ -f $SID_HOME/admin/utility.ctl ]; then
bc=`UtilShortName $SID_HOME/admin/utility.ctl|grep "^backup"|wc -l`                                                      
tc=`UtilShortName $SID_HOME/admin/utility.ctl|egrep '^((tape_copy)|(tcopy_rman))'|wc -l`                                                      
if [ $bc -eq 0 ]; then
msg="$msg No backup ctl record in utility.ctl. Verify cron entries and controlfile."
elif [ $bc -eq 1 ]; then
br=`UtilShortName $SID_HOME/admin/utility.ctl|grep "^backup" | cut -d: -f2-`
else
br=`UtilShortName $SID_HOME/admin/utility.ctl|grep "^backup"| cut -d: -f2- | sed -f $nsedfile`
fi
# if backup uses RMAN, get RMAN schedule
rman_sched=""
rman_ctl_files=""
rman_sed_str=""
rman_flag=false
UtilShortName $SID_HOME/admin/utility.ctl| grep '^backup_rman' | cut -d: -f2- |
  while read nxtline; do
    rman_flag=true
    cnt=2
    while [ 1 = 1 ]; do
      cnt=`expr $cnt + 1`
      nxtarg=`echo $nxtline | cut -d: -f$cnt `
      if [ -z "$nxtarg" ]; then
        break
      fi
      if [ "$nxtarg" = "hot" -o "$nxtarg" = "cold" -o "$nxtarg" = "arch" \
           -o "$nxtarg" = "NotifyAlways" ]; then
          continue
      fi
      if [ -f "$SID_HOME/admin/$nxtarg" ]; then
        if [ `echo $rman_ctl_files | grep -c "$SID_HOME/admin/$nxtarg"` -eq 0 ]
        then
          rman_ctl_files="$rman_ctl_files $SID_HOME/admin/$nxtarg"
	  upcase_arg=`echo $nxtarg | tr [:lower:] [:upper:]`
	  rman_sed_str="s:${upcase_arg}:BACKUPSET:;${rman_sed_str}"
          break
        fi
      fi
    done
done
rman_delim=""
if [ "$rman_flag" = "true" -a -z "$rman_ctl_files" -a -f "$SID_HOME/audit/rman.ctl" ]; then
  # utility.ctl did not use optional param for RMAN ctl file
  rman_ctl_files="$SID_HOME/audit/rman.ctl"
fi
if [ -n "$rman_ctl_files" ]; then
  for nxtfile in "$rman_ctl_files"; do
    tmp_sched=`grep '^INCREMENTAL_FLAG:N' $nxtfile`
    if [ $? -eq 1 ]; then
      tmp_sched=`grep '^INCREMENTAL_LEVEL:' $nxtfile | cut -d: -f2`
    fi
    rman_sched="${rman_sched}${rman_delim}${tmp_sched}"
    rman_delim=";"
  done
fi
if [ "$rman_flag" = "true" -a -z "$rman_ctl_files" ]; then
  msg="$msg No RMAN control files found for backups in utility.ctl"
fi
    
if [ $tc -eq 0 ]; then
msg="$msg No tape_copy ctl record in utility.ctl."
elif [ $tc -eq 1 ]; then
tr=`UtilShortName $SID_HOME/admin/utility.ctl|egrep '^((tape_copy)|(tcopy_rman))' | cut -d: -f2-`
else
tr=`UtilShortName $SID_HOME/admin/utility.ctl|egrep '^((tape_copy)|(tcopy_rman))'|cut -d: -f2- | sed -f $nsedfile`
fi
else 
msg='No utility.ctl available. Verify cron entries and controlfile.'
fi
}
chkutlaudit()
{
if [ -f $SID_HOME/audit/utility.audit ]; then
utilityaudit="Y"
if [ `find $SID_HOME/audit -name utility.audit -mtime -1 -print|wc -l` -eq 1 ]; then
utilityauditupdated="Y"
else
utilityauditupdated="N"
msg="$msg Seems no jobs ran in past one day. If this is scheduled to run then check if cron is commented."
fi
else
utilityaudit="N"
msg="$msg No utility.audit available. Pls. check cron entries."
fi
}
backupheader()
{
echo "\t\t\t\t  Backup / Tapecopy Audit Report"                                                                              
echo "\t\t\t\t      On Hostname - `hostname` "                                                                      
echo "\t\t\t\t         $rundate "                                                                                          
echo "\t\t\t\tJobs submitted In last 24 hours"                                                                  
echo "\t\t\t\t*********************************\n"                                                              
}
setsedfiles()
{
echo "{" > $nsedfile          
echo "N" >> $nsedfile          
echo 's/\\n/,/' >> $nsedfile    
echo "}" >> $nsedfile  

echo '/backup.*.sh /{' > $bsedfile  
echo "N" >>$bsedfile                 
echo 's/\\n/ status /' >> $bsedfile  
echo "}">>$bsedfile                  

echo "/tape_copy.sh /{" > $tsedfile      
echo "N" >>$tsedfile                  
echo 's/\\n/ status /' >> $tsedfile   
echo "}">>$tsedfile                   

echo "/tcopy_rman.sh /{" >> $tsedfile      
echo "N" >>$tsedfile                  
echo 's/\\n/ status /' >> $tsedfile   
echo "}">>$tsedfile                   
chmod 777 $tsedfile
chmod 777 $bsedfile
chmod 777 $nsedfile
}
runaudit()
{
rundate=`date '+%m-%d-%y:%H:%M'`
auditctl=$DBA_HOME/admin/backup_audit.ctl
oratab=/var/opt/oracle/oratab 
utlaudbkup=/tmp/utlaudbkup.txt
utlaudbkuptmp=/tmp/utlaudbkup.txt.tmp
utlaudtapebkup=/tmp/utlaudtapebkup.txt
utlaudtapebkuptmp=/tmp/utlaudtapebkup.txt.tmp
bsedfile=$DBA_HOME/audit/bsedfile.sed
nsedfile=$DBA_HOME/audit/nsedfile.sed
tsedfile=$DBA_HOME/audit/tsedfile.sed
chmod 777 $bsedfile
chmod 777 $tsedfile
setsedfiles
tapeauditrpt=$DBA_HOME/audit/`hostname`_tapecopy_"$rundate".txt
backupauditrpt=$DBA_HOME/audit/`hostname`_backup_"$rundate".txt
backupheader 
sidlist=`cat $oratab| grep -v \# | grep -v \* | awk -F: '{print $1}' |sort` 
#sidlist=`cat $oratab| grep  | grep -v \# | grep -v \* | awk -F: '{print $1}' |sort` 
for sid in $sidlist                                                     
do                                                                      
osowner=`cat $auditctl | grep $sid|cut -f2 -d:`
comment=`cat $auditctl | grep $sid|cut -f3 -d:`
utilityaudit="N"
utilityauditupdated="N"                                                  
backupjob="NS"
backupstatus="NS"
tapebackupjob="NS"
tapebackupstatus="NS"
tstartstr=""
tendstr=""
bstartstr=""
bendstr=""
SID_HOME=""
if [ "$osowner" = "$LOGNAME" ]; then
echo 
echo "Database :	$sid"
echo "**********************"
setenv
if [ $? -ne 0 ]; then
  continue
fi
if [ "$APP" = "sss" ]; then
  is_sss=true
fi
chkutladmin
chkutlaudit
if [ "$utilityauditupdated" = "Y" ]; then
bkpstatus
echo
tapebkpstatus
#else
#printf "%-10s %-40s DBBACKUP %-10s %-10s %-20s %-20s \n" $sid $br $backupjob $backupstatus $bstartstr $bendstr 
#printf "%-10s %-40s TAPECOPY %-10s %-10s %-20s %-20s \n" $sid $tr $tapebackupjob $tapebackupstatus $tstartstr $tendstr
fi
echo "	HINTS                     :     $msg"
echo "	COMMENTS                  :     $comment"
fi
done
}
#main
DBA_HOME=/`hostname | cut -c5-8`/dba01/oracle;export DBA_HOME 
is_sss=false
backuprpt=$DBA_HOME/audit/backup_audit_`hostname`_`date +%m%d-%H:%M`.out
runaudit > $backuprpt 2>&1
if [ "$1" = "email" ]; then      
  if [ "$is_sss" = "true" ]; then
    mailx -s "Backup Audit Report - `hostname` @ `date +%m/%d-%H:%M`" sumit.mondaiyka@ge.com GTSsssDba@corporate.ge.com< $backuprpt
  else
    mailx -s "Backup Audit Report - `hostname` @ `date +%m/%d-%H:%M`" sumit.mondaiyka@ge.com < $backuprpt
    notify.sh -s "Backup Audit Report - `hostname` @ `date +%m/%d-%H:%M`" -f $backuprpt -w oncall,server
  fi
  echo "Mail Sent.."
else
  cat $backuprpt
fi
