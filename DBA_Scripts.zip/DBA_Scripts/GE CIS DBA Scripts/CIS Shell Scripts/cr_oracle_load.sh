#!/bin/ksh
notify()
{
# Email and page the oncall DBA and email the appropriate load administrators
# if this script abends or produces warnings
  echo
  if [ ! -z "${cntl_path}" ]
  then
    if [ -f ${cntl_path}/${LOAD_SET}_load.test ]
    then
      echo "Event notification disabled by flag file ${LOAD_SET}_load.test"
      return
    fi
  fi
  echo "Notification of script abend will be emailed to:"
  charset=us-ascii; export charset
  oncall=`grep "load:all" $HOME/bin/notify.ctl | cut -d: -f3`
  emailsw=1
  while read notify_line
  do
    notify_host=`echo $notify_line | cut -d: -f1`
    notify_sid=`echo $notify_line | cut -d: -f2`
    notify_schema=`echo $notify_line | cut -d: -f3`
    notify_job=`echo $notify_line | cut -d: -f4`
    notify_who=`echo $notify_line | cut -d: -f5`
    if [ "$notify_host" = "`hostname`" ]
    then
      if [ "$notify_sid" != "$ORACLE_SID" -a "$notify_sid" != "all" ]
      then
        continue
      fi
      if [ "$notify_schema" != "$SCHEMA" -a "$notify_schema" != "all" ]
      then
        continue
      fi
      len=`echo $notify_job | awk '{print length($0)}'`
      if [ "$notify_job" != "`echo $LOAD_SET|cut -c1-$len`" -a "$notify_job" != "all" ]
      then
        continue
      fi
      echo $notify_who
      mailx -s "$notify_host $ORACLE_SID $LOAD_SET $script_name $page_msg" $notify_who@corporate.ge.com < ${audit_trail}
      if [ "$oncall" = "$notify_who" ]
      then
        emailsw=0
      fi
    fi
  done <$loadadm_home/bin/notify.ctl
  if [ ! -z "$oncall" ]
  then
    if [ $rval -eq 1 ]
    then
      notify_pager=`grep "#$oncall" $HOME/bin/notify.ctl | cut -d: -f2`
      if [ ! -z "$notify_pager" ]
      then
        echo "`hostname`-$ORACLE_SID\n${LOAD_SET} $script_name ${page_msg}" | mailx $notify_pager
      fi
    fi
    if [ $emailsw -eq 1 ]
    then
      echo $oncall
      mailx -s "`hostname` $ORACLE_SID $LOAD_SET $script_name $page_msg" $oncall@corporate.ge.com < ${audit_trail}
    fi
  fi
}
#main
echo "************************************************************************"
echo "====>Script cr_oracle_load.sh starting on" `date`
echo "************************************************************************"
rval=1; export rval
loadadm_home=`cat /etc/passwd | awk -F: '{
  if ($1 == "loadadm") {print $6}}'`
export loadadm_home
page_msg=abend; export page_msg
script_name=cr_oracle_load; export script_name
SCHEMA=""
LOAD_SET=""
echo 'cr_oracle_load script abended\ncheck audit trail on the server under $LOAD_HOME/audit'>$HOME/bin/qdw.error
audit_trail=$HOME/bin/qdw.error
export audit_trail
if [ $# -lt 1 ]
then
  echo
  echo "Invalid parameter input"
  echo "Usage is cr_oracle_load.sh sid"
  echo "Script is terminating"
  notify
  exit 1
fi
SID=$1
if [ ! -f $HOME/bin/$SID ]
then
  echo
  echo "Cannot find the sid environment script under $HOME/bin"
  echo "Script is terminating due to error"
  notify
  exit 1
fi
. $HOME/bin/$SID
cntl_path=$LOAD_HOME/cntl
scripts_path=$DBA_HOME/admin
audit_path=$LOAD_HOME/audit
export cntl_path scripts_path audit_path
ready_cnt=`ls -c1 ${cntl_path}/*load.ready | wc -l`
if [ ${ready_cnt} -eq 0 ]
then
  exit
fi
ready_file=`ls -C1 -t ${cntl_path}/*load.ready |awk -F/ '
  {readyfile = $NF}
END {print readyfile}
'`
SCHEMA=`cat ${cntl_path}/$ready_file|cut -d: -f2`
LOAD_SET=`cat ${cntl_path}/$ready_file|cut -d: -f3`
export SCHEMA LOAD_SET
mv ${cntl_path}/${LOAD_SET}_load.ready ${cntl_path}/${LOAD_SET}_load.start
audit_trail=${audit_path}/${LOAD_SET}_load.audit
export audit_trail
${scripts_path}/qdw_load.sh $SID $SCHEMA $LOAD_SET >> ${audit_trail} 2>&1
rval=$?
export rval
script_name=qdw_load; export script_name
if [ $rval -eq 0 -o $rval -eq 2 -o $rval -eq 99 ]
then
  while read cntl_rec
  do
    table_label=`echo ${cntl_rec} | cut -d: -f1`
    rm -f ${cntl_path}/${table_label}*_ftp.done
    ftp_fs=`echo ${cntl_rec} | cut -d: -f3`
    ftp_num=`echo ${cntl_rec} | cut -d: -f4`
    data_fs=`echo ${cntl_rec} | cut -d: -f5`
    ftp_dir=/user/${ftp_fs}/${ORACLE_SID}
    ftp_cnt=1
    while [ ${ftp_cnt} -le ${ftp_num} ]
    do
      if [ -f ${ftp_dir}/${table_label}${ftp_cnt}.zip ]
      then
        rm -f ${ftp_dir}/${table_label}${ftp_cnt}.dat >/dev/null 2>&1
      fi
      ftp_cnt=`expr ${ftp_cnt} + 1`
    done
    if [ "${ftp_fs}" != "${data_fs}" -a $rval -ne 99 -a ${ftp_num} -ne 0 ]
    then
      data_dir=/user/${data_fs}/${ORACLE_SID}
      rm -f ${data_dir}/${table_label}* >/dev/null 2>&1
    fi
  done < ${LOAD_HOME}/admin/${LOAD_SET}.ctl
  touch ${cntl_path}/${LOAD_SET}_load.done
  rm -f ${audit_path}/${LOAD_SET}.restart
  if [ $rval -eq 2 ]
  then
    echo
    echo "qdw_load.sh for ${LOAD_SET} TERMINATED WITH WARNINGS"
    notify
  fi
# rm -f ${audit_path}/${LOAD_SET}.audit
  audit_date=`date +%m%d`
  mv ${audit_trail} ${audit_trail}${audit_date}
  if [ $rval -ne 99 ]
  then
    if [ -f ${SID_HOME}/admin/qdw_counts.sh ]
    then
#     Extract load counts from the load audit trail and store in table t_dba_load_count
      ${SID_HOME}/admin/qdw_counts.sh ${ORACLE_SID} ${LOAD_SET}_load.audit${audit_date}
    fi
  fi
else
  echo
  chmod 664 ${LOAD_HOME}/audit/${LOAD_SET}.restart >/dev/null 2>&1
  chown loadadm:qdw ${LOAD_HOME}/audit/${LOAD_SET}.restart >/dev/null 2>&1
  echo "qdw_load.sh for ${LOAD_SET} TERMINATED ABNORMALLY"
  notify
fi
chmod 664 ${LOAD_HOME}/cntl/${LOAD_SET}_load* >/dev/null 2>&1
chown loadadm:qdw ${LOAD_HOME}/cntl/${LOAD_SET}_load* >/dev/null 2>&1
chmod 664 ${LOAD_HOME}/audit/${LOAD_SET}_load* >/dev/null 2>&1
chown loadadm:qdw ${LOAD_HOME}/audit/${LOAD_SET}_load* >/dev/null 2>&1
rm -f ${LOAD_HOME}/audit/${LOAD_SET}.ora.error >/dev/null 2>&1
rm -f ${LOAD_HOME}/audit/${LOAD_SET}.cnt >/dev/null 2>&1
rm -fr ${LOAD_HOME}/audit/${LOAD_SET} >/dev/null 2>&1
exit
