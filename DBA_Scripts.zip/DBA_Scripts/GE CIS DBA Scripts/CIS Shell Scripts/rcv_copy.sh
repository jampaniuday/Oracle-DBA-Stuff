#!/bin/ksh
#############################################################################
## rcv_copy.sh
##   PURPOSE: To generate a script to copy the latest oracle disk backup files
##     to the selected oracle datafile(s) and/or logfile(s).
##     Note that the script will recognize both compressed and uncompressed
##     backup files and generate copy or uncompress commands respectively.
##   USAGE: This is an interactive script that prompts for:
##     1) a valid controlfile trace that reflects the state of the 
##        database at the desired point of recovery. Note that you MUST have a
##        good controlfile in place before you can use the generated recovery
##        script; this script does nothing to recover the Oracle control file!
##        (you can select the latest existing controlfile trace, a
##         specific controlfile trace, or you can choose to generate
##         a new trace now)
##     2) a backup.ctl file which must exist under $SID_HOME/admin
##        (you should use the same default or alternate backup.ctl file
##         that was used to generate the backup files in script backup.sh) 
##     3) a log recovery option which allows you to specify log recovery from
##        backup files or from an undamaged mirror
##     4) a tablespace datafile recovery option which allows you to specify
##        all tablespace datafiles or a subset of tablespace datafiles whose
##        names contain character strings that you supply.
##        This ability to specify oracle datafile masks will allow the user to
##        easily generate a recovery copy script for recovery from a particular
##        disk failure by simply supplying the filesystem of the corrupt disk
##        as the mask.
##        
##        To submit the script, enter : rcv_copy.sh ${ORACLE_SID}
##   OUTPUTS: An Oracle datafile and/or logfile recovery copy script located
##     under $SID_HOME/admin and named recover_${ORACLE_SID}.sh
##     This script is NOT automatically submitted! The user should review its
##     contents and then issue the following command to execute it:
##       $SID_HOME/admin/recover_${ORACLE_SID}.sh
##   MODIFICATIONS:
#############################################################################
SID=$1
#
#This Function Added By Ranjit Mhatre on 23-Aug-00
#
DBUP ()
{
dbn=$1
for PROCESS in pmon dbw lgwr smon
do
dbst="`ps -afe|egrep $1|egrep $PROCESS`"
if [ -z "$dbst" ]
then
dbup=1
else
dbup=0
fi
done
}

#End Function 
if [ -z "$SID" ]
then
  echo
  echo "Script requires your sid as input - rerun as rcv_copy.sh ssss"
  echo
  exit
fi
if [ ! -f $HOME/bin/$SID ]
then
  echo
  echo "Cannot find your sid's environment script under $HOME/bin"
  echo "Script is terminating due to error"
  echo
  exit
fi
. $HOME/bin/$1
echo
echo "Enter q at any prompt to terminate processing"
echo "#!/bin/ksh" >$SID_HOME/admin/recover_${ORACLE_SID}.sh
# -------------------------------------------------------------------
# identify the controlfile trace to be used to guide the copy process
# -------------------------------------------------------------------
if [ ! -d $SID_HOME/audit ]
then
  mkdir $SID_HOME/audit
fi
ans=
while [ -z "$ans" ]
do
  echo
  echo "WARNING:The controlfile trace you supply must match the physical"
  echo "        structure of the database at the intended point of recovery!"
  echo
  echo "Use the latest controlfile trace from the last backup processing (respond l) or"
  echo "use a specific controlfile trace (respond with the trace filename) or"
  echo "create a new controlfile trace now (respond n) ====>"
  read ans
done
if [ $ans = "q" ]
then
  echo
  echo "Script is terminating by user request"
  echo
  exit
fi
shutdown_sw=0
DBUP $ORACLE_SID
if [ $dbup -eq 1 ]
then
  shutdown_sw=1
  echo "Starting instance $ORACLE_SID in mount state to produce a controlfile trace"
# Added by David DeClercq
  if [ "`echo exit|sqlplus /nolog|grep 'Release [8-9]'`" ]
  then
    sqlplus /nolog <<EOF >$SID_HOME/audit/ora.error
    connect / as sysdba
    startup mount
    exit
EOF
  else
    svrmgrl <<EOF >$SID_HOME/audit/ora.error
    connect internal
    startup mount
    exit
EOF
  fi
  grep "ORA-" $SID_HOME/audit/ora.error
  if [ $? -eq 0 ]
  then
    cat $SID_HOME/audit/ora.error
    echo
    echo "Script is terminating due to error"
    echo
    exit
  fi
fi
if [ $ans = "n" ]
then
# Added by David DeClercq
  if [ "`echo exit|sqlplus /nolog|grep 'Release [8-9]'`" ]
  then
    sqlplus /nolog >$SID_HOME/audit/ora.error
    connect / as sysdba
    alter database backup controlfile to trace noresetlogs;
    exit
EOF
  else
    svrmgrl <<EOF >$SID_HOME/audit/ora.error
    connect internal
    alter database backup controlfile to trace noresetlogs;
    exit
EOF
  fi
  grep "ORA-" $SID_HOME/audit/ora.error
  if [ $? -eq 0 ]
  then
    cat $SID_HOME/audit/ora.error
    echo
    echo "Script is terminating due to error"
    echo
    exit
  else
    ans=l
  fi
fi
rm $SID_HOME/audit/bkdest.list >/dev/null 2>&1
# Added by David DeClercq
  if [ "`echo exit|sqlplus /nolog|grep 'Release [8-9]'`" ]
  then
   sqlplus /nolog <<EOF >$SID_HOME/audit/ora.error
   connect / as sysdba
   spool $SID_HOME/audit/bkdest.list
   select value
   from v\$parameter where name = 'user_dump_dest';
   spool off
EOF
  else
   svrmgrl <<EOF >$SID_HOME/audit/ora.error
   connect internal
   spool $SID_HOME/audit/bkdest.list
   select value
   from v\$parameter where name = 'user_dump_dest';
   spool off
EOF
  fi
grep "ORA-" $SID_HOME/audit/ora.error
if [ $? -eq 0 ]
then
  cat $SID_HOME/audit/ora.error
  echo
  echo "Script is terminating due to error"
  echo
  exit
fi
dump_dest=`grep dump $SID_HOME/audit/bkdest.list | awk '{
  if (substr($1,length($1),1) == "/") {print $1} else {print $1 "/"}}'`
if [ $ans = "l" ]
then
  trc_count=`ls -t ${dump_dest}*ora* | wc -l | awk '{print $NF}'`
  if [ ${trc_count} -gt 1 ]
  then
    controlfile=`ls -t ${dump_dest}*ora* | sed -e 2,${trc_count}d`
  else
    controlfile=`ls -t ${dump_dest}*ora*`
  fi
else
  controlfile=${dump_dest}$ans
  if [ ! -f $controlfile ]
  then
    echo
    echo "The controlfile trace you supplied does not exist under the oracle"
    echo "  user_dump_dest directory"
    echo "Script is terminating unsuccessfully"
    echo
    exit
  fi
fi
rm $SID_HOME/audit/bkdest.list >/dev/null 2>&1
if [ $shutdown_sw -eq 1 ]
then
  echo "Shutting instance $ORACLE_SID back down"
# Added by David DeClercq
  if [ "`echo exit|sqlplus /nolog|grep 'Release [8-9]'`" ]
  then
    sqlplus /nolog <<EOF >$SID_HOME/audit/ora.error
    connect / as sysdba
    shutdown immediate
    exit
EOF
  else
    svrmgrl <<EOF >$SID_HOME/audit/ora.error
    connect internal
    shutdown immediate
    exit
EOF
  fi
  grep "ORA-" $SID_HOME/audit/ora.error
  if [ $? -eq 0 ]
  then
    cat $SID_HOME/audit/ora.error
    echo
    echo "Script is terminating due to error"
    echo
    exit
  fi
fi
echo
echo Using controlfile trace $controlfile
# --------------------------------------------------------------------
# extract database datafile types and names from the controlfile trace
# --------------------------------------------------------------------
awk -F"'" '{
if (substr($1,1,4) == "LOGF" || substr($1,1,4) == "DATA")
{
   filetype = substr($1,1,1) " "
}
else
{ if (substr($1,3,5) == "GROUP")
  {
     filetype = substr(filetype,1,1) substr($1,9,1)
  }
  else
  { if (substr($2,1,1) == "/")
    {
       print filetype " " $2
    }
  }
}
}' $controlfile >$SID_HOME/audit/datafile.list
# --------------------------------------------------------------------
# determine backup directories to search for backup files
# --------------------------------------------------------------------
echo
echo "File \$SID_HOME/admin/backup.ctl will be used to identify backup locations"
echo "  unless an alternate file (which must exist under \$SID_HOME/admin) is"
echo "  entered here (CR to accept default) ====>"
read backup_file
if [ ! -z "$backup_file" ]
then
  if [ "$backup_file" = "q" ]
  then
    echo
    echo "Script is terminating by user request"
    echo
    exit
  else
    backup_ctl=$SID_HOME/admin/$backup_file
  fi
else
  backup_ctl=$SID_HOME/admin/backup.ctl
fi
if [ ! -f ${backup_ctl} ]
then
  echo
  echo "File ${backup_ctl} does not exist"
  echo "Script is terminating due to error"
  echo
  exit
fi
#
# Eliminate any duplicate backup locations specified in the backup control file.
# Keep the least qualified backup path as all subdirectories will be searched
# to locate backup files.
#
sort -t : -k 2.1 -o ${backup_ctl}.sort ${backup_ctl}
last_backup_levels=xxxx
while read backup_line
do
  if [ -z "$backup_line" ] || [ "`echo $backup_line | cut -c1`" = "#" ]
  then
    continue
  fi
  backup_path=`echo $backup_line | awk -F: '{print $2}'`
  level_cnt=1
  dup_sw=1
  for last_level in `echo $last_backup_levels`
  do
    level_cnt=`expr $level_cnt + 1`
    if [ "$last_level" != "`echo $backup_path|cut -d/ -f${level_cnt}`" ]
    then
      dup_sw=0
      echo $backup_path
      last_backup_levels=`echo $backup_path|awk -F/ '{
        for (i = 1; i <= NF; i++) print $i}'`
      break
    fi
  done
done <${backup_ctl}.sort >${backup_ctl}.temp
# --------------------------------------------------------------------
# find all available backup files
# --------------------------------------------------------------------
>$SID_HOME/audit/backup.list
while read bkdir
do
  ls -ltR $bkdir | sed -e '/^$/d' -e '/^total/d' > $SID_HOME/audit/backup.temp
  while read ls1 ls2 ls3 ls4 ls5 ls6 ls7 ls8 ls9
  do
    echo $ls1 | grep ':' >/dev/null
    if [ $? -eq 0 ]
    then
      echo $ls1 | grep oracle\/$ORACLE_SID > /dev/null
      if [ $? -eq 0 ]
      then
	backup_path=`echo $ls1 | awk -F: '{print $1}'`
      fi
    else
      if [[ ! -z $ls9 && -f $backup_path/$ls9 ]]
      then
	echo $backup_path/$ls9 $ls6 $ls7 $ls8 >>$SID_HOME/audit/backup.list
      fi
    fi
  done<$SID_HOME/audit/backup.temp
done<${backup_ctl}.temp
rm $SID_HOME/audit/backup.temp
# --------------------------------------------------------------------
# prompt for log recovery from mirror or backup
# --------------------------------------------------------------------
log_cptype=x
while [ "$log_cptype" != "b" -a "$log_cptype" != "m" -a "$log_cptype" != "s" \
        -a "$log_cptype" != "q" ]
do
  echo
  echo "Generate copies for redo logs from backup(b),from mirror(m), or skip(s) ====>"
  read log_cptype
done
if [ $log_cptype = "q" ]
then
  echo
  echo "Script is terminating by user request"
  echo
  exit
fi
if [ $log_cptype = "m" ]
then
  log_cpsource=
  while [[ -z "$log_cpsource" ]]
  do
    echo
    echo "Enter a logfile mask that identifies your good log mirror:"
    echo "(ex:If your log mount points were /u03 and /u04, you might enter /u04) ====>"
    read log_cpsource
  done
  if [ $log_cpsource = "q" ]
  then
    echo
    echo "Script is terminating by user request"
    echo
    exit
  fi
  >$SID_HOME/audit/log.good
  >$SID_HOME/audit/log.bad
fi
# -------------------------------------------------------------------------
# prompt for datafile recovery type of full, commented full, or using masks
# -------------------------------------------------------------------------
data_cptype=x
while [ "$data_cptype" != "f" -a "$data_cptype" != "c" \
   -a "$data_cptype" != "m" -a "$data_cptype" != "s" -a "$data_cptype" != "q" ]
do
  echo
  echo "Generate copies for tablespace datafiles as follows:"
  echo "  full (f)"
  echo "  full but commented copy commands (c)"
  echo "  selective using datafile masks (m)"
  echo "  skip tablespace datafile processing (s)"
  echo "====>"
  read data_cptype
done
if [ $data_cptype = "q" ]
then
  echo
  echo "Script is terminating by user request"
  echo
  exit
fi
if [ $data_cptype = "m" ]
then
  >$SID_HOME/audit/mask.file
  data_mask=#####
  echo "Note: Datafile masks are processed as fixed strings occurring anywhere"
  echo "      within the fully qualified filename"
  echo "      (Do not enter wildcard characters)"
  while [[ ! -z "$data_mask" ]]
  do
    echo "Enter next mask for tablespace datafile selection or CR to end input ====>"
    read data_mask
    if [[ ! -z $data_mask ]]
    then
      echo $data_mask >>$SID_HOME/audit/mask.file
    fi
  done
fi
echo
echo "Script is processing your selections: Please wait....."
# --------------------------------------------------------------------
# generate copy commands from backup files to database datafiles
# --------------------------------------------------------------------
first_datafile=1
first_log=1
while read filetype pathname 
do
  filename=`echo $pathname | awk -F/ '{print $NF}'`
  grep "$filename" $SID_HOME/audit/backup.list >temp.out
  if [ $? -eq 0 ]
  then
    count=`cat temp.out | wc -l`
    if [ $count -gt 1 ]
    then
      line_no=0
      while read dup a b c
      do
	line_no=`expr $line_no + 1`
	if [ $line_no -eq 1 ] || [[ $dup -nt $newest_file ]]
	then
	  newest_file=$dup
	  newest_num=$line_no
        fi
      done<temp.out
      cp temp.out temp.out2
      echo "#Msg====> duplicate backups were found for" $filename
      echo "#Msg====> the following older backups were ignored:"
      awk -v keep_num="$newest_num" '{
	if (NR != keep_num)
	{
	   print "#Msg====>",$0
        }
	else
	{
	   print $0 > "temp.out"
        }
      }' temp.out2
      rm temp.out2
    fi
    filetype1=`echo $filetype | cut -c1`
    if [ $filetype1 = "D" ]
    then
      if [ $data_cptype != "s" ]
      then
        if [ $first_datafile -eq 1 ]
        then
	  first_datafile=0
	  echo "##===================================================================##"
	  echo "##=============== DATAFILE COPY COMMANDS ============================##"
	  echo "##===================================================================##"
        fi
	keep_data=1
	if [ $data_cptype = "c" ]
	then
	  comment=#
        else
	  comment=
        fi
	if [ $data_cptype = "m" ]
	then
	  keep_data=0
	  while read data_mask
	  do
	    echo $pathname | fgrep "$data_mask" >/dev/null
	    if [ $? -eq 0 ]
	    then
	      keep_data=1
            fi
          done<$SID_HOME/audit/mask.file
        fi
	if [ $keep_data -eq 1 ]
	then
	  echo "${comment}echo Recovering $pathname"
	  if [ "`awk '{print substr($1,length($1)-1,2)}' temp.out`" = ".Z" ]
	  then
            echo ${comment}'uncompress <' `awk '{print $1}' temp.out` "\\"
            echo ${comment}'  >' $pathname `awk '{print "#---------------->",$2,$3,$4}' temp.out`
	  else
            echo ${comment}cp `awk '{print $1}' temp.out` "\\"
            echo ${comment} " " $pathname `awk '{print "#---------------->",$2,$3,$4}' temp.out`
          fi
	  echo ${comment}'copyrc=$?'
	  echo ${comment}'if [ $copyrc -ne 0 ]'
	  echo ${comment}'then'
	  echo ${comment}'  echo "====>ERROR: copy return code = $copyrc"'
	  echo ${comment}'fi'
	fi
      fi
    else
      if [ $log_cptype != "s" ]
      then
	if [ $log_cptype = "m" ]
	then
	  echo $filetype $pathname | fgrep "$log_cpsource" >>$SID_HOME/audit/log.good
	  if [ $? -eq 1 ]
	  then
	    echo $filetype $pathname >>$SID_HOME/audit/log.bad
	  fi
        else
          if [ $first_log -eq 1 ]
          then
	    first_log=0
	    echo "##===================================================================##"
	    echo "##================== LOG COPY COMMANDS ==============================##"
	    echo "##===================================================================##"
          fi
	  echo "echo Recovering $pathname"
	  if [ "`awk '{print substr($1,length($1)-1,2)}' temp.out`" = ".Z" ]
	  then
            echo 'uncompress <' `awk '{print $1}' temp.out` "\\"
            echo '  >' $pathname `awk '{print "#---------------->",$2,$3,$4}' temp.out`
	  else
            echo "cp" `awk '{print $1}' temp.out` "\\"
            echo "  " $pathname `awk '{print "#---------------->",$2,$3,$4}' temp.out`
	  fi
	  echo 'copyrc=$?'
	  echo 'if [ $copyrc -ne 0 ]'
	  echo 'then'
	  echo '  echo "====>ERROR: copy return code = $copyrc"'
	  echo 'fi'
	fi
      fi
    fi
  else
    echo "#Msg====> no backup for" $pathname
  fi
done<$SID_HOME/audit/datafile.list>>$SID_HOME/admin/recover_${ORACLE_SID}.sh
if [ $log_cptype = "m" ]
then
  if [ $first_log -eq 1 ]
  then
    first_log=0
    echo "##===================================================================##" >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
    echo "##================== LOG COPY COMMANDS ==============================##" >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
    echo "##===================================================================##" >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
  fi
  while read badgrp badlog
  do
    goodlog=`awk -v badg="$badgrp" '{
      if ($1 == badg)
      { print $2 }
      }' $SID_HOME/audit/log.good`
    echo "echo Recovering $badlog" >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
    echo "cp" $goodlog "\\" >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
    echo "  " $badlog >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
    echo 'copyrc=$?' >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
    echo 'if [ $copyrc -ne 0 ]' >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
    echo 'then' >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
    echo '  echo "====>ERROR: copy return code = $copyrc"' >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
    echo 'fi' >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
  done<$SID_HOME/audit/log.bad
fi
echo "exit" >>$SID_HOME/admin/recover_${ORACLE_SID}.sh
echo
echo "Processing is complete"
echo "View the generated recovery script, \$SID_HOME/admin/recover_${ORACLE_SID}.sh"
echo 'Scan the script for any "#Msg====>" messages and approve before submitting'
echo
chmod 700 $SID_HOME/admin/recover_${ORACLE_SID}.sh
rm ${backup_ctl}.sort >/dev/null 2>&1
rm ${backup_ctl}.temp >/dev/null 2>&1
rm $SID_HOME/audit/mask.file >/dev/null 2>&1
rm $SID_HOME/audit/log.good >/dev/null 2>&1
rm $SID_HOME/audit/log.bad >/dev/null 2>&1
rm temp.out >/dev/null 2>&1
rm $SID_HOME/audit/ora.error >/dev/null 2>&1
exit
