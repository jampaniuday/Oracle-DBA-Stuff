#!/bin/ksh
###############################################################################
## test_backup_copy.sh
##
##   PURPOSE: To execute the actual compressed and full datafile copy commands
##     for the specific Oracle datafiles or tablespaces supplied by calling
##     script, test_backup.sh
##   USAGE: The command line submitted by test_backup.sh is:
##     test_backup_copy.sh GroupId
##     >$SID_HOME/audit/backup_GroupId.audit 2>&1
##     Note: Do NOT attempt to run this script directly since many required
##           inputs are passed as exported variables from backup.sh
##
###############################################################################
group_id=$1
if [ ! -f ${audit_path}/backup.${group_id}.list ]
then
  echo "#######################################################"
  echo "## ERROR ====> required backup list file does not exist"
  echo "#######################################################"
  error_switch=1
  exit
fi
error_switch=0
recovery_file=$default_dir/recover_${group_id}.sh
echo "#!/bin/ksh" > $recovery_file
echo 'echo "====>Starting recovery of $ORACLE_SID datafiles on `date`"' >>$recovery_file
echo
echo "====>Processing ${group_id} datafile group"
echo
## ------------------------------------------------------------------------ ##
##     execute a compressed unix backup of each oracle datafile             ##
## ------------------------------------------------------------------------ ##
first_sw=1
copy_cnt=0
last_tablespace_name=xxxxxxxx
error_tablespace_name=xxxxxxxx
# Loop over the selective data, log, and/or control file list created by parent
# script, backup.sh, from the Oracle catalog and from filters supplied in the 
# backup.ctl input file
cat ${audit_path}/backup.${group_id}.list | while read backup_list
do
  tablespace_name=`echo ${backup_list} | awk '{print $1}'`
  if [ ${backup_type} = "hot" ]
  then
    if [ ${tablespace_name} = "REDOLOG" -o ${tablespace_name} = "CONTROLFILE" ]
    then
      continue
    fi
  fi
  full_file_name=`echo ${backup_list} | awk '{print $2}'`
  file_name=`basename ${full_file_name}`
# For hot backup processing only,
# execute an Oracle end backup command for the last tablespace processed and
# an Oracle begin backup command for the next tablespace to process
  if [ ${tablespace_name} != ${last_tablespace_name} -a ${backup_type} = "hot" ]
  then
    if [ ${first_sw} -eq 0 ]
    then
      END_BACKUP=${last_tablespace_name}; export END_BACKUP
      sqlplus -s /nolog >${audit_path}/bkstatus_${group_id}.list <<END
      connect / as SYSDBA
      alter tablespace ${END_BACKUP} end backup;
      exit
END
      grep "ORA-" ${audit_path}/bkstatus_${group_id}.list | egrep -v "01142" >/dev/null
      if [ $? -eq 0 ]
      then
        echo "#####################################################"
        echo "## ERROR ====> end backup failed for ${last_tablespace_name}"
        cat ${audit_path}/bkstatus_${group_id}.list | grep ORA- | awk '{print "##", $0}'
        echo "#####################################################"
        error_switch=1
        error_tablespace_name=${last_tablespace_name}
        break
      fi
    else
      first_sw=0
    fi
    BEGIN_BACKUP=${tablespace_name}; export BEGIN_BACKUP
    sqlplus -s /nolog >${audit_path}/bkstatus_${group_id}.list <<END
    connect / as SYSDBA
    alter tablespace ${BEGIN_BACKUP} begin backup;
    exit
END
    grep "ORA-" ${audit_path}/bkstatus_${group_id}.list >/dev/null
    if [ $? -eq 0 ]
    then
      grep "ORA-01642" ${audit_path}/bkstatus_${group_id}.list >/dev/null
      if [ $? -eq 0 ]
      then
        echo "================================================================"
        echo "== WARNING ====> ${tablespace_name} backup skipped-tablespace is read only"
        cat ${audit_path}/bkstatus_${group_id}.list | grep ORA- | awk '{print "==", $0}'
        echo "================================================================"
        if [ ${error_switch} -eq 0 ]
        then
          error_switch=2
        fi
        first_sw=1
        continue
      else
        last_tablespace_name=${tablespace_name}
        grep "ORA-01146" ${audit_path}/bkstatus_${group_id}.list >/dev/null
        if [ $? -eq 0 ]
        then
          echo "====================================================="
          echo "== WARNING ====> begin backup failed for ${tablespace_name}"
          cat ${audit_path}/bkstatus_${group_id}.list | grep ORA- | awk '{print "==", $0}'
          echo "====================================================="
          if [ ${error_switch} -eq 0 ]
          then
            error_switch=2
          fi
        else
          echo "#####################################################"
          echo "## ERROR ====> begin backup failed for ${tablespace_name}"
          cat ${audit_path}/bkstatus_${group_id}.list | grep ORA- | awk '{print "##", $0}'
          echo "#####################################################"
          error_switch=1
          error_tablespace_name=${tablespace_name}
          first_sw=1
          break
        fi
      fi
    else
      last_tablespace_name=${tablespace_name}
    fi
  fi
if [ ${error_tablespace_name} != ${tablespace_name} ]
then
# Loop over the backup.ctl file to determine the backup directory to use for
# the current Oracle file being processed
  while read backup_ctl
  do
    if [ -z "$backup_ctl" ] || [ "`echo $backup_ctl | cut -c1`" = "#" ] || \
       [ "`echo $backup_ctl | cut -d: -f1`" = "ONLY" ] || \
       [ "`echo $backup_ctl | cut -c1-7`" = "TSGROUP" ] || \
       [ "`echo $backup_ctl | cut -c1-9`" = "FILEGROUP" ]
    then
      continue
    fi
    from_dir=`echo $backup_ctl | awk -F: '{print $1}'`
    from_levels=`echo $from_dir|awk -F/ '{for (i = 1; i <= NF; i++) print $i}'`
    match_sw=1
    level_cnt=1
    for level in `echo $from_levels`
    do
      level_cnt=`expr $level_cnt + 1`
      if [ "$level" != "`echo $full_file_name|cut -d/ -f${level_cnt}`" ]
      then
        match_sw=0
        break
      fi
    done
    if [ $match_sw -eq 1 ]
    then
      to_dir=`echo $backup_ctl | awk -F: '{print $2}'`
      break
    fi
  done <${backup_file}.sort
# Append oracle/${ORACLE_SID}/data or log or control to the backup directory
# path extracted from backup.ctl to construct the full backup directory path
# to use
  to_extend=`echo $full_file_name|awk '{
    print substr($1,index($1,"/oracle"),length($1)-index($1,"/oracle")+1)}'`
# If the current Oracle file does not match any specific entry in the
# backup.ctl file, use the DEFAULT entry as the backup location
  if [ $match_sw -eq 0 ]
  then
    to_dir=${default_dir}
  fi
  to_file_name=${to_dir}${to_extend}
  test_file_name=${to_dir}/test${to_extend}
  test2_file_name=${to_dir}/test2${to_extend}
  to_path=`dirname $to_file_name`
  if [ ! -d $to_path ]
  then
    mkdir -p $to_path >/dev/null 2>&1
  fi
  from_level=`echo $full_file_name|awk '{
    print substr($1,1,index($1,"/oracle")-1)}'`
  test2_level=${to_dir}/test2
# write recovery entries for this file to a recovery script under the default
# backup directory
  echo '##' >>$recovery_file
  echo '##=====>Recover ' $file_name >>$recovery_file
  echo '##' >>$recovery_file
  echo '/usr/bin/uncompress <'${to_file_name}'.Z >'${test2_file_name} >>$recovery_file 
  echo 'copyrc=$?' >>$recovery_file
  echo 'from_bytes=`ls -l '$to_file_name'.Z | awk '"'"'{print $5}'"'"'`' >>$recovery_file
  echo 'if [ $copyrc -ne 0 ]' >>$recovery_file
  echo 'then' >>$recovery_file
  echo '  echo "cp '$file_name $to_dir' ===> '$test2_level' ##ERROR===>rc:$copyrc"' >>$recovery_file
  echo 'else' >>$recovery_file
  echo '  to_bytes=`ls -l '$test2_file_name' | awk '"'"'{print $5}'"'"'`' >>$recovery_file
  echo '  echo "cp '$file_name $to_dir' ===> '$test2_level' bytes: $from_bytes => $to_bytes"' >>$recovery_file
  echo 'fi' >>$recovery_file
  echo 'diff '$test_file_name' '$test2_file_name >>$recovery_file
  echo 'if [ $? -eq 0 ]' >>$recovery_file
  echo 'then' >> $recovery_file
  echo '  rm '$test2_file_name >>$recovery_file
  echo 'fi' >>$recovery_file
# Save last backup until the current file copy completes successfully
  if [ -f ${to_file_name}.Z ]
  then
    cp -p ${to_file_name}.Z ${to_file_name}.Z.save
  fi
# create a compressed backup file
  /usr/bin/compress -f < ${full_file_name} > ${to_file_name}.Z
  copyrc=$?
  from_bytes=`ls -l $full_file_name | awk '{print $5}'`
  if [ $copyrc -ne 0 -a $copyrc -ne 2 ]
  then
    echo "cp ${file_name} ${from_level} ===> ${to_dir}"
    echo "#####################################################"
    echo "## ERROR ====> return code from copy command is " $copyrc
    echo "#####################################################"
    error_switch=1
    error_tablespace_name=${tablespace_name}
    break
  else
    cp -p ${full_file_name} ${test_file_name}
    if [ $? -ne 0 ]
    then
      echo "###################################################################"
      echo "## ERROR ====> uncompressed copy of " $full_file_name " failed"
      echo "###################################################################"
    fi
    copy_cnt=`expr $copy_cnt + 1`
    to_bytes=`ls -l ${to_file_name}.Z | awk '{print $5}'`
    echo "cp ${file_name} ${from_level} => ${to_dir} bytes: ${from_bytes} => ${to_bytes}"
# Remove last backup now that the current file copy has completed successfully
    rm ${to_file_name}.Z.save >/dev/null 2>&1
    if [ $copyrc -eq 2 ]
    then
      echo "########################################################"
      echo "## WARNING ====> compressed file is larger than original"
      echo "########################################################"
    fi
  fi
fi
done
# For hot backups only, execute an Oracle end backup command for the last
# tablespace processed
if [ $backup_type = "hot" -a $first_sw -eq 0 ]
then
  END_BACKUP=${last_tablespace_name}; export END_BACKUP
  sqlplus -s /nolog >${audit_path}/bkstatus_${group_id}.list <<END
  connect / as SYSDBA
  alter tablespace ${END_BACKUP} end backup;
  exit
END
  grep "ORA-" ${audit_path}/bkstatus_${group_id}.list | egrep -v "01142" >/dev/null
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> end backup failed for ${last_tablespace_name}"
    cat ${audit_path}/bkstatus_${group_id}.list | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    error_tablespace_name=${last_tablespace_name}
  fi
fi
echo
echo "====>Completed ${backup_type} backup of ${group_id} datafiles on" `date`
echo
echo "${group_id} successful datafile copy count is $copy_cnt"
echo 'echo "====>Recovery ending on `date`"' >>$recovery_file
echo 'exit' >>$recovery_file
rm ${audit_path}/bkstatus_${group_id}.list >/dev/null 2>&1
exit $error_switch
