#!/bin/ksh
## Purpose    : Gathers schema Tables / Indexes with 30% sample, to make best use of CBO
##              on the specified instance.
## Usage      : ohrschemas.sh <SID>
## Parameter  : Oracle SID
## Created by : Mugunthan

## Notify Information ##
sid=$1
notify_who="mugunthan.bala"
notify_host=`hostname`
notify_sid=$sid
notify_type="Gather Schema"

## Check for SID parameter ##
if [ -z "$sid" ]
then
  echo
  echo "Invalid Parameter input"
  echo "Usage is ohrschemas.sh sid"
  echo
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/ohrschemas.audit
  exit
fi

## Check for $HOME/bin/SID Environment ##
if [ ! -f $HOME/bin/$sid ]
then
  echo "Error====>No environment script found for instance \"$sid\""
  echo "          Script is terminating!"
  exit
fi

## Set Environment ##
. $HOME/bin/$sid

echo "###############################################################"
echo "##    Script ohrschemas.sh starting on " `date` for $sid
echo "###############################################################"

## Check for Instance ##
inst=`ps -ef | grep ora_smon_$sid | grep -v grep`
if [ -z "$inst" ]
then
  echo "Oracle instance, $sid is not available."
  echo "Script is terminating."
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/ohrschemas.audit
  exit
fi

## Pick up apps password from tellme ##
PWD=`$HOME/bin/tellme apps`
if [ -z "$PWD" ]
then
  echo "Error : No password selected for APPS"
  echo "Script is termianting"
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/ohrschemas.audit
  exit
fi

sqlplus -s apps/${PWD}@$sid <<EOF
exec fnd_stats.gather_schema_statistics('APPS','30');
exec fnd_stats.gather_schema_statistics('APPLSYS','30');
exec fnd_stats.gather_schema_statistics('HR','30');
exec fnd_stats.gather_schema_statistics('GEHR','30');
exit;
echo "Gather Schema ran successfully for $sid"
