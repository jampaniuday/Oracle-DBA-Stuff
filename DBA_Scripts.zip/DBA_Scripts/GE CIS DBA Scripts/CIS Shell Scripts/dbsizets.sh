#!/bin/ksh

# Created By: Satyen Jadia
# Created Date: November 25th 2003
# Purppose: Script to get database size
# Usage: dbsize


oratab_loc=/etc/oratab
audit_path=/tmp
audit_file_name=`hostname`".dbsize"
echo "Database size report for Server `hostname`" > $audit_path/$audit_file_name
echo "--------------------------------------------" >> $audit_path/$audit_file_name
echo "" >> $audit_path/$audit_file_name

if [ ! -f $oratab_loc ]
then
  echo "Oratab file not found."
  exit 1
fi

while read oratab_line
do
  dbname=`echo $oratab_line| awk -F":" '{print $1}'`
  if [ ! -z "$dbname" ]
  then
  # Check database is up
  dbup=`ps -ef | grep "$dbname" | grep pmon | grep -v grep`
  if [ ! -z "$dbup" ]
  then
    # Check database environment file
    if [ ! -f $HOME/bin/$dbname ]
    then
      echo "Database environment file does not exists for $dbname."
    else
      echo "DB Name	-	$dbname" >> $audit_path/$audit_file_name
      echo "---------------------------" >> $audit_path/$audit_file_name
      # Setup environment & calculate space
      . $HOME/bin/$dbname
      # Get System Password
      syspswd=`$HOME/bin/tellme system`
      if [ ! -z "$syspswd" ]
      then
sqlplus -s system/$syspswd << EOF > $audit_path/ora.error
col "TotalSize(GB)" format 9,999,999.99
col tablespace_name format a40
set pages 100 feedback off
break on report
compute sum of "TotalSize(GB)" on report
spool $audit_path/dbsize.lst
select tablespace_name, sum(bytes)/(1024*1024*1024) "TotalSize(GB)"
from   dba_data_files
group  by tablespace_name;
spool off
exit
EOF
        err=`grep "ORA-" $audit_path/ora.error`
        if [ ! -z "$err" ]
        then
          echo "Error selecting database size for $dbname." >> $audit_path/$audit_file_name
        else
          cat $audit_path/dbsize.lst >> $audit_path/$audit_file_name
          echo "">> $audit_path/$audit_file_name
        fi
      else
        echo "Invalid system password for $dbname." >> $audit_path/$audit_file_name
      fi
    fi
  fi
  fi
done < $oratab_loc

#mailx -s "Database size on `hostname`" monica.valeanu@corporate.ge.com < $audit_path/$audit_file_name
#mailx -s "Database size on `hostname`" dwh.ssprdsupp@ge.com,monica.valeanu@corporate.ge.com,sumit.mondaiyka@gecis.ge.com,purushottam.nivaskar@ge.com,suparna.saldanha@ge.com < $audit_path/$audit_file_name
mailx -s "Database size on `hostname`" gts.gecisnotifydba@corporate.ge.com,sumit.mondaiyka@gecis.ge.com < $audit_path/$audit_file_name
exit 0
