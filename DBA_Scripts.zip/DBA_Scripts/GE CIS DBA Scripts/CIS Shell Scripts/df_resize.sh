##############################################################################################
# This script is ment to help DBA's in resizing the datafiles by finding the high watermark  #
# of datafiles. The script generates one sql file for every instance, the sql file contains  #
# sql statments to resize the datafiles of that instance alsong with the amount of space that#	
# will be released due to each datafile reorg. Also it will generate a shell script          #
# run_df_resize.sh using which the DBA's can execute the datafile resize statements for      #
# for multiple instances at one go.				     			     #
# The script can be run for one instance or for all the instances that are up and running.   #
# Output of the script will be emailed to the concerned persons.			     #
##############################################################################################
# Limitations : 									     #
# 1) The script will work from DB versions Oracle 8.1.7.4 onwards only.	                     #
# 2) The datafiles will be resized with a buffer of 10% of extisting datafile size.          # 
# 3) The script will not resize datafiles of SYSTEM, RBS, and Temp.			     #
# 4) The script must be executed from the Oracle OS user who is the owner for that instance. #  
##############################################################################################
# Usage  : df_resize.sh {sid|all}							     #
# Author : Ramesh.P									     #
##############################################################################################

if [ -z "$1" ] 
then 
   echo "Usage is : df_resize.sh {sid|all} "
   exit 1
fi

if [ $1 = "all" ]
then
#   allsid=`ps -eo comm | grep pmon | cut -d_ -f3|xargs echo`
    allsid=`ps -ef | grep pmon | grep -v grep | awk '{print $8}' | cut -d_ -f3 | xargs echo`
else
   ps -ef | grep pmon | grep $1 > /dev/null 2>&1
   if [ $? -eq 0 ] 
   then
      allsid=$1
   else
      echo "Please check the SID, The instance must be up."
      exit 1
   fi 
fi

script_loc=$DBA_HOME/admin
resize_loc=$DBA_HOME/admin/resize

if [ ! -d $resize_loc ]
then
   mkdir $DBA_HOME/admin/resize
fi 

rm $script_loc/run_df_resize.sh
rm $resize_loc/*.sql
rm $resize_loc/*.log

tot_space=0
for ALLS in $allsid
do
os_user=`ps -ef | grep pmon | grep $ALLS | awk '{print $1}'`
if [ -f $HOME/bin/$ALLS -a "$os_user" = "$LOGNAME" ]
then
. $HOME/bin/$ALLS
if [ "$ORACLE_SID" = "$ALLS" ]
then
sqlplus -s "/as sysdba" @$script_loc/df_resize_proc.sql <<EOF >$SID_HOME/audit/cerr.err
EOF
   
   connerr=`grep "SP2" $SID_HOME/audit/cerr.err`
   sqlerr=`grep "ORA-" $SID_HOME/audit/cerr.err`

   if [ ! -z "$connerr" -o ! -z "$sqlerr" ]
   then
      echo "Script Terminated."
      echo "Please check the $SID_HOME/audit/cerr.err log file for more information."
      exit 1
   fi

   inst_space=0
   inst_space=`grep "Total" $resize_loc/$ALLS.sql|cut -d: -f2`
   tot_space=`expr $tot_space + $inst_space`

   if [ $inst_space -gt 0 ]  
   then
      echo ". $HOME/bin/$ALLS" >> $script_loc/run_df_resize.sh
      echo "sqlplus '/as sysdba' <<EOF" >> $script_loc/run_df_resize.sh
      echo "@$DBA_HOME/admin/resize/$ALLS.sql" >> $script_loc/run_df_resize.sh
      echo "Exit;" >> $script_loc/run_df_resize.sh
      echo "EOF" >> $script_loc/run_df_resize.sh
      echo "echo \"Datafiles Resized on $ALLS\" " >> $script_loc/run_df_resize.sh
      echo "#####################################################" >> $script_loc/run_df_resize.sh
      echo "Total Space in MB that can be released from $ALLS instance is $inst_space" >> $resize_loc/resize.log
   fi
fi
else
   echo "Execute the script as $os_user for $ALLS instance." >> $resize_loc/resize.log
fi
done

if [ -f $script_loc/run_df_resize.sh ]
then
   chmod 755 $script_loc/run_df_resize.sh
fi

if [ -f $resize_loc/resize.log ]
then
   echo " " >> $resize_loc/done.log
   echo " " >> $resize_loc/done.log
   echo "Host : `hostname`" >> $resize_loc/done.log
   echo " " >> $resize_loc/done.log
   echo "Total Space in MB that can be released from this reorg is $tot_space" >> $resize_loc/done.log
   echo " " >> $resize_loc/done.log
   echo "To proceed with the Datafile resize Please execute the following script." >> $resize_loc/done.log
   echo "$script_loc/run_df_resize.sh" >>  $resize_loc/done.log
   echo " " >> $resize_loc/done.log
   grep "Execute the script as" $resize_loc/resize.log >> $resize_loc/done.log
   echo " " >> $resize_loc/done.log 
   echo "-------------------------------------------------------------------------" >> $resize_loc/done.log
   if [ $1 = "all" ]
   then 
      echo " " >> $resize_loc/done.log
      echo "Here is the instance wise list." >> $resize_loc/done.log
      echo " " >> $resize_loc/done.log
      grep "Total Space in MB that can be released from" $resize_loc/resize.log >> $resize_loc/done.log
   fi
   echo " " >> $resize_loc/done.log
   echo " " >> $resize_loc/done.log
   echo "Thanks & Regards" >> $resize_loc/done.log
   echo "Ramesh.P" >> $resize_loc/done.log
   cat $resize_loc/done.log
mailx -s "Datafile Resize Output." corpgtsgecisdba@gecis.ge.com < $resize_loc/done.log
fi
