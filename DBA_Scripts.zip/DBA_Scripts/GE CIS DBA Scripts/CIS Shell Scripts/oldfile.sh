#!/bin/ksh 

linux()
{
DATE=`date +%m-%d-%y-%H:%M`
b=`echo "/"`
rm /tmp/oldfile.lst
user=`id |cut -f2 -d=|cut -f2 -d"("|cut -f1 -d")"`
for i in `ls -l $b |awk '{print $9}'|grep "00"`
do
  for s in `ls -l $b$i |awk '{print$9}'|grep "u[0-9][0-9]"`
  do
  mount=`echo "$b$i/\$s/\$user"`
  if [ ! -d $mount ]
  then
    echo "test">>/dev/null
  else
    cd $mount
    for j in `ls -l $mount |awk '{print $9}'|grep -v product`
    do
      c=`echo "$mount/\$j"`
      find $c -type f -mtime +60 -exec ls -l {} \;>>/tmp/oldfile.lst
    done
  fi
  done
done
}

hp()
{
DATE=`date +%m-%d-%y-%H:%M`
b=`echo "/"`
rm /tmp/oldfile.lst
user=`id |cut -f2 -d=|cut -f2 -d"("|cut -f1 -d")"`
mp=`echo $user|cut -c 4-8`
for i in `ls -l $b |awk '{print $9}'|grep $mp`
do
  for s in `ls -l $b$i |awk '{print$9}'|grep "u[0-9][0-9]"`
  do
  mount=`echo "$b$i/\$s/oracle"`
  if [ ! -d $mount ]
  then
    echo "test">>/dev/null
  else
    cd $mount
    for j in `ls -l $mount |awk '{print $9}'|grep -v product`
    do
      c=`echo "$mount/\$j"`
      find $c -type f -mtime +60 -exec ls -l {} \;>>/tmp/oldfile.lst
    done
  fi
  done
done
}
sun()
{
DATE=`date +%m-%d-%y-%H:%M`
a=`hostname |cut -c5-9`
b=`echo "/\$a"`
rm /tmp/oldfile.lst
user=`id |cut -f2 -d=|cut -f2 -d"("|cut -f1 -d")"`
for i in `ls -l $b |awk '{print $9}'|grep "u[0-9][0-9]"`
do
  mount=`echo "$b/\$i/\$user"`
  if [ ! -d $mount ]
  then
    echo "test">>/dev/null
  else
    cd $mount
    for j in `ls -l $mount |awk '{print $9}'|grep -v product`
    do
      c=`echo "$mount/\$j"`
      find $c -type f -mtime +60 -exec ls -l {} \;>>/tmp/oldfile.lst
    done
  fi
done
}

if [ `uname` = "Linux" ]
then
linux
elif [ `uname` = "SunOS" ]
then 
sun
elif [ `uname` = "HP-UX" ]
then
hp
fi
mv /tmp/oldfile.lst /tmp/oldfile.lst.bk
cat /tmp/oldfile.lst.bk|grep -v temp|grep -v TEMP >/tmp/oldfile.lst 
size=`ls -l /tmp/oldfile.lst|awk '{print $5}'`
if [ $size -ne 0 ]
then
mailx -s "Old File Report - `hostname`" gtsshrd.ortm@ge.com,GTSOHR.LeadDBAs@corporate.ge.com < /tmp/oldfile.lst
echo "Mail"
fi
