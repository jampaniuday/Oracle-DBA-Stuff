#!/bin/ksh
################ Variables #################
notifyTo="matt.mullin@corporate.ge.com"

################## Inits #############
serverName=`uname -n`
runDateTime=`date`

mailtextHeader=`echo "Following are the file system stat from $serverName at $runDateTime"`

(echo $mailtextHeader;df -k)|mailx -s "File Stats from $serverName" $notifyTo
