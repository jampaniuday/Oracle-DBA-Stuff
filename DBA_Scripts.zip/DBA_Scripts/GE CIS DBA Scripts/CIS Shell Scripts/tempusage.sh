#!/bin/ksh

## Monitor temporary tablespace usage.
## Usage: tempusage.sh <SID>

## Verify usage

if [ -z "$1" ]
then
  echo "Error: Invalid usage."
  echo "Usage: tempusage.sh <SID>"
  exit 1
fi

## Verify environment script exists for the database

if [ ! -f "$HOME/bin/$1" ]
then
  echo "Environment script does not exists for database, $1."
  echo "Make sure script exists under $HOME/bin directory."
  exit 1
fi

## Setup environment

. $HOME/bin/$1

## Get system password

systempswd=`$HOME/bin/tellme system`

if [ -z "$systempswd" ]
then
  echo "Error: Cannot get system password for the database $1."
  echo "Update file $HOME/bin/oratask.lst with proper password."
  exit 1
fi

## Get Temp Space Usage for the database

sqlplus -s system/$systempswd << EOF > $SID_HOME/audit/tempusage.err
set pages 60
REM select  machine, count(*) from v\$session
REM group   by machine ;
select  to_char(sysdate, 'mm/dd/yyyy hh24:mi:ss') dtstamp,
        s.tablespace_name,
        d.tbspc_mb,
        s.total_blocks*8192/1024/1024 temp_tot_mb,
        s.used_blocks*8192/1024/1024 temp_used_mb,
        s.free_blocks*8192/1024/1024 temp_free_mb
from    v\$sort_segment s,
(select tablespace_name,sum(bytes/1024/1024) tbspc_mb
from    dba_data_files
group   by tablespace_name
union
select  tablespace_name,sum(bytes/1024/1024) tbspc_mb
from    dba_temp_files
group   by tablespace_name) d
where   s.tablespace_name=d.tablespace_name;
exit
EOF

err=`grep "ORA-" $SID_HOME/audit/tempusage.err`

if [ ! -z "$err" ]
then
  echo "Error selecting temp usage for database, $1."
  echo "      $err"
  echo "Check for $SID_HOME/audit/tempusage.err file for"
  echo "more information."
  exit 1
fi

cat $SID_HOME/audit/tempusage.err >> $SID_HOME/audit/tempusage.history

## Remove error file

rm $SID_HOME/audit/tempusage.err

exit 0
