#!/bin/ksh

## Check environment file exists 

if [ ! -f $HOME/bin/hrp1 ]
then
  echo "Environment file does not exists."
  echo "Script is terminating."
  exit 1
fi

## Set environment 

. $HOME/bin/hrp1

pswd=`tellme system`

if [ -z "$pswd" ]
then
  echo "No password for database user, couradm01."
  echo "Cannot connect to database."
  echo "Script is terminating."
  exit 1
fi

sqlplus -s system/$pswd << EOF > $SID_HOME/audit/invobj.error
set heading off echo off feedback off
select count(*) from dba_objects where status = 'INVALID'
having count(*) > 50;
exit
EOF

err=`grep -i "ORA-" $SID_HOME/audit/invobj.error`

if [ ! -z "$err" ]
then
  echo "Error selecting invalid objects count."
  echo "Check audit file, $SID_HOME/audit/invobj.error."
  echo "Script is terminating."
  exit 1
fi

## Remove temporary files

objcnt=`cat $SID_HOME/audit/invobj.error`

if [ -z "$objcnt" ]
then
  echo "Script completed successfully."
else
  mailx -s "Invalid objects greater than 50 in HRP1" jadia.satyen@corporate.ge.com < $SID_HOME/audit/invobj.error
  mailx -s "Invalid objects greater than 50 in HRP1" dharkara@corporate.ge.com < $SID_HOME/audit/invobj.error
  mailx -s "Invalid objects greater than 50 in HRP1" mhatrer@corporate.ge.com < $SID_HOME/audit/invobj.error
  exit 1
fi

exit 0
