#!/bin/ksh

Usage()
{
   echo ""
   echo ""
   echo ""
   echo "   MySccs.sh create               <FileName>   Create a new file in sccs(First time checkin)  "
   echo "   MySccs.sh checkout             <FileName>   Checkout the file"
   echo "   MySccs.sh checkin              <FileName>   Checkin the file"
   echo "   MySccs.sh del                  <FileName>   Delete the file"
   echo "   MySccs.sh undo                 <FileName>   Rollback the Checkout "
   echo "   MySccs.sh get                  <FileName>   Get the latest version (Readonly, can't change the file)"
   echo "   MySccs.sh version              <FileName>   Report the versions of a file  "
   echo "   MySccs.sh where                <FileName>   Report the repository for a file  "
   echo "   MySccs.sh owner                <FileName>   Report the User who currently checkout the file.  "
   echo "   MySccs.sh move                 <FileName> <repository>   switch the file to a different repository"
   echo ""
   echo ""
   echo "   MySccs.sh create <FileName> [<repository>]   Create a new file in sccs(First time checkin)  "
   echo "   MySccs.sh diff   <FileName> <version> >      Compare the current version with some specific version.  "
   echo "   MySccs.sh get     <FileName> <version>   Get a readonly copy of some specific version.  "
   echo "   MySccs.sh checkout <FileName> <version>   Checkout some old version.  "
   echo ""        
   echo "   MySccs.sh diff <FileName> <OldVer> <NewVer> Compare two versions  "
   echo ""
   echo ""
   exit 1
}

old_Usage()
{
   echo ""
   echo ""
   echo "Usage is MySccs.sh [[create|checkout|undo|checkin|get|version|owner][[diff|get|edit] -r <version>] \
[diff -r OV NV ] <FileName>"
   echo ""
   echo "   MySccs.sh create               <FileName>   Create a new file in sccs(First time checkin)  "
   echo "   MySccs.sh checkout             <FileName>   Checkout the file"
   echo "   MySccs.sh checkin              <FileName>   Checkin the file"
   echo "   MySccs.sh undo                 <FileName>   Rollback the Checkout "
   echo "   MySccs.sh get                  <FileName>   Get the latest version (Readonly, can't change the file)"
   echo "   MySccs.sh version              <FileName>   Report the versions of a file  "
   echo "   MySccs.sh owner                <FileName>   Report the User who currently checkout the file.  "
   echo "   MySccs.sh move                 <FileName> <repository>   switch the file to a different repository"
   echo ""
   echo "   MySccs.sh create <FileName> [<repository>]   Create a new file in sccs(First time checkin)  "
   echo ""
   echo "   MySccs.sh diff     -r <version>   <FileName>   Compare the current version with some specific version.  "
   echo "   MySccs.sh get      -r <version>   <FileName>   Get a readonly copy of some specific version.  "
   echo "   MySccs.sh checkout -r <version>   <FileName>   Checkout some old version.  "
   echo ""        
   echo "   MySccs.sh diff -r <OldVer> <NewVer> <FileName>   Compare two versions  "
   echo ""
   echo ""
   exit 1
}

get_answer() {
  init_prompt=$1
  printf "$init_prompt :"
  y_or_n=""
  while [ -z "$y_or_n" ]; do
    read y_or_n
    y_or_n=`echo $y_or_n | tr [:lower:] [:upper:]`
    if [ "$y_or_n" = "Y" ]; then
      retval=0
    elif [ "$y_or_n" = "N" ]; then
      retval=1
    else
      y_or_n=""
      printf "Please type Y or N :"
    fi
  done
  return $retval
}

GetFilesActualHome()
{
crd=`pwd`
bsname=`basename $crd`
drname=`dirname $crd`
if     [ `basename $drname` = "test" ]; then
       FilesActHome=`dirname $drname`/$bsname
else
       FilesActHome=$crd
fi
export FilesActHome
export FilesCheckoutDir=`dirname $FilesActHome`/test/`basename $FilesActHome`
#echo "!!!!! FilesActHome=>$FilesActHome"
#echo "!!!!! FilesCheckoutDir=>$FilesCheckoutDir"
}

ChkPwdEqlChkoutDir()
{
if     [ `pwd` != $FilesCheckoutDir ]; then
       echo "**** checkin or undo ($FileName) you need to be in ($FilesCheckoutDir)****" 
       exit 1
fi   
}

ValCheckoutDir()
{
if    [ ! -d $FilesCheckoutDir ]; then
      #GetFilePermissions;
      FilesCheckoutRoot="$FilesCheckoutDir"
      while [ ! -d "`dirname $FilesCheckoutRoot`" ]; do
        FilesCheckoutRoot=`dirname $FilesCheckoutRoot`
      done
      echo "***** Creating Checkout Directory ($FilesCheckoutDir) *****"
      pbrun mkdir -p $FilesCheckoutDir
      status=$?
      if [ $status -eq 0 ]; then
        pbrun chown -R $OwnerGroup $FilesCheckoutRoot
      fi
      if [ $status -ne 0 ]; then
	echo "Error creating Checkout Directory"
	echo "  --- exiting now!"
	exit $status
      fi
fi
}

SetRep4NewFile()
{

if     [ -z "$ControlFile" ]; then 
       export PROJECTDIR=$FilesActHome

       if    [ ! -d $FilesActHome/SCCS ]; then
             echo "Creating $FilesActHome/SCCS directory......"
             mkdir $FilesActHome/SCCS
             pbrun chgrp $SCCSGROUP $FilesActHome/SCCS
             pbrun chmod 775 $FilesActHome/SCCS
             CaptureRepPaths;
       fi

       if    [ -f $FilesActHome/SCCS/s.$FileName ]; then
             echo "File already in version control directory ($FilesActHome/SCCS/s.$FileName)****"
             exit 1
       fi
#elif   [ -z $CreateInSharedRep ]; then
#       export PROJECTDIR=$FilesActHome
#
#       if    [ ! -d $FilesActHome/SCCS ]; then
#             echo "Creating $FilesActHome/SCCS directory......"
#             mkdir $FilesActHome/SCCS
#             pbrun chgrp $SCCSGROUP $FilesActHome/SCCS
#             pbrun chmod 775 $FilesActHome/SCCS
#             CaptureRepPaths;
#       fi

else
      GetCountInControlFile;

      if    [ $DirEntriesInControlFile -gt 1 ]; then
            echo "****More then one entries for ($FilesActHome) in control file ($ControlFile)****"
            exit 1
      elif  [ $DirEntriesInControlFile -eq 0 ]; then
            export PROJECTDIR=$FilesActHome
      else
        for nextRep in $SharedRepositoryList; do
	  if [ "$nextRep" = "local" ]; then
	    RepPath=$FilesActHome
	  else
	    RepPath=`grep "^repository:${nextRep}:" $ControlFile | cut -d: -f3`
	    if [ -n "$RepositorySubdir" ]; then
	      RepPath="$RepPath/$RepositorySubdir"
	    fi
	  fi
	  if [ -f ${RepPath}/SCCS/s.${FileName} ]; then
            echo "***($FileName) exists in repository (${RepPath}/SCCS/s.$FileName)"
	    exit 1
	  fi
	done
	if [ "$Repository" = "local" ]; then
          export PROJECTDIR=$FilesActHome
	else  
	  export PROJECTDIR=`grep "^repository:${Repository}:" $ControlFile | cut -d: -f3`
	  if [ -n "$RepositorySubdir" ]; then
	    PROJECTDIR="$PROJECTDIR/$RepositorySubdir"
	  fi
	fi

      fi

      if    [ ! -d $PROJECTDIR/SCCS ]; then
             echo "Creating $PROJECTDIR/SCCS directory......"
             mkdir $PROJECTDIR/SCCS
             pbrun chgrp $SCCSGROUP $PROJECTDIR/SCCS
             pbrun chmod 775 $PROJECTDIR/SCCS
             CaptureRepPaths;
      fi
fi
#echo "!!!!! PROJECTDIR=>$PROJECTDIR"
}

FindRep4ExistingFile()
{
if     [ -z "$ControlFile" ]; then
       export PROJECTDIR=$FilesActHome

       if    [ ! -d $FilesActHome/SCCS ]; then
             echo "****Repository ($FilesActHome/SCCS) dosn't exist****"
             exit 1
       fi
  
       if    [ ! -f $FilesActHome/SCCS/s.$FileName ]; then
             echo "File ($FileName) doesn't exist in repository ($FilesActHome/SCCS/s.$FileName)****"
             exit 1
       fi
       CurrentRepository=local

else
      GetCountInControlFile;

      if    [ $DirEntriesInControlFile -gt 1 ]; then
            echo "****More then one entries for $FilesActHome in control file $ControlFile****"
            exit 1
      elif  [ $DirEntriesInControlFile -eq 0 ]; then
            export PROJECTDIR=$FilesActHome

            if    [ ! -d $PROJECTDIR/SCCS ]; then
                  echo "**** Repository $PROJECTDIR/SCCS doesn't exist****"
                  exit 1
            fi 

            if    [ ! -f $PROJECTDIR/SCCS/s.$FileName ]; then
                  echo "**** ($FileName) doesn't exist in repository $PROJECTDIR/SCCS ****"
                  exit 1
            fi 

#ADD
      elif  [ -f $FilesActHome/SCCS/s.$FileName ]; then
            export PROJECTDIR=$FilesActHome
      else
	unset PROJECTDIR
        for nextRep in $SharedRepositoryList; do
	  RepPath=`grep "^repository:${nextRep}:" $ControlFile  | cut -d: -f3`
	  if [ -n "$RepPath" ]; then
	    RepPath="$RepPath/$RepositorySubdir"
	  fi
          if    [ -f $RepPath/SCCS/s.$FileName ]; then
                  export PROJECTDIR=$RepPath
		  CurrentRepository=$nextRep
		  break
	  fi
	done
        if [ -z "$PROJECTDIR" ]; then
          echo "**** $FileName doesn't exist in Repositories $SharedRepositoryList****"
          exit 1
        fi
      fi
fi
CaptureRepPaths;
#echo "!!!!! PROJECTDIR=>$PROJECTDIR"
}

GetCountInControlFile()
{
export DirEntriesInControlFile=0;
if [ -f "$ControlFile" ]; then
  DirEntriesInControlFile=`cat $ControlFile | awk -F: '{print $6":"}' | grep "$FilesActHome:" | wc -l `
  export DirEntriesInControlFile
fi

#echo "!!!!! DirEntriesInControlFile=>$DirEntriesInControlFile"
}

AskUserName()
{
    printf "User ID : "
    read uid
    export UserName=$uid
}

GetComment() 
{
  Description=""
  commentPrompt="Change Description:"
  while [ -z "$Description" ]; do
    printf "\n$commentPrompt"
    read Description
    commentPrompt="A Description of the Change is Required to proceed.\nPlease enter one:"
  done
}


ValCheckOutServer()
{
#echo "!!!!! ControlFile=>$ControlFile"
#echo "!!!!! DirEntriesInControlFile=>$DirEntriesInControlFile"
#if     [ ! -z $ControlFile ]; then
if     [ $DirEntriesInControlFile -eq 1 ]; then
       CheckoutFlag=`sed 's/#.*$//' $ControlFile| grep "${FilesActHome}:" |awk -F: '{print $6":"$4}' |awk -F: '{print $2}'`

       if    [ -z $CheckoutFlag ]; then
             echo "Checkout or move on this Server is not allowed...."
             exit 1
       fi

       if    [ $CheckoutFlag = "N" ]; then
             echo "Checkout or move on this Server is not allowed...."
             exit 1
       fi

fi
}


ValFileNotCheckedout()
{
if   [ -f $PROJECTDIR/SCCS/p.$FileName ]; then
     echo "***($FileName) is checkedout in ($FilesCheckoutDir), checkout or move is not allowed ***"
     echo "#########Already Checkedout By################"
     cat $PROJECTDIR/SCCS/p.$FileName
     echo "##############################################"
     exit 1;
fi
}


CheckCtrlFileExistance()
{
export ControlFile=""
if     [ -n "$GE_SCCS_CTL" ]; then
  if [ -f "$GE_SCCS_CTL" ]; then
       export ControlFile=$GE_SCCS_CTL
  else
    # Control File specified, but does not exist
    echo "Control file $GE_SCCS_CTL not found --- exiting !!!"
    exit 1
  fi
elif    [ ! -f $DBA_HOME/admin/MySccs.ctl ]; then
      echo "*****No centralized repositories defined, only local repositories are in use*****"
else
      export ControlFile=$DBA_HOME/admin/MySccs.ctl
     #echo "!!!!! ControlFile=>$ControlFile"
fi
if [ -f "$ControlFile" ]; then
  export SCCSGROUP=`grep SCCS_GROUP $ControlFile| awk -F: '{print $2}'`
fi
if    [ -z $SCCSGROUP ]; then
      export SCCSGROUP="gtsdba"
fi
#echo "!!!!! SCCSGROUP=>$SCCSGROUP"
}


SetFilePermissionsInHome()
{
if     [ -f  $FilesActHome/$FileName ]; then
       pbrun chmod $Permission $FilesActHome/$FileName
       pbrun chgrp $FileGroup $FilesActHome/$FileName
elif   [ -f  $FilesActHome/,$FileName ]; then
       cp $FilesActHome/,$FileName $FilesActHome/$FileName
       pbrun chmod $Permission $FilesActHome/$FileName
       pbrun chgrp $FileGroup $FilesActHome/$FileName
else
       echo
       echo "**** ($FilesActHome/$FileName) didn't exist before this action, so default permission set, change it ****" 
       echo
fi
if   [ -f  $FilesActHome/,$FileName ]; then
       rm -f $FilesActHome/,$FileName 
fi
}


SetFilePermissionsInTest()
{
if     [ -f  $FilesActHome/$FileName ]; then
       pbrun  chmod $Permission $FilesCheckoutDir/$FileName
       pbrun  chgrp $FileGroup $FilesCheckoutDir/$FileName
else
       echo
       echo "**** ($FilesActHome/$FileName) didn't exist before this action, so default permission set, change it ****" 
       echo
fi
}

CaptureRepPaths()
{
if     [ ! -f  $DBA_HOME/admin/MySccs.repositories ]; then
       touch $DBA_HOME/admin/MySccs.repositories
       pbrun chgrp $SCCSGROUP $DBA_HOME/admin/MySccs.repositories
       pbrun chmod 775 $DBA_HOME/admin/MySccs.repositories
fi
grep "^${PROJECTDIR}$" $DBA_HOME/admin/MySccs.repositories >/dev/null 2>&1
if [ $? -ne 0 ]; then
  echo $PROJECTDIR>>$DBA_HOME/admin/MySccs.repositories
fi
}

AuditAction()
{
CurrUser="$1"
if [ -z "$Version" ]; then
  Version=`sccs prs -d':I:' ${FileName}`
fi

      if     [ ! -f $PROJECTDIR/SCCS/MySccs.audit ]; then
             printf "%-18s%-8s %-8s %-20s %-8s %s\n" Date User Host FileName Version TargetDir> $PROJECTDIR/SCCS/MySccs.audit
             pbrun chgrp $SCCSGROUP $PROJECTDIR/SCCS/MySccs.audit
             pbrun chmod 775 $PROJECTDIR/SCCS/MySccs.audit
      fi
       printf "%-18s%-8s %-8s %-20s %-8s %s\n" "`date '+%m/%d/%y %H:%M:%S'`" "$CurrUser" "$host" ${FileName} "$Version" "`pwd`">> $PROJECTDIR/SCCS/MySccs.audit
}


GetFilePermissions()
{
  #clone_from="$1"
  clone_from="${FilesActHome}/${FileName}"
  OwnerGroup=`ls -ld $FilesActHome | awk '{print $3}'`:${SCCSGROUP}
  if [ ! -f "$clone_from" ]; then
    if [ "$UserAction" = "get" ]; then
      echo "$0: cannot get permissions on file $clone_from --- using defaults"
    elif [ "$UserAction" != "del" -a "$UserAction" != "move" ]; then
      echo "$0: $clone_from not found"
      exit 1
    fi
    from_perms="-rwxr-xr-x"
    FileGroup=$SCCSGROUP
  else
    from_perms=`ls -l $clone_from | awk '{print $1}'`
    FileGroup=`ls -ld $clone_from | awk '{print $4}'`
  fi

  if [ -z "$1" ]; then
    perms_template="---------"
  else
    perms_template="$1"
  fi

  Permission=""
  perms_delim=""
  lock_perm=`echo ${from_perms}${perms_template} | grep -c 'L'`
  typeset -i perm_indx=2
  while [ $perm_indx -lt 11 ]; do
    perm_bit=`echo $from_perms | cut -c$perm_indx`
    if [ $perm_indx -ne 7 -o $lock_perm -eq 0 ]; then
      # mandatory lock is not set 
      if [ "$perm_bit" = '-' ]; then
        perm_bit=`echo $perms_template | cut -c$perm_indx`
      fi
      if [ "$perm_bit" = 's' ]; then
        tmp_perm="${tmp_perm}xs"
      elif [ "$perm_bit" != '-' ]; then
        tmp_perm="${tmp_perm}${perm_bit}"
      fi
    fi
    case $perm_indx in
      4) perm_range=u
	  ;;
      7) perm_range=g
	  ;;
      10) perm_range=o
	   ;;
       *) perm_range=""
           ;;
    esac
    if [ -n "$perm_range" -a -n "$tmp_perm" ]; then
      Permission="${Permission}${perms_delim}${perm_range}=${tmp_perm}"
      perms_delim=","
      tmp_perm=""
    fi
    perm_indx=perm_indx+1
  done
  if [ "$lock_perm" -eq 1 ]; then
    Permission="${Permission}${perms_delim}+l"
  fi
  #echo "OwnerGroup=> $OwnerGroup"
}

CheckinCleanup() {
  cd $FilesActHome
  if [ -f b.$FileName ]; then
    mv b.$FileName $FileName
  fi
}

DeployCandidates()
{
CurrWorkDir=`pwd`
#echo "FilesActHome=>$FilesActHome"
if [ -f "$ControlFile" ]; then
  sed 's/#.*//' $ControlFile | grep -v '^[ ]*$' |
  awk -F: -v rep=$nextRep -v subdir=$RepositorySubdir -v host=$host '{
    if (NF > 6 && $1 != host ) {
      split($7,reparray,",");
      for (i in reparray) {
	if (rep == reparray[i] && subdir == $8) {print}
      }}}' | while read ControlFileContent; do
  #    echo $ControlFileContent
      CServerName=`echo $ControlFileContent | awk -F: '{print $1}'`
      CServerPlatform=`echo $ControlFileContent | awk -F: '{print $2}'`
      CServerType=`echo $ControlFileContent | awk -F: '{print $3}'`
      CCheckout=`echo $ControlFileContent | awk -F: '{print $4}'`
      CAutomaticDeploy=`echo $ControlFileContent | awk -F: '{print $5}'`
      CDir=`echo $ControlFileContent | awk -F: '{print $6}'`
      #echo "~~~~~~~"
      #echo "ServerName=>$CServerName"
      #echo "ServerPlatform=>$CServerPlatform"
      #echo "ServerType=>$CServerType"
      #echo "Checkout=>$CCheckout"
      #echo "AutomaticDeploy=>$CAutomaticDeploy"
      #echo "Dir=>$CDir"
      if    [ $CAutomaticDeploy = "Y" ]; then
           echo
           echo "-----------------------------"
           echo "Deploying on Server=>$CServerName"
           echo "-----------------------------"
           echo
           remsh $CServerName -n ". bin/MySccs.env; cd $CDir; MySccs.sh get $FileName" 
           echo "-----------------------------"
           echo ""
      fi
  done
fi
}

ChkCrontab()
{
   if    [ `/usr/bin/crontab -l | grep $FilesCheckoutDir/$FileName | wc -l` -ne 0 ]; then
         echo "----------------!!!!------------------------------------"
         echo " There is a crontab entry for $FilesCheckoutDir/$FileName on $host"
	 echo ""
	 echo "Please change this, as $FileName has been removed from $FilesCheckoutDir"
         echo "----------------!!!!------------------------------------"
   fi
}

ChkFileBusy()
{
  pid_list=`fuser "${FilesActHome}/${FileName}"  2>/dev/null | tr -s ' ' ,`
  if [ -n "$pid_list" ]; then
    echo "${FilesActHome}/${FileName} is currently in use by the following processes:"
    ps -f -p $pid_list
    return 1
  else
    return 0
  fi
}

Chk4PercentSeq() {
  # SCCS uses ID Keywords in format %<some uppercase letter>%
  # Check for sequences that are probably intended to be something else
  #  
  # For instance, date + %H_%S (but without underscore) could be replaced
  # by SCCS with current date S (percent-H-percent and the letter S)
  # So you would get date +03/07/17S instead.
  grep '%[A-Z]%[%A-Za-z0-9]' $FileName >/dev/null 2>&1
  if [ $? -eq 0 ]; then
    # found a problem line
    echo ""
    echo "$FileName contains strings which may be misinterpreted by SCCS"
    echo "  as SCCS ID Keywords, and will be replaced on create or get:"
    awk '{pos=match($0,/%[A-Z]%[%A-Za-z0-9]/); 
	  if ( pos > 0 ) { 
	    format="%"pos"s\n\n";
	    print "line "NR":";
	    print;
            printf format, "^"
          }}' $FileName
    echo ""
    echo "Please resolve this issue before proceeding"
    return 1
  else
    return 0
  fi
}

CheckRemote() {
# should only called on actions that will modify or add a file to a Repository
# look for string indicating that this file is maintained in a remote repository
# (like generic scripts on corpp001).  If Yes, only allow action if using
# identified repository on identified server

  RepositoryName=$1
  # check for flag indicating this file belongs in a remote repository
  if [ -f "$ControlFile" ]; then
    remote_flag=`awk -F: "/^repository:${RepositoryName}:/ {print toupper(\\$4)}" $ControlFile`
  else
    remote_flag=N
  fi

  remote_info=`grep -n '^[^ A-Za-z0-9][^ ]*[ ]*in_remote_SCCS_repository[ ]*:[^:]*$' $FileName | tail -1`
  if [ -n "$remote_info" ]; then
    # grep -n prepends line number to each returned row
    lineno=`echo $remote_info | cut -d: -f1`
    remote_repository=`echo $remote_info | cut -d: -f3`
    if [ "$remote_repository" != "$RepositoryName" ]; then
      echo "$FileName is maintained in the repository $remote_repository on scripts server"
      echo "Please perform all SCCS functions there"
      exit 1
    fi
    if [ "$remote_flag" != "Y" ]; then
      echo "MySccs.sh: line $lineno of $FileName contains remote repository tag:"
      echo "    $remote_info" | sed 's/[0-9]*://'
      echo ""
      echo "  but there is no Remote Repository Flag set for this repository"
      echo "  in $ControlFile .  Please fix this."
      exit 1
    fi
  elif [ "$remote_flag" = "Y" ]; then
      case `echo $FileName | awk -F. '{print $NF}'` in
        sh) commentchar='#' ;;
       sql) commentchar='---' ;;
         c) commentchar='/* ';;
         *) commentchar='<commentchar>' ;
      esac

      echo "Repository $Repository is used to support remote servers"	
      echo "Please add the following comment to $FileName :"
      echo ""
      echo "${commentchar}in_remote_SCCS_repository:${Repository}"
      exit 1
  fi
}


# sccs-prs helper functions
setFromTo() {
  case $1 in
    from) tmp="-l" ;;
      to) tmp="-e" ;;
       *) echo "MySccs.sh : setFromTo System Error"
	  exit 1
  esac
  if [ -n "$from_or_to" -a "$from_or_to" != "$tmp" ]; then
    echo "$0 version : you can use from or to, but not both"
    exit 1
  fi
  from_or_to="$tmp"
}

toPrsDate() {
  # convert mm/dd/yy to yymmdd
  if [ -n "$prs_date" ]; then
    echo "MySccs.sh version: only one date may be specified"
    exit 1
  fi
  prs_date=`echo "$1" | awk -F/ '{if (NF != 3) print "ugly"; else printf "%02d%02d%02d\n" ,$3,$1,$2}'`
  if [ "$prs_date" = "ugly" ]; then
    echo "MySccs.sh version: $1 is not in correct date format mm/dd/yy"
    exit 1
  elif [ "$prs_date" -gt "999999" -o "$prs_date" -lt 101 ]; then
    echo "$0 version: $1 is not in correct date format mm/dd/yy"
    exit
  fi
}
    
  


###################################################################################
###                                    Main                                     ###
###################################################################################

#
#----(BEGIN)--Define Variable Section---------------------------------------------#
#
if [ -f $HOME/bin/MySccs.env ]; then
  . $HOME/bin/MySccs.env
fi

OS_TYPE=`uname`
if [ "$OS_TYPE" = "SunOS" ]; then 
  export PATH=.:/usr/xpg4/bin:$PATH
else
  export PATH=.:$PATH
fi
umask 002

#export FileName=`eval echo \\$$#`
export DirEntriesInControlFile=0
export SCCSGROUP="gtsdba"
export ExitStatus=0 
user=`id|cut -d"(" -f2|cut -d")" -f1`

Status=0

#
#----( END )--Define Variable Section---------------------------------------------#
#

#
#----(BEGIN)--Check the command line parameters---------------------------------------------#
#


#      if     [ $1 != "get"        -a \
#               $1 != "owner"      -a \
#               $1 != "version"    -a \
#               $1 != "create"     -a \
#               $1 != "checkout"   -a \
#               $1 != "checkin"    -a \
#               $1 != "move"       -a \
#               $1 != "undo" ]; then
#            Usage;
#      fi

if [ $# -lt 2 ]; then
  Usage
fi

UserAction=$1
FileName=$2
if [ `dirname $FileName` != "." ]; then
  cd `dirname $FileName`
  FileName=`basename $FileName`
fi

filetype=`file $FileName | cut -d: -f2 | awk '{print $1}'`

# SCCS supports binary files by uuencoding them , but behavior can be flaky
if [ "$filetype" = "ELF" ]; then
  echo "$0 : binary files are not supported"
  exit 1
fi

Repository=""
shift 2
GetFilesActualHome;

host=`hostname`
CheckCtrlFileExistance;
#DefaultVersionFormat=':DT: :I: :Dm:/:Dd:/:Dy: :T: :P: :DS: :DP:\t:DL:\nMRs:\n:MR:COMMENTS:\n:C:'
prs_format=':DT: :I: :Dm:/:Dd:/:Dy: :T: :P: :DS: :DP:\t:DL:\nMRs:\n:MR:COMMENTS:\n:C:'
#prs_format=':DT: :I: :Dm:/:Dd:/:Dy: :T: :P: :DS: :DP:\\t:DL:\\nMRs:\\n:MR:COMMENTS:\\n:C:'
#SharedRepositoryList="appshr dbshr allshr"

if [ -n "$ControlFile" ]; then
  SharedRepositoryList=`awk -F: -v dir=$FilesActHome -v host=$host -F: \
    '{if ( $1 == host && $6 == dir ) {gsub(","," ",$7);print $7}}' \
    $ControlFile`
else
  SharedRepositoryList=""
fi
if [ -n "$SharedRepositoryList" ]; then
  RepositorySubdir=`awk -F: -v dir=$FilesActHome -v host=$host -F: \
    '{if ( $1 == host && $6 == dir ) {print $8}}' \
    $ControlFile`
else
  RepositorySubdir=""
fi
  
SharedRepositoryList="$SharedRepositoryList local"

if [ -n "$1" ]; then
  for nxtfile in $SharedRepositoryList ; do
    if [ "$nxtfile" = "$1" ]; then
      Repository=$1
      shift
      break
    fi
  done
fi

if [ -z "$Repository" ]; then
  Repository=local
  if [ "$UserAction" = "move" ]; then
    echo "Moving $FileName to local repository"
    get_answer "Is this OK?"
    if [ "$y_or_n" = "N" ]; then
      # user answered no
      exit 1
    fi
  fi
else
  if [ "$UserAction" = "create" ]; then
    if [ "$Repository" != "local" ]; then
      export CreateInSharedRep="Y"
    fi
  elif [ "$UserAction" != "move" ]; then
    Usage
  fi
fi



#if    [ -z $DBA_HOME ];then
#      echo "**** DBA_HOME is not defined ****"
#      exit 1; 
#fi

#
#----( END )--Check the command line parameters---------------------------------------------#
#



#
#----(BEGIN)--Getting Files actual home ----------------------------------
#

GetFilePermissions;

#
#----( END )--Getting Files actual home & check control file existance----------------------#
#

#
#----(BEGIN)--Setting up PROJECTDIR variables-----------------------------------------------#
#

#if    [ $1 = "create" -o $1 = "dbshr" -o $1 = "appshr" -o $1 = "allshr" ]; then
if [ "$UserAction" = "create" ]; then
  SetRep4NewFile;
  CheckRemote $Repository
else
  FindRep4ExistingFile;
  if [ "$UserAction" = "move" ]; then
    CheckRemote $Repository
  elif [ "$UserAction" = "checkin" ]; then
    CheckRemote $CurrentRepository
  fi
fi

#
#----( END )--Setting up PROJECTDIR variables-----------------------------------------------#
#

#DeployCandidates;

Version=""
# at this point, most actions should have no parameters left
if [ "$UserAction" = "get" ]; then
  while [ $# -gt 0 ]; do
    # support for defGroup and defParm not implemented, but
    # leaving parsing for now
    getParam=`echo $1 | cut -d= -f1`
    getValue=`echo $1 | cut -d= -f2`
    if [ "$getParam" = "defPerm" ]; then
      defPerm="$getValue"
    elif [ "$getParam" = "defGroup" ]; then
      defGroup="$getValue"
    elif [ -z "$Version" -a "$getParam" = "$getValue" ]; then
      # $getParam will = $getValue if there are no = signs in the arg
      Version="-r$1"
    else
      Usage
    fi
    shift
  done
  # take this out if adding support for defPerm and defGroup
  if [ -n "$defPerm" -o -n "$defGroup" ]; then
    Usage
  fi
fi

if [ $# -eq 1 ]; then
  if [ "$UserAction" = "diff" -o "$UserAction" = "checkout" ]; then
     Version="-r$1"
     shift
  fi
elif [ "$UserAction" = "diff" -a $# -eq 2 ]; then
      Version="-r$1 -r$2"
      shift 2
fi

if [ "$UserAction" = "version" ]; then
  from_or_to=""
  prs_date=""
  #prs_format="'${DefaultVersionFormat}'"
  while [ $# -gt 0 ]; do
    nxtarg="$1"
    echo "$nxtarg"| grep '=' >/dev/null 2>/dev/null
    if [ $? -ne 0 ]; then
      # did not get expected = sign
      Usage
    fi
    verParam=`echo $nxtarg | cut -d= -f1`
    verValue=`echo $nxtarg | cut -d= -f2`
    case $verParam in
      fromdate) toPrsDate $verValue
		setFromTo from
	        ;;
      todate) 	toPrsDate $verValue
		setFromTo to
	        ;;
      fromver) 	prs_sid=$verValue
		setFromTo from
		;;
      tover) 	prs_sid=$verValue
		setFromTo to
		;;
      format)	prs_format="$verValue"
		;;
	*)	Usage;
    esac
    shift
  done
fi
    
if [ $# -eq 1 -a "$Repository" = "local" ]; then
  if [ "$UserAction" = "create" -o "$UserAction" = "move" ]; then
    # assume last param was Repository, and it wasn't matched
    echo "Repository $1 not allowed for directory `pwd`"
    exit 1
  fi
fi

if [ $# -ne 0 ]; then
  Usage
fi

case $UserAction in
  get)   ChkFileBusy
	 ExitStatus=$?
	 if [ "$ExitStatus" -eq 0 ]; then
  	   #GetFilePermissions;
  	   if [ -f $FileName ]; then
       	     mv $FileName b.$FileName
  	   fi
           sccs get $Version $FileName
           ExitStatus=$?
           if   [ $ExitStatus -eq 0 ]; then
             SetFilePermissionsInHome;
             pbrun rm -rf b.$FileName
           else
             mv b.$FileName $FileName
           fi   
           ChkCrontab;
           AuditAction $user
	 fi
         ;;

  owner)
	 # CSSC distribution does not seem to be able to invoke sact correctly
	 if [ -x /usr/libexec/cssc/sact ]; then
	   /usr/libexec/cssc/sact $PROJECTDIR/SCCS/s.$FileName
         else
           sccs sact $FileName
         fi
         ExitStatus=$?
         ;;

  version) 
		# ${x:-f} prints -f only if $x is set
		sccs prs $from_or_to ${prs_date:+-c}$prs_date -d"${prs_format}" ${prs_sid:+-r}$prs_sid $FileName
		 ExitStatus=$?
		 ;;

	  create)
		 Chk4PercentSeq $FileName
		 ExitStatus=$?
		 if [ $ExitStatus -eq 0 ]; then
		   #GetFilePermissions; 
		   sccs create $FileName
		   ExitStatus=$?
		   if [ "$ExitStatus" -eq 0 ]; then
		     echo "**** ($FileName) created in repository ($PROJECTDIR) ****"
		   fi
		   SetFilePermissionsInHome;
		 fi
		 ;;
		     
	  checkout)
		 ValCheckOutServer;
		 ValCheckoutDir;
		 ValFileNotCheckedout;
		 CurrentDir=`pwd`
		 cd $FilesCheckoutDir
		 pbrun rm -rf $FilesCheckoutDir/$FileName
		 AskUserName;
		 su $UserName -c "sccs edit $Version $FileName"
		 ExitStatus=$?
		 if [ "$ExitStatus" -eq 0 ]; then
		   echo
		   echo "****($FileName) Checkedout in (`pwd`)****"
		   echo
		   cd $CurrentDir
		   #GetFilePermissions; 
		   SetFilePermissionsInTest;
		 fi
		 ;;

	  checkin)
		 ValCheckOutServer;
		 ChkPwdEqlChkoutDir;
		 Chk4PercentSeq 
		 ExitStatus=$?
		 if [ $ExitStatus -eq 0 ]; then
		   ChkFileBusy
		   ExitStatus=$?
		 fi
		 if [ $ExitStatus -eq 0 ]; then
		   #GetFilePermissions; 
		   if [ -f $FilesActHome/$FileName ]; then
		     fOwner=`ls -l $FilesActHome/$FileName | awk '{print $3}'`
		     if [ "$fOwner" != "$user" ]; then
		       echo "You must be $fOwner to Check in $FileName"
		       ExitStatus=1
		     else
		       mv $FilesActHome/$FileName $FilesActHome/b.$FileName
		       ExitStatus=$?
		     fi
		   fi
		 fi
		 if [ $ExitStatus -eq 0 ]; then 
		   trap "CheckinCleanup; exit 1" INT
		   GetComment;
		   AskUserName;
		   su $UserName -c " trap 'exit 1' INT; set -e; \
		     sccs delta -y\"${Description}\" $FileName ; \
		     cd $FilesActHome ; rm -f $FilesCheckoutDir/$FileName "
		   ExitStatus=$?
		   if [ $ExitStatus -eq 0 ]; then
		     ChkCrontab;
		     cd $FilesActHome
		     sccs get $FileName
		     ExitStatus=$?
		   fi
		 
		   if [ $ExitStatus -eq 0 ]; then
		     #SetFilePermissionsInTest;
		     SetFilePermissionsInHome;
		     pbrun rm -rf b.$FileName
           	     AuditAction $user
		     DeployCandidates;
		   else
		     CheckinCleanup
		   fi
		 fi   
		 trap - INT
		 ;;

	  diff)  param3=`echo "$Version" | awk '{print $2}' | cut -c1-2` 
		 if [ "$param3" = "-r" ]; then
		   # Version is in format -r old -r new
		   sccs sccsdiff $Version $FileName
		   ExitStatus=$?
		 else
		   echo "< SCCS  > `pwd`"
		   sccs diffs $Version $FileName  
		   ExitStatus=$?
		 fi
		 ;;

	  undo)  ValCheckOutServer;
		 ChkPwdEqlChkoutDir;
		 AskUserName;
		 su $UserName -c "set -e ; sccs unedit $FileName ; \
		   rm -f $FilesCheckoutDir/$FileName"
		 ExitStatus=$?
		 ;;

	 where)	if [ -z "$CurrentRepository" -a "$PROJECTDIR" = `pwd` ]; then
		  CurrentRepository=local
		fi
		if [ -n "$CurrentRepository" ]; then
		   echo "$FileName in $CurrentRepository ($PROJECTDIR)"
		   exit 0
		 else
		   exit 1
		 fi
		 ;;

	  move_2)  # this probably needs more work
		   # place holder for move with only two params
		 ValCheckOutServer;
		 ValFileNotCheckedout;
		 echo "Current Rep=>$PROJECTDIR"
		 echo "DefaultRep4File=>$DefaultRep4File"
		 echo "SecondRep4File=>$SecondRep4File"
		 if     [ $PROJECTDIR = $DefaultRep4File ]; then
		    pbrun mv $PROJECTDIR/$FileName $SecondRep4File/$FileName 
		    ExitStatus=$?
		    if [ "$ExitStatus" -eq 0 ]; then
		    pbrun mv $PROJECTDIR/SCCS/s.$FileName \
				$SecondRep4File/SCCS/s.$FileName
		    ExitStatus=$?
		    echo "**** ($FileName) has moved from repository"\
			" ($PROJECTDIR) to ($SecondRep4File) ****"
		    fi
		 else
		   pbrun mv $PROJECTDIR/$FileName $DefaultRep4File/$FileName
		   ExitStatus=$?
		   if [ $ExitStatus -eq 0 ]; then
		     pbrun mv $PROJECTDIR/SCCS/s.$FileName $DefaultRep4File/SCCS/s.$FileName
		     ExitStatus=$?
		     echo "**** ($FileName) has moved from repository ($PROJECTDIR) "\
			"to ($DefaultRep4File) ****"
		   fi
		 fi
		 ;;

	  move)
		 ValCheckOutServer;
		 ValFileNotCheckedout;
		 if [ "$Repository" = "local" ]; then
		   newRepPath=`pwd`
		 else
		   newRepPath=`grep "^repository:${Repository}:" $ControlFile | cut -d: -f3`
		   if [ -n "$RepositorySubdir" ]; then
		     newRepPath="$newRepPath/$RepositorySubdir"
		   fi
		 fi
		 if [ -f ${newRepPath}/SCCS/s.${FileName} ]; then
		   echo "File ${newRepPath}/SCCS/s.${FileName} already exists"
		   exit 1
		 fi
		 if [ -f $PROJECTDIR/$FileName -a "$Repository" != "local" ]; then
		   if [ $PROJECTDIR = $FilesActHome ]; then
		     cp -p $PROJECTDIR/$FileName $newRepPath/$FileName
		     ExitStatus=$?
		   else
		     mv $PROJECTDIR/$FileName $newRepPath
		     ExitStatus=$?
		   fi
		 fi
		 if [ $ExitStatus -eq 0 ]; then
		   mv $PROJECTDIR/SCCS/s.$FileName $newRepPath/SCCS
		   ExitStatus=$?
		 fi
		 if [ $ExitStatus -eq 0 ]; then
		   echo "**** ($FileName) has been moved from repository "\
				  "($PROJECTDIR) to ($newRepPath) ****"
		 else
		   echo "**** Unable to move ($FileName) from repository"\
				  "($PROJECTDIR) to ($newRepPath) ****"
		 fi  
		;;

	  del)
		 ValCheckOutServer;
		 ValFileNotCheckedout;
		 if [ -f $PROJECTDIR/$FileName -a $PROJECTDIR != $FilesActHome ]; then
		     rm $PROJECTDIR/$FileName 
		 fi
		 rm $PROJECTDIR/SCCS/s.$FileName 
		 ExitStatus=$?
		 if [ $ExitStatus -eq 0 ]; then
		   echo "**** ($FileName) has been removed from repository "\
				  "($PROJECTDIR) ****"
		 fi
		;;
	  *) Usage
		;;
	esac

	# end of main statement
	echo ""
	echo "MySccs.sh exiting with status $ExitStatus"
	exit $ExitStatus



