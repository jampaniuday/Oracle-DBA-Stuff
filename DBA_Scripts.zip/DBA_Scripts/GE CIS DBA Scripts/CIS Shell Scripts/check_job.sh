#! /bin/ksh
###################################################################################################
# This script is used to send notification when database jobs fails to execute
#
###################################################################################################
if test $# -ne 2
then
  echo "ERR==>Input params SID/Job owner"
  echo "USAGE : check_job.sh <SID> <JOB_OWNER>"
  exit 1
fi

. $HOME/bin/$1

JOB_OWNER=`echo $2 | tr '[a-z]' '[A-Z]'`

audit_path=${SID_HOME}/audit
audit_file=$audit_path/$2_JOB_STATUS.audit
SPASS=`$HOME/bin/tellme system`
#EMAIL=raji.nagarajan@ge.com


sqlplus -s system/${SPASS} <<EOF > ${audit_path}/$2_JOB_STATUS.audit_`date +%H%M%S`
set feedback off
set echo off
set term off
set verify off
set head off
set lines 1000

spool ${audit_path}/$2_NUMBER_OF_JOBS.ctl
select 'No of jobes failed is:'||count(*) from dba_jobs where broken<>'N'and log_user like '$JOB_OWNER';
spool off

spool ${audit_path}/$2_JOB_STATUS.log
select 'The job '||what|| 'with Job number '||job||' is in broken state at '||to_char(LAST_DATE,'dd-mon-yyyy hh24:mi:ss') lastrun from dba_jobs where broken<>'N'and log_user like '$JOB_OWNER';
spool off
EOF
#

TEMP_FILE="`cat ${audit_path}/$2_NUMBER_OF_JOBS.ctl|awk -F: '{print $2}'`"

#CountLine=`wc -l ${audit_path}/$2_NUMBER_OF_JOBS.ctl`

Time_stamp=`date`

if [ $TEMP_FILE -gt 0 ]
then
 

#mailx -s "$1 Failed Jobs at $Time_stamp " $EMAIL <${audit_path}/$2_JOB_STATUS.log

echo "Please check  ${audit_path}/$2_JOB_STATUS.audit_`date +%H%M%S` for more details "

$DBA_HOME/admin/notify.sh -s "$1 Failed Jobs at $Time_stamp " -f ${audit_path}/$2_JOB_STATUS.log -w sid


 rm -f ${audit_path}/$2_NUMBER_OF_JOBS.ctl 2>/dev/null >/dev/null
 rm -f ${audit_path}/$2_JOB_STATUS.log 2>/dev/null >/dev/null

      # exit 1
else

 rm -f ${audit_path}/$2_NUMBER_OF_JOBS.ctl 2>/dev/null >/dev/null
 rm -f ${audit_path}/$2_JOB_STATUS.log 2>/dev/null >/dev/null

fi
echo "===================  Ending ========================" >$audit_file
