#!/bin/ksh
## Purpose    : Identifiy toad processes
##              on the specified instance.
## Usage      : toad.sh <SID>
## Parameter  : Oracle SID
## Created by : Govind.narain

## Notify Information ##
sid=$1
notify_who="govind.narain"
notify_who1="gtsohrdba"
notify_host=`hostname`
notify_sid=$sid
notify_type="Toad_Sessions"

## Check for SID parameter ##
if [ -z "$sid" ]
then
  echo
  echo "Invalid Parameter input" 
  echo "Usage is toad.sh sid" 
  echo
  mailx -s "$notify_host $notify_sid $notify_type ABEND " $notify_who@corporate.ge.com < $SID_HOME/audit/toad.audit
  exit
fi

## Check for $HOME/bin/SID Environment ##
if [ ! -f $HOME/bin/$sid ]
then
  echo "Error====>No environment script found for instance \"$sid\"" 
  echo "          Script is terminating!" 
  exit
fi

## Set Environment ##
. $HOME/bin/$sid

echo "###############################################################"
echo "##    Script toad.sh starting on " `date` for $sid
echo "###############################################################"

## Check for Instance ##
inst=`ps -ef | grep ora_smon_$sid | grep -v grep`
if [ -z "$inst" ]
then
  echo "Oracle instance, $sid is not available." 
  echo "Script is terminating." 
  mailx -s "$notify_host $notify_sid $notify_type ABEND" $notify_who@corporate.ge.com < $SID_HOME/audit/toad.audit
  exit
fi

## Pick up apps password from tellme ##
PWD=`$HOME/bin/tellme system`
if [ -z "$PWD" ]
then
  echo "Error : No password selected for System" 
  echo "Script is termianting" 
  mailx -s "$notify_host $notify_sid $notify_type ABEND " $notify_who@corporate.ge.com < $SID_HOME/audit/toad.audit
  exit
fi

sqlplus -s system/${PWD}@$sid <<EOF
@$DBA_HOME/adminsql/toad.sql
exit;
EOF

norows=`grep "no rows selected" $SID_HOME/audit/toad.audit`

if [ ! -z "$norows" ]
then
  exit 0
fi

mailx -s "$notify_host $notify_sid $notify_type " $notify_who@corporate.ge.com < $SID_HOME/audit/toad.audit
mailx -s "$notify_host $notify_sid $notify_type " jadia.satyen@corporate.ge.com < $SID_HOME/audit/toad.audit
mailx -s "$notify_host $notify_sid $notify_type " abhay.dharkar@corporate.ge.com < $SID_HOME/audit/toad.audit
mailx -s "$notify_host $notify_sid $notify_type " bala.mugunthan@corporate.ge.com < $SID_HOME/audit/toad.audit
mailx -s "$notify_host $notify_sid $notify_type " ranjit.mhatre@corporate.ge.com < $SID_HOME/audit/toad.audit
mailx -s "$notify_host $notify_sid $notify_type " ravi.meda@corporate.ge.com < $SID_HOME/audit/toad.audit
mailx -s "$notify_host $notify_sid $notify_type " richard.alexander@corporate.ge.com < $SID_HOME/audit/toad.audit

## Generate script to kill toad sessions

sqlplus -s system/${PWD}@$sid <<EOF
@$DBA_HOME/adminsql/toadpr.sql
exit;
EOF

## Kill toad processes

sqlplus -s system/${PWD}@$sid <<EOF
@$SID_HOME/audit/killtoadpr.sql
exit;
EOF

echo "Toad processes killed."

exit 0
