#!/bin/ksh
###############################################################################
#export.sh: Script to export at the FULL, SCHEMA, and TABLE levels.
#
#  Environment variable, EXPORT_HOME, must be set by the instance environment
#  script and will denote the location of all export dump files and any
#  optional parfile input
#
#  All exports are compressed via a named pipe.	
#
#  If a FULL export is desired then:
#    $1=SID
#    $2="full" or "full-nodata" for now rows
#    $3=optional parfile to override any export default except mode and rows
#       which can only be set using $2
#
#  If a SCHEMA level export is desired then:
#    $1=SID
#    $2=owner or owner-nodata (where owner is the Oracle schema owner)
#    $3=optional parfile to override any export default except mode and rows
#       which can only be set using $2
#
#  If a TABLE level export is desired then:
#    $1=SID
#    $2=owner.tablename or owner.tablename-nodata (where owner.tablename
#       is the Oracle owner and tablename)
#    $3=optional parfile to override any export default except mode and rows
#       which can only be set using $2
#
###############################################################################
#Notify logic for Autosys

notify() {
  parent_pid=`ps -o ppid -p $$ |tail -1`
  parent_program=`ps -o args -p ${parent_pid}|tail -1`
  echo $parent_program |grep utility.sh
  if [ "$?" != 0 ]
  then
    current_prog=`echo $0|sed -e 's/.*\///'`
    $DBA_HOME/admin/notify.sh -s "$current_prog ABEND" -b "$current_prog failure: Please look at audit file" -w sid
    $DBA_HOME/admin/notify.sh -p "$current_prog ABEND" -w sid
   fi
}

###############################################################################

. $HOME/bin/$1
PWDSYS=`$HOME/bin/tellme sys`
PWD=`$HOME/bin/tellme system`
echo "#############################################################"
echo "Starting export.sh on `date`   "
echo "#############################################################"
if [ ! "$1" ]
then
  echo "#################################################"
  echo "# ERROR: First parameter must be the Oracle sid"
  echo "#################################################"
  notify ; exit 1
fi
if [ ! -f $HOME/bin/$1 ]
then
  echo "###################################################"
  echo "# ERROR: Instance environment script does not exist"
  echo "###################################################"
  notify ; exit 1
fi
. $HOME/bin/$1
if [ ! "$EXPORT_HOME" ]
then
  echo "###############################################################"
  echo "# ERROR: Required environment variable, EXPORT_HOME, is not set"
  echo "###############################################################"
  notify ; exit 1
fi
if [ ! -d $EXPORT_HOME ]
then
  echo "###############################################################"
  echo "# ERROR: Required environment variable, EXPORT_HOME, is invalid"
  echo "###############################################################"
  notify ; exit 1
fi
if [ ! "$2" ]
then
  echo "#################################################"
  echo "# ERROR: Must provide an export mode"
  echo "#   full or full-nodata,"
  echo "#   owner or owner-nodata,"
  echo "#   owner.tablename or owner.tablename-nodata"
  echo "#################################################"
  notify ; exit 1
fi
if [ "$3" ]
then
  if [ ! -f $EXPORT_HOME/$3 ]
  then
    echo "###############################################################"
    echo "# ERROR: Parameter file does not exist under EXPORT_HOME"
    echo "###############################################################"
    notify ; exit 1
  else
    parfile="parfile=$EXPORT_HOME/$3"
  fi
else
  parfile=""
fi
if [ ! "`ps -ef|grep pmon_$1|grep -v grep`" ]
then
  echo "#################################################"
  echo "# ERROR: Oracle Instance $1 is down"	
  echo "#################################################"
  notify ; exit 1
fi
mode=`echo $2 | awk -F"-" '{print $1}'`
rows=`echo $2 | awk -F"-" '{print $2}'`
if [ ! "$rows" ]
then
  export_rows="rows=Y"
else
  if [ $rows = "nodata" ]
  then
    export_rows="rows=N"
  else
    echo "#################################################"
    echo "# ERROR: Invalid export mode which must be:"
    echo "#   full or full-nodata,"
    echo "#   owner or owner-nodata,"
    echo "#   owner.tablename or owner.tablename-nodata"
    echo "#################################################"
    notify ; exit 1
  fi
fi
if [ $mode = "full" ]
then
  export_mode="full=Y"
  outfile=$1
else
  cnt=`echo $mode | awk -F"." '{print NF}'`
  if [ $cnt -eq 1 ]
  then
    export_mode="owner=$mode"
    outfile=$mode
    found=`sqlplus -s system/$PWD <<EOF
      set heading off
      select count(*) from dba_users
        where username = upper('$mode');
EOF
`
    if [ $found -eq 0 ]
    then
        echo "#####################################################"
        echo "ERROR: User $mode does not exist."
        echo "#####################################################"
        notify ; exit 1 
    fi
  else
    export_mode="tables=$mode"
    owner=`echo $mode | awk -F"." '{print $1}'`
    tablename=`echo $mode | awk -F"." '{print $2}'`
    outfile=$mode
    found=`sqlplus -s system/$PWD <<EOF
      set heading off
      select count(*) from dba_tables
        where owner = upper('$owner')
        and   table_name = upper('$tablename');
EOF
`
    if [ $found -eq 0 ]
    then
        echo "#####################################################"
        echo "ERROR: Table $mode does not exist."
        echo "#####################################################"
        notify ; exit 1
    fi     
  fi
fi
dump_file=$EXPORT_HOME/$outfile.dmp`date +%m%d_%H%M`
log_file=$EXPORT_HOME/$outfile.log`date +%m%d_%H%M`
rm $dump_file >/dev/null 2>&1
/usr/sbin/mknod $dump_file p
#exp userid=system/$PWD file=$dump_file log=$log_file $export_mode $export_rows $parfile &
exp userid="'sys/$PWDSYS AS SYSDBA'" file=$dump_file log=$log_file statistics=none $export_mode $export_rows $parfile &
compress <$dump_file >$dump_file.Z
rm $dump_file >/dev/null 2>&1	
sleep 10	
if [ "`grep -e ORA- -e EXP- $log_file`" ]
then
  echo "#################################################"
  echo "# ERROR: There are errors in the export log file."
  echo "#################################################"
  notify ; exit 1
fi   
if [ ! -f $dump_file.Z ]
then
  echo "#################################################"
  echo "# ERROR: Export file was not created."
  echo "#################################################"
  notify ; exit 1
fi	
echo
echo "#############################################################"
echo "Script export.sh ending on " `date`
echo "#############################################################"
exit 0
