#
#!/bin/ksh
# Name         : chk_session.sh
# Purpose      : To notify the oncall DBAs when the no. of sessions reach 75 %
#                of the configured value
# Date written : 03-JAN-2000
# Author       : Muthukumar Ponnambalam
# Revised date : 05-Jan-2000
# Revision     : Originally the script was written with union and later made
#                two individual scripts to facilitate interpreting the output
# Usage        : chk_session.sh <Oracle_Sid>
#
if [ $# -ne 1 ]
then
   echo "===> Usage : $0 {<Oracle_Sid>|all}"
   echo "===> Script terminating"
   exit 1
fi
Scope=`echo $1 | tr [A-Z] [a-z]`
if [ $Scope = "all" ]
then
   Sid_List=`ps -ef | grep pmon | grep -v grep | awk '{ print $NF }' | cut -f3 -d"_"`
else
   Sid_List=$1
fi
cat << ! > $DBA_HOME/admin/sp_count.sql
set termout off head off
select 'Processes:' || to_char(count(a.pid)) || ':' ||
       b.value || ':' ||
       to_char(round((count(a.pid) / b.value) * 100)) Sessions
from v\$process a, v\$parameter b
where b.name = 'processes'
group by b.value ;
select 'Sessions:' || to_char(count(a.sid)) || ':' ||
       b.value || ':' ||
       to_char(round((count(a.sid) / b.value) * 100)) Processes
from v\$session a, v\$parameter b
where b.name = 'sessions'
group by b.value ;
spool off
exit
!
for Oracle_Sid in $Sid_List
do
   if [ ! -f $HOME/bin/$Oracle_Sid ]
   then
      echo "Invalid ORACLE_SID. Try again"
      exit 1
   else
      . $HOME/bin/$Oracle_Sid
   fi
   Uname=apps
   Passwd=`$HOME/bin/tellme apps`
   sqlplus -s $Uname/$Passwd << !
spool $SID_HOME/audit/sp_count.lst
@$DBA_HOME/admin/sp_count.sql
spool off
!
   Cf_Sess=`grep Sessions $SID_HOME/audit/sp_count.lst | cut -d: -f2`
   Cf_Proc=`grep Processes $SID_HOME/audit/sp_count.lst | cut -d: -f2`
   grep 'no rows selected' $SID_HOME/audit/sp_count.lst > /dev/null 2>&1
   if [ $? -eq 0 ]
   then
      if [ -z $Cf_Sess ]
      then
         echo "Session count/parameter not found. Check $DBA_HOME/admin/sp_count.sql"
         exit 1
      elif [ -z $Cf_Proc ]
      then
         echo "Process count/parameter not found. Check $DBA_HOME/admin/sp_count.sql"
         exit 1
      fi
   fi
   Cr_Sess=`grep Sessions $SID_HOME/audit/sp_count.lst | cut -d: -f3`
   Sess_Pct=`grep Sessions $SID_HOME/audit/sp_count.lst | cut -d: -f4`
   Cr_Proc=`grep Processes $SID_HOME/audit/sp_count.lst | cut -d: -f3`
   Proc_Pct=`grep Processes $SID_HOME/audit/sp_count.lst | cut -d: -f4`
   if [ $Sess_Pct -ge 20 -o $Proc_Pct -ge 20 ]
   then
      Hostname=`hostname`
      grep "$Hostname:$Oracle_Sid" $HOME/bin/notify.ctl > $SID_HOME/audit/notify.lst
      while read Notify_Rec
      do
	    if [ `echo $Notify_Rec | cut -c 1-1` = "#" ]
	    then
	       continue
            fi
            Notify_Host=`echo $Notify_Rec | cut -d: -f1`
            Notify_Sid=`echo $Notify_Rec | cut -d: -f2`
            Notify_Who=`echo $Notify_Rec | cut -d: -f3`
	    if [ $Notify_Host = $Hostname -a $Notify_Sid = $Oracle_Sid ]
	    then
	       Mail_File=$SID_HOME/audit/mail.msg
	       Mail_Sub="$Notify_Host $0 Sessions approach high watermark"
	       cat << ! > $Mail_File
Sessions and Processes reached high watermark. Instance Id. : $Oracle_Sid
# of sessions configured : $Cf_Sess
# of sessions connected currently : $Cr_Sess
% of sessions connected to configured : $Sess_Pct
# of processes configured : $Cf_Proc
# of processes running currently : $Cr_Proc
% of processes connected to configured : $Proc_Pct
!
               #mailx -s "$Mail_Sub" $Notify_Who@corporate.ge.com < $Mail_File
	       $DBA_HOME/admin/notify.sh -s "$Mail_Sub" -f $Mail_File -w sid
	    fi
      done < $SID_HOME/audit/notify.lst
   fi
   for File in $Mail_File $SID_HOME/audit/notify.lst $DBA_HOME/admin/sp_count.sql $SID_HOME/audit/sp_count.lst
   do
       if [ -f $File ]
       then
          rm $File
       fi
   done
done
