#########
#
#Name :  ohr_profile_change.sh 
#
#Ravi Kumar
#
#
#Purpose : to modify the profile values after the instance refresh
#             profile values will be taken from the  ohr_profile.ctl 
#             appltop, webhost, webport, port number ,dbc and sid of the instance
#
#Usage : ohr_profile_change.sh <SID>
#
#
##
SIDVAL=$1
# Verify sid input
if [ -z "$1" ]
then
  echo "Error====>Required parameter SID  is missing"
  echo "                "
  echo "          Usage is ohr_profile_change.sh sid "
  echo "                      "
  echo "          Script is terminating!"
  echo "     "
  exit 1
fi
if [ ! -f $HOME/bin/$SIDVAL ]
then
  echo "  "
   echo "Invalid ORACLE_SID. Try again"
   echo " Environment file is not found for $SIDVAL in $HOME/bin:"
   echo "  "
   exit 1
fi

if [ $SIDVAL = "hrp1" ]
then
   echo "         Can't refresh production "
   echo "          Script is terminating!"
fi

. $HOME/bin/${SIDVAL}

APPLTOP1=APPLTOP_${SIDVAL}
WEB_HOST1=WEB_HOST_${SIDVAL}
WEB_PORT1=WEB_PORT_${SIDVAL}
SID1=ORACLE_SID_${SIDVAL}
DBC1=DBC_${SIDVAL}

APPLTOP=`awk -F"=" '{print $0 |"grep -i '$APPLTOP1' |cut -d= -f2 "}' $DBA_HOME/admin/ohr_profile.ctl `
WEB_HOST=`awk -F"="  '{print $0 |"grep -i  '$WEB_HOST1' |cut -d= -f2 "}' $DBA_HOME/admin/ohr_profile.ctl `
WEB_PORT=`awk -F"=" '{print $0 |"grep -i  '$WEB_PORT1' |cut -d= -f2 "}' $DBA_HOME/admin/ohr_profile.ctl `
SID=`awk -F"="  '{print $0 |"grep -i '$SID1' |cut -d= -f2 "}' $DBA_HOME/admin/ohr_profile.ctl `
DBC=`awk -F"="  '{print $0 |"grep -i '$DBC1' |cut -d= -f2 "}' $DBA_HOME/admin/ohr_profile.ctl `

echo $APPLTOP
echo $WEB_HOST
echo $WEB_PORT
echo $SID
echo $DBC
pwd1=`$HOME/bin/tellme apps`
echo $pwd1
audit_path=$SID_HOME/audit
#audit_path=/t030/oracle50/ravi
rm ${audit_path}/password_check.error
sqlplus -s apps/$pwd1@$1 <<EOF  >${audit_path}/password_check.error
EOF
  grep "ORA-01017" ${audit_path}/password_check.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> invalid username/password; logon denied"
    echo "##       ====>  cannot continue"
    cat ${audit_path}/password_check.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi

  grep " ORA-12541:" ${audit_path}/password_check.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> TNS:no listener"
    echo "##       ====>  cannot continue"
    cat ${audit_path}/password_check.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi

grep "ORA-" ${audit_path}/password_check.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "##       ====> cannot continue"
    cat ${audit_path}/password_check.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi
sqlplus -s  apps/$pwd1@$SID @$DBA_HOME/admin/ohr_profile_change.sql  $APPLTOP $WEB_HOST $WEB_PORT $SID $DBC

# Dropping the psapps database link 
#sourcepassword=`remsh corpp078 bin/getpswd psapps`
sourcepassword=`remsh corpp078 -l oracle50 "(cd \/p078/oracle50/bin;. hrp1;tellme psapps)"`
#echo $sourcepassword
sqlplus -s psapps/$sourcepassword@$1 <<EOF  >${audit_path}/ps_password_check.error
EOF
  grep "ORA-01017" ${audit_path}/ps_password_check.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> invalid username/password; logon denied"
    echo "##       ====>  cannot continue"
    echo "Pls. check the password for psapps in hrp1 instnace \n "
    echo "Pls. drop the database link in psapps schema \n"
    cat ${audit_path}/ps_password_check.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi
sqlplus -s psapps/$sourcepassword@$1 <<EOF  
spool ${audit_path}/ps_dblink_drop.list
drop database link pstoolslink.corporate.ge.com ;
spool off
EOF
# this exit is for the sqlplus 
#exit 
cat ${audit_path}/ps_dblink_drop.list
# this exit is for the unxi shell 
#exit
#/
