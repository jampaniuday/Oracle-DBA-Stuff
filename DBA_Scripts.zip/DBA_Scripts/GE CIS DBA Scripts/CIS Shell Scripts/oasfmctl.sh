#!/bin/ksh
#set -x 
# +============================================================================+
# | FILENAME
# |   oasfmctl.sh
# |
# | DESCRIPTION
# |   Start / Stop Enterprise Connector for requested Oracle instance
# |
# | USAGE
# |   oasfmctl.sh {start|stop} $DB_NAME
# |
# | MODIFICATIONS
# |
# +============================================================================+

#typeset -i classpid
exit_status=0

#echo $PATH | grep "xpg4">/dev/null
#if [ $? -ne 0 ]
#then
#  PATH=/usr/xpg4/bin:$PATH; export PATH
#fi

if [ $# -lt 2 ]
then
   echo ""
   echo "oasfmctl.sh: too few arguments specified."
   echo ""
   echo "Usage is oasfmctl.sh {start|stop|status} $DB_NAME"
   echo ""
   exit 1
fi

control_code="$1"

if test "$control_code" != "start" -a "$control_code" != "stop" -a "$control_code" != "status"
then
   echo ""
   echo "oasfmctl.sh: You must specify either 'start' or 'stop' or 'status'"
   echo ""
   exit 1
fi

DB_NAME="$2"

user=`id|cut -d"(" -f2|cut -d")" -f1`
user=`echo $user|cut -c1-7`
if [ "$user" != "sfmgr" ]
then
   echo "Error: You are not logged on to sfmgr account"
   exit 1
fi

#
# setup the environment for Oracle and SQLFLOW  Manager
#
oracle_id=`ls -l $0 | awk '{print $3}'`
ohome=`grep "^${oracle_id}:" /etc/passwd | cut -f6 -d:`
if [ ! -f $ohome/bin/$2 ]
then
   echo "Oracle environment file for database $DB_NAME is not found"
   exit 1
#else
#   unset MRO_LIB_CLASSPATH
   . $ohome/bin/$2
fi

SFM_TOP=`grep "^${user}:" /etc/passwd | cut -f6 -d:`

if [ -z "$SFM_TOP" ]; then
  echo ""
  echo "oasfmctl.sh: SFM_TOP variable is not defined"
  echo ""
  exit 1
fi

if [ ! -d "$SFM_TOP/$DB_NAME" ]; then
  echo ""
  echo "oasfmctl.sh: $SFM_TOP/$DB_NAME not found"
  echo ""
  exit 1
fi
inst_admindir=$SFM_TOP/$DB_NAME
logdir=${inst_admindir}/sfmgr/logs


  cfgfile="${inst_admindir}/sqlflow.env"
  if [ ! -e ${cfgfile} ]; then
    echo ""
    echo "oasfmctl.sh:  Cannot find configuration file \"${cfgfile}\"."
    echo ""
    exit 2
  fi
  
  #logdir="${inst_admindir}/logs"
  if [ ! -d ${logdir} ]; then
    echo ""
    echo "oasfmctl.sh: Directory \"${logdir}\" does not exist."
    echo ""
    exit 2
  fi

if test "$control_code" = "start"
then
if [ `ps -ef | grep $user | grep $DB_NAME | grep par | wc -l` -eq 0 ]; then 
  cd $inst_admindir
  .  $inst_admindir/sqlflow.env
  cd scripts
  startmgr.sh ALL 1
  echo ""
  ps -ef | grep $user | grep $DB_NAME | grep par
else  
  echo "" 
  echo "SQLFLOW Manager Already Running" 
fi
else
  if test "$control_code" = "status"
  then
  cd $inst_admindir
  .  $inst_admindir/sqlflow.env
  cd scripts
  checkmgr.sh ALL
  echo ""
  ps -ef | grep $user | grep $DB_NAME | grep par
else
  if test "$control_code" = "stop"
  then
  cd $inst_admindir
  .  $inst_admindir/sqlflow.env
  cd scripts
  stopmgr.sh ALL
fi
fi
fi 


echo ""
echo "oasfmctl.sh: exiting with status $exit_status"
echo ""

exit $exit_status
  
