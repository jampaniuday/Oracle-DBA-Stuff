#!/bin/ksh
########################################################################
## oamgr_db.sh
##
##   PURPOSE: To start, stop or status Oracle Apps database server processes
##
##   USAGE:   This script is invoked as follows:
##
## $DBA_HOME/admin/oamgr_db.sh sid {start|stop|status} {all|ccm|ctx|oas|ias|cbl|ffs} {roll_logs}
##      >>$SID_HOME/audit/oamgr.log 2>&1
##
##   PREREQS: $HOME/bin/oraapp.ctl must exist and contain entries
##            denoting all applicable Oracle Apps processes for this Oracle sid
##
##   SCRIPT PROCESS FLOW:
##     0) Verify the state of the requested Oracle instance
##     1) For action equal start|stop, process scope equal all
##            - start|stop concurrent manager, context server
##              where applicable 
##     2) For action equal start|stop, process scope equal ccm
##            - start|stop concurrent manager where applicable 
##     3) For action equal start|stop, process scope equal ctx
##            - start|stop context server where applicable 
##     4) For action equal start|stop, process scope equal oas
##            - start|stop remote OAS408 Web Server where applicable (applies
##              only to utility.ctl processing around database backups)
##     5) For action equal start|stop, process scope equal ias
##            - start|stop remote iAS Web Server where applicable (applies
##              only to utility.ctl processing around database backups)
##     6) For action equal start|stop, process scope equal cbl
##            - start|stop remote Catalog Loader background process where 
##              applicable (applies only to utility.ctl processing around 
##              database backups)
##
##   RESTART: none
##
##   OUTPUTS: A full audit trail of script results under $SID_HOME/audit.
##
##   NOTIFICATION: None.
##
##   MODIFICATIONS:
##       Date        Name         Description
##       ----------  -----------  ---------------------------------------------
##       11/01/99    Linda Slyer  New script to start|stop|status all relevant
##                                Oracle Application processes on the database
##                                server side
##
##   NOTE:  This script will ALWAYS exit with a zero (0) return code.  This
##          ensures that the backup will run when scheduled.
##
########################################################################
########################################################################
## start_xserver() function
## 
##  
########################################################################
start_xserver() {
  for xdir in `ls -d /tmp/.X*`; do
    if [ ! -x $xdir -o ! -w $xdir ]; then
      /usr/bin/pbrun -l chmod 777 $xdir
    fi
  done
  which_server=$1
  case $which_server in
  Xvnc) xserver_home=$VNC_HOME
        xlog=$HOME/.vnc/${DISPLAY}.log
       ;;
  Xvfb) xserver_home=$XVFB_HOME
        xlog=$audit_path/Xvfb_${DISPLAY}.log.$ts
        ;;
  esac

  if [ -n "$xserver_home" -a -n "$DISPLAY" ]
  then
    display_host=`echo $DISPLAY | cut -d: -f1`
    if [ "$display_host" != "$ohost" ]; then
      echo "DISPLAY $DISPLAY is not same as host $host"
      echo "Not initializing $which_server"
      return
    fi
    display_screen=`echo $DISPLAY | cut -d: -f2`
    if [ "$which_server" = "Xvfb" ]; then
        display=`echo $display_screen | cut -d. -f1`
        screen=`echo $display_screen | awk -F. '{printf "%d",$2}'`
    else
      display=$display_screen
    fi
    if [ -z "$display_screen" ]; then
      echo "Unable to determine screen number for DISPLAY $DISPLAY"
      echo "Not initializing $which_server"
      return
    fi

    if [ -z "$HOME" ]; then
     # on boot, HOME is not yet defined
      HOME=$2
      export HOME
    fi

    #if [ "`ps -ef | grep $which_server`" -lt 2 ]; then
    if [ "`ps -ef | grep $which_server | grep -c \" :$display\"`" -lt 1 ]; then
      # Xserver not started -- start it
      echo ""
      echo "oamgr_app.sh: Starting $which_server Virtual X server"
      echo ""
      
      if [ "$which_server" = "Xvnc" ]; then
        PATH=${PATH}:/usr/openwin/bin:${VNC_HOME}
        export PATH
        vncserver :$display_screen -pn -localhost
        xstat=$?
      else
	# add PATH to xhost
        PATH=${PATH}:/usr/openwin/bin
	# Replaced Elance default size with Oracle's.  
        # This is ok per Shivraj Ahluwalia from Elance
        #$XVFB_HOME/bin/Xvfb :$display -screen $screen 1152x900x8 & >> $xlog 2>&1
        #$XVFB_HOME/bin/Xvfb :$display -screen $screen 1024x800x8 & >> $xlog 2>&1
        if [ -r $XVFB_HOME/etc/SecurityPolicy ]; then
          policy_file=$XVFB_HOME/etc/SecurityPolicy
        else
          policy_file=/usr/X/server/etc/SecurityPolicy
        fi
        $XVFB_HOME/bin/Xvfb :$display -pn -sp $policy_file & >> $xlog 2>&1
        
        xstat=$?
	if [ $xstat -eq 0 ]; then
	  sleep 2
        fi
        cat $xlog
      fi

      if [ $xstat -ne 0 -o "`ps -ef | grep $which_server | grep -c \" :$display\"`" -lt 1 ]
      then
        echo ""
        echo "oamgr_db.sh: Unable to start $which_server Virtual X Server"
        echo "$xlog may contain details"
        return 1
      fi
      xhost +
    fi
  fi
  return 0
}

start_xserver_old() {
## Added DISPLAY for D2KP6
  ccm_host=`hostname`
  if [ $? -ne 0 -o -z "$ccm_host" ]; then
    echo ""
    echo "oamgr_db.sh: unable to determine host name for DISPLAY"
    echo ""
    return 1
  fi

  if [ -n "$VNC_HOME" ]
  then
    # set DISPLAY, start VNC if not started
    DISPLAY=${ccm_host}:1;export DISPLAY

    if [ -z "$HOME" ]; then
     # on boot, HOME is not yet defined
      HOME=$1
      export HOME
    fi

    if [ "`ps -ef | grep -c Xvnc`" -lt 2 ]; then
      # VNC Xserver not started -- start it
      echo ""
      echo "oamgr_db.sh: Starting VNC Virtual X server"
      echo ""
      PATH=${PATH}:/usr/openwin/bin:${VNC_HOME}
      export PATH
      vncserver :1 -pn -localhost
      if [ $? -ne 0 -o "`ps -ef | grep -c Xvnc`" -lt 2 ]
      then
        echo ""
        echo "oamgr_db.sh: Unable to start VNC Virtual X Server"
        echo "$HOME/.vnc/${DISPLAY}.log may contain details"
        return 1
      fi
      xhost +
    fi
  fi
  return 0
}

write_passphrases() {
 if [ -f "${audit_path}/.helpmenow" ]; then
   rm -f  ${audit_path}/.helpmenow
 fi
 if [ -n "$ccmgr_pass" ]
 then
   if [ -f "${SSH_CONFIGS}/${apps_owner}/identification" ]; then
     old_umask=`umask`
     umask 06
     cat ${SSH_CONFIGS}/${apps_owner}/identification | while read token id_value; do
       if [ "$token" = "IdKey" -a -n "$id_value" ]; then
         pass_phrase=`tellme ssh_${id_value}`
         if [ -n "$pass_phrase" ]; then
           echo "$id_value:$pass_phrase"
         fi
       fi
     done | crypt $ccmgr_pass > ${audit_path}/.helpmenow
     chgrp oraapp  ${audit_path}/.helpmenow
     umask $old_umask
   fi
 fi
}

setup_ssh() {
  RemoteHost=$1
  CertFile=$2
  if [ -z "$CertFile" -o ! -f "${SSH_CONFIGS}/${oracle_id}/$CertFile" ]; then
    echo "Unable to find certificate file for $sid on $RemoteHost"
    return 1
  else
    ORACLE_SID=unix
    passphrase=`tellme ssh_${RemoteHost}`
    ORACLE_SID=$sid
    if [ -z "$passphrase" ]; then
      echo "Unable to determine connection details for $sid on $RemoteHost"
      return 1
    else
      agent_status=0
      if [ -z "$SSH2_AGENT_PID" ]; then 
        eval `ssh-agent2 -s`
        agent_status=$?
      else
        if [ `ps -p $SSH2_AGENT_PID | wc -l` -eq 1 ]; then
          eval `ssh-agent2 -s`
          agent_status=$?
        fi
      fi
      if [ $agent_status -ne 0 ]; then
        echo "Unable to start ssh agent --- cannot login to remote server"
        return 1
      else
        echo $passphrase | ssh-add2 -p ${SSH_CONFIGS}/${oracle_id}/$CertFile
        ssh-add2 -l > /dev/null 2>&1
        if [ $? -ne 0 ]; then
           echo "Unable to store passphrase --- cannot login to remote server"
           return 1
        fi      
      fi
    fi
  fi
  return 0
}
  
  

## ------------------------------------------------------------------------ ##
##         Process inputs and set the instance and script environment       ##
## ------------------------------------------------------------------------ ##
if [ $# -eq 2 ]
then
# only need sid and action if sid=fndfs
  if [ $1 = "fndfs" -o $2 = "fndfs" ]
  then
    sid="fndfs"
  else
    if [ $1 = "ecm" -o $2 = "ecm" ]
    then
      sid="ecm"
    fi
  fi
fi
if [ $# -lt 3 -a "$sid" != "fndfs" -a "$sid" != "ecm" ]
then
   echo ""
   echo "oamgr_db.sh: too few arguments specified."
   echo ""
   echo "Usage is oamgr_db.sh sid {start|stop|status} {all|awx|ccm|ctx|ecm|ent|ffs} {roll_logs}"
   echo ""
   exit 1
fi
if [ $1 = "start" -o $1 = "stop" -o $1 = "status" ]
then
 all_args=$*
 action="$1"
 sid="$2"
 scope=$3
 shift 3
 xtra_args=$*
 set $all_args
else
  if [ $2 = "start" -o $2 = "stop" -o $2 = "status" ]
  then
    all_args=$*
    action="$2"
    sid="$1"
    scope=$3
    shift 3
    xtra_args=$*
    set $all_args
  else
    echo ""
    echo "oamgr_db.sh: Invalid argument specification."
    echo ""
    echo "Usage is oamgr_db.sh sid {start|stop|status} {all|ccm|ctx}"
    echo ""
    exit 1
  fi
fi
if [ $sid = fndfs -o $sid = ecm ]
then
  if [ ! -z "$scope" ]
  then
    echo "oamgr_db.sh: Invalid argument specification."
    echo ""
    echo "Usage is oamgr_db.sh {fndfs|ecm} {start|stop|status}"
    exit 1
  else
   # set scope to "none" so references to $scope work ok
    scope=none
  fi
fi

##
## Set Oracle's HOME directory
##
oracle_id=`ls -l $0 | awk '{print $3}'`
ohome=`grep "^${oracle_id}:" /etc/passwd | cut -f6 -d:`
 
ohost=`hostname`

#unset support_levels ent_alert_list
#if [ -f "$ohome/bin/notify.ctl" ]; then
#  support_levels=`grep "^${ohost}:all" $ohome/bin/notify.ctl | cut -d: -f4`
#fi
support_level=`$DBA_HOME/admin/notify.sh -q | grep 'Server Support' | cut -d: -f2`
#for support_level in $support_levels; do
  if [ "$support_level" = "gold" ]; then
    ent_alert_list="5185732892@vtext.com SSSProdAlrt@corporate.ge.com 5184842282@myairmail.com 5184842649@myairmail.com"
  fi
#done
if [ -z "$ent_alert_list" ]; then
  ent_alert_list="David.Bates@corporate.ge.com SSSProdAlrt@corporate.ge.com"
fi

##
## Verify the instance environment script exists
##
if [ ! -f $ohome/bin/$sid ]
then
  if [ $sid = fndfs ]
  then
    fndfs_env=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep '^fndfs:' |cut -d: -f3`
    if [ ! -f $ohome/bin/$fndfs_env ]
    then
      echo "Error====>Unable to find script $fndfs_env"
      echo "  to set environment for FNDFS "
      echo "          Script is terminating!"
      exit 1
    fi
    . $ohome/bin/$fndfs_env
    echo Audit trail for fndfs is in $SID_HOME/audit
  else
    if [ $sid = ecm ]
    then
      ecm_env=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep :ecm: | cut -d: -f1`
      if [ ! -f $ohome/bin/$ecm_env ]
      then
        echo "Error====>Unable to find script $ecm_env"
        echo "  to set environment for Autoclass "
        echo "          Script is terminating!"
        exit 1
      fi
      . $ohome/bin/$ecm_env
      sid=$ORACLE_SID
      scope=ecm
      echo Audit trail for Autoclass is in $SID_HOME/audit
    else
      echo "Error====>No environment script found for instance \"$sid\""
      echo "          Script is terminating!"
      exit 0
    fi
  fi
else
  ##
  ## Set the instance environment
  ##
  unset VNC_HOME XVFB_HOME
  . $ohome/bin/$sid
fi
scripts_path=$DBA_HOME/admin
audit_path=$SID_HOME/audit
tmpfile=$audit_path/oamgr$ts.list
##
## Verify that the Oracle Applications process control script exists
##
if [ ! -f $ohome/bin/oraapp.ctl ]
then
  echo "Error====>No Oracle Applications process control file exists"
  echo "          Script is terminating!"
  exit 0
fi

echo "************************************************************************"
echo "====>Script oamgr_db.sh starting on" `date`
echo "************************************************************************"
echo
error_switch=0
ts=`date +%m%d_%H%M%S`
cd ${audit_path}
## ------------------------------------------------------------------------ ##
##         Verify if the requested Oracle instance is available             ##
## ------------------------------------------------------------------------ ##
if [ -n "`sed 's/#.*$//' $ohome/bin/oraapp.ctl| grep $sid:ccm `" ]; then
  ccmgr_pass=`$ohome/bin/tellme apps`; export ccmgr_pass
  if [ -z "$ccmgr_pass" ]; then
    echo "Error====>Unable to determine Concurrent Manager password"
    echo "          Script is terminating!"
    exit 0
  fi

  sqlplus -s <<EOF >/dev/null 2>&1
  apps/$ccmgr_pass
  whenever sqlerror exit failure
  set heading off
  select * from dual;
  exit;
EOF
  db_status=$?
else
  sys_pass=`$ohome/bin/tellme system`
  if [ -z "$sys_pass" ]; then
    echo "Error====>Unable to determine Database password"
    echo "          Script is terminating!"
    exit 0
  fi

  sqlplus -s <<EOF >/dev/null 2>&1
  system/$sys_pass
  whenever sqlerror exit failure
  set heading off
  select * from dual;
  exit;
EOF
  db_status=$?
fi


if [ $db_status -ne 0 -a "$sid" != "fndfs" ]
then
    echo "Oracle instance $ORACLE_SID not available"
    echo "Bypassing $action of Oracle Apps processes"
    exit 0
fi

## ------------------------------------------------------------------------ ##
##         Process the requested command                                    ##
## ------------------------------------------------------------------------ ##
##

case $action in
'start')
  if [ $scope = "all" -o $scope = "ccm" ]
  then
### Start concurrent managers where applicable
    apps_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ccm |cut -d: -f3`
    remote_host=`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ccm |cut -d: -f4`
    remote_path=`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ccm |cut -d: -f5`
    if [ ! -z "$apps_owner" ]
    then
      if [ ! -z "$remote_host" ]
      then
        echo "====>Starting Concurrent Manager for $sid on node $remote_host"
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_db.sh $sid start ccm"
      else
        echo "====>Starting Concurrent Manager for $sid"
	if [ -n "$XVFB_HOME" ]; then
          start_xserver Xvfb $ohome
	else
	  start_xserver Xvnc $ohome
	fi
        write_passphrases
        /usr/bin/pbrun -l su $apps_owner -c "$DBA_HOME/admin/oaccmctl.sh $action $sid $xtra_args"
#       Verify that the Concurrent Manager is running
        sleep 60
        /usr/bin/pbrun -l su $apps_owner -c "$DBA_HOME/admin/oaccmctl.sh status $sid " > $SID_HOME/audit/$sid.ccm.out
        if [ "`egrep 'not active|not running' $SID_HOME/audit/$sid.ccm.out`" ]
        then
          echo "################################################################"
          echo "###ERROR====>Concurrent Manager failed to start              ###"
          echo "################################################################"
          echo
          error_switch=1
        fi
      fi
      rm -f $SID_HOME/audit/$sid.ccm.out
    fi
  fi
  if [ $scope = "all" -o $scope = "ent" ]
  then
### Start Enterprise connector where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ent `" ]
    then
      echo "====>Starting Enterprise Connector for $sid"
      # check if enterprise appears to be up
      if [ `ps  -u entsys | grep -c entser` -eq 0 ]; then
        echo ""
        echo "################################################################"
        echo "oamgr_db.sh: Enterprise not available at this time.  "
        echo "             --- connector for $sid will not be started"
        echo "################################################################"
        echo ""
        echo "Cannot start connector because Enterprise is not currently running." | mailx -s "$ohost ent $ORACLE_SID abend" $ent_alert_list
        ${DBA_HOME}/admin/notify.sh -s "ent abend" -b "Cannot start connector because Enterprise is not currently running." -w sid,server
        
        error_switch=1
      else 
        apps_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ent |cut -d: -f3`
        /usr/bin/pbrun -l su $apps_owner -c "$DBA_HOME/admin/oaentctl.sh start $sid" 
#       Verify that the connector is running
        if [ $? -ne 0 ]
        then
          echo "################################################################"
          echo "###ERROR====>Enterprise Connector failed to start            ###"
          echo "################################################################"
          echo
          error_switch=1
        fi
      fi
    fi
  fi
  if [ $scope = "all" -o $scope = "ctx" ]
  then
### Start context server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ctx `" ]
    then
      echo "====>Starting Context Server for $sid"
      $DBA_HOME/admin/oactxctl.sh $action $sid
#     Verify that the context server is running
      $DBA_HOME/admin/oactxctl.sh status $sid > $SID_HOME/audit/$sid.ctx.out
      if [ "`egrep 'not running' $SID_HOME/audit/$sid.ctx.out`" ]
      then
        echo "################################################################"
        echo "###ERROR====>Context Server failed to start                  ###"
        echo "################################################################"
        echo
        error_switch=1
      fi
      rm -f $SID_HOME/audit/$sid.ctx.out
    fi
  fi
  if [ $scope = "all" -o $scope = "sfm" ]
  then
### Start SQLFLOW Manager where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl  |grep $sid:sfm `" ]
    then
      echo "====>Starting SQLFLOW Manager  for $sid"
        /usr/bin/pbrun -l su - sfmgr -c "$DBA_HOME/admin/oasfmctl.sh start $sid"
#     Verify that the SQLFLOW Manager is running
        if [ $? -ne 0 ]
        then
        echo "################################################################"
        echo "###ERROR====>SQLFLOW Manager failed to start                 ###"
        echo "################################################################"
        echo
        error_switch=1
        fi
    fi
  fi
  if [ $scope = "oas" ]
  then
### Start remote OAS408 Web Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:oas `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:oas > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        echo Submitting remote command to start OAS for $sid on $remote_host
        remsh ${remote_host} -n "(echo \"${remote_path}/admin/oamgr_app.sh start oas $sid > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
      done < $tmpfile
    fi
  fi
  if [ $scope = "ias" ]
  then
### Start remote iAS Web Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ias `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ias > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        echo Submitting remote command to start iAS for $sid on $remote_host
        remsh ${remote_host} -n "(echo \"${remote_path}/admin/oamgr_app.sh start ias $sid > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
      done < $tmpfile
    fi
  fi
  if [ $scope = "maint" ]
  then
### Start remote iAS Maint Web Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraappmaint.ctl|grep $sid:ias `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraappmaint.ctl |grep $sid:ias > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        remote_scope=`echo $oa_process | cut -d: -f5`
        echo
        echo Submitting remote command to start iAS for $sid on $remote_host
        remsh ${remote_host} -n "(echo \"${remote_path}/admin/oamgr_app.sh start ias ${remote_scope} > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
      done < $tmpfile
    fi
  fi
  if [ $scope = "170all" ]
  then
### Start remote OC4J mv where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:$scope`" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:$scope > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        echo Submitting remote command to start OC4J $scope for $sid on $remote_host
echo Start $sid $scope
        remsh ${remote_host} -n "(echo \"${remote_path}/admin/oamgr_app.sh start $scope $sid > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
      done < $tmpfile
    fi
  fi
  if [ $scope = "bea" ]
  then
### Start remote BEA WebLogic server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:bea `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:bea > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        certfile=`echo $oa_process | cut -d: -f4`
	remote_id=`echo $oa_process | cut -d: -f5`
        remote_path=`echo $oa_process | cut -d: -f6`
        echo
        echo Submitting remote command to start WebLogic for $sid on $remote_host
        setup_ssh $remote_host $certfile
        if [ $? -eq 0 ]; then
	  if [ "$remote_id" = "weblogic" ]; then
	    ssh2 weblogic@${remote_host} '. ./.bash_profile;./WebLogicCtl.sh start'
          else
	    if [ -n "$remote_id" ]; then
	      remote_id="${remote_id}@"
            fi
            ssh2 ${remote_id}${remote_host} "(echo \"${remote_path}/admin/oamgr_app.sh start bea $sid > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
          fi
        else
	  # no ssh entry
	  echo "Using remsh rather than ssh"
	  if [ -n "$remote_id" ]; then
	    remote_id="-l ${remote_id} "
          fi
            remsh ${remote_id}${remote_host} "(echo \"${remote_path}/admin/oamgr_app.sh start bea $sid > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
        fi
      done < $tmpfile
    fi
    if [ -n "$SSH2_AGENT_PID" ]; then
      kill -9 $SSH2_AGENT_PID
    fi
  fi
  if [ $scope = "cbl" ]
  then
### Start remote Catalog Loader background process where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:cbl `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:cbl > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        echo Submitting remote command to start CBL for $sid on $remote_host
        remsh ${remote_host} -n "(echo \"${remote_path}/admin/oamgr_app.sh start cbl $sid > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
      done < $tmpfile
    fi
  fi
  if [ $sid = "fndfs" ]
  then
    fndfs_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep '^fndfs:' | cut -d: -f2`
    if [ ! -z "$fndfs_owner" ]
    then
      echo "====>Starting FNDFS Listener"
      /usr/bin/pbrun -l su $fndfs_owner -c "$DBA_HOME/admin/oaffsctl.sh $action "
      error_switch=$?
    else
      echo "No entry in oraapp.ctl for fndfs  -- listener not started"
      error_switch=1
    fi
  fi
#
# Added for Instance Specific FNDFS process
# 6/23/03 - DBD
#
  if [ $scope = "all" -o $scope = "ffs" ]
  then
    ffs_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ffs | cut -d: -f3`
    if [ ! -z "$ffs_owner" ]
    then
      echo "====>Starting ${sid} FNDFS Listener"
      /usr/bin/pbrun -l su $ffs_owner -c "$DBA_HOME/admin/oaffsctl.sh $action $sid "
      error_switch=$?
    fi
  fi
  if [ $scope = "ecm" ]
  then
### Start remote Autoclass/ECM background process where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep :ecm: `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep :ecm: > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        echo Submitting remote command to start Autoclass on $remote_host
        remsh ${remote_host} -n "(echo \"${remote_path}/admin/oamgr_app.sh start ecm > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
      done < $tmpfile
    fi
  fi
    ;;
'stop')
  if [ $scope = "all" -o $scope = "ccm" ]
  then
### Stop concurrent managers where applicable
    apps_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ccm |cut -d: -f3`
    remote_host=`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ccm |cut -d: -f4`
    remote_path=`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ccm |cut -d: -f5`
    if [ ! -z "$apps_owner" ]
    then
      if [ ! -z "$remote_host" ]
      then
        echo "====>Stopping Concurrent Manager for $sid on node $remote_host"
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_db.sh $sid stop ccm"
      else
        echo "====>Stopping Concurrent Manager for $sid"
        /usr/bin/pbrun -l su $apps_owner -c "$DBA_HOME/admin/oaccmctl.sh $action $sid"
      fi
    fi
  fi
  if [ $scope = "all" -o $scope = "ent" ]
  then
### Stop Enterprise Connector where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ent `" ]
    then
      echo "====>Stopping Enterprise Connector for $sid"
      apps_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ent | cut -d: -f3`
      /usr/bin/pbrun -l su $apps_owner -c "$DBA_HOME/admin/oaentctl.sh stop $sid" 
    fi
  fi
  if [ $scope = "all" -o $scope = "ctx" ]
  then
### Stop Context Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ctx `" ]
    then
      echo "====>Stopping Context Server for $sid"
      $DBA_HOME/admin/oactxctl.sh $action $sid
    fi
  fi
  if [ $scope = "all" -o $scope = "sfm" ]
  then
### Stop SQLFLOW Manager where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:sfm `" ]
    then
      echo "====>Stopping SQLFLOW Manager for $sid"
      /usr/bin/pbrun -l su - sfmgr -c "$DBA_HOME/admin/oasfmctl.sh $action $sid"
    fi
  fi
  if [ $scope = "oas" ]
  then
### Stop remote OAS408 Web Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:oas `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:oas > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh stop oas $sid"
      done < $tmpfile
    fi
  fi
  if [ $scope = "ias" ]
  then
### Stop remote iAS Web Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ias `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ias > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh stop ias $sid"
      done < $tmpfile
    fi
  fi
  if [ $scope = "maint" ]
  then
### Stop remote iAS Web Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraappmaint.ctl|grep $sid:ias `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraappmaint.ctl |grep $sid:ias > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        remote_scope=`echo $oa_process | cut -d: -f5`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh stop ias ${remote_scope}"
      done < $tmpfile
    fi
  fi
  if [ $scope = "170all" ]
  then
### Stop remote OC4J mv where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:$scope `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:$scope > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh stop $scope $sid"
      done < $tmpfile
    fi
  fi
  if [ $scope = "bea" ]
  then
### Stop remote BEA WebLogic server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:bea `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:bea > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        certfile=`echo $oa_process | cut -d: -f4`
	remote_id=`echo $oa_process | cut -d: -f5`
        remote_path=`echo $oa_process | cut -d: -f6`
        echo
        echo Submitting remote command to stop WebLogic for $sid on $remote_host
        setup_ssh $remote_host $certfile
        if [ $? -eq 0 ]; then
	  if [ "$remote_id" = "weblogic" ]; then
	    ssh2 weblogic@${remote_host} '. ./.bash_profile;./WebLogicCtl.sh stop'
          else
	    if [ -n "$remote_id" ]; then
	      remote_id="${remote_id}@"
            fi
            ssh2 ${remote_id}${remote_host} "(echo \"${remote_path}/admin/oamgr_app.sh stop bea $sid > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
          fi
        else
	  # no ssh entry
	  echo "Using remsh rather than ssh"
	  if [ -n "$remote_id" ]; then
	    remote_id="-l ${remote_id} "
          fi
          remsh ${remote_id}${remote_host} "(echo \"${remote_path}/admin/oamgr_app.sh stop bea $sid > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
	  
        fi
      done < $tmpfile
    fi
    if [ -n "$SSH2_AGENT_PID" ]; then
      kill -9 $SSH2_AGENT_PID
    fi
  fi
  if [ $scope = "cbl" ]
  then
### Stop remote Catalog Loader background process where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:cbl `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:cbl > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh stop cbl $sid"
      done < $tmpfile
    fi
  fi
  if [ $sid = "fndfs" ]
  then
    fndfs_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep '^fndfs:' | cut -d: -f2`
    if [ ! -z "$fndfs_owner" ]
    then
      echo "====>Stopping FNDFS Listener"
      /usr/bin/pbrun -l su $fndfs_owner -c "$DBA_HOME/admin/oaffsctl.sh $action "
      error_switch=$?
    else
      echo "No entry in oraapp.ctl for fndfs  -- listener not stopped"
      error_switch=1
    fi
  fi

#
# Added for Instance Specific FNDFS process
# 6/23/03 - DBD
#
  if [ $scope = "all" -o $scope = "ffs" ]
  then
    ffs_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ffs | cut -d: -f3`
    if [ ! -z "$ffs_owner" ]
    then
      echo "====>Stopping ${sid} FNDFS Listener"
      /usr/bin/pbrun -l su $ffs_owner -c "$DBA_HOME/admin/oaffsctl.sh $action $sid "
      error_switch=$?
    fi
  fi

  if [ $scope = "ecm" ]
  then
### Stop remote Autoclass/ECM background process where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep :ecm: `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep :ecm: > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        echo Submitting remote command to stop Autoclass on $remote_host
        remsh ${remote_host} -n "(echo \"${remote_path}/admin/oamgr_app.sh stop ecm > ${remote_path}/audit/oamgr_app.audit`date +\%m\%d_\%H\%M\%S` 2>&1\"|at now +1 minute)"
      done < $tmpfile
    fi
  fi
  if [ $scope = "cbl" ]
  then
### Stop remote Catalog Loader background process where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:cbl `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:cbl > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh stop cbl $sid"
      done < $tmpfile
    fi
  fi
    ;;
'status')
  if [ $scope = "all" -o $scope = "ccm" ]
  then
### Status concurrent managers where applicable
    apps_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ccm |cut -d: -f3`
    remote_host=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ccm |cut -d: -f4`
    remote_path=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ccm |cut -d: -f5`
    if [ ! -z "$remote_host" ]
    then
      echo "====>Status Concurrent Manager for $sid on node $remote_host"
      remsh ${remote_host} -n "${remote_path}/admin/oamgr_db.sh $sid status ccm"
    else
      echo "====>Status Concurrent Manager for $sid"
      echo
      /usr/bin/pbrun -l su $apps_owner -c "$DBA_HOME/admin/oaccmctl.sh $action $sid"
    fi
  fi
  if [ $scope = "all" -o $scope = "ent" ]
  then
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ent `" ]
    then
###   Print the Status of the Enterprise Connector
      apps_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ent |cut -d: -f3`
      /usr/bin/pbrun -l su $apps_owner -c "$DBA_HOME/admin/oaentctl.sh status $sid" 
    fi
  fi
  if [ $scope = "all" -o $scope = "ctx" ]
  then
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ctx `" ]
    then
###   Print the Status of the Context Server
      $DBA_HOME/admin/oactxctl.sh $action $sid
    fi
  fi
  if [ $scope = "all" -o $scope = "sfm" ]
  then
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:sfm `" ]
    then
###   Print the Status of the SQLFLOW Manager
    /usr/bin/pbrun -l su - sfmgr -c "$DBA_HOME/admin/oasfmctl.sh status $sid"
    fi
  fi
  if [ $scope = "oas" ]
  then
### Status remote OAS408 Web Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:oas `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:oas > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh status oas $sid"
      done < $tmpfile
    fi
  fi
  if [ $scope = "ias" ]
  then
### Status remote iAS Web Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:ias `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ias > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh status ias $sid"
      done < $tmpfile
    fi
  fi
  if [ $scope = "maint" ]
  then
### Status remote iAS Maint Web Server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraappmaint.ctl|grep $sid:ias `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraappmaint.ctl |grep $sid:ias > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        remote_source=`echo $oa_process | cut -d: -f5`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh status ias ${remote_source}"
      done < $tmpfile
    fi
  fi
  if [ $scope = "bea" ]
  then
### Status remote BEA WebLogic server where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:bea `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:bea > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        certfile=`echo $oa_process | cut -d: -f4`
	remote_id=`echo $oa_process | cut -d: -f5`
        remote_path=`echo $oa_process | cut -d: -f6`
        echo
        echo Submitting remote command to status WebLogic for $sid on $remote_host
        setup_ssh $remote_host $certfile
        if [ $? -eq 0 ]; then
	  if [ "$remote_id" = "weblogic" ]; then
            ssh2 -q weblogic@${remote_host} '. ./.bash_profile;./WebLogicCtl.sh status'
          else
	    if [ -n "$remote_id" ]; then
	      remote_id="${remote_id}@"
            fi
            ssh2 ${remote_id}${remote_host} "${remote_path}/admin/oamgr_app.sh status bea $sid"
          fi
        fi
	# no ssh entry
	echo "Using remsh rather than ssh"
	if [ -n "$remote_id" ]; then
	  remote_id="-l ${remote_id} "
        fi
        remsh ${remote_id}${remote_host} "${remote_path}/admin/oamgr_app.sh status bea $sid"
      done < $tmpfile
    fi
    if [ -n "$SSH2_AGENT_PID" ]; then
      kill -9 $SSH2_AGENT_PID
    fi
  fi
  if [ $scope = "cbl" ]
  then
### Status remote Catalog Loader background process where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep $sid:cbl `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:cbl > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh status cbl $sid"
      done < $tmpfile
    fi
  fi
  if [ $sid = "fndfs" ]
  then
    fndfs_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep '^fndfs:' | cut -d: -f2`
    if [ ! -z "$fndfs_owner" ]
    then
      echo "====>Status FNDFS Listener"
      /usr/bin/pbrun -l su $fndfs_owner -c "$DBA_HOME/admin/oaffsctl.sh $action "
      error_switch=$?
    else
      echo "No entry in oraapp.ctl for fndfs  -- listener not stopped"
      error_switch=1
    fi
  fi
#
# Added for Instance Specific FNDFS process
# 6/23/03 - DBD
#
  if [ $scope = "all" -o $scope = "ffs" ]
  then
    ffs_owner=`sed 's/#.*$//' $ohome/bin/oraapp.ctl |grep $sid:ffs | cut -d: -f3`
    if [ ! -z "$ffs_owner" ]
    then
      echo "====>Status ${sid} FNDFS Listener"
      /usr/bin/pbrun -l su $ffs_owner -c "$DBA_HOME/admin/oaffsctl.sh $action $sid "
      error_switch=$?
    fi
  fi
  if [ $scope = "ecm" ]
  then
### Status remote Autoclass background process where applicable
    if [ "`sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep :ecm: `" ]
    then
      sed 's/#.*$//' $ohome/bin/oraapp.ctl|grep :ecm: > $tmpfile
      while read oa_process
      do
        remote_host=`echo $oa_process | cut -d: -f3`
        remote_path=`echo $oa_process | cut -d: -f4`
        echo
        remsh ${remote_host} -n "${remote_path}/admin/oamgr_app.sh status ecm"
      done < $tmpfile
    fi
  fi
    ;;
*)
    echo "usage: $0 sid {start|stop|status} {all|ccm|ctx}"
    ;;
esac

rm -f $tmpfile
echo ""
echo "oamgr_db.sh: exiting with status $error_switch"
echo ""

exit $error_switch
