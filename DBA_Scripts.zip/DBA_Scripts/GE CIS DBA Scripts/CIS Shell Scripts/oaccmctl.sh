#!/bin/ksh
# +============================================================================+
# | FILENAME
# |   oaccmctl.sh
# |
# | DESCRIPTION
# |   Start / Stop Concurrent Manager for requested Oracle instance
# |
# | USAGE
# |   oaccmctl.sh {start|stop} $ORACLE_SID
# |
# | MODIFICATIONS
# |	Added TWO_TASK for 11i - DBD 10/18/00
# |
# +============================================================================+
########################################################################
##
## Functions
##
########################################################################
function check_process
{
CCMGRTYP=$1
sqlplus -s apps/${ccmgr_pass}@${TWO_TASK} << EOF >${APPL_TOP}/ccmgr_show_${ORACLE_SID}.list
set heading off feedback off echo off
select substr(os_process_id,1,10), concurrent_queue_name
  from applsys.fnd_concurrent_processes p, applsys.fnd_concurrent_queues q
  where p.queue_application_id = q.application_id
  and   p.concurrent_queue_id = q.concurrent_queue_id
  and   concurrent_queue_name like '$1%'
  and   process_status_code in ('A', 'C');
exit
EOF

if [ "`cat ${APPL_TOP}/ccmgr_show_${ORACLE_SID}.list | grep "$CCMGRTYP"`" != "" ]
then
    Pid=`cat ${APPL_TOP}/ccmgr_show_${ORACLE_SID}.list | grep "$CCMGRTYP" | \
         grep -v grep | awk '{print $1}'`
    for pid in $Pid
    do
        if [ "`ps -p $pid | grep -v "PID"`" = "" ]
        then
            ##
            ##  Unix process unavailable so set error switch
            ##
            echo "Concurrent Manager $CCMGRTYP process $pid"\
                 "for $ORACLE_SID not running"
            error_switch=1
        else
            echo "Concurrent Manager $CCMGRTYP process $pid"\
                 "for $ORACLE_SID running"
        fi
    done
else
    echo "Concurrent Manager $CCMGRTYP process for"\
         "$ORACLE_SID not active"
    error_switch=1
fi
}


echo $PATH | grep "xpg4">/dev/null
if [ $? -ne 0 ]
then
  PATH=/usr/xpg4/bin:$PATH; export PATH
fi

if [ $# -lt 2 ]
then
   echo ""
   echo "oaccmctl.sh: too few arguments specified."
   echo ""
   echo "Usage is oaccmctl.sh {start|stop|status} $ORACLE_SID"
   echo ""
   exit 1
fi

control_code="$1"

if test "$control_code" != "start" -a "$control_code" != "stop" -a "$control_code" != "status"
then
   echo ""
   echo "oaccmctl.sh: You must specify either 'start' or 'stop' or 'status'"
   echo ""
   exit 1
fi

DB_NAME="$2"

user=`id|cut -d"(" -f2|cut -d")" -f1`
mailto=$user
user=`echo $user|cut -c1-7`
if [ "$user" != "applmgr" ]
then
   echo "Error: You are not logged on to an applmgr account"
   exit 1
fi

#
# setup the environment for Oracle and Applications
#
oracle_id=`ls -l $0 | awk '{print $3}'`
ohome=`grep "^${oracle_id}:" /etc/passwd | cut -f6 -d:`

case `echo $APP | tr '[:lower:]' '[:upper:]'` in
  'SSS') concsub_uname=APPSDBA 
         ;;
  'HR')  concsub_uname=APPSDBA
         ;;
  *)     concsub_uname=SYSADMIN
         ;;
esac

if [ ! -f $ohome/bin/$2 ]
then
   echo "Oracle environment file for database $DB_NAME is not found"
   exit 1
else
   . $ohome/bin/$2
   . $APPL_TOP/APPS${ORACLE_SID}_`hostname`.env
fi

if [ -z "$ccmgr_pass" ]
then
#
# Prompt for the apps password if oaccmctl.sh was submitted directly from a
# terminal
#
  if [ -z "`who -m 2>/dev/null`" ]
  then
    echo
    echo "Unknown apps password"
    echo
    exit 1
  else
    echo "Enter the apps password====>"
    read ccmgr_pass
    clear
  fi
fi

# don't export ccmgr_pass to subshells
typeset +x ccmgr_pass

if test "$control_code" = "start"
then
# Check to see if a shutdown file is present. If yes, remove it - DBD
  if [ -f "$APPLCSF/log/shutdown" ]
  then
     rm $APPLCSF/log/shutdown
  fi
  if [ -n "$VNC_HOME" ]; then
    if [ -z "$DISPLAY" ]; then
      echo ""
      echo oaccmctl.sh: DISPLAY environment variable has not been set
      echo ""
    else
      echo "       DISPLAY for Concurrent Manager is $DISPLAY"
    fi
  fi
  if [ "$APP" = "HR" ]
  then
    $OAH_TOP/admin/scripts/${ORACLE_SID}_`hostname`/adalnctl.sh start
    $OAH_TOP/admin/scripts/${ORACLE_SID}_`hostname`/adcmctl.sh start apps/${ccmgr_pass}
  else
  startmgr sysmgr="apps/${ccmgr_pass}@${TWO_TASK}" \
           mgrname="${DB_NAME}"      \
           logfile=$APPLCSF/$APPLLOG/${DB_NAME}.mgr \
           mailto="$mailto"    \
           restart="N"         \
           sleep=30 
  fi
  exit_code=$?
     if [ -f "$FND_TOP/resource/wfmail_${ORACLE_SID}.cfg" ]
     then
       sleep 5
       CONCSUB apps/${ccmgr_pass} SYSADMIN "System Administrator" $concsub_uname \
       CONCURRENT \
       FND \
       FNDWFMAIL \
       PROGRAM_NAME='"Notification Mailer"' \
       "$FND_TOP/resource/wfmail_${ORACLE_SID}.cfg"
     fi
else
  if test "$control_code" = "stop"
  then
# Stopping APPS listener for HR
  if [ "$APP" = "HR" ]
  then
    $OAH_TOP/admin/scripts/${ORACLE_SID}_`hostname`/adalnctl.sh stop
  fi
#
# Place a file called shutdown in the ccm log dir to stop the
# Workflow Mailer - DBD
    touch $APPLCSF/log/shutdown
    sleep 15
    CONCSUB apps/${ccmgr_pass}@${TWO_TASK} SYSADMIN "System Administrator" $concsub_uname WAIT=N CONCURRENT FND ABORT
    exit_code=$?
  else
    check_process "FNDICM"        ## Internal Concurrent Manager
    check_process "FNDCRM"        ## Conflict Resolution Manager
    check_process "STANDARD"      ## Standard Manager
    #rm ${APPL_TOP}/ccmgr_show_${ORACLE_SID}.list >/dev/null 2>&1
    if [ -n "$VNC_HOME" ]
    then
      echo ""
      if [ `ps -ef | grep -c Xvnc` -lt 2 ]
      then
        echo "No X Server is running!"
      else
        echo "X Server process:"
        ps -ef | grep Xvnc | grep -v grep
      fi
      echo ""
    fi

  fi
fi

echo ""
echo "oaccmctl.sh: exiting with status $exit_code"
echo ""

exit $exit_code
