#!/bin/ksh
########################################################################
##
## purge.sh - To purge specified directories of files older than
##            the defined purge period.
##            A file named purge.ctl must first be defined under
##            the $HOME/bin directory.  Entries in this file
##            must be formatted as follows:
##            path:purgeperiod:mask:owner
##            The path and purge period fields are required;
##            The mask field can be omitted if all files under the
##            specified path are candidates for removal.
##            A literal "recursive" can be provided to recursively remove
##            directories whose name contains the string supplied in the mask
##            parameter (mask is required for recursive processing!)
##
##            With the following sample purge.ctl file:
##
##            /dump01/oracle/asst/bdump:10:.trc
##            /arch01/oracle/asst:10
##            /users/oracle/rdbms/audit:0
##            /dump01/oracle/asst/cdump:7:core:recursive
##            /var/tmp/:7::faxmgr
##
##            the script will remove all files containing the string
##            .trc and older than 10 days from the bdump directory;
##            all files older than 10 days from the asst archive log
##            directory; all files from Oracle's audit directory; and
##            all files and directories containing the string core and
##            older than 7 days from the cdump directory; all files
##            older than 7 days and owned by faxmgr from the /var/tmp directory.
##
##            NOTE: For instances using tape_copy.sh to save archive logs
##                  to tape, additional logic is applied before removing any
##                  archive log. The log name must first exist in the
##                  log_to_tape.list file under the log archive directory thus
##                  signifying that it was previously saved to tape.
##
## Author : Linda Slyer
## Date   : Dec 13, 1996
##
########################################################################
echo $0
OS_TYPE=`uname`
if [ "$OS_TYPE" = "SunOS" ]
then
  PATH=/usr/xpg4/bin:$PATH:/usr/ucb; export PATH
  ORATAB=/var/opt/oracle/oratab
else
  ORATAB=/etc/oratab
fi

rval=0
currmonth=`date +%m`
##########################################################################
# Determine who to notify in case of subsequent abend
##########################################################################
charset=us-ascii; export charset
ohost=`hostname`
#if [ -f $HOME/bin/notify.ctl ]
#then
#  ooncall=`cat $HOME/bin/notify.ctl | awk -F: '
#    BEGIN {firstsw = 1}
#    {if (firstsw == 1 && $1 == "all" && $2 == "all" && NF > 2) {
#       print $3; firstsw = 0}}'`
#  oserver_rep=`cat $HOME/bin/notify.ctl | awk -F: -v host="$ohost" '
#    BEGIN {firstsw = 1}
#    {if (firstsw == 1 && $1 == host && $2 == "all" && NF > 2) {
#       print $3; firstsw = 0}}'`
#else
#  ooncall=linda.slyer
#  oserver_rep=linda.slyer
#fi

rmsg="purge.sh abended - check \$DBA_HOME/audit/purge.audit"

#Changes Made By Ramesh Putumbaka 

notify()
{
$DBA_HOME/admin/notify.sh -s "Purge Abend." -b "$rmsg"  -w server
}

##########################################################################
# run any Oracle environment script, to set DBA_HOME
##########################################################################
sid_sw=0
for sid in `grep '^.*:.*:Y[ ]*$' $ORATAB |cut -d: -f1`; do
  if [ -f $HOME/bin/$sid ]; then
    if ( . $HOME/bin/$sid >/dev/null 2>&1 ); then
      . $HOME/bin/$sid
      sid_sw=1
      break
    fi
  fi
done

if [ -z "$DBA_HOME" ]; then
  user=`id|cut -d"(" -f2|cut -d")" -f1`
  uhome=`grep "^${user}:" /etc/passwd | cut -d: -f6`
  unset dba_home
  filelist=`ls -t $uhome/bin`
    for f in $filelist; do
      if [ -n "$dba_home" ]; then break; fi
      x=`sed 's/^[ ]*export //'  $uhome/bin/$f 2>/dev/null | grep '^[ ]*DBA_HOME=' | tr ';' ' ' | head -1 | awk '{print $1}'`
      eval $x
      if [ -d "${DBA_HOME}/admin" -a -n "$DBA_HOME" ]; then
        if [ `find $DBA_HOME -type d -user $user -prune 2>/dev/null | wc -l` -ge 1 ]; then
          dba_home=$DBA_HOME
          break
        fi
      fi
    done
fi

if [ -z "$DBA_HOME" ]
then
  # try to derive DBA_HOME from location of this file
  currdir=`dirname $0`
  if [ "$currdir" = "." ]; then
    currdir=`pwd`
  fi
  DBA_HOME=`dirname $currdir`
  if [ ! -d $DBA_HOME/admin -o ! -d $DBA_HOME/audit -o -z "$DBA_HOME" ]; then
    rval=1
    echo "Could not find an Oracle environment to set DBA_HOME"
    echo "Script is terminating"
    notify
    exit $rval
  fi
fi

if [ -z "$DBA_HOME" ]
then
  rval=1
  echo "DBA_HOME not set by environment script $sid"
  echo "Script is terminating"
  notify
  exit $rval
fi
tmpfile=$DBA_HOME/audit/purge.filelist.$$
failure_list=$DBA_HOME/audit/purge.failures.$$
if [ -f $failure_list ]; then
  rm -f $failure_list
fi

##########################################################################
# Loop over the entries in file, purge.ctl
##########################################################################
ctl_lines=`wc -l $HOME/bin/purge.ctl | awk '{print $1}'`
curr_line=1
while [ $curr_line -le $ctl_lines ]
do
  purge_control=`sed -n "$curr_line p" $HOME/bin/purge.ctl `
  curr_line=`expr $curr_line + 1`
  nextdir=`echo ${purge_control} | awk -F: '{print $1}'`
  if [ -z "$nextdir" ] || [ "`echo $nextdir|cut -c1`" = "#" ]
  then
    continue
  fi
  perms=-1
  if [ "$OS_TYPE" = "SunOS" ]
  then
    echo "${nextdir}/" | grep -q '^/var/preserve'
    if [ $? -eq 0 ]; then
      perms=600
      set -x
      pbrun -l chmod -R 777 ${nextdir}
      set +x
    fi
  fi
  purge_period=`echo ${purge_control} | awk -F: '{print $2}'`
  mask_sw=0
  purge_mask=
  recursive_sw=0
  opt3=`echo ${purge_control} | cut -d: -f3`
  opt4=`echo ${purge_control} | cut -d: -f4`
  opt5=`echo ${purge_control} | cut -d: -f5`
  file_owner=
  if [ ! -z "$opt3" ]
  then
    if [ "$opt3" = "recursive" ]
    then
      if [ -z "$opt4" ]
      then
        echo "Syntax error: ${purge_control} - line ignored"
        rval=1
        continue
      else
        mask_sw=1
        recursive_sw=1
        purge_mask=$opt4
        if [ ! -z "$opt5" ]
        then
          file_owner=$opt5
        fi
      fi
    else
      mask_sw=1
      purge_mask=$opt3
      if [ "$opt4" = "recursive" ]
      then
        recursive_sw=1
        if [ ! -z "$opt5" ]
        then
          file_owner=$opt5
        fi
      else
        if [ ! -z "$opt4" ]
        then
          file_owner=$opt4
        fi
        if [ ! -z "$opt5" ]
        then
          echo "Syntax error: ${purge_control} - line ignored"
          rval=1
          continue
        fi
      fi
    fi
  else
    if [ ! -z "$opt4" ]
    then
      file_owner=$opt4
    fi
    if [ ! -z "$opt5" ]
    then
      echo "Syntax error: ${purge_control} - line ignored"
      rval=1
      continue
    fi
  fi
  if [ ! -z "$file_owner" ]
  then
    grep -s "^${file_owner}:" /etc/passwd > /dev/null
    if [ $? -ne 0 ]
    then
      echo "Syntax error: ${purge_control} - user $file_owner not found in /etc/passwd - line ignored"
      continue
    fi
  fi

  removectr=0
  filectr=0
  for cleandir in $nextdir; do
    if [ ! -d "$cleandir" ]; then
      continue
    fi
    cd $cleandir
    if [ $? -ne 0 ]; then
      rval=l
      echo Unable to change directory to $cleandir
      continue
    fi
  ##########################################################################
  # Loop over the files in the current purge.ctl directory being processed
  ##########################################################################
    #for filename in `ls`
    #ls -1tr | while read  filename
    if [ -f $tmpfile ]; then
      rm -f $tmpfile
    fi
    ls -1tr > $tmpfile
    if [ $? -ne 0 ]; then
      echo Error creating temporary file $tmpfile
      rval=1
      continue
    fi
    while read -r filename
    do
      if [ $mask_sw -eq 1 ]
      then
        echo $filename | egrep "$purge_mask" >/dev/null 2>&1
        if [ $? -eq 1 ]
        then
          # check whether we should break out because this file is newer
          # than purge period
          not2new=`find "./$filename" -prune -mtime +$purge_period `
          if [ $? -ne 0 -o -n "$not2new" ]; then
            continue
          else
            break
          fi
        fi
      fi
      filectr=`expr $filectr + 1`
      echo $cleandir | grep "arch" >/dev/null
      if [ $? -eq 0 ]
      then
        if [ -f log_to_tape.list ]
        then
          grep "$filename" log_to_tape.list >/dev/null
          if [ $? -eq 1 ]
          then
            continue
          fi
        fi
      fi
      if [ ! -z "$file_owner" ]
      then
        deletable_files=`find "./$filename" -prune -user $file_owner -mtime +$purge_period | wc -l`
      else
        deletable_files=`find "./$filename" -prune -mtime +$purge_period | wc -l`
      fi
      if [ $deletable_files -gt 0 ]
      then
        if [ -d "$filename" ]
        then
          if [ $recursive_sw -eq 1 ]
          then
            rm -rf "./$filename"
            # Added by Stampalia to capture rm failures
            if [ $? -ne 0 ]
            then 
              rval=1
              echo "$cleandir/$filename" >> $failure_list
            fi
            removectr=`expr $removectr + 1`
          fi
        else
          if [ "$cleandir" = "/var/tmp" -a "`echo $filename | cut -c1-2`" = "Ex" ]
           then
             pbrun -l rm -f "./$filename"
             rm_stat=$?
           else
             rm -f "./$filename"
             rm_stat=$?
          fi
          # Added by Stampalia to capture rm failures
          if [ $rm_stat -ne 0 ]
          then 
            rval=1
	    echo "$cleandir/$filename" >> $failure_list
          fi
          removectr=`expr $removectr + 1`
        fi
      else
        # file did not match file_owner and/or purge_period
        # break out if purge_period is too old
        if [ ! -z "$file_owner" ]
        then
          deletable_files=`find "./$filename" -prune -mtime +$purge_period `
          if [ $? -eq 0 -a -z "$deletable_files" ]; then
            break
          fi
        else
          break
        fi
      fi
    done < $tmpfile
  done
  if [ "$perms" -ge 0 ]; then
    set -x
    pbrun -l chmod -R $perms $nextdir
    set +x
  fi
  echo $nextdir":" $removectr "of" $filectr $purge_mask "files removed"
#done < $DBA_HOME/admin/purge.ctl
#done < $HOME/bin/purge.ctl
done
rm -f $tmpfile
if [ $rval -ne 0 ]
then
  echo "Errors encountered"
  if [ -f $failure_list ]; then
    echo "Following candidate files may not have been purged:"
    cat $failure_list
    rm $failure_list
  fi
  notify
fi
exit $rval
