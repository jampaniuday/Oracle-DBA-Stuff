#!/bin/ksh 

usage() {
  echo "usage: oa_request.sh sid {start|stop|cycle|status} {ccm|ias|cbl|tcf|f60} [roll_logs]"
  exit 1
}


if [ $# -lt 3 ]
then
   echo ""
   echo "oa_request.sh : too few arguments specified."
   usage
fi
if [ $1 = "start" -o $1 = "stop" -o $1 = "status" -o $1 = "cycle" ]
then
 action="$1"
 sid="$2"
 scope=$3
else
  if [ $2 = "start" -o $2 = "stop" -o $2 = "status" -o $2 = "cycle" ]
  then
    action="$2"
    sid="$1"
    scope=$3
  else
    echo ""
    echo "oa_request.sh : Invalid argument specification."
    echo ""
    usage
  fi
fi
if [ -n "$4" ] 
then
  if [ "$4" = "roll_logs" ]
  then 
    roll_logs=roll_logs
  else
    usage
  fi
else
  roll_logs=""
fi


##
## Set Oracle's HOME directory
##
#ohome=`cat /etc/passwd | awk -F: '{
#  if ($1 == "oracle") {print $6}}'`
if [ -z "$APP" ]                                              
then                                                          
        echo "Environment variable APP is not set "           
        echo " APP is the Application name like HR,SSS etc"   
        exit 0                                                
else                                                          
        if [ $APP = "SSS" -o $APP = "sss" ]                                 
        then                                                  
                ohome=`cat /etc/passwd | awk -F: '{           
                if ($1 == "oracle") {print $6}}'`             
        fi                                                    
        if [ $APP = "HR" -o $APP = "hr" ]                                  
        then                                                  
                ohome=`cat /etc/passwd | awk -F: '{           
                if ($1 == "oracle50") {print $6}}'`           
        fi                                                    
fi                                                            
                                                              
                                                              
                                                              

   
if [ ! -f "$ohome/bin/requests.ctl" ]; then
  echo oa_request.sh : No Request System Control File found - exiting
  exit 1
fi

scope_ok=0
request_sid=`grep ^RequestDB: $ohome/bin/requests.ctl | cut -d: -f2`
if [ -z "$request_sid" ]; then
  echo "oa_request.sh : No Request Database defined in control file - exiting"
  exit 1
fi

apps_db_link=`grep ^link:${sid}: $ohome/bin/requests.ctl | cut -d: -f3`
if [ -z "$apps_db_link" ]; then
  echo oa_request.sh : No database link in Control file for $sid - exiting
  exit 1
fi

for product in `grep ^products: $ohome/bin/requests.ctl | cut -f2 -d: \
  | tr , ' ' `; do
  if [ "$product" = "$scope" ]; then
    scope_ok=1
    break
  fi
done
if [ $scope_ok -eq 0 ]; then
  echo oa_request.sh : cannot submit $scope on this tier
  usage
fi  

##
## Verify the instance environment script exists
##
if [ ! -f $ohome/bin/$request_sid ]
then
  echo "Error====>No environment script found for Request Database"
  echo "          Script is terminating!"
  exit 0
else
  ##
  ## Set the instance environment
  ##
  . $ohome/bin/$request_sid
fi
# running websid points to a sqlplus which works ok in a setuid script (!)
if [ -f "$ohome/bin/web$request_sid" ]
then
  . $ohome/bin/web$request_sid
fi

scripts_path=$DBA_HOME/admin
script_name=oa_request.sh
short_name=oa_request
script_pid=$$
hostname=`hostname`

echo "************************************************************************"
echo "====>Script $script_name starting on" `date`
echo "************************************************************************"
echo
error_switch=0
ts=`date +%m%d`_`date +%H%M%S`
if [ -f "$DBA_HOME/admin/oamgr_db.sh" ]; then
  # assume on DB server
  oa_script=oamgr_db.sh
  if [ -d "$SID_HOME/audit" ]; then
    audit_path=$SID_HOME/audit
    logfile=$SID_HOME/audit/${short_name}_${ts}_$$.log
    tmpfile=$SID_HOME/audit/${short_name}_${ts}_$$.tmp
  else
    audit_path=$DBA_HOME/audit
    logfile=$DBA_HOME/audit/${short_name}_${sid}_${ts}_$$.log
    tmpfile=$DBA_HOME/audit/${short_name}_${sid}_${ts}_$$.tmp
  fi
else
  if [ -f "$DBA_HOME/admin/oamgr_app.sh" ]; then
    # on app server
    oa_script=oamgr_app.sh
    audit_path=$DBA_HOME/audit
    logfile=$DBA_HOME/audit/${short_name}_${sid}_${ts}_$$.log
    tmpfile=$DBA_HOME/audit/${short_name}_${sid}_${ts}_$$.tmp
   else
     echo "No Oracle Apps Manager script found. Request cannot be processed"
     oa_script=""
   fi
fi

## ------------------------------------------------------------------------ ##
##         Verify if the requested Oracle instance is available             ##
## ------------------------------------------------------------------------ ##
dba_pwd=`$ohome/bin/tellme gedba`
if [ -z "$dba_pwd" ]; then
  echo "Error====>Unable to determine Request Database password"
  echo "          Script is terminating!"
  exit 0
fi

if [ -f $tmpfile ]; then
  rm -f $tmpfile
  if [ -f $tmpfile ]; then
    echo "Unable to remove temporary file -exiting"
    exit 1
  fi
fi

sqlplus -s <<EOF >/dev/null 2>&1
gedba/$dba_pwd
whenever sqlerror exit failure
set heading off
spool $tmpfile
select * from dual@${apps_db_link};
spool off
exit;
EOF
db_status=$?

if [ "`grep -c ^ORA- $tmpfile 2>/dev/null `" -ne 0 ]; then
  echo "Possible Database link error"
  grep  ^ORA- $tmpfile 
  echo "Terminating now"
  exit 0
fi
if [ $db_status -ne 0 ]
then
    echo "Oracle instance $ORACLE_SID not available"
    echo "Terminating now"
    exit 0
fi
if [ -f $tmpfile ]; then
  rm -f $tmpfile
fi

## ------------------------------------------------------------------------ ##
##         Process the requested command                                    ##
## ------------------------------------------------------------------------ ##
##
## Set Patrol's HOME directory
##
PATROL_HOME=/usr/gemaint/patrol


echo "Please enter your Apps User ID: \c"
read apps_uid
trap "stty echo;exit 1" INT
stty -echo
echo "Password: \c"
read apps_pwd
stty echo

cd ${audit_path}

sqlplus -s <<EOF
gedba/$dba_pwd

set verify off
set feedback off
set serveroutput on
whenever sqlerror exit failure
whenever oserror exit failure

define pid=$script_pid
define run_params='$action $scope $roll_logs'

declare
x varchar2(80);
n number;
req_id number;
uid fnd_user.user_id@${apps_db_link}%type;
email_addr fnd_user.email_address@${apps_db_link}%type;
db_name varchar2(9);
begin
x:=ge_sec.validatePassword@${apps_db_link}('$apps_uid','$apps_pwd',n);
-- dbms_output.put_line('x='||x||' n='||n);
if (x < 0) then
  raise LOGIN_DENIED;
end if;
begin
  select r.userid, u.email_address
  into uid, email_addr
  from ge_request_users r, fnd_user@${apps_db_link} u, v\$database@${apps_db_link} d
  where r.userid=u.user_id
  and   upper(d.name)=upper(r.sid)
  and   sysdate between r.start_date and nvl(r.end_date,sysdate+1)
  and   u.user_name=upper('$apps_uid');
exception
  when no_data_found then
    dbms_output.put_line('You are not authorized to run this command at this time.');
    raise LOGIN_DENIED;
end;
if '&pid' is null  then
  dbms_output.put_line('No Process ID specified');
  raise VALUE_ERROR;
end if;
if '&run_params' is null  then
  dbms_output.put_line('No requested process specified');
  raise VALUE_ERROR;
end if;

select GE_REQUEST_SEQ.NEXTVAL
into req_id
from dual;

select d.name
into db_name
from v\$database@${apps_db_link} d;

insert into ge_request_requests 
  (userid, ospid, email_address, request_id, request_date, sid, host,
    request_params, status, audit_file)
   values
  (uid, &pid, email_addr, req_id, sysdate, db_name, '$hostname',
   '&run_params', 'REQUESTED', '$logfile');
commit;
dbms_output.put_line('Request ID '||req_id||' submitted.');
dbms_output.put_line('Output will be saved in $logfile');
if email_addr is null then
  dbms_output.put_line('Output will not be emailed - Apps User $apps_uid has no Email Address');
else
  dbms_output.put_line('Output will be emailed to '||email_addr);
end if;
end;
/
exit
EOF

status=$?
exit $status  

  
