#!/bin/ksh

#######Modified by  deepa.goruganthu########
######Purpose : Montly job lists old files on server ####
if [ `uname` = "Linux" ]
then
DATE=`date +%m-%d-%y-%H:%M`
b=`echo "/"`
user=`id |cut -f2 -d=|cut -f2 -d"("|cut -f1 -d")"`
for i in `ls -l $b |awk '{print $9}'|grep "00"`
do
  for s in `ls -l $b$i |awk '{print$9}'|grep "u[0-9][0-9]"`
  do
  mount=`echo "$b$i/\$s/\$user"`
  if [ ! -d $mount ]
  then
    echo "test">>/dev/null
  else
    cd $mount
    for j in `ls -l $mount |awk '{print $9}'|grep -v product`
    do
      c=`echo "$mount/\$j"`
      find $c -type f -mtime +60 -exec ls -l {} \;>>/tmp/oldfile.lst
    done
  fi
  done
done
fi
cat /tmp/oratask.lst |grep -v temp|grep -v TEMP > /tmp/oratask.lst
size=`ls -l /tmp/oldfile.lst|awk '{print $5}'`
if [ $size -ne 0 ]
then
mailx -s "Old File Report - `hostname`" deepa.goruganthu@ge.com < /tmp/oldfile.lst
mv /tmp/oldfile.lst /tmp/oldfile.lst.bk
echo "Old file names exist in oldfile.lst.bak file"
fi
