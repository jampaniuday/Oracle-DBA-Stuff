#!/bin/ksh
# +============================================================================+
# | FILENAME
# |   oactxctl.sh
# |
# | DESCRIPTION
# |   Start / Stop Context Server for requested Oracle instance
# |
# | USAGE
# |   oactxctl.sh {start|stop} $ORACLE_SID
# |
# +============================================================================+
exit_code=0

if [ $# -lt 2 ]
then
   echo ""
   echo "oactxctl.sh: too few arguments specified."
   echo ""
   echo "Usage is oactxctl.sh {start|stop|status} $ORACLE_SID"
   echo ""
   exit 1
fi

control_code="$1"

if test "$control_code" != "start" -a "$control_code" != "stop" -a "$control_code" != "status"
then
   echo ""
   echo "oactxctl.sh: You must specify either 'start' or 'stop' or 'status'"
   echo ""
   exit 1
fi

DB_NAME="$2"

#
# setup the environment for Oracle and Applications
#
#ohome=`cat /etc/passwd | awk -F: '{
#  if ($1 == "oracle") {print $6}}'`
if [ -z "$APP" ]                                              
then                                                          
        echo "Environment variable APP is not set "           
        echo " APP is the Application name like HR,SSS etc"   
        exit 0                                                
else                                                          
        if [ $APP = "SSS" -o $APP = "sss" ]                                 
        then                                                  
                ohome=`cat /etc/passwd | awk -F: '{           
                if ($1 == "oracle") {print $6}}'`             
        fi                                                    
        if [ $APP = "HR" -o $APP = "hr" ]                                  
        then                                                  
                ohome=`cat /etc/passwd | awk -F: '{           
                if ($1 == "oracle50") {print $6}}'`           
        fi                                                    
fi                                                            
                                                              
                                                              
                                                              
if [ ! -f $ohome/bin/$2 ]
then
   echo "Oracle environment file for database $DB_NAME is not found"
   exit 1
else
   . $ohome/bin/$2
fi

if test "$control_code" = "start"
then
  ctxsrv -user ctxsys/ctxsys -personality DQMRL >$SID_HOME/audit/$2_ctx.out &
  sleep 60
  cat $SID_HOME/audit/$2_ctx.out
  rm -f $SID_HOME/audit/$2_ctx.out
elif test "$control_code" = "stop"
then
  sqlplus ctxsys/ctxsys <<EOF>$SID_HOME/audit/$2_ctx.out
  begin
  ctx_adm.shutdown('ALL', 1);
  end;
/
EOF
  sleep 60
  cat $SID_HOME/audit/$2_ctx.out
  rm -f $SID_HOME/audit/$2_ctx.out
else
  sqlplus -s ctxsys/ctxsys <<EOF>$SID_HOME/audit/$2_ctx.out
          set feed off
          col "DB User" for a10
          col "Server Name" for a15
          col "Process" Heading 'Unix|Process'
          select username   "DB User", 
                 process    "Process",
                 osuser     "OS User",
                 ser_name   "Server Name",
                 ser_status "Status"
            from v\$session, ctx_servers
           where audsid = ser_audsid ;
EOF
  if [ `ls -l $SID_HOME/audit/$2_ctx.out | awk '{ print $5 }'` -eq 0 ]
  then
     echo "Context server not running for $2 instance"
  else
     echo "====>Status of the Context Server for $2"
     cat $SID_HOME/audit/$2_ctx.out
     rm $SID_HOME/audit/$2_ctx.out
  fi
fi

echo ""
echo "oactxctl.sh: exiting with status $exit_code"
echo ""

exit $exit_code
