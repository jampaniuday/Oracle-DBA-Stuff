#!/bin/ksh
########################################################################
## ent_copy.sh
##
##   PURPOSE: To execute an ADSM tape backup of critical Enterprise files 
##        needed for recovery
##   USAGE:   ent_copy.sh>$DBA_HOME/audit/ent_copy.auditMMDD[_HHMM] 2>&1
##   NOTIFICATION: Email notification for successful and failed executions 
##        will always be directed to the responsible DBA for this instance  
##        and to SSS production control.
##        For abends, SSS production control will also be paged.
##
########################################################################
notify()
{
error_switch=$1
if [ $error_switch -ne 0 ]
then
  mailx -s "$ohost ent_copy ABEND" $sssmail@corporate.ge.com<${audit_file}
#  mailx -s "$ohost ent_copy ABEND" $oserver_rep@corporate.ge.com<${audit_file}
${mnt}/dba01/oracle/admin/notify.sh -s "ent_copy ABEND" -f ${audit_file} -w server
  if [ $error_switch -eq 2 -a "$ohost" = "corpp032" ]
  then
    #echo "`hostname`-Enterprise Midnight Scan\nbackup not produced" | mailx 5184842282@myairmail.com
    ${mnt}/dba01/oracle/admin/notify.sh -p "`hostname`-Enterprise Midnight Scan backup not produced" -w server
  fi
else
  #mailx -s "$ohost ent_copy" $oserver_rep@corporate.ge.com<${audit_file}
  ${mnt}/dba01/oracle/admin/notify.sh -s "ent_copy" -f ${audit_file} -w sid
fi
}

check_adsm() {
  save_rc=$1
  if [ -z "$dsm_log" ]; then
    echo "Internal errror: ADSM temporary log file not defined" >> $audit_file
    return 1
  fi
  if [ -s "$dsm_log" ]; then
    cat $dsm_log >> $audit_file
    #failures=`awk '/^Total number of objects failed:/ {failures += $6} END{print failures}' $dsm_log`
    # ignore Warnings (ANSxxxxW) and invalid mount point (ANS1492S)
    err_count=`grep '^ANS' $dsm_log | egrep -cv 'ANS([0-9]*W)|(1492S) '`
    if [ "$err_count" -gt 0 ]; then
      return $save_rc
    else
      return 0
    fi
  else
    # empty log file
    echo "ADSM temporary log file is empty." >> $audit_file
    return 1
  fi
}

PATH=/usr/xpg4/bin:$PATH:/usr/ucb; export PATH

##########################################################################
# Determine who to notify with script results
##########################################################################
charset=us-ascii; export charset
ohost=`hostname`

#mnt=`hostname|cut -c5-8`
this_dir=`dirname $0`
if [ "`echo $this_dir | cut -c1`" != "/" ]; then
  PWD=`pwd`
  this_dir=`dirname $PWD`
fi
mnt=/`echo $this_dir | cut -d/ -f2`
export mnt

if [ -f $HOME/bin/notify.ctl ]
then
  oserver_rep=`cat $HOME/bin/notify.ctl | awk -F: -v host="$ohost" '
    BEGIN {firstsw = 1}
    {if (firstsw == 1 && $1 == host && $2 == "all" && NF > 2) {
       print $3; firstsw = 0}}'`
else
  oserver_rep=linda.slyer
fi
sssmail=SSSProdAlrt
audit_file=/$mnt/dba01/oracle/audit/ent_copy.audit`date +\%m\%d`
>${audit_file}
export ohome sssmail oserver_rep audit_file

mgmt_class=cis35day

echo "**********************************************************************************">>$audit_file
echo "====>Script ent_copy.sh starting on" `date`>>$audit_file
echo "**********************************************************************************">>$audit_file

# Set the enterprise environment
ENT_HOME=`grep entsys /etc/passwd | cut -d: -f6`
if [ ! -f $ENT_HOME/bin/setenv ]
then
  echo>>$audit_file
  echo "Error====>No enterprise environment script found ">>$audit_file
  echo "          Script is terminating!">>$audit_file
  notify 1
  exit
fi
. $ENT_HOME/bin/setenv
if [ -z "$ENTSYS_LOG" ]
then
  echo>>$audit_file
  echo 'Error====>Environment variable $ENTSYS_LOG is not defined'>>$audit_file
  echo "          Script is terminating!">>$audit_file
  notify 1
  exit
fi
sleep_ctr=0
while [ ! -f $ENTSYS_LOG/lastcopy -o ! -f $ENTSYS_LOG/TNETBK.log -o \
     ! -f $ENTSYS_LOG/TNETBK.tar.Z ]
do
  if [ "$sleep_ctr" -lt 10 ]; then
    sleep 60
    sleep_ctr=`expr $sleep_ctr + 1`
  else
    echo>>$audit_file
    echo 'Error====>Required control file $ENTSYS_LOG/lastcopy has been deleted'>>$audit_file
    echo '          Touch this file, manually verify timestamps of TNETBK* files'>>$audit_file
    echo '          and, if confirmed to be from a successful run of midnight scan today,'>>$audit_file
    echo '          touch these TNETBK* files to have a timestamp later than that of lastcopy'>>$audit_file
    echo '          and rerun this script'>>$audit_file
    echo "          Script is terminating!">>$audit_file
    notify 1
    exit
  fi
done

sleep_ctr=0
file_found=0
if [ $ENTSYS_LOG/TNETBK.log -nt $ENTSYS_LOG/lastcopy -a \
     $ENTSYS_LOG/TNETBK.tar.Z -nt $ENTSYS_LOG/lastcopy ]
then
  file_found=1
fi
while [ $sleep_ctr -lt 12 -a $file_found -eq 0 ]
do
  if [ $sleep_ctr -eq 0 ]
  then
    echo>>$audit_file
    echo Sleeping 5 minutes...... [waiting for midnight scan to run]>>$audit_file
  else
    echo Sleeping 5 more minutes......>>$audit_file
  fi
  sleep 300
  if [ $ENTSYS_LOG/TNETBK.log -nt $ENTSYS_LOG/lastcopy -a \
       $ENTSYS_LOG/TNETBK.tar.Z -nt $ENTSYS_LOG/lastcopy ]
  then
    file_found=1
  else
    sleep_ctr=`expr $sleep_ctr + 1`
  fi
done
if [ $file_found -eq 0 ]
then
  echo>>$audit_file
  echo 'Error====>Midnight scan did not run -'>>$audit_file
  echo '          TNETBK.log and tar.Z have timestamps that pre-date the last copy run'>>$audit_file
  echo "          Script is terminating!">>$audit_file
  notify 2
  exit
fi
echo>>$audit_file
echo "====>Timestamps for files found">>$audit_file
echo>>$audit_file
ls -l $ENTSYS_LOG/lastcopy>>$audit_file
ls -l $ENTSYS_LOG/TNETBK*>>$audit_file
dsm_log=/$mnt/dba01/oracle/audit/adsm.log.$$
save_command="dsmc archive -archmc=$mgmt_class -subdir=y -quiet"  
save_redir=">$dsm_log 2>&1" 
echo>>$audit_file
echo "====>Using management class " $mgmt_class>>$audit_file
## ------------------------------------------------------------------------# 
##     BACKUP THE ENTSYS LOG DIRECTORY                                     # 
## ------------------------------------------------------------------------# 
slash_sw=`echo $ENTSYS_LOG | awk '{
  if (substr($1,length($1),length($1)) == "/")
  {print "0"} else {print "1"}}'`
if [ $slash_sw -eq 1 ]
then
  ENTSYS_LOG=$ENTSYS_LOG"/"
fi
echo>>$audit_file
echo "====>Offload the entsys log directory to tape on" `date`>>$audit_file
echo>>$audit_file
echo $save_command $ENTSYS_LOG>>$audit_file
echo>>$audit_file
#$save_command $ENTSYS_LOG >>$audit_file
eval $save_command $ENTSYS_LOG $save_redir
save_status=$?
check_adsm $save_status 
if [ $? -ne 0 ]
then
  echo>>$audit_file
  echo "##########################################################">>$audit_file
  echo "## ERROR ====> Offload of $ENTSYS_LOG abended">>$audit_file
  echo "##       ====> Script is terminating">>$audit_file
  echo "##########################################################">>$audit_file
  notify 1
  exit
else
  echo>>$audit_file
  echo "====>$ENTSYS_LOG saved">>$audit_file
  touch ${ENTSYS_LOG}lastcopy
fi

echo>>$audit_file
echo "**********************************************************************************">>$audit_file
echo "====>Script ent_copy.sh ending on" `date`>>$audit_file
echo "**********************************************************************************">>$audit_file
notify 0
exit
