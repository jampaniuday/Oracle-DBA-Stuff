#!/usr/bin/ksh 
#
# Name : logtrim.sh
# Author : Ranjit Mhatre 
# Script Date : 17-Aug-2000
# Purpose : Weekly copy the alert.log and listener.log to the most recent file
#           and retain this file till the  specified weeks.
#Changes:   Added lstnmgr.sh logic - Shirdivas on 13-Dec-2004
#
echo `cat <<EOF   
\t USAGE: logtrim.sh [logs_to_retain] \n 
\t Purpose : Weekly copy the alert.log and listener.log  \n
\t to the most recent file and retain this file till the \n
\t specified weeks. \n

# \n
#       W A R N I N G  !!!!!!!! \n 
# \n
\n
You are about to run the logtrim program on all the Databases \n 
\n
\0007 \0007 \0007 \0007 \0007 \0007 \0007 \0007 \0007 \0007

	Press "Cntrl + c " Now  to STOP ........\n
\n

EOF`
sleep 30

if [ $# -ge 1 ]; then
  r_period=$1
else
  r_period=5  # Retention Period 
fi

al_file=true # Alert file trim true or false
ln_file=true # Listener File Trim true or false
hostname=`hostname`

add_file=false # Wants to run trim for other files true or false
# if add_file is true then  add the filename in ad_files with full path separated by space

ad_files=""

if [ "${add_file}" = "true" -o "${add_file}" = "True" -o "${add_file}" = "TRUE" ] ; then
    if [ -z "$ad_file" ] ; then
      echo "ERROR :add_file parameter is set to true :Enter the value of ad_file parameter in the script"
      exit 1
    fi
fi
oncall=`grep "all:all" $HOME/bin/notify.ctl | cut -d: -f3`
#oncall=ranjit.mhatre
pgoncall=`grep "#$oncall" $HOME/bin/notify.ctl | cut -d: -f2`
#
# Functions 
#
SendMsg()
{
oncall=David.Bates
#echo $* | mailx -s "Script error while trimming the file messeage from logtrim.sh " $oncall@corporate.ge.com
if [ -n "$dbname" ]; then
  ORACLE_SID=$dbname
  export ORACLE_SID
fi
$DBA_HOME/admin/notify.sh -s "Script error while trimming the file messeage from logtrim.sh" -b "Script error while trimming the file messeage from logtrim.sh" -w sid,server
}

SendMsgDb()
{
  dbname=$1
echo $dbname
  if [ -z "$dbname" ]; then
    SendMsg $*
  fi
  shift
  notify_list=`egrep "^$hostname:((all)|($dbname))" $HOME/bin/notify.ctl |
    cut -d: -f3 | sort -u`
  for mailname in $notify_list ; do
    maillist="$maillist ${mailname}@corporate.ge.com"
  done
maillist=David.Bates@corporate.ge.com
#  echo $* | mailx -s "${hostname} logtrim ${dbname} failure" $maillist
if [ -n "$dbname" ]; then
  ORACLE_SID=$dbname
  export ORACLE_SID
  echo $ORACLE_SID
  sleep 10
fi
$DBA_HOME/admin/notify.sh -s "logtrim failure" -b "logtrim ${dbname} failure" -w sid,server
}

SendPg()
{
#echo $* | mailx  $pgoncall
$DBA_HOME/admin/notify.sh -p "$*" -w server -L gold,silver
}

# Trimfile <filename with full path > 
Trimfile()
{
tfile=`basename $1`
tpath=`dirname $1`
bfile=`echo $tfile|awk -F "." '{print $1}'`
efile=`echo $tfile|awk -F "." '{print $2}'`
i=`echo $r_period`
if [ -f $1 ]
then
     while [ ${i} -ne 0 ]
     do
     if [ ${i} -eq ${r_period} ]
     then
     	rm ${tpath}/${bfile}_${i}.${efile} >/dev/null 2>&1
     	echo "Remove the oldest log file ${tpath}/${bfile}_${i}.${efile}"
    	i=`expr $i - 1` 
	else
     	n=`expr $i + 1`
     	 mv ${tpath}/${bfile}_${i}.${efile} ${tpath}/${bfile}_${n}.${efile} >/dev/null 2>&1
     	echo " Move the file ${tpath}/${bfile}_${i}.${efile} to ${tpath}/${bfile}_${n}.${efile}"
	if [ ${i} -eq 1 ]
     	then
     	cp ${tpath}/${bfile}.${efile} ${tpath}/${bfile}_${i}.${efile} >/dev/null 2>&1 
		if [ $? -ne 0 ]
		then
		delfile=1
		else
		delfile=0
		echo "Done Trimming the file ${tpath}/${bfile}.${efile} on `date`"
		fi
	fi
    	i=`expr $i - 1` 
     fi 
    done
	if [ $delfile -eq 0 ]
	then
		cat /dev/null >${tpath}/${bfile}.${efile}
	else
		echo "Log Trim Failed for ${bfile}.${efile} Sending email to Oncall DBA"
		SendMsg "File ${tpath}/${bfile}.${efile} could not trim as error while moving the other files "
	fi
fi
}

echo start
#
# Trimming Alert.log file
#
user=`id|cut -d"(" -f2|cut -d")" -f1`

OS_TYPE=`uname`
if [ "$OS_TYPE" = "SunOS" ] || [ "$OS_TYPE" = "OSF1" ]; then
  MAIL_EXE=mailx
else
  if [ "$OS_TYPE" = "Linux" ] ; then
     MAIL_EXE=mail
  elif [ "$OS_TYPE" = "HP-UX" ] ; then
     MAIL_EXE=mailx
   else
     echo "Script Not Ported for this OS --- using mailx"
     MAIL_EXE=mailx
   fi
fi

#  Get the location and file name from various database 
# get the location of oratab
if [ "`uname -a | cut -c1-3`" = "Sun" ]
then
	 oratab=/var/opt/oracle/oratab
else
  	oratab=/etc/oratab
fi

#alldb=`cat $oratab|grep -v \#|grep -v \*|awk -F: '{print $1}'|xargs echo`
#
alldb=""
for nxtline in ` cat $oratab |awk -F: '{print $1":"$2}' | grep -v \#|grep -v \*| grep -v '^[ ]*$'`; do
    dbname=`echo $nxtline | cut -d: -f1`
    dbhome=`echo $nxtline | cut -d: -f2`
    start_on_boot=`echo $nxtline | cut -d: -f3`
    home_owner=`ls -ld $dbhome | awk '{print $3}'`
#    if [ "$user" = "$home_owner" -a "$start_on_boot" = "Y" ]; then
#  Added this to run logtrim for Cluster database where dbstart is N
    if [ "$user" = "$home_owner" ]; then
      alldb="$alldb $dbname"
    fi
done

if [ "${al_file}" = "true" -o "${al_file}" = "True" -o "${al_file}" = "TRUE" ] ; then
    for dbname in  $alldb
      do
        if ( . $HOME/bin/$dbname ) ; then
          . $HOME/bin/$dbname
        else
          echo "Unable to trim alert logs for $dbname -- bad environment file"
          SendMsgDb $dbname "Unable to trim alert logs for $dbname -- bad environment file"
          continue
        fi
sqlplus -s '/as sysdba'<<EOF >$SID_HOME/audit/logtrim_ora.err
           set pagesize 0 feedback off verify off echo off termout off heading off
           spool $SID_HOME/audit/background_dump.list
           select ltrim(rtrim(value))||'/alert_'||instance_name||'.log'  from v\$parameter,v\$instance where name like 'background_dump_dest';
           spool off
EOF
   ora_error=`cat $SID_HOME/audit/logtrim_ora.err  |grep ORA- |wc -l`
        if [ $ora_error -ge 1 ]; then
           echo  "ERROR: not able to connect to $dbname"
           SendMsgDb $dbname "ERROR: not able to connect to $dbname "
        else
           export af=`cat $SID_HOME/audit/background_dump.list`
	if [ -f ${af} ]
	then 
	Trimfile $af	
	else
	echo "ERROR: $af file not found "
	SendMsgDb $dbname "ERROR: $af file not found "
	fi
        fi
	done	
else
echo Alert file is not set for trim  
fi

# Done triming Alertlog file 
#
# Triming listener log file 
#
if [ "${ln_file}" = "true" -o "${ln_file}" = "True" -o "${ln_file}" = "TRUE" ]
then
	for dbname in  $alldb
	do
        if ( . $HOME/bin/$dbname )
        then
          . $HOME/bin/$dbname
        else
          SendMsgDb $dbname "Unable to trim listener logs for $dbname -- bad environment file"
          echo "Unable to trim listener logs for $dbname -- bad environment file"
          continue
        fi

        lsnr_out=$SID_HOME/audit/lsnrinfo.tmp.$$
        if [ -x $DBA_HOME/admin/lstnmgr.sh -a -n "$TCL_HOME" ] ; then
          $DBA_HOME/admin/lstnmgr.sh $dbname lstn$dbname status > $lsnr_out 2>&1
        else
          $ORACLE_HOME/bin/lsnrctl status lstn${dbname} >$lsnr_out 2>&1
        fi
        lf=`cat $lsnr_out |grep 'Listener Log File' | tr -d '\r' |awk '{print $4}'`

	if [ ! "${lf}" = "" ]
	then
	 	Trimfile $lf
	else
		echo "${dbname}: Listener not UP"
		echo ""
	        cat $lsnr_out
		echo ""
		SendMsgDb $dbname "Listener not UP"
	fi
	rm -f $lsnr_out
	done
fi

# Done trimming Listener log file 
#
# Doing trimming for addition files 

if [ "${add_file}" = "true" -o "${add_file}" = "True" -o "${add_file}" = "TRUE" ]
then
for file in $ad_files
do
	if [ -f $file ]
	then
	Trimfile $file
	fi
done
fi
echo End
# End of the script logtrim.sh
