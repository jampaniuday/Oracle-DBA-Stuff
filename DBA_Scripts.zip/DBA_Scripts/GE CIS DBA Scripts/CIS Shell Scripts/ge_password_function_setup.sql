PROMPT "CREATING GE PASSWORD VERIFY FUNCTION "
Rem $Header: utlpwdmg.sql 30-may-96.17:02:41 asurpur Exp $
Rem
Rem utlpwdmg.sql
Rem
Rem  Copyright (c) Oracle Corporation 1996, 1997. All Rights Reserved.
Rem
Rem    NAME
Rem      utlpwdmg.sql - script for Default Password Resource Limits
Rem
Rem    DESCRIPTION
Rem      This is a script for enabling the password management features
Rem      by setting the default password resource limits.
Rem
Rem    NOTES
Rem      This file contains a function for minimum checking of password
Rem      complexity. This is more of a sample function that the customer
Rem      can use to develop the function for actual complexity checks that the 
Rem      customer wants to make on the new password.
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    asurpur     04/17/97 - Fix for bug479763
Rem    asurpur     12/12/96 - Changing the name of password_verify_function
Rem    asurpur     05/30/96 - New script for default password management
Rem    asurpur     05/30/96 - Created
Rem
REM   October 23, 2006
REM   This script has some additions made to it by Paul Krempa (GE)
REM   The additions conform to  the recomendations in  
REM   http://data.supportcentral.ge.com/upload/15039/doc_1137171.doc
REM   ( AS of October 23, 2006) with the exception of case management 
REM   This checks 
REM   Must be a minimum of 8 characters long.
REM   Must be a maximum of 15 characters long.
REM   Must contain a minimum of 2 numbers and all numbers must be embedded. 
REM   This means that a number cannot be the first or last character of the password.
REM   Must NOT contain the username.
REM   May contain the following special characters  -, _, . 

-- This script sets the default password resource parameters
-- This script needs to be run to enable the password features.
-- However the default resource parameters can be changed based 
-- on the need.
-- A default password complexity function is also provided.
-- This function makes the minimum complexity checks like
-- the minimum length of the password, password not same as the
-- username, etc. The user may enhance this function according to
-- the need.
-- This function must be created in SYS schema.
-- connect sys/<password> as sysdba before running the script

CREATE OR REPLACE FUNCTION F_GE_PASSWORD_VERIFY
(username varchar2,
  password varchar2,
  old_password varchar2)
  RETURN boolean IS 
   n boolean;
   m integer;
   differ integer;
   isdigit_counter number; -- 
   isdigit boolean;
   isdigit_bookend boolean;
   ischar  boolean;
   ispunct boolean;
   lower_chararray varchar2(26);
   digitarray varchar2(20);
   punctarray varchar2(25);
   chararray varchar2(52);
   reserved_punctarray varchar2(25);
   reserved_punct boolean;
   islchar boolean;
   iscontained number;

BEGIN 
   digitarray:= '0123456789';
   chararray:= 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
   lower_chararray:= 'abcdefghijklmnopqrstuvwxyz';
   punctarray:='-_.';
   reserved_punctarray:=':?/+*!#%@$=&"(),<>`; ';

   -- Check if the password is same as the username
   IF password = username THEN
     raise_application_error(-20001, 'Password same as user');
   END IF;

   -- Check for the minimum length of the password
   IF length(password) < 8 THEN
      raise_application_error(-20002, 'Password length must be between 8 and 15 characters ( <8)');
   END IF;

   -- Check for the maximum length of the password
   IF length(password) > 15 THEN
      raise_application_error(-20002, 'Password length must be between 8 and 15 characters ( >15)');
   END IF;

   -- Check if the password contains reserved punctuation characters
   -- that may cause problem with NON-Oracle external third party products 
   reserved_punct:=FALSE;
   m := length(password);
   FOR i IN 1..length(punctarray) LOOP 
      FOR j IN 1..m LOOP 
         IF substr(password,j,1) = substr(reserved_punctarray,i,1) THEN
            reserved_punct:=TRUE;
         END IF;
      END LOOP;
   END LOOP;
   IF reserved_punct = TRUE THEN
      raise_application_error(-20003, 'Password contains a reserved punctuation character "@$&"(),<>`; " ');
   END IF;

   -- Check if the password contains at least one letter, two digits and one
   -- punctuation mark.
   -- 1. Check for 2 digits
   isdigit:=FALSE;
   isdigit_counter:=0;
   m := length(password);
   FOR i IN 1..10 LOOP 
      FOR j IN 1..m LOOP 
         IF substr(password,j,1) = substr(digitarray,i,1) THEN
            isdigit_counter := isdigit_counter +1;
            IF isdigit_counter >=2
            THEN 
               isdigit:=TRUE;
 	       GOTO findchar;
            END IF;
         END IF;
      END LOOP;
   END LOOP;
   IF isdigit = FALSE THEN
      raise_application_error(-20004, 'Password should contain at least two digits, one character and one punctuation "-._"');
   END IF;
   -- 2. Check for the character
   <<findchar>>
   ischar:=FALSE;
   FOR i IN 1..length(chararray) LOOP 
      FOR j IN 1..m LOOP 
         IF substr(password,j,1) = substr(chararray,i,1) THEN
            ischar:=TRUE;
             GOTO findpunct;
         END IF;
      END LOOP;
   END LOOP;
   IF ischar = FALSE THEN
    raise_application_error(-20005, 'Password should contain at least two digits, one character and one punctuation "-_."');
   END IF;
   --
   -- 3. Check for the punctuation
   <<findpunct>>
   ispunct:=FALSE;
   FOR i IN 1..length(punctarray) LOOP 
      FOR j IN 1..m LOOP 
         IF substr(password,j,1) = substr(punctarray,i,1) THEN
            ispunct:=TRUE;
             GOTO endsearch;
         END IF;
      END LOOP;
   END LOOP;
   IF ispunct = FALSE THEN
      raise_application_error(-20006, 'Password should contain at least one digit, one character and one punctuation "!#%*+,-/:=?_"');
   END IF;

   <<endsearch>>
   -- Check if the password differs from the previous password by at least
   -- 2 characters
   IF old_password = '' THEN
      raise_application_error(-20007, 'Old password is null');
   END IF;
   -- Everything is fine; return TRUE ;   
   differ := length(old_password) - length(password);

   IF abs(differ) < 2 THEN
      IF length(password) < length(old_password) THEN
         m := length(password);
      ELSE
         m := length(old_password);
      END IF;
      differ := abs(differ);
      FOR i IN 1..m LOOP
          IF substr(password,i,1) != substr(old_password,i,1) THEN
             differ := differ + 1;
          END IF;
      END LOOP;
      IF differ < 2 THEN
          raise_application_error(-20008, 'Password should differ by at least 2 characters');
      END IF;
   END IF;

   -- 4. Check for the lowercase (Not needed as Oracle passwords are case insensitive)
/*  <<lowercharacter>>
   islchar:=FALSE;
   FOR i IN 1..length(lower_chararray) LOOP
      FOR j IN 1..m LOOP
         IF substr(password,j,1) = substr(lower_chararray,i,1) THEN
            islchar:=TRUE;
         END IF;
      END LOOP;
   END LOOP;
   IF islchar = FALSE THEN
      raise_application_error(-20009, 'Password should contain a lower case character');
   END IF;
*/

-- Check to make sure that first or last characters are not digits
   isdigit_bookend:=FALSE;
   m := length(password);

   ------Loop through the number 0-9 and check)
   FOR i IN 1..10 LOOP 
         IF ( substr(password,1,1) = substr(digitarray,i,1) )  or ( substr(password,m,1) = substr(digitarray,i,1) )
           THEN
            isdigit_bookend:=TRUE;
         END IF;
   END LOOP;
   IF isdigit_bookend = TRUE THEN
      raise_application_error(-20010, 'Number in Password can not be in first or last characters');
   END IF;
--
-- Check to see if password contains username.
   select instr(lower(password),lower(username)) into iscontained from dual;
   IF (iscontained >0 )
     THEN
       raise_application_error(-20011, 'Password contains username '||username);
   END IF;


   -- Everything is fine; return TRUE ;   
   RETURN(TRUE);
END;
/

PROMPT "END OF FUNCTION CREATE"


PROMPT "ALTERING PROFILES TO INCLUDE GE_PASSWORD FUNCTION"
Begin
for profile in ( select unique profile from dba_profiles)
loop
execute immediate 'alter profile '|| profile.profile ||' LIMIT PASSWORD_VERIFY_FUNCTION F_GE_PASSWORD_VERIFY';

end loop;
END;
/

PROMPT "DONE"

