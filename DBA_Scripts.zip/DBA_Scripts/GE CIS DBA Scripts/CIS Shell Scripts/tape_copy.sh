#!/bin/ksh 
########################################################################
## tape_copy.sh
##
##   PURPOSE: To execute an ADSM or NSR tape backup of the Oracle disk backup
##            directory, the Oracle archive log directory, and/or the Oracle
##            export directory. The tape archive system to use is determined
##            from the $TAPE environment variable set by the instance
##            environment script.
##   USAGE: This script is called by the utility.sh script when a scheduled
##     tape_copy.sh entry exists in control file, $SID_HOME/admin/utility.ctl.
##     The command line submitted by utility.sh is:
##          tape_copy.sh sid domain [AltBackupCtl] [AltMgmtClass]
##          >$SID_HOME/audit/tape_copy_${ORACLE_SID}.auditMMDD[_HHMM] 2>&1
##     The required utility.ctl record format is:
##          tape_copy:wwwwwddddddd:domain[:AltBackupCtl:AltMgmtClass]
##          where w(fiscal week)=0(skip),1(run); d(day)=0(skip),1(run),
##                domain=backup(to archive the Oracle backup and archive dirs),
##                       export(to archive the Oracle export dir), or
##                       arch  (to archive the Oracle archive dir), or
##                       all   (to archive all of the above)
##     A default backup.ctl file or an optional alternate backup control file
##       must exist under $SID_HOME/admin. Backup.ctl records must be
##       formatted as:
##          DEFAULT:BackupDatafilePath
##          TMP:TemporarySaveLastBackupPath
##          CLEANUP:{yes|no}
##          OracleDatafilePath:BackupDatafilePath
##     The default adsm management class is cis35day but can be overridden by
##       parameter input [AltMgmtClass].
##   SCRIPT PROCESS FLOW:
##     1) Verify script input parameters
##     2) Verify the state of the CASC backup area
##     3) If domain = backup or all:
##        Loop over backup.ctl and generate a save command for each 'to'
##        directory entry not included under a higher level entry 
##     4) If domain = backup or arch or all:
##        Query the oracle catalog for the name of the log archive directory
##        and save this directory to tape. Save a list of all logs successfully
##        archived in file log_to_tape.list under the log archive directory
##        (this file is used by purge.sh).
##     5) If domain = export or all:
##        Generate a save command for the directory denoted by variable
##        $EXPORT_HOME
##   RESTART: All restarts should be performed using the restart capabilities
##        of the utility.sh script. If you choose to restart the tape_copy.sh 
##        script itself, you will loose the email notification and audit trail
##        formatting provided by the utility.sh script.
##   NOTIFICATION: Email notification of abends will be directed to the oncall
##        Oracle DBA; email notification for successful and failed executions 
##        will always be directed to the responsible DBA for this instance.  
##        This script MUST be initiated by script utility.sh to activate this
##        notification process. $HOME/bin/notify.ctl must contain the proper 
##        notification names.
##
##   MODIFICATIONS:
##        Date        Name         Description
##        ----------  -----------  --------------------------------------------
##
##        2002-09-05  D DeClercq    Added logic for 9i db, svrmgrl is obsolete
##        2006-12-07  Raj Mareddi   Added logic for Notification from Autosys
##
########################################################################
#in_remote_SCCS_repository:gtsshr
## ------------------------------------------------------------------------ ##
##         Process inputs and set the instance and script environment       ##
## ------------------------------------------------------------------------ ##
##Notify logic for Autosys
notify() {
  parent_pid=`ps -o ppid -p $$ |tail -1`
  parent_program=`ps -o args -p ${parent_pid}|tail -1`
  echo $parent_program |grep utility.sh
  if [ "$?" != 0 ]
  then
    current_prog=`echo $0|sed -e 's/.*\///'`
    $DBA_HOME/admin/notify.sh -s "$current_prog ABEND" -b "$current_prog failure: Please look at audit file" -w sid
    $DBA_HOME/admin/notify.sh -p "$current_prog ABEND" -w sid
   fi
}
##########################################
#This Function Added By Ranjit Mhatre on 23-Aug-00
#
DBUP ()
{
dbn=$1
for PROCESS in pmon dbw lgwr smon
do
dbst="`ps -afe|egrep $1|egrep $PROCESS`"
if [ -z "$dbst" ]
then
dbup=1
else
dbup=0
fi
done
}

lock_compress() {
  set -o noclobber
  if [ -f $compress_lock ]; then
    # check process name
    compress_pid=`head -1 $compress_lock`
    compress_process=`ps -o comm -p $compress_pid | grep -v '^COMMAND'`
    expected_process=`tail -1 $compress_lock`
    if [ "$compress_process" != "$expected process" ] ; then
	echo "Log compress process $compress_pid is running a different command"
	echo "Expected: `tail -1 $compress_lock`"
        echo "Actual: $compress_process"
        echo "`date`: Removing file $compress_pid --- will run compress now."
        rm -f $compress_lock 
    fi
  fi
  echo $$ > $compress_lock
  if [ $? -ne 0 ]; then
    if [ ! -f $compress_lock ]; then
      set +o noclobber
      echo "Unable to create lock file $SID_HOME/audit/log_compress.lk"
      return_stat=2
    else
      # another process beat us to the punch
      return_stat=1
    fi
  else
    # wrote file successfully
    ps -o comm -p $$ | grep -v '^COMMAND' >> $compress_lock
    return_stat=0
  fi
  set +o noclobber
  return $return_stat
}

ok2save() {
  return_stat=0
  which_save=$1
  save_dir=$2
  if [ -z "$1" ]; then
    echo "$which_save is not set --- files cannot be backed up."
    return_stat=1
  else
    if [ "$save_dir" = "/" ]; then
      echo "$which_save is set to '/' which is not a legal value."
      echo "Backup of will be skipped."
      return_stat=1
    else
      if [ ! -d "$save_dir" ]; then
        echo "$which_save is set to $save_dir .  Directory not found."
        echo "Backup will be skipped."
        return_stat=1
      fi
    fi
  fi
  return $return_stat
}

check_adsm() {
 save_rc=$1
 if [ -z "$dsm_log" ]; then
   echo "Internal errror: ADSM temporary log file not defined"
   return 1
 fi
 if [ -s "$dsm_log" ]; then
   cat $dsm_log
   completed=`grep -c '^Elapsed processing time:' $dsm_log`
   err_count=`grep '^ANS' $dsm_log | egrep -v 'ANS([0-9]*W)|(1492S) '| grep -cv 'dsmprune.log'`
   if [ "$completed" -eq 0 ]; then
      if [ "$save_rc" -eq 0 ]; then
        return 137
      else
        return $save_rc
     fi
   elif [ "$err_count" -gt 0 ]; then
     return $save_rc
   else
     return 0
   fi
 else
   echo "ADSM temporary log file is empty."
   return 1
 fi
}


check_netbackup() {
 save_rc=$1
 if [ -z "$dsm_log" ]; then
   echo "Internal errror: NETBACKUP temporary log file not defined"
   return 1
 fi
 if [ -s "$dsm_log" ]; then
   cat $dsm_log
   completed=`grep -c 'INF - Client completed sending data for backup' $dsm_log`
   err_count=`grep -c 'ERR' $dsm_log`
   err_count1=`grep -c "network connection timed out" $dsm_log`
   if [ "$completed" -eq 0 ]; then
      if [ "$save_rc" -eq 0 ]; then
        return 137
      else
        return $save_rc
     fi
   elif [ "$err_count" -gt 0 -o "$err_count1" -gt 0 ]; then
     return $save_rc
   else
     return 0
   fi
 else
   echo "NETBACKUP temporary log file is empty."
   return 1
 fi
}

write_arch_list_netbackup() {
if [ -z "$arch_dir" ]; then
echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
echo "Archive Directory not defined"
echo "Unable to write log_to_tape.list"
echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
return 1
fi
if [ "$TAPE" = "netbackup" ]
then
   cd $arch_dir
   mv log_to_tape.list log_to_tape.tmp
   if [ "$OS_TYPE" = "Linux" ];then
      arch_dir=`echo $arch_dir|sed 's/arch01/arch0*/g'`
      echo $arch_dir
   fi
   /usr/openv/netbackup/bin/bplist -B -l -R -s $frdate "${arch_dir}/"  | tr -d '\000'|awk '{print$8}'|
   awk 'BEGIN{fname_pos=0; skipone=0}
   {
    fname=$0
        fname_indx=split(fname,a,"/");
        print a[fname_indx];
   }' |
      sort -u >log_to_tape.list
      log_stat=$?
   if [ $log_stat -ne 0 ]; then
      echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
      echo "Unable to write log_to_tape.list from DSM"
      echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
      mv log_to_tape.tmp log_to_tape.list
   else
      rm log_to_tape.tmp
      ls -l $PWD/log_to_tape.list
   fi
else
 cd $arch_dir
 ls -c1 > log_to_tape.list
 log_stat=0
fi
return $log_stat
}

write_arch_list_adsm() {
if [ -z "$arch_dir" ]; then
 echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
 echo "Archive Directory not defined"
 echo "Unable to write log_to_tape.list"
 echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
 return 1
fi
if [ "$TAPE" = "adsm" ]
then
 cd $arch_dir
 mv log_to_tape.list log_to_tape.tmp
 if [ "$OS_TYPE" = "Linux" ];then
    arch_dir=`echo $arch_dir|sed 's/arch01/arch0*/g'`
 echo $arch_dir
 fi
 dsmc query archive -filesonly -fromdate=$frdate "${arch_dir}/" |
  awk 'BEGIN{fname_pos=0; skipone=0}
        {if (fname_pos > 0 ) {
          if ( skipone == 1)
            skipone=0;
          else
            {fname=substr($0,fname_pos,length($0)-fname_pos);
             tmp=substr(fname,1,index(fname," ")-1);
             fname_indx=split(tmp,a,"/");
             print a[fname_indx];
            }
          }
        else {
          fname_pos=index($0,"File - Expires on - Description");
          skipone=1; }}' |
   sort -u >log_to_tape.list
 log_stat=$?
 if [ $log_stat -ne 0 ]; then
   echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
   echo "Unable to write log_to_tape.list from DSM"
   echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
   mv log_to_tape.tmp log_to_tape.list
 else
   rm log_to_tape.tmp
   ls -l $PWD/log_to_tape.list
 fi
else
 cd $arch_dir
 ls -c1 > log_to_tape.list
 log_stat=0
fi
return $log_stat
}

    
#End Functions

UNIX95=1
export UNIX95
OS_TYPE=`uname`
export OS_TYPE

# Verify sid input
if [ -z "$1" ]
then
  echo "Error===>Required parameter is missing"
  echo "         Usage is tape_copy.sh sid domain [AltBackupCtl] [AltMgmtClass]"
  echo "         Script is terminating!"
  notify ; exit 1
else
  ORACLE_SID=$1
  export ORACLE_SID
  # Set the instance environment
  if [ ! -f $HOME/bin/$1 ]
  then
     echo "Error====>No environment script found for instance \"$1\""
     echo "          Script is terminating!"
     notify ; exit 1
  fi
  . $HOME/bin/$1
fi
# Verify domain input
if [ -z "$2" ]
then
  echo "Error===>Required parameter is missing"
  echo "         Usage is tape_copy.sh sid domain [AltBackupCtl] [AltMgmtClass]"
  echo "         Script is terminating!"
  notify ; exit 1
else
  if [ "$2" = "backup" -o "$2" = "arch" -o "$2" = "export" -o "$2" = "all" ]
  then
    domain=$2
  else
    echo "Error===>Required domain parameter is invalid"
    echo "         Value must be backup|arch|export|all"
    echo "         Script is terminating!"
    notify ; exit 1
  fi
fi
# Set the backup.ctl file and the adsm management class to parameter input
# or to the default value if not supplied
backup_file=$SID_HOME/admin/backup.ctl
if [ "$TAPE" = "netbackup" ]
then
  mgmt_class=user_back_5week
  if [ ! -z "$3" ]
  then
     if [ "`echo $3| tr [:upper:] [:lower:] | cut -c1-10`" = "user_back_" ]
     then
        mgmt_class=$3
        if [ ! -z "$4" ]
        then
           backup_file=$SID_HOME/admin/$4
        fi
     else
        backup_file=$SID_HOME/admin/$3
        if [ ! -z "$4" ]
        then
           mgmt_class=$4
        fi
     fi
  fi
else
   mgmt_class=cis35day
   if [ ! -z "$3" ]
   then
      if [ "`echo $3|cut -c1-3`" = "cis" ]
      then
         mgmt_class=$3
         if [ ! -z "$4" ]
         then
            backup_file=$SID_HOME/admin/$4
         fi
      else
         backup_file=$SID_HOME/admin/$3
         if [ ! -z "$4" ]
         then
            mgmt_class=$4
         fi
      fi
   fi
fi
if [ $domain = "backup" -o $domain = "all" ]
then
  if [ ! -f $backup_file ]
  then
    echo "Error====>Backup control file does not exist"
    echo "          Script is terminating!"
    notify ; exit 1
  fi
fi

ora_version=`echo "exit" | sqlplus | awk '
  /Release/ {for (x=1; x<=NF; x++)
    { if ( $x == "Release" ) {x++; split($x,rel,"."); print rel[1]; break}
  }}'`

# Verify that variable $TAPE is defined
if [ -z "$TAPE" ]
then
  echo 'Error====>Environment variable $TAPE is not defined'
  echo "          Script is terminating!"
  notify ; exit 1
fi
# For domain=export or all, verify that variable $EXPORT_HOME is defined
if [ $domain = "export" -o $domain = "all" ]
then
  if [ -z "$EXPORT_HOME" ]
  then
    echo 'Error====>Environment variable $EXPORT_HOME is not defined'
    echo "          Script is terminating!"
    notify ; exit 1
  fi
fi

scripts_path=$DBA_HOME/admin
audit_path=$SID_HOME/audit
cntl_path=$SID_HOME/admin

if [ "$TAPE" = "adsm" ]
then
   dsm_log=$audit_path/adsm.log.$$
   save_command="dsmc archive -archmc=$mgmt_class -subdir=y -quiet"
   save_redir=">$dsm_log 2>&1"
elif [ "$TAPE" = "netbackup" ]
     then
        dsm_log=$audit_path/netadsm.log.$$
        save_command="/usr/openv/netbackup/bin/bpbackup -w -s $mgmt_class -L "
        save_redir="$dsm_log"
else
     if [ "$TAPE" = "nsr" ]
        then
           save_command="save -q -N `hostname`$ORACLE_SID"
           if [ ! -z "$TAPE_SERVER" ]
           then
              save_command="$save_command -s $TAPE_SERVER"
           fi
     else
           echo "Error====>Tapecopy.sh does not support $TAPE tape archiving"
           echo "Script is terminating!"
           notify ; exit 1
     fi
fi
echo "************************************************************************"
echo "====>Script tape_copy.sh starting on" `date`
echo "************************************************************************"
if [ "$TAPE" = "adsm" -o "$TAPE" = "netbackup" ]
then
 echo
 echo "====>Using management class " $mgmt_class
fi
error_switch=0
## ------------------------------------------------------------------------# 
##     BACKUP THE ORACLE EXPORT DIRECTORY                                  # 
## ------------------------------------------------------------------------# 
if [ $domain = "export" -o $domain = "all" ]
then
  echo
  echo "====>Offload the Oracle export directory to tape on" `date`
  echo
  if [ -d $EXPORT_HOME ]
  then
    slash_sw=`echo $EXPORT_HOME | awk '{
      if (substr($1,length($1),length($1)) == "/")
      {print "0"} else {print "1"}}'`
    if [ $slash_sw -eq 1 ]
    then
      EXPORT_HOME=$EXPORT_HOME"/"
    fi
  fi
  echo $save_command $EXPORT_HOME
  echo
  ok2save EXPORT_HOME $EXPORT_HOME
  if [ $? -eq 0 ]; then
    if [ "$TAPE" = "adsm" ]
    then
       eval $save_command $EXPORT_HOME $save_redir
    elif [ "$TAPE" = "netbackup" ]
    then
       eval $save_command $save_redir $EXPORT_HOME
    fi
    save_status=$?
    echo $TAPE return_code=$save_status
set -x
    check_$TAPE $save_status
    save_status=$?
set +x
  else
    save_status=1
  fi
  if [ $save_status -ne 0 ]
  then
    echo
    echo "##########################################################"
    echo "## ERROR ====> Offload of $EXPORT_HOME abended"
    echo "##       ====> Script is terminating"
    echo "##########################################################"
    notify ; exit 1
  else
    echo
    echo "====>$EXPORT_HOME saved"
  fi
fi
if [ $domain = "export" ]
then
  echo
  echo "***********************************************************************"
  echo "====>Script tape_copy.sh ending on" `date`
  echo "***********************************************************************"
  [ "$error_switch" -ne 0 ] && notify
  exit $error_switch
fi
# Verify the state of the backup area for CASC instances
if [ $domain = "backup" -o $domain = "all" ]
then
  if [ "`echo $APP|cut -c1-4`" = "cics" ]
  then
    echo "====>Verify the backup area state"
    echo
    process_state=`cat ${audit_path}/process_state`
    ls ${audit_path}/${process_state}_state* 2>/dev/null
    echo
    if [[ ! -f ${audit_path}/${process_state}_state02 && \
          ! -f ${audit_path}/${process_state}_state51 && \
          ! -f ${audit_path}/${process_state}_state98 ]]
    then
      echo "##########################################################"
      echo "## ERROR ====> Backup area state prohibits offload to tape"
      echo "##       ====> Script is terminating"
      echo "##########################################################"
      echo
      notify ; exit 1
    else
      rm ${audit_path}/${process_state}_state* 2>/dev/null
      echo ${process_state}-batch tape processing is in progress >${audit_path}/${process_state}_state03
    fi
  fi
fi
# Loop over the backup.ctl file to determine the backup directories to 
# offload to tape
# Eliminate any duplicate backup locations specified in the backup control file.
# Keep the least qualified backup path as all subdirectories will be searched
# to locate backup files.
#
if [ $domain = "backup" -o $domain = "all" ]
then
  sort -t : -k 2.1 -o ${backup_file}.sort ${backup_file}
  last_backup_levels=xxxx
  while read backup_line
  do
    if [ -z "$backup_line" ] || [ "`echo $backup_line | cut -c1`" = "#" ]
    then
      continue
    else
      if [ "`echo $backup_line | cut -c1-4`" = "FILE" ]
      then
        continue
      else
        if [ "`echo $backup_line | cut -c1-4`" = "TSGR" ]
        then
          continue
        else
          if [ "`echo $backup_line | cut -c1-3`" = "TMP" ]
          then
            continue
          else
            if [ "`echo $backup_line | cut -c1-5`" = "CLEAN" ]
            then
              continue
            fi
          fi
        fi
      fi
    fi
    backup_path=`echo $backup_line | awk -F: '{print $2}'`
    level_cnt=1
    dup_sw=1
    for last_level in `echo $last_backup_levels`
    do
      level_cnt=`expr $level_cnt + 1`
      if [ "$last_level" != "`echo $backup_path|cut -d/ -f${level_cnt}`" ]
      then
        dup_sw=0
        echo $backup_path
        last_backup_levels=`echo $backup_path|awk -F/ '{
          for (i = 1; i <= NF; i++) print $i}'`
        break
      fi
    done
  done <${backup_file}.sort >${backup_file}.temp
  echo
  echo "====>Offload Oracle disk backups to tape on" `date`
  echo
  while read bkdir
  do
#   $save_command $bkdir > /tmp/adsm$FNAME.log 2> /tmp/adsm$FNAME.err
    if [ -d $bkdir ]
    then
      slash_sw=`echo $bkdir | awk '{
        if (substr($1,length($1),length($1)) == "/")
        {print "0"} else {print "1"}}'`
      if [ $slash_sw -eq 1 ]
      then
        bkdir=$bkdir"/"
      fi
    fi
    echo $save_command $bkdir
    echo
    ok2save bkdir $bkdir
    if [ $? -eq 0 ]; then
      if [ "$TAPE" = "adsm" ]
      then
         eval $save_command $bkdir $save_redir
      elif [ "$TAPE" = "netbackup" ]
      then
         eval $save_command $save_redir $bkdir
      fi
      save_status=$?
      echo $TAPE return_code=$save_status
set -x
      check_$TAPE $save_status
      save_status=$?
set +x
    else
      save_status=1
    fi
    if [ $save_status -ne 0 ]
    then
      echo
      echo "##########################################################"
      echo "## ERROR ====> Offload of $bkdir abended"
      echo "##       ====> Script is terminating"
      echo "##########################################################"
      if [ "`echo $APP|cut -c1-4`" = "cics" ]
      then
        rm ${audit_path}/${process_state}_state*
        echo "${process_state}-batch tape processing abended" > ${audit_path}/${process_state}_state98
      fi
      notify ; exit 1
    else
      echo
      echo "====>$bkdir saved"
    fi
  done<${backup_file}.temp
fi
## ------------------------------------------------------------------------ ##
##     Backup the log archive directory                                     ##
## ------------------------------------------------------------------------ ##
rm ${audit_path}/arch_dest.list >/dev/null 2>&1
rm ${audit_path}/log_mode.lst >/dev/null 2>&1
rm ${audit_path}/ora.error >/dev/null 2>&1
shutdown_sw=0
PASSWD=`$HOME/bin/tellme system`
DBUP $ORACLE_SID
if [ $dbup -eq 1 ]
then
  shutdown_sw=1
  echo
  echo "====>Starting instance $ORACLE_SID to determine log archive directory"
# Added by David DeClercq
  if [ "$ora_version" -gt 7 ]
  then
    sqlplus /nolog <<EOF >$SID_HOME/audit/ora.error
    connect / as sysdba
    startup open
    exit
EOF
  else
    svrmgrl <<EOF >$SID_HOME/audit/ora.error
    connect internal
    startup open
    exit
EOF
  fi 
  grep "ORA-" $SID_HOME/audit/ora.error
  if [ $? -eq 0 ]
  then
    echo
    cat $SID_HOME/audit/ora.error
    echo
    echo "##########################################################"
    echo "## ERROR ====> Startup of Oracle failed"
    echo "##       ====> Script is terminating"
    echo "##########################################################"
    notify ; exit 1
  fi
fi
echo
echo "====>Query the oracle catalog for the log archive directory"
sqlplus -s system/${PASSWD} <<END >/dev/null
set pagesize 0 feedback off verify off echo off heading off
/* ------------------------------------------------------------------------ */
/*     query the oracle catalog for the name of the log archive dir*/
/* ------------------------------------------------------------------------ */
spool ${audit_path}/arch_dest.list
/* Added for Standby Database */
select destination value
  from v\$archive_dest
  where destination is not null
  and status='VALID'
  and target='PRIMARY'
  and rownum=1
union
select value
 from v\$parameter where name = 'log_archive_dest';
spool off
spool ${audit_path}/frdate.list
select 'adsm-'||to_char(sysdate-3,'MM/DD/YY')
from dual;
select 'netbackup-'||to_char(sysdate-3,'MM/DD/YYYY hh:mm:ss')
from dual;
spool off
spool ${audit_path}/log_mode.lst
select log_mode from v\$database;
spool off
END

log_mode=`sed 's/[ ]*$//' ${audit_path}/log_mode.lst`
if [ "$log_mode" = "ARCHIVELOG" ];then    ####DB ARCHIVE STATUS CHECK
   arch_string=`cat ${audit_path}/arch_dest.list`
   arch_string=`echo ${arch_string}`
   if [ "$TAPE" = "adsm" ]
   then
      frdate=`cat ${audit_path}/frdate.list|grep adsm|cut -f2 -d '-'`
      echo $frdate | egrep -s '^[01][0-9]/[0-3][0-9]/[0-9][0-9][ ]*$'
   elif [ "$TAPE" = "netbackup" ]
   then
      frdate=`cat ${audit_path}/frdate.list|grep netbackup|cut -f2 -d '-'`
      echo $frdate | egrep -s '^[0-1][0-9]/[0-3][0-9]/[0-9][0-9][0-9][0-9][ ][0-9][0-9]:[0-9][0-9]:[0-9][0-9]'
   fi
   if [ $? -ne 0 ]; then
      echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
      echo "Unexpected 'From Date' value :"
   fi
   if [ -d $arch_string ]
   then
      arch_dir=$arch_string
   else
      arch_dir=`dirname $arch_string`
   fi
   echo
   echo "====>Offload the Oracle log archive directory to tape on" `date`
   echo
   if [ -d $arch_dir ]
   then
     slash_sw=`echo $arch_dir | awk -F" " '{
       if (substr($1,length($1),length($1)) == "/")
         {print "0"} else {print "1"}}'`

     if [ $slash_sw -eq 1 ]
     then
       arch_dir=$arch_dir'/'
     fi
   fi
   write_arch_list_$TAPE
   if [ $? -ne 0 ]; then
     error_switch=1
   fi
   compress_lock=$SID_HOME/audit/log_compress.lk
   typeset -i compress_time=0
   save_arch=1
   if [ ! -f $compress_lock ]; then
     lock_compress
   fi
   while [ -f $compress_lock ]; do
      compress_pid=`head -1 $compress_lock`
      if [ -z "$compress_pid" ]; then
        echo 
        echo "######################################################"
        echo "## ERROR ===> Unable to determine compress process id"
        echo "######################################################"
        save_arch=0
        break
      else
        if [ `head -1 $compress_lock` = $$ ]; then
          break
        fi
        compress_process=`ps -o comm -p $compress_pid | grep -v '^COMMAND'`
        if [ -z "$compress_process" ]; then
          lock_compress
           status=$?
           case $status in 
             0 )
               break
               ;;
             1 )
               if [ -f "$compress_lock" ]; then
                  compress_pid=`head -1 $compress_lock`
                  if [ -n "$compress_pid" ]; then
                     if [ `ps -f -p $compress_pid | wc -l` -eq 1 ]; then
                        rm -f $compress_lock
                     fi
                  fi
               fi
               ;;
             2 )
               save_arch=0 
               break
              ;;
           esac
        fi
      fi 
      if [ $compress_time -gt 60 ]; then
        echo 
        echo "######################################################"
        echo "## ERROR ===> Compress process $compress_process is still running after $compress_time minutes"
        echo "######################################################"
        ps -f -p $compress_pid
        save_arch=0
        break
      else
        echo "`date` : The following process currently is compressing logs:"
        ps -f -p $compress_pid
        echo "sleeping 5 minutes..."
        sleep 300
        compress_time=$compress_time+5
      fi
      if [ ! -f "$compress_lock" ]; then
        lock_compress
        if [ $? -eq 2 ]; then 
          save_arch=0 
          break
        fi
      fi
   done
   if [ $save_arch -eq 0 ] 
   then
     if [ -f "$compress_lock" ]; then
       if [ `head -1 $compress_lock` -eq $$ ]; then
          rm -f $compress_lock
        fi
      fi
      echo
      echo "##########################################################"
      echo "## ERROR ====> Offload of $arch_dir abended"
      echo "##       ====> Script is terminating"
      echo "##########################################################"
      notify ; exit 1
   fi
   echo $save_command $arch_dir
   echo
   ok2save Archive $arch_dir
   if [ $? -eq 0 ]; then
     if [ "$TAPE" = "adsm" ]
     then
        eval $save_command $arch_dir $save_redir
        save_status=$?
     elif [ "$TAPE" = "netbackup" ]
     then
        eval $save_command $save_redir $arch_dir
        save_status=$?
        sleep 60
     fi
     echo $TAPE return_code=$save_status
     set -x
     check_$TAPE $save_status
     save_status=$?
     set +x
   else
     save_status=1
   fi
   if [ $save_status -ne 0 ]
   then
     echo
     echo "##########################################################"
     echo "## ERROR ====> Offload of $arch_dir abended"
     echo "##       ====> Script is terminating"
     echo "##########################################################"
     error_switch=1
   else
     echo
     echo "====>$arch_dir saved"
     cd $arch_dir
     ls -c1 > log_to_tape.list
   fi
   if [ -f "$compress_lock" ]; then
     if [ `head -1 $compress_lock` -eq $$ ]; then
       rm -f $compress_lock
     fi
   fi
   if [ $shutdown_sw -eq 1 ]
   then
     echo
     echo "====>Shutting instance $ORACLE_SID back down"
     if [ "$ora_version" -gt 7 ]
     then
       sqlplus /nolog <<EOF >$SID_HOME/audit/ora.error
          connect / as sysdba
          shutdown immediate
          exit
EOF
     else
       svrmgrl <<EOF >$SID_HOME/audit/ora.error
         connect internal
         shutdown immediate
         exit
EOF
     fi
     grep "ORA-" $SID_HOME/audit/ora.error
     if [ $? -eq 0 ]
     then
       echo
       cat $SID_HOME/audit/ora.error
       echo
       echo "##########################################################"
       echo "## ERROR ====> Shutdown of Oracle failed"
       echo "##       ====> Script is terminating"
       echo "##########################################################"
       notify ; exit 1
     fi
   fi
   if [ "$TAPE" = "adsm" -o "$TAPE" = "netbackup" ]
   then
     # rewrite arch log list a second time, to reflect what was
     # written to tape
     write_arch_list_$TAPE
     if [ $? -ne 0 ]; then
        error_switch=1
     fi
   fi

   echo
   echo "************************************************************************"
   echo "====>Script tape_copy.sh ending on" `date`
   echo "************************************************************************"
   rm ${backup_file}.sort >/dev/null 2>&1
   rm ${backup_file}.temp >/dev/null 2>&1
   rm ${audit_path}/arch_dest.list >/dev/null 2>&1
   rm ${audit_path}/log_mode.lst >/dev/null 2>&1
   rm ${audit_path}/ora.error >/dev/null 2>&1
   [ "$error_switch" -ne 0 ] && notify
   exit $error_switch
else       #### DB ARCHIVE ELSE
  log_mode=`sed 's/[ ]*$//' ${audit_path}/log_mode.lst`
  if [ "$log_mode" = "NOARCHIVELOG" ];then
     echo "====>DB not in archive log mode"
     exit_status=0
   else
      echo "!!!!!!!!!!!!!!!!!!!!!!!"
      echo "====>DB archive log mode could not be determined!"
      exit_status=1
      notify
   fi 
   echo "************************************************************************"
   echo "====>Script tape_copy.sh ending on" `date`
   echo "************************************************************************"
   rm ${backup_file}.sort >/dev/null 2>&1
   rm ${backup_file}.temp >/dev/null 2>&1
   rm ${audit_path}/arch_dest.list >/dev/null 2>&1
   rm ${audit_path}/log_mode.lst >/dev/null 2>&1
   rm ${audit_path}/ora.error >/dev/null 2>&1
   exit $exit_status
fi
