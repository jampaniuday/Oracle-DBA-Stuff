#!/bin/ksh
## Purpose    : Gathers schema Tables / Indexes with 30% sample, to make best use of CBO
##              on the specified instance.
## Usage      : hrschema.sh <SID>
## Parameter  : Oracle SID
## Created by : Mugunthan

## Notify Information ##
sid=$1
notify_who="mugunthan.bala"
notify_host=`hostname`
notify_sid=$sid
notify_type="Gather Schema"

## Check for SID parameter ##
if [ -z "$sid" ]
then
  echo
  echo "Invalid Parameter input"
  echo "Usage is hrschema.sh sid"
  echo
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/hrschema.audit
  exit
fi

## Check for $HOME/bin/SID Environment ##
if [ ! -f $HOME/bin/$sid ]
then
  echo "Error====>No environment script found for instance \"$sid\""
  echo "          Script is terminating!"
  exit
fi

## Set Environment ##
. $HOME/bin/$sid

## Check SID_HOME/audit directory exists or not  ##
if [ ! $SID_HOME/audit ]
then
echo "SID_HOME/audit directory doesnt exists"
  echo "please create it and rerun the script"
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/hrschema.audit
  exit
fi


echo "###############################################################"
echo "##    Script hrschema.sh starting on " `date` for $sid
echo "###############################################################"

## Check for Instance ##
inst=`ps -ef | grep ora_smon_$sid | grep -v grep`
if [ -z "$inst" ]
then
  echo "Oracle instance, $sid is not available."
  echo "Script is terminating."
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/hrschema.audit
  exit
fi

## Pick up apps password from tellme ##
PWD=`$HOME/bin/tellme apps`
if [ -z "$PWD" ]
then
  echo "Error : No password selected for APPS"
  echo "Script is termianting"
  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/hrschema.audit
  exit
fi

  sqlplus -s apps/${PWD}@$sid <<EOF >$SID_HOME/audit/hr_analyzed.log
  alter system flush shared_pool;
  exec fnd_stats.gather_schema_statistics('HR','10');
  select table_name,last_analyzed,sample_size from dba_tables where owner = 'HR' and to_char(last_analyzed,'MM-DD-YYYY')  < to_char(SYSDATE,'MM-DD-YYYY');
!mailx -s ANALYZED_${sid} ${notify_who}@corporate.ge.com < $SID_HOME/audit/hr_analyzed.log
  exit;
