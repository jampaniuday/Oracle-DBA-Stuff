file=/p078/hrapp/ftp_top/ALL/183184_EITDATNEW.dat
aa=BB
while [ $aa = "BB"  ]
do
pbrun chmod 777 "$file"
aa=cc
done
