#!/usr/bin/ksh 
# Name 	: chpass.sh 
# Date 	: 25-Oct-01
# Author: Ranjit Mhatre
# Desc 	: To Change the database password for the the database's on Server. 
#	  It will Modify the oratask.lst file and charm.file .
#         Note : Charm file  only gets modify when changing sys password.	
# 		You have to change the password in sequence as sys/system/other
#	 USAGE: chpass.sh <Oracle_username> <New Password> <Charm_data>
##########################################################################

if [ $# -ne 2 ]
then
	if [ $# -ne 3 ]
	then
	echo "USAGE: chpass.sh <Oracle_username> <New Password> <Charm_data>\n"
	echo "\teg : chpass.sh system newpass 9:2"
	echo "\t     system Password will change to n9ewpass\n"
	echo "       The script will change the password for all instance on server "
	echo "\tOracle_username\t: Name of the database user which you want to \n\t\t\t  change the password "
	echo "\tNew Password\t: New Password without month character" 
	echo "\tCharm_data\t: Do entry as 9:2 where 9 is  character month  to \n \t\t\t  be inserted in the 2 nd position of given password"
	exit 0
	fi
fi
# Validating data
if [ $# -eq 2 ]
then
	echo "No charm File Data Will not change file charm.file"
	Charmmod=1
else
	Charmd=$3
	charm1=`echo $Charmd|awk -F: '{print $1}'`
	charm2=`echo $Charmd|awk -F: '{print $2}'`
	if [ -z "$charm1" -o -z "$charm2" ]
	then
		echo "Please enter Charm_data correct"
		exit 1
	else
		if [ $charm1 -eq 0 -o $charm2 -eq 0 ]
		then
			echo "Charm_data should not be 0"
			exit 1
		fi
	fi
	if [ $charm1 -gt 12 ]
	then
		echo "month Character to be inserted should be equal to or lessthan 12 "
		exit 1
	fi

	psle=`echo $2|wc -c`
	psle=`expr $psle - 1`
	if [ $charm2 -gt $psle ]
	then
		echo "Password should be longer than character  position specified in charm file"
		exit 1
	fi
	Charmmod=0
fi
#echo charm1 $charm1
#echo charm2 $charm2
#echo psle $psle
#echo Charmmod $Charmmod
if [ "$1" = "sys" ]
then
	echo "Sys User "  >$DBA_HOME/admin/Sysdone.ctl
 curr_pd=`cat $HOME/bin/oratask.lst|grep ":sys:"|head -1|cut -d: -f3`
 clist=`cat $HOME/bin/oratask.lst|grep -v ^#|grep -v asis|grep -v ":sys:"|grep -v ":system:"|grep $curr_pd`
 clist1=`cat $HOME/bin/oratask.lst|grep -v ^#|grep -v asis|grep -v ":sys:"|grep -v ":system:"|grep -v $curr_pd`
echo "#################################################################" >/tmp/ps.out
echo " Alert: Following users have same password as sys and uses charm" >>/tmp/ps.out
echo $clist >>/tmp/ps.out
echo " Alert: Following uses charm" >>/tmp/ps.out
echo $clist1 >>/tmp/ps.out
echo "#################################################################" >>/tmp/ps.out
else
	if [ "$1" = "system" ]
	then
		if [ ! -f $DBA_HOME/admin/Sysdone.ctl ]
		then
			echo "First Modify The sys user then System"
			exit 1
		fi
			oldch1=`cat $HOME/bin/charm.file`
			if [ "$oldch1" = $3 ]
			then
			Nocharm=Y
			else
				echo "Charm_data should be same as sys"
				exit 1
			fi
		mv $DBA_HOME/admin/Sysdone.ctl $DBA_HOME/admin/Systemdone.ctl
	else
		if [ $Charmmod -eq 0 ]
		then
			oldch=`cat $HOME/bin/charm.file`
			if [ "$oldch" = $3 ]
			then
			Nocharm=Y
			else
				echo "Charm_data should be same as sys/system"
				exit 1
			fi
		fi
	fi
fi
# get the location of oratab                   

if [ "`uname -a | cut -c1-3`" = "Sun" ]        
then                                           
 	 oratab=/var/opt/oracle/oratab                
# 	 oratab=oratab
else                                         
	oratab=/etc/oratab                         
fi                                             
allsid=`cat $oratab |grep -v \#|grep -v \*|grep -v oracle50|awk -F: '{print $1}'|xargs echo`
dbu=$1;export dbu
if [ $Charmmod -eq 0 ]
then
	charm2l=`expr $charm2 - 1`
	dbp1=`echo $2|cut -c1-${charm2l}`
	dbp2=`echo $2|cut -c${charm2}-${psle}`
	dbp=`echo ${dbp1}${charm1}${dbp2}`;export dbp
else
	dbp=$2;export dbp
fi
echo  dbp $dbp 
for ALLS in $allsid 
do 

# Changes Made By Ramesh.P
  ps -ef | grep pmon | grep $ALLS > /dev/null 2>&1
  if [ $? -eq 0 ]
  then
   os_user=`ps -ef | grep pmon | grep $ALLS | awk '{print $1}'`
   if [ -f $HOME/bin/$ALLS -a "$os_user" = "$LOGNAME" ]
   then
# Chages END
unset ORA_NLS33
    . $HOME/bin/$ALLS
    if [ "$ORACLE_SID" = "$ALLS" ]
    then
     PASSWD=`tellme sys`
sqlplus -s "sys/$PASSWD as sysdba" <<EOF >$SID_HOME/audit/perr.err
alter user $dbu identified by "$dbp";

EOF
     oerr=`cat $SID_HOME/audit/perr.err|grep ORA-|grep -v grep`
     if [ ! -z "$oerr" ]
     then
      echo Error changing password for $ALLS  
	cat $SID_HOME/audit/perr.err
     else
	echo changing the oratask.lst file
	rm $HOME/bin/oratask.RRR >/dev/null 2>&1
	while read line 
	do 
	chline=`echo $line|grep -v ^#|grep  ^"${ALLS}:${dbu}:"`
	if [ -z "$chline" ]
	then
		echo $line >>$HOME/bin/oratask.RRR
	else
		if [ $Charmmod -eq 0 ]
		then
			echo "${ALLS}:${dbu}:${2}" >>$HOME/bin/oratask.RRR
		else
			echo "${ALLS}:${dbu}:${dbp}:asis" >>$HOME/bin/oratask.RRR
		fi
		echo "changed for $ALLS"
	fi
	done <$HOME/bin/oratask.lst
	cp $HOME/bin/oratask.RRR $HOME/bin/oratask.lst
	rm $HOME/bin/oratask.RRR
     fi
    fi

#Changes By Ramesh.P
   else
    echo "Execute the script as $os_user for $ALLS instance."
   fi
  else 
   echo "The instance $ALLS Seems to be Down."
 fi 
#Changes END

done
if [ $Charmmod -eq 0 ]
then
    if [ "X${Nocharm}" = "XY" ]
    then
	echo "Not Modifying charm File it's gets modify only for sys user"
    else
	if [ $1 = "sys" ]
	then
	echo "Modifying charm.file ......"
	cp $HOME/bin/charm.file $HOME/bin/charm.file.old`date +%m%d`
	echo $3 >$HOME/bin/charm.file
	fi
    fi
fi
if [ "$1" = "sys" ]
then
cat /tmp/ps.out
echo " Please check file /tmp/ps.out for users using charm data or same password as sys"
fi
