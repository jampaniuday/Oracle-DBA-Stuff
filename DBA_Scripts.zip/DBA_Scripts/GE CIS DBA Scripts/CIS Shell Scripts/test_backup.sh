#!/bin/ksh
###############################################################################
## test_backup.sh
##
##   PURPOSE: This script is a modified version of backup.sh that facilitates
##     compression testing from UNIX compression to tape archive compression
##     to tape recall to UNIX decompression. This test should always be executed
##     once for each different tape archive system and/or each operating system
##     platform.  Test processing supports the full range of backup options
##     (i.e. full hot and cold backup plus 'ONLY', 'FILEGROUP#', and 'TSGROUP#' ##     options are available as in backup.sh).
##   USAGE: test_backup.sh sid backup_type [AltBackupCtl] [AltPfile]
##          >$SID_HOME/audit/backup_${ORACLE_SID}.auditMMDD[_HHMM] 2>&1 &
##     A default backup.ctl file or an optional alternate backup control file
##       must exist under $SID_HOME/admin. See initial comments in backup.sh
##       for the formatting requirements of this file.
##   NOTE: This script WILL NOT create any test or test2 subdirectory
##             structures. You must manually create these structures before
##             running this script.
##   SCRIPT PROCESS FLOW:
##     See backup.sh for the general process flow of this script. The only
##     difference is that, in addition to creating a compressed copy of each
##     file under the backup directory designated in $SID_HOME/admin/backup.ctl,
##     this script also creates an uncompressed copy of each file in
##     subdirectory, test, under the same backup directory.
##     It also changes the standard recovery script produced by this script
##     to contain commands to uncompress to a test2 subdirectory
##     the compressed backup file created by test_backup.sh
##     that was manually sent through tape compression and recalled; then,
##     to execute a UNIX diff command between the never compressed test
##     subdirectory file and the test2 subdirectory file which was doubly
##     compressed then decompressed
##
########################################################################
## ------------------------------------------------------------------------ ##
##         Process inputs and set the instance and script environment       ##
## ------------------------------------------------------------------------ ##
###############################################################################
## ------------------------------------------------------------------------ ##
##         Process inputs and set the instance and script environment       ##
## ------------------------------------------------------------------------ ##
# Verify sid input
if [ -z "$1" ]
then
  echo "Error====>Required parameter is missing"
  echo "          Usage is backup.sh sid backup_type"
  echo "          Script is terminating!"
  exit 1
fi
# Set the instance environment
if [ ! -f $HOME/bin/$1 ]
then
  echo "Error====>No environment script found for instance \"$1\""
  echo "          Script is terminating!"
  exit 1
fi
. $HOME/bin/$1
# Verify backup type input
if [ -z "$2" ]
then
  echo "Error====>Required parameter is missing"
  echo "          Usage is backup.sh sid backup_type"
  echo "          Script is terminating!"
  exit 1
fi
backup_type=$2
export backup_type
if [ "$backup_type" != "cold" -a "$backup_type" != "hot" ]
then
  echo "Error====>Backup type parameter is invalid"
  echo "          Value must be cold or hot"
  echo "          Script is terminating!"
  exit 1
fi
scripts_path=$DBA_HOME/admin
audit_path=$SID_HOME/audit
cntl_path=$SID_HOME/admin
# Set the backup.ctl file and Oracle pfile to parameter input or to the
# default filename
backup_file=$SID_HOME/admin/backup.ctl
init_file=$ORACLE_HOME/dbs/init$ORACLE_SID.ora
if [ ! -z "$3" ]
then
  echo $3 | grep init >/dev/null 2>&1
  if [ $? -eq 0 ]
  then
    init_file=$ORACLE_HOME/dbs/$3
  else
    backup_file=$SID_HOME/admin/$3
  fi
fi
if [ ! -z "$4" ]
then
  echo $4 | grep init >/dev/null 2>&1
  if [ $? -eq 0 ]
  then
    init_file=$ORACLE_HOME/dbs/$4
  else
    backup_file=$SID_HOME/admin/$4
  fi
fi
if [ ! -f $init_file ]
then
  echo "Error====>Oracle pfile does not exist"
  echo "          Script is terminating!"
  exit 1
fi
if [ ! -f $backup_file ]
then
  echo "Error====>Backup control file does not exist"
  echo "          Script is terminating!"
  exit 1
fi
export backup_file
default_dir=`grep DEFAULT ${backup_file}|grep -v "#DEFAULT"|awk -F: '{print $2}'`
if [ ! -d "$default_dir" ]
then
  echo "Error====>Missing or invalid DEFAULT entry in the backup control file"
  echo "          Script is terminating!"
  rm ${audit_path}/default.dir >/dev/null 2>&1
  exit 1
else
  echo $default_dir > ${audit_path}/default.dir
fi
export default_dir
# Examine the backup.ctl file for special processing requests of 'ONLY' to only
# backup specified tablespaces, 'FILEGROUP#' to create multiple, parallel
# cold backup streams to reduce backup outage times on multiprocessor systems,
# or 'TSGROUP#' to also create multiple, parallel backup streams but for hot
# backup processing on multiprocessor systems.
# Edit for conflicting or invalid options and produce special processing
# files to be used as a filter (ONLY processing) or group designator (TSGROUP
# or FILEGROUP processing) when processing the complete list of
# Oracle datafiles that is extracted from the Oracle data dictionary.
only_sw=0
group_sw=NONE
group_cnt=1
out_label=${ORACLE_SID}
if [ "`grep "ONLY:" ${backup_file}`" ]
then
  if [ "`egrep 'TSGROUP|FILEGROUP' ${backup_file}`" ]
  then
    echo "Error====>Cannot request both ONLY and GROUP processing"
    echo "          Script is terminating!"
    exit 1
  else
    only_sw=1
    out_label=`basename ${backup_file} | awk -F"[.]|[_]" '{print $1}'`
    audit_path=${audit_path}/${out_label}
    if [ ! -d $audit_path ]
    then
      mkdir -p $audit_path
    fi
    only_file=${audit_path}/only.ctl
    awk -F: '{
      if ($1 == "ONLY") {print $2}
    }' ${backup_file} > ${only_file} 
  fi
else
  if [ "`egrep 'TSGROUP|FILEGROUP' ${backup_file}`" ]
  then
    if [ "`grep "FILEGROUP" ${backup_file}`" ]
    then
      if [ "`grep "TSGROUP" ${backup_file}`" ]
      then
        echo "Error====>Cannot request both TSGROUP and FILEGROUP processing"
        echo "          Script is terminating!"
        exit 1
      else
        group_sw=FILEGROUP
      fi
    else
      group_sw=TSGROUP
    fi
    group_file=${audit_path}/group.ctl
    groupid_file=${audit_path}/group.id
    grep ${group_sw} ${backup_file} | awk -F: '{
      print tolower($1)":"$2}' > ${group_file}
    sort -t : -u -k 1,1 -o ${groupid_file} ${group_file}
    group_cnt=`cat ${groupid_file} | wc -l`
    default_group=`awk -F: '{if (NR == 1) {print tolower($1)}}' ${groupid_file}`
  fi
fi
if [ ${backup_type} = "hot" -a ${group_sw} = "FILEGROUP" ]
then
  echo "Error====>FILEGROUP processing not allowed for hot backup"
  echo "          Must use TSGROUP processing instead"
  echo "          Script is terminating!"
  exit 1
fi
if [ ${backup_type} = "cold" -a ${only_sw} -eq 1 ]
then
  echo "Error====>ONLY processing not allowed for cold backup"
  echo "          Script is terminating!"
  exit 1
fi
if [ ${backup_type} = "cold" -a ${group_sw} = "TSGROUP" ]
then
  echo "Error====>TSGROUP processing not allowed for cold backup"
  echo "          Must use FILEGROUP processing instead"
  echo "          Script is terminating!"
  exit 1
fi
export audit_path
echo "************************************************************************"
echo "====>Script backup.sh starting on" `date`
echo "************************************************************************"
echo
# For CASC instances, verify the state of the backup area
if [ "`echo $APP|cut -c1-4`" = "cics" ]
then
  echo "====>Verify the backup area state"
  echo
  process_state=`cat ${audit_path}/process_state`
  ls ${audit_path}/${process_state}_state* 2>/dev/null
  echo
  if [[ ! -f ${audit_path}/${process_state}_state04 && \
        ! -f ${audit_path}/${process_state}_state51 && \
        ! -f ${audit_path}/${process_state}_state99 ]]
  then
    echo "#####################################################"
    echo "## ERROR ====> Backup area state prohibits backup"
    echo "##       ====> Script is terminating"
    echo "#####################################################"
    echo
    exit 1
  else
    rm ${audit_path}/${process_state}_state* 2>/dev/null
    echo ${process_state}-batch backup processing is in progress >${audit_path}/${process_state}_state01
    touch $PATROL/$ORACLE_SID
  fi
fi
sort -t : -k 1.1 -o ${backup_file}.sort ${backup_file}
PASSWD=`$HOME/bin/tellme system`
# Remove any files from previous executions of the backup script
rm ${audit_path}/bkarc.sql >/dev/null 2>&1
rm ${audit_path}/backup.*.list >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.control >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.arc.status >/dev/null 2>&1
rm ${audit_path}/bkstatus.list > /dev/null 2>&1
rm ${audit_path}/bkdest.list > /dev/null 2>&1
rm ${audit_path}/bkfmt.list > /dev/null 2>&1
rm ${audit_path}/bkcontrol.list > /dev/null 2>&1
rm ${audit_path}/ora.error > /dev/null 2>&1
rm ${audit_path}/default.dir > /dev/null 2>&1
error_switch=0
cd ${audit_path}
## ------------------------------------------------------------------------ ##
##         For cold backups, shutdown Oracle abort                          ##
## ------------------------------------------------------------------------ ##
if [ ${backup_type} = "cold" ]
then
  ## Added by Satyen Jadia
  ## Purpose - To get sessions high watermark for the instance
  echo
  echo "====>Query database to get sessions high watermark"
  $DBA_HOME/admin/session_dtl.sh $ORACLE_SID > $audit_path/${ORACLE_SID}_lic.audit
  ##
  ## End
  echo
  echo "====>Shutting down instance $ORACLE_SID to kill any active users"
  sqlplus -s /nolog <<EOF >${audit_path}/ora.error
  connect / as SYSDBA
  shutdown abort
  exit
EOF
  grep "ORA-" ${audit_path}/ora.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> Shutdown abort of Oracle failed"
    echo "##       ====> Backup processing cannot continue"
    cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi
fi
## ------------------------------------------------------------------------ ##
##         Start up Oracle if it is down                                    ##
##         (open for hot backups; restrict for cold backups)                ##
## ------------------------------------------------------------------------ ##
sleep 120
ps_cnt=`ps -ef|grep ora_pmon_${ORACLE_SID}|grep -v grep|wc -l`
if [ $ps_cnt -eq 0 ]
then
  if [ $backup_type = "cold" ]
  then
    db_mode=restrict;export db_mode
  else
    db_mode=open;export db_mode
  fi
  echo
  echo "====>Starting instance $ORACLE_SID in $db_mode mode"
  sqlplus -s /nolog <<EOF >${audit_path}/ora.error
  connect / as SYSDBA
  startup $db_mode
  exit
EOF
  grep "ORA-" ${audit_path}/ora.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> Startup of Oracle failed"
    echo "##       ====> Backup processing cannot continue"
    cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi
fi
echo
echo "====>Query the oracle catalog for a list of datafiles to backup"
sqlplus -s system/${PASSWD} <<END >${audit_path}/ora.error
/* ------------------------------------------------------------------------ */
/*      obtain a list of data and log files to backup for this ORACLE_SID   */
/* ------------------------------------------------------------------------ */
set pagesize 0 linesize 132 feedback off verify off echo off termout off heading off
spool ${audit_path}/backup.${ORACLE_SID}.list
/* ====>  select all tablespace names and associated datafiles        <==== */
select tablespace_name, substr(file_name,1,80)
  from dba_data_files
  order by tablespace_name, file_id;
/* ====>  select all log group member names                           <==== */
select 'REDOLOG '||member from v\$logfile;
spool off
END
grep "ORA-" ${audit_path}/ora.error
if [ $? -eq 0 ]
then
  echo "############################################################"
  echo "## ERROR ====> Failed to produce list of datafiles to backup"
  echo "##       ====> Backup processing cannot continue"
  cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
  echo "############################################################"
  error_switch=1
# attempt to disable restricted session before exiting
  sqlplus -s /nolog <<EOF >/dev/null
  connect / as SYSDBA
  alter system disable restricted session;
  exit
EOF
  exit 1
fi
sqlplus -s system/$PASSWD <<END >/dev/null
/* ------------------------------------------------------------------------ */
/*         obtain a list of control files to backup for this ORACLE_SID     */
/* ------------------------------------------------------------------------ */
set pagesize 0 linesize 512 feedback off verify off echo off termout off heading off
spool ${audit_path}/backup.${ORACLE_SID}.control
select value
 from v\$parameter where name = 'control_files';
spool off
END
awk -F",[ ]*|[ ]+" '{
for (i = 1; i <= NF; i++) if ($i != "") {print "CONTROLFILE",$i}
}' ${audit_path}/backup.${ORACLE_SID}.control >>${audit_path}/backup.${ORACLE_SID}.list
## ------------------------------------------------------------------------ ##
## Apply any 'ONLY' or 'GROUP' filters to the Oracle datafile list just     ##
## produced.                                                                ##
## ------------------------------------------------------------------------ ##
if [ ${only_sw} -eq 1 ]
then
  while read backup_ts backup_dbf
  do
    if [ "`grep ${backup_ts} ${only_file}`" ]
    then
      echo ${backup_ts} ${backup_dbf} >> ${audit_path}/backup.${out_label}.list
    fi
  done < ${audit_path}/backup.${ORACLE_SID}.list
fi
if [ ${group_sw} = "TSGROUP" ]
then
  while read backup_ts backup_dbf
  do
    if [ ${backup_ts} = "REDOLOG" -o ${backup_ts} = "CONTROLFILE" ]
    then
      continue
    fi
    awk -F: -v ts="$backup_ts" -v dbf="$backup_dbf" -v def="$default_group" '
    BEGIN {
    match_sw = 0
    }
    {if (ts == $2)
      {outfile = "backup."$1".list"
       print ts, dbf >> outfile
       match_sw = 1
       exit}
    }
    END {
    if (match_sw == 0)
      {outfile = "backup."def".list"
       print ts, dbf >> outfile}
    }' ${group_file}
  done < ${audit_path}/backup.${ORACLE_SID}.list
fi
if [ ${group_sw} = "FILEGROUP" ]
then
  while read backup_ts backup_dbf
  do
    awk -F: -v ts="$backup_ts" -v dbf="$backup_dbf" -v def="$default_group" '
    BEGIN {
    match_sw = 0
    }
    {pos = index(dbf,$2)
     if (pos != 0)
      {outfile = "backup."$1".list"
       print ts, dbf >> outfile
       match_sw = 1
       exit}
    }
    END {
    if (match_sw == 0)
      {outfile = "backup."def".list"
       print ts, dbf >> outfile}
    }' ${group_file}
  done < ${audit_path}/backup.${ORACLE_SID}.list
fi
echo
if [ ${only_sw} -eq 1 ]
then
  echo "Selective tablespace backup processing requested for only:"
  echo
  cat ${only_file}
else
  if [ $backup_type = "cold" ]
  then
    echo ${ORACLE_SID} oracle datafile count is `cat ${audit_path}/backup.${ORACLE_SID}.list|wc -l`
  else
    echo ${ORACLE_SID} oracle datafile count is `cat ${audit_path}/backup.${ORACLE_SID}.list|egrep -v "REDOLOG|CONTROLFILE"|wc -l`
  fi
fi
## ------------------------------------------------------------------------ ##
##         For cold backups, shutdown Oracle immediate                      ##
## ------------------------------------------------------------------------ ##
if [ ${backup_type} = "cold" ]
then
  echo
  echo "====>Shutting down instance $ORACLE_SID for a cold backup"
  sqlplus -s /nolog <<EOF >${audit_path}/ora.error
  connect / as SYSDBA
  shutdown immediate
  exit
EOF
  grep "ORA-" ${audit_path}/ora.error
  if [ $? -eq 0 ]
  then
    cat ${audit_path}/ora.error
    echo "#####################################################"
    echo "## ERROR ====> Shutdown  of Oracle failed"
    echo "##       ====> Backup processing cannot continue"
    cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit $error_switch
  fi
fi
## ------------------------------------------------------------------------ ##
##         For hot backups, execute a system checkpoint                     ##
## ------------------------------------------------------------------------ ##
if [ ${backup_type} = "hot" ]
then
  echo
  echo "====>Checkpointing the Oracle instance"
  sqlplus -s /nolog <<EOF >${audit_path}/ora.error
  connect / as SYSDBA
  alter system checkpoint;
  exit
EOF
  grep "ORA-" ${audit_path}/ora.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> Checkpoint of Oracle failed"
    cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi
fi
export out_label
echo
echo "====>Starting $backup_type backup of $ORACLE_SID datafiles on" `date`
## ------------------------------------------------------------------------ ##
## Submit test_backup_copy.sh for each datafile subgroup                    ##
## ------------------------------------------------------------------------ ##
group_sub=1
while [ ${group_sub} -le ${group_cnt} ]
do
  if [ ${group_sw} = "NONE" ]
  then
    group_id=${out_label}
  else
    group_id=`awk -F: -v recnum="${group_sub}" '{
      if (NR == recnum) {print $1}}' ${groupid_file}`
  fi
  $DBA_HOME/adminscripts9i/test_backup_copy.sh ${group_id} >${audit_path}/${ORACLE_SID}_${group_id}.audit 2>&1 &
  group_sub=`expr ${group_sub} + 1`
done
wait
## ------------------------------------------------------------------------ ##
## Confirm termination status of all datafile subgroup compressed copy jobs ##
## ------------------------------------------------------------------------ ##
group_sub=1
while [ ${group_sub} -le ${group_cnt} ]
do
  if [ ${group_sw} = "NONE" ]
  then
    group_id=${out_label}
  else
    group_id=`awk -F: -v recnum="${group_sub}" '{
      if (NR == recnum) {print $1}}' ${groupid_file}`
  fi
  if [ "`grep "ERROR" ${audit_path}/${ORACLE_SID}_${group_id}.audit`" ]
  then
    error_switch=1
  fi
  if [ "`grep "WARNING" ${audit_path}/${ORACLE_SID}_${group_id}.audit`" ]
  then
    if [ ${error_switch} -eq 0 ]
    then
      error_switch=2
    fi
  fi
  cat ${audit_path}/${ORACLE_SID}_${group_id}.audit
  rm -f ${audit_path}/${ORACLE_SID}_${group_id}.audit
  group_sub=`expr ${group_sub} + 1`
done
## ------------------------------------------------------------------------ ##
##     confirm inactive status of all online backups                        ##
## ------------------------------------------------------------------------ ##
if [ ${backup_type} = "hot" ]
then
  echo
  echo "====>confirm inactive status of all online backups"
  sqlplus -s system/${PASSWD} >${audit_path}/bkstatus.list <<END
  set pagesize 1000 linesize 200 heading off feedback off
  select d.tablespace_name, b.status
    from v\$backup b, dba_data_files d
    where b.file# = d.file_id
    and   b.status = 'ACTIVE';
END
  cat ${audit_path}/bkstatus.list | awk '{print $1,$2}' | grep ACTIVE >${audit_path}/bkactive.list
  if [ $? -eq 0 ]
  then
    if [ $only_sw -eq 0 ]
    then
      echo
      echo "#####################################################"
      echo "## ERROR ====> tablespaces left in begin backup status"
      echo "#####################################################"
      echo
      cat ${audit_path}/bkactive.list
      echo
      error_switch=1
    else
      while read active_ts active_status
      do
        grep $active_ts $only_file >/dev/null 2>&1
        if [ $? -eq 0 ]
        then
          echo
          echo "#####################################################"
          echo "## ERROR ====> tablespaces left in begin backup status"
          echo "#####################################################"
          echo
          echo $active_ts
          echo
          error_switch=1
          break
        fi
      done <${audit_path}/bkactive.list
    fi
  fi
fi
# If any errors were detected while backing up any Oracle file then
# terminate processing now with a nonzero return code
if [ ${error_switch} -eq 1 ]
then
  exit 1
fi
## ------------------------------------------------------------------------ ##
##         Startup Oracle following a cold backup                           ##
## ------------------------------------------------------------------------ ##
if [ ${backup_type} = "cold" ]
then
  echo
  echo "====>Starting instance $ORACLE_SID for user access"
  echo
  echo "Using pfile $init_file"
  sqlplus -s /nolog <<EOF >${audit_path}/ora.error
  connect / as SYSDBA
  startup open pfile=$init_file
  exit
EOF
  grep "ORA-" ${audit_path}/ora.error
  if [ $? -eq 0 ]
  then
    cat ${audit_path}/ora.error
    echo "#####################################################"
    echo "## ERROR ====> Startup of Oracle failed"
    echo "##       ====> Backup processing cannot continue"
    cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit $error_switch
  fi
fi
sqlplus -s system/${PASSWD} << END >/dev/null
/* ------------------------------------------------------------------------ */
/*     determine if database is in archivelog mode                          */
/* ------------------------------------------------------------------------ */
set pagesize 0 feedback off verify off echo off termout off heading off
spool ${audit_path}/backup.${ORACLE_SID}.arc.status
select log_mode from v\$database;
spool off
END
grep "NO" ${audit_path}/backup.${ORACLE_SID}.arc.status
if [ $? -eq 0 ]
then
  echo "====================================================="
  echo "== WARNING ====> database is in NOARCHIVELOG mode"
  echo "====================================================="
  archivelog_sw=0
else
  archivelog_sw=1
fi
if [ $archivelog_sw -eq 1 ]
then
  sqlplus -s system/${PASSWD} <<END
/* ------------------------------------------------------------------------ */
/*     force a log switch                                                   */
/* ------------------------------------------------------------------------ */
  prompt
  prompt ====>switch logfile
  alter system switch logfile;
/* ------------------------------------------------------------------------ */
/*     wait for switched log to be archived                                 */
/* ------------------------------------------------------------------------ */
  prompt ====>wait for log to be archived
  set buffer bkarc
  input
  set termout off verify off echo off feedback off heading off
  spool ${audit_path}/backup.${ORACLE_SID}.arc.status
  select archived from v\$log where status != 'CURRENT';
  spool off

  save bkarc replace
  start bkarc
END
  log_status="NO"
  sleep_ctr=0
  while [ ${log_status} = "NO" -a ${sleep_ctr} -lt 3 ]
  do
    grep "NO" ${audit_path}/backup.${ORACLE_SID}.arc.status >/dev/null
    if [ $? -eq 0 ]
    then
      log_status="NO"
      echo sleeping for 5 minutes ........................
      sleep 300
      sleep_ctr=`expr ${sleep_ctr} + 1`
      sqlplus -s system/${PASSWD} <<END
      start bkarc
END
    else
      log_status="YES"
    fi
  done
  if [ ${log_status} = "NO" ]
  then
    echo
    echo "WARNING====>log archive did not complete within 15 minutes"
    echo "       ====>continuing with backup process"
  fi
fi
sqlplus -s system/${PASSWD} <<END
/* ------------------------------------------------------------------------ */
/*     display current log status                                           */
/* ------------------------------------------------------------------------ */
prompt
prompt ====>Display current log status
select * from v\$log;
END
## Bypass log compression for 'ONLY' tablespace processing since the assumption
## is that multiple concurrent backups will be running and each should not
## be attempting to compress logs simultaneously. Schedule the log_compress
## script to run daily instead.
if [ ${only_sw} -eq 0 ]
then
  echo "====>query the oracle catalog for the name of the log archive dir"
  sqlplus -s system/${PASSWD} <<END >/dev/null
  set pagesize 0 feedback off verify off echo off termout off heading off
/* ------------------------------------------------------------------------ */
/*     query the oracle catalog for the name of the log archive dir         */
/* ------------------------------------------------------------------------ */
  spool ${audit_path}/bkdest.list
  select value
    from v\$parameter where name = 'log_archive_dest';
  spool off
  spool ${audit_path}/bkfmt.list
  select value
    from v\$parameter where name = 'log_archive_format';
  spool off
END
## ------------------------------------------------------------------------ ##
##     compress archive logs under the log archive directory                ##
## ------------------------------------------------------------------------ ##
  echo
  echo "====>compress archive logs >= 2 days under the log archive directory"
  echo
  arch_string=`cat ${audit_path}/bkdest.list`
  if [ -d $arch_string ]
  then
    arch_dest=$arch_string
    log_prefix=`awk -F"%s" '{print $1}' ${audit_path}/bkfmt.list`
  else
    arch_dest=`dirname $arch_string`
    log_prefix=`basename $arch_string`
  fi
  cd ${arch_dest}
  for logfile in `find . -name "$log_prefix*" -mtime +1 | egrep -v ".Z" | sort`
  do
    log=`basename $logfile`
    /usr/bin/compress -f < $log > $log.Z
    copyrc=$?
    from_bytes=`ls -l $log | awk '{print $5}'`
    if [ $copyrc -ne 0 -a $copyrc -ne 2 ]
    then
      echo "${log}"
      echo "#########################################################"
      echo "## ERROR ====> return code from compress command is " $copyrc
      echo "#########################################################"
      error_switch=1
      break
    else
      to_bytes=`ls -l $log.Z | awk '{print $5}'`
      echo "${log}    bytes: ${from_bytes} => ${to_bytes}"
      rm ${log} >/dev/null 2>&1
      if [ $copyrc -eq 2 ]
      then
        echo "#########################################################"
        echo "## WARNING ====> compressed file is larger than original"
        echo "#########################################################"
      fi
    fi
  done
  echo
## ------------------------------------------------------------------------ ##
##     select log history from Oracle and save under the log archive dir    ##
## ------------------------------------------------------------------------ ##
  sqlplus -s system/${PASSWD} > ${arch_dest}/version.log  2>&1 <<END
  exit
  END
  grep Oracle[8-9] version.log
  if [ $? -eq 0 ]
  then
    sqlplus -s system/${PASSWD} <<END >/dev/null
    set pagesize 1000 recsep off 
    spool ${arch_dest}/log_history.lst
    select sequence#, first_time, first_change#, next_change#
      from v\$log_history
      order by next_change# desc;
    spool off
 END
  else
    sqlplus -s system/${PASSWD} <<END >/dev/null
    set pagesize 1000 recsep off 
    spool ${arch_dest}/log_history.lst
    select archive_name,'    ',time,low_change#,high_change#
      from v\$log_history
      order by high_change# desc;
    spool off
 END
  fi
fi
sqlplus -s system/${PASSWD} <<END
set pagesize 1000 linesize 200 heading on feedback on
/* ------------------------------------------------------------------------ */
/*     backup control file to trace                                         */
/* ------------------------------------------------------------------------ */
prompt ====>backup controlfile to trace
alter database backup controlfile to trace noresetlogs;
END
echo "====>query the oracle catalog for the name of the user dump dir"
sqlplus -s system/${PASSWD} <<END >/dev/null
set pagesize 0 feedback off verify off echo off termout off heading off
/* ------------------------------------------------------------------------ */
/*     query the oracle catalog for the name of the user dump dir           */
/* ------------------------------------------------------------------------ */
spool ${audit_path}/bkdest.list
select value
  from v\$parameter where name = 'user_dump_dest';
spool off
END
## ------------------------------------------------------------------------ ##
##     copy the latest control file trace to the default backup directory   ##
## ------------------------------------------------------------------------ ##
echo
echo "====>copy the controlfile trace to the default backup directory"
dump_dest=`cat ${audit_path}/bkdest.list | awk '{
  if (substr($1,length($1),1) == "/") {print $1} else {print $1 "/"}}'`
cd ${dump_dest}
trc_count=`ls -t *ora* | wc -l | awk '{print $NF}'`
if [ ${trc_count} -gt 1 ]
then
  last_trc=`ls -t *ora* | sed -e 2,${trc_count}d`
else
  last_trc=`ls -t *ora*`
fi
echo
echo "Copying ${dump_dest}${last_trc} to ${default_dir}/control.create"
cp ${last_trc} ${default_dir}/control.create
## ------------------------------------------------------------------------ ##
##     For hot backups, execute an Oracle backup controlfile command        ##
##     to the default backup directory                                      ##
## ------------------------------------------------------------------------ ##
if [ ${backup_type} = "hot" ]
then
  if [ ${only_sw} -eq 1 ]
  then
    CONTROL_BACKUP=${default_dir}/ctl.back_${out_label}
  else
    CONTROL_BACKUP=${default_dir}/ctl.back_${fiscal_day}
  fi
  export CONTROL_BACKUP
  echo
  echo "====>backup current control file to ${CONTROL_BACKUP}"
  rm ${CONTROL_BACKUP} >/dev/null 2>&1
  sqlplus -s /nolog >${audit_path}/bkcontrol.list <<END
  connect / as SYSDBA
  alter database backup controlfile to '${CONTROL_BACKUP}';
  exit
END
  grep "ORA-" ${audit_path}/bkcontrol.list >/dev/null
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> backup of controlfile failed"
    cat ${audit_path}/bkcontrol.list | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
  fi
fi
## ------------------------------------------------------------------------ ##
##     copy the latest parameter file to the default backup directory       ##
## ------------------------------------------------------------------------ ##
echo
echo "====>copy the instance parameter file to the default backup directory"
echo
init_filename=`echo $init_file|awk -F/ '{print $NF}'`
echo "Copying ${init_file} to ${default_dir}/${init_filename}"
cp ${init_file} ${default_dir}/${init_filename}
## ------------------------------------------------------------------------ ##
##     display backup and archive filesystem usage statistics               ##
## ------------------------------------------------------------------------ ##
echo
echo "====>Display backup and archive filesystem usage statistics"
>${audit_path}/filesystem.list
while read backup_ctl
do
  if [ "$backup_ctl" = "" -o "`echo $backup_ctl | cut -c1`" = "#" -o \
       "`echo $backup_ctl | cut -c1-4`" = "ONLY"  -o \
       "`echo $backup_ctl | cut -c1-7`" = "TSGROUP"  -o \
       "`echo $backup_ctl | cut -c1-9`" = "FILEGROUP" ]
  then
    continue
  fi
  to_dir=`echo $backup_ctl | awk -F: '{print $2}'`
  filesys=`echo $to_dir | awk -F/ '{
    if (substr($2,1,2) == "us") {print $3} else {print $2}}'`
  grep $filesys ${audit_path}/filesystem.list >/dev/null 2>&1
  if [ $? -ne 0 ]
  then
    echo $filesys >> ${audit_path}/filesystem.list
  fi
done < ${backup_file}
sqlplus -s system/${PASSWD} <<END >/dev/null
set pagesize 0 feedback off verify off echo off termout off heading off
spool ${audit_path}/bkdest.list
select value
  from v\$parameter where name = 'log_archive_dest';
spool off
END
filesys=`cat ${audit_path}/bkdest.list | awk -F/ '{
  if (substr($2,1,2) == "us") {print $3} else {print $2}}'`
grep $filesys ${audit_path}/filesystem.list >/dev/null 2>&1
if [ $? -ne 0 ]
then
  echo $filesys >> ${audit_path}/filesystem.list
fi
if [ "`uname -a | cut -c1-2`" = "HP" ]
then
  cmd=bdf
else
  if [ "`uname -a | cut -c1-3`" = "Sun" ]
  then
    cmd="df -k"
  else
    cmd=df
  fi
fi
echo
$cmd | grep Filesystem
while read filesys
do
  $cmd | grep $filesys
done < ${audit_path}/filesystem.list
## ------------------------------------------------------------------------ ##
##     script wrapup processing                                             ##
## ------------------------------------------------------------------------ ##
echo
echo "************************************************************************"
echo "====>Script backup.sh ending on" `date`
echo "************************************************************************"
rm ${audit_path}/bkarc.sql >/dev/null 2>&1
rm ${backup_file}.sort >/dev/null 2>&1
rm ${audit_path}/backup.*.list >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.control >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.arc.status >/dev/null 2>&1
rm ${audit_path}/bkstatus.list > /dev/null 2>&1
rm ${audit_path}/bkactive.list > /dev/null 2>&1
rm ${audit_path}/bkdest.list > /dev/null 2>&1
rm ${audit_path}/bkfmt.list > /dev/null 2>&1
rm ${audit_path}/bkcontrol.list > /dev/null 2>&1
rm ${audit_path}/ora.error > /dev/null 2>&1
rm ${audit_path}/filesystem.list >/dev/null 2>&1
rm ${audit_path}/default.dir >/dev/null 2>&1
rm ${audit_path}/group.ctl > /dev/null 2>&1
rm ${audit_path}/group.id > /dev/null 2>&1
rm ${arch_dest}/version.log > /dev/null 2>&1
if [ ${only_sw} -eq 1 ]
then
  rm ${audit_path}/${only_file} >/dev/null 2>&1
fi
exit $error_switch
