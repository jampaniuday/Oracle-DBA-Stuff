#!/bin/ksh
# Script to flush shared_pool
# Usage  : flush.sh <sid>
. $HOME/bin/$1
passwd=`$HOME/bin/tellme system`
sqlplus -s system/$passwd <<EOF
alter system flush shared_pool;
exit
EOF
