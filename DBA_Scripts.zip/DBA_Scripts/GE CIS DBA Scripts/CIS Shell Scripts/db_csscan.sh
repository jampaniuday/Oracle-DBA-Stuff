##############################################################################################
# This script db_csscan.sh is ment to automate the csscan utility execution on each instance #
# The script can be executed as a stand alone using db_csscan.sh {sid|all} command or the    #
# can be scheduled to execute at specific intervals using utility.sh script by mentioning the#
# schedules in utility.ctl file.                                                             #
# The script will also mail the output files of csscan (.out .txt .err) to the users in      #
# mailing list. The script will tar the 3 files and will compress the tar file using gzip    #
# The zip file will then be mailed to the users in the mailing list.                         #
##############################################################################################
# Limitations :                                                                              #
# 1) The script must be executed from the Oracle OS user who is the owner for that instance. #
##############################################################################################
# Usage  : db_csscan.sh {sid|all}                                                            #
# Author : Ramesh.P                                                                          #
# Date   : 04-07-05                                                                          #
##############################################################################################
#### Notify function for autosys
notify() {
  parent_pid=`ps -o ppid -p $$ |tail -1`
  parent_program=`ps -o args -p ${parent_pid}|tail -1`
  echo $parent_program |grep utility.sh
  if [ "$?" != 0 ]
  then
    current_prog=`echo $0|sed -e 's/.*\///'`
    $DBA_HOME/admin/notify.sh -s "$current_prog ABEND" -b "$current_prog failure: Please look at audit file" -w sid
    $DBA_HOME/admin/notify.sh -p "$current_prog ABEND" -w sid
   fi
}
############################
if [ -z "$1" ]
then
   echo "Usage is : db_csscan.sh {sid|all} "
   notify ; exit 1
fi

if [ $1 = "all" ]
then
#   allsid=`ps -eo comm | grep pmon |grep -v arkq|grep -v epss| cut -d_ -f3|xargs echo`
    allsid=`ps -eo comm | grep pmon | cut -d_ -f3|xargs echo`
else
   ps -ef | grep pmon | grep $1 > /dev/null 2>&1
   if [ $? -eq 0 ]
   then
      allsid=$1
   else
      echo "Please check the SID, The instance must be up for this."
      notify ; exit 1
   fi
fi

if [ ! -d $DBA_HOME/audit/csscan ]
then
   mkdir $DBA_HOME/audit/csscan
fi

rm $DBA_HOME/audit/csscan/*instlist.txt 2>&1

for ALLS in $allsid
do
os_user=`ps -ef | grep pmon | grep $ALLS | awk '{print $1}'`
if [ "$os_user" = "$LOGNAME" ]
then
   echo "$ALLS " >> $DBA_HOME/audit/csscan/instlist.txt
else
   echo "$ALLS  --  $os_user" >> $DBA_HOME/audit/csscan/other_os_user_instlist.txt
fi
done

maillist="corpgts.oracleoperations@ge.com"

if [ -f $DBA_HOME/audit/csscan/other_os_user_instlist.txt ]
then
   mailx -s "Pls execute csscan script for these instances from the OS users mentioned below."  $maillist < $DBA_HOME/audit/csscan/other_os_user_instlist.txt
fi

for ALLS in `cat $DBA_HOME/audit/csscan/instlist.txt`
do
os_user=`ps -ef | grep pmon | grep $ALLS | awk '{print $1}'`
if [ -f $HOME/bin/$ALLS ]
then
. $HOME/bin/$ALLS
LD_LIBRARY_PATH=$ORACLE_HOME/lib:/usr/local/ActiveTcl/lib
export LD_LIBRARY_PATH
if [ "$ORACLE_SID" = "$ALLS" ]
then
pwd=`$HOME/bin/tellme system`
sqlplus -s system/$pwd <<EOF >$SID_HOME/audit/cerr.err
EOF

   connerr=`grep "SP2" $SID_HOME/audit/cerr.err`
   sqlerr=`grep "ORA-" $SID_HOME/audit/cerr.err`

   if [ ! -z "$connerr" -o ! -z "$sqlerr" ]
   then
      echo "Script Terminated."
      echo "Please check the $SID_HOME/audit/cerr.err log file for more information."
      notify ; exit 1
   fi

sqlplus -s system/$pwd <<EOF >$SID_HOME/audit/cerr.err
set head off
select decode(username,'CSMIG','TRUE',username) from dba_users where username='CSMIG';
exit
EOF
 
   grep "TRUE" $SID_HOME/audit/cerr.err 2>&1

   if [ $? -ne 0 ] 
   then
sqlplus "/as sysdba" << EOF > $SID_HOME/audit/cerr.log
@?/rdbms/admin/csminst.sql
exit
EOF
   fi 

   logloc=$DBA_HOME/audit/csscan
   logname=$1_`date +"%m%d%y"`

   $ORACLE_HOME/bin/csscan userid=system/$pwd parfile=$SID_HOME/admin/csscan.param log=$logloc/$logname 2>$logloc/csscan_error.log

   grep "Scanner terminated successfully." $logloc/$logname.out 2>&1

   if [ $? -ne 0 ] 
   then
	uuencode $logloc/csscan_error.log csscan_error.log | mailx -s "$ALLS Instance CSSCAN Failed." $maillist
   else
	tar -cvf $logloc/$logname.tar $logloc/$logname* 2>&1
        gzip -S ".z" $logloc/$logname.tar 2>&1
	uuencode $logloc/$logname.tar.z $logname.tar.z | mailx -s "Pls find $ALLS Instance CSSCAN Results." $maillist
   fi
fi
fi
mv $logloc/csscan_error.log $logloc/$logname_csscan_error.log
done
