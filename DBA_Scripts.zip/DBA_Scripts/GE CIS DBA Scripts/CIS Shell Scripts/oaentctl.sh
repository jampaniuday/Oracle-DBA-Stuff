#!/bin/ksh
# +============================================================================+
# | FILENAME
# |   oaentctl.sh
# |
# | DESCRIPTION
# |   Start / Stop Enterprise Connector for requested Oracle instance
# |
# | USAGE
# |   oaentctl.sh {start|stop} $ORACLE_SID
# |
# | MODIFICATIONS
# |
# +============================================================================+

typeset -i classpid
exit_status=0

echo $PATH | grep "xpg4">/dev/null
if [ $? -ne 0 ]
then
  PATH=/usr/xpg4/bin:$PATH; export PATH
fi

if [ $# -lt 2 ]
then
   echo ""
   echo "oaentctl.sh: too few arguments specified."
   echo ""
   echo "Usage is oaentctl.sh {start|stop|status} $ORACLE_SID"
   echo ""
   exit 1
fi

control_code="$1"

if test "$control_code" != "start" -a "$control_code" != "stop" -a "$control_code" != "status"
then
   echo ""
   echo "oaentctl.sh: You must specify either 'start' or 'stop' or 'status'"
   echo ""
   exit 1
fi

DB_NAME="$2"

user=`id|cut -d"(" -f2|cut -d")" -f1`
user=`echo $user|cut -c1-7`
if [ "$user" != "applmgr" ]
then
   echo "Error: You are not logged on to an applmgr account"
   exit 1
fi

#
# setup the environment for Oracle and Applications
#
oracle_id=`ls -l $0 | awk '{print $3}'`
ohome=`grep "^${oracle_id}:" /etc/passwd | cut -f6 -d:`
if [ ! -f $ohome/bin/$2 ]
then
   echo "Oracle environment file for database $DB_NAME is not found"
   exit 1
else
   unset MRO_LIB_CLASSPATH
   . $ohome/bin/$2
fi


if [ -z "$MRO_TOP" ]; then
  echo ""
  echo "oaentctl.sh: MRO_TOP variable is not defined"
  echo ""
  exit 1
fi

if [ ! -d "$MRO_TOP/admin/$ORACLE_SID" ]; then
  echo ""
  echo "oaentctl.sh: $MRO_TOP/admin/$ORACLE_SID not found"
  echo ""
  exit 1
fi
inst_admindir=$MRO_TOP/admin/$ORACLE_SID
logdir=${inst_admindir}/logs


if test "$control_code" = "start"
then
  MRO_JAVA_TOP=$GECMPO_TOP/java/ent_connector
  if [ ! -d "$MRO_JAVA_TOP" ]; then
    echo 
    echo "oaentctl.sh - directory $MRO_JAVA_TOP not found"
    echo
    exit 1
  fi
  # Feb-17-2003 - DLB removed :$CLASSPATH from end of the following line
  if [ -z "$MRO_LIB_CLASSPATH" ]; then
    MRO_LIB_CLASSPATH=$JAVA_TOP/jdbc12.zip:$MRO_JAVA_TOP/lib/aqapi.jar:$MRO_JAVA_TOP/lib/aqapi11.jar
  fi
  CLASSPATH=${MRO_LIB_CLASSPATH}:$MRO_JAVA_TOP/lib/router.jar:$MRO_JAVA_TOP/lib/servlet.jar:$MRO_JAVA_TOP/lib/client.jar:$MRO_JAVA_TOP/lib/xerces.jar:$MRO_JAVA_TOP/lib/xalanj1compat.jar:$MRO_JAVA_TOP/lib/xalan.jar:.:$CLASSPATH
  #CLASSPATH=$JAVA_TOP/jdbc12.zip:$MRO_JAVA_TOP/lib/aqapi.jar:$MRO_JAVA_TOP/lib/aqapi11.jar:$MRO_JAVA_TOP/lib/router.jar:$MRO_JAVA_TOP/lib/servlet.jar:$MRO_JAVA_TOP/lib/client.jar:$MRO_JAVA_TOP/lib/xerces.jar:$MRO_JAVA_TOP/lib/xalanj1compat.jar:$MRO_JAVA_TOP/lib/xalan.jar:.
  export CLASSPATH

  cfgfile="${inst_admindir}/config/MROSettings.prop"
  if [ ! -e ${cfgfile} ]; then
    echo ""
    echo "oaentctl.sh:  Cannot find configuration file \"${cfgfile}\"."
    echo ""
    exit 2
  fi
  
  logdir="${inst_admindir}/logs"
  if [ ! -d ${logdir} ]; then
    echo ""
    echo "oaentctl.sh: Directory \"${logdir}\" does not exist."
    echo ""
    exit 2
  fi


  for classname in MROInbound MROOutbound; do
    is_running=false
    logfile="${logdir}/nohup-${classname}.log"
    pidfile="${logdir}/${classname}.pid"
    if [ -f "$pidfile" ]; then
      classpid=`cat $pidfile`
      if [ `ps -f -p $classpid | grep -c java` -gt 0 ]; then
        echo ""
        echo "oaentctl.sh: $classname is already running for $ORACLE_SID"
        ps -f -p $classpid
        exit_status=1
        is_running=true
      else
        echo ""
        echo "oaentctl.sh: found file ${pidfile} but no process"
        echo " -- check logs for ungraceful termination"
        echo " will restart process now"
        sleep 2
      fi
    fi
    if [ "$is_running" = "false" ]; then
      for nextlog in `ls ${logdir}/*${classname}.log `
      do
        # roll log files
        highest_version=`ls ${nextlog}.* 2>/dev/null | awk -F. '{print $NF}' | sort -n | tail -1`
        if [ ! -z "$highest_version" ]
        then
          # found $nextlog.[0-9]+  --- rename each file increasing version number
          # by 1 (access_log.3 will become access_log.4 )
          version=$highest_version
          while [ $version -gt 0 ]
          do
            new_version=`expr $version + 1`
  	  if [ -f "${nextlog}.${version}" ] 
  	  then
              mv ${nextlog}.${version} $nextlog.${new_version}
  	    chmod g+w $nextlog.${new_version}
  	  fi
            version=`expr $version - 1`
          done
        fi
        if [ -f "$nextlog" ]; then
          mv ${nextlog} ${nextlog}.1
          chmod g+w ${nextlog}.1
        fi
      done
    
      currdir=$PWD
      cd $MRO_JAVA_TOP
      echo "Starting $classname at `date`" >>$logfile
      echo "Using the following classpath:" >> $logfile
      echo "$CLASSPATH" | sed 's/:/:\\\
/g'>> $logfile
      nohup java -Xms64M -Xmx256m ${classname} ${cfgfile} 2>&1 >> ${logfile} &
      status=$?
      pid=$!
      echo "${pid}" > ${pidfile}
      if [ $status -ne 0 ]; then
        echo ""
        echo "oaentctl.sh: Unable to start $classname"
        echo ""
        exit_status=3
      fi
   fi
  done
  if [ "$exit_status" -eq 0 ]; then
    # sleep will need to increasse
    sleep 10
    for classname in MROInbound MROOutbound; do
      pidfile="${logdir}/${classname}.pid"
      if [ -f "$pidfile" ]; then
        classpid=`cat $pidfile`
        if [ `ps -f -p $classpid | grep -c java` -eq 0 ]; then
          echo ""
          echo "oaentctl.sh: $classname is not running for $ORACLE_SID"
          echo "Please check log files in $logdir"
          exit_status=3
        fi
      fi
    done
  fi
else
  if test "$control_code" = "stop"
  then
    for classname in MROInbound MROOutbound; do
      logfile="${logdir}/nohup-${classname}.log"
      pidfile="${logdir}/${classname}.pid"
      if [ -f $pidfile ]; then
        echo "`date`: Shutting down $classname" >> $logfile
        echo Killing $classname ...
        echo killing the following:
        /usr/ucb/ps -ww `cat $pidfile `
        if [ $? -eq 0 ]; then
          kill -9 `cat $pidfile `
        fi
        if [ $? -eq 0 ]; then
          rm $pidfile
        fi
      else
        echo
        echo file $pidfile not found -- could not stop $classname
        echo
      fi
    done
  else
    # status
    for classname in MROInbound MROOutbound; do
      pidfile="${logdir}/${classname}.pid"
      echo ""
      echo "Status $classname ..."
      if [ ! -f $pidfile  ] ;then
         echo unable to determine process id 
         echo
         this_pid=-1
       else
         this_pid=`cat $pidfile`
         ps -f -p $this_pid
       fi
    done
    echo ""
  fi #stop
fi 


echo ""
echo "oaentctl.sh: exiting with status $exit_status"
echo ""

exit $exit_status
  
