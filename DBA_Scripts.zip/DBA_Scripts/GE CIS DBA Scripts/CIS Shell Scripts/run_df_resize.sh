. /opt/oracle/bin/d1hems
sqlplus '/as sysdba' <<EOF
@/db037/dba01/oracle/admin/resize/d1hems.sql
Exit;
EOF
echo "Datafiles Resized on d1hems" 
#####################################################
