#!/bin/ksh

## Purpose		:	To get max sessions for an instance
## Script		:	session_dtl.sh
## Usage		:	session.sh <Oracle SID>
## Created by	:	Satyen Jadia
## Date Created	:	Sep 2nd '98

## Verify usage

if [ -z "$1" ]
then
  echo "Error : Invalid usage, try again."
  echo "Usage : session_dtl.sh <Oracle SID>"
  echo "Script is terminating."

  exit 1
fi

## Verify whether instance is under usage patrol

if [ ! -f $HOME/bin/licdb.ctl ]
then
  echo "Error : Control file licdb.ctl does not exists."
  echo "Script is terminating."

  exit 1
fi

db_usage=`grep "$1" $HOME/bin/licdb.ctl`

if [ -z "$db_usage" ]
then
  echo "Database instance, $1, is not under usage patrol."
  echo "Script is terminating."

  exit 0
fi

## Verify instance environment script exists

if [ ! -f $HOME/bin/$1 ]
then
  echo "Error : Instance environment script does not exists for, $1."
  echo "Script is terminating."

  exit 1
fi

## Setup instance environment

. $HOME/bin/$1

## Get password for system

passwd=`$HOME/bin/tellme system`

if [ -z "$passwd" ]
then
  echo "Error : Null password for system, cannot connect to instance $1."
  echo "Script is terminating."

  exit
fi

## Query dynamic performance table v$license for max no. of sessions

sqlplus -s system/$passwd << EOF > $SID_HOME/audit/ora.error
set heading off echo off feedback off
spool $SID_HOME/audit/sessions.lst
select sessions_highwater from v\$license ;
spool off
EOF

## Check for errors

err=`grep "ORA-" $SID_HOME/audit/ora.error`

if [ ! -z "$err" ]
then
  echo "Error : Cannot query v$license."
  echo "Script is terminating."

  exit 1
fi

## Set variable no_of_sessions to high watermark

no_of_sessions=`cat $SID_HOME/audit/sessions.lst`

if [ -z "$no_of_sessions" ]
then
  echo "Error : No records selected."
  echo "Script is terminating."

  exit 1
fi

## Insert sessions data into sesions_detail

sqlplus -s system/$passwd << EOF > $SID_HOME/audit/ora.error
set heading off feedback off echo off
insert into sessions_detail
values (sessid.nextval, sysdate, $no_of_sessions) ;
commit ;
EOF

## Check for errors

err=`grep "ORA-" $SID_HOME/audit/ora.error`

if [ ! -z "$err" ]
then
  echo "Error : Cannot update sessions_detail."
  echo "Script is terminating."

  exit 1
fi

echo "Updated successfully sessions_detail for no. of sessions."

rm $SID_HOME/audit/ora.error
rm $SID_HOME/audit/sessions.lst

exit 0
