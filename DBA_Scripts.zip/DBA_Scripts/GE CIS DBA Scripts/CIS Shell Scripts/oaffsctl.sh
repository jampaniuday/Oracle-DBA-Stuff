#!/bin/ksh
# +============================================================================+
# | FILENAME
# |   oactxctl.sh
# |
# | DESCRIPTION
# |   Start / Stop FNDFS listenener for Server
# |
# | USAGE
# |   oaffsctl.sh {start|stop} 
# |
# +============================================================================+
exit_code=0

if [ $# -lt 1 ]
then
   echo ""
   echo "oaffsctl.sh: too few arguments specified."
   echo ""
   echo "Usage is  oafffsctl.sh {start|stop|status} "
   echo ""
   exit 1
fi

control_code="$1"

if test "$control_code" != "start" -a "$control_code" != "stop" -a "$control_code" != "status"
then
   echo ""
   echo "oaffsctl.sh: You must specify either 'start' or 'stop' or 'status'"
   echo ""
   exit 1
fi

#
# setup the environment for Oracle and Applications
#
#ohome=`cat /etc/passwd | awk -F: '{
#  if ($1 == "oracle") {print $6}}'`
if [ -z "$APP" ]                                              
then                                                          
        echo "Environment variable APP is not set "           
        echo " APP is the Application name like HR,SSS etc"   
        exit 0                                                
else                                                          
        if [ $APP = "SSS" -o $APP = "sss" ]                                 
        then                                                  
                ohome=`cat /etc/passwd | awk -F: '{           
                if ($1 == "oracle") {print $6}}'`             
        fi                                                    
        if [ $APP = "HR" -o $APP = "hr" ]                                  
        then                                                  
                ohome=`cat /etc/passwd | awk -F: '{           
                if ($1 == "oracle50") {print $6}}'`           
        fi                                                    
fi                                                            
                                                              
                                                              
                                                              
fndfs_env=`grep ^fndfs: $ohome/bin/oraapp.ctl | cut -d: -f3`
if [ ! -f $ohome/bin/$fndfs_env ]
then
  echo "Error====>Unable to find script $fndfs_env"
  echo "  to set environment for FNDFS "
  echo "          Script is terminating!"
  exit 1
fi
. $ohome/bin/$fndfs_env

if test "$control_code" = "start"
then
  lsnrctl start lstnfndfs
  tmpstat=$?
  if [ $tmpstat -ne 0 ]
  then
    echo Unable to start FNDFS Listener
    exit_code=$tmpstat
  else
    if [ `ps -ef | grep inherit | grep -c fndfs` -eq 0 ]
    then
      echo "################################################################"
      echo "###ERROR====>FNDFS Listener failed to start                  ###"
      echo "################################################################"
      echo
      exit_code=1
    fi
  fi
elif test "$control_code" = "stop"
then
  lsnrctl stop lstnfndfs
  tmpstat=$?
  if [ $tmpstat -ne 0 ]
  then
    echo Unable to stop FNDFS Listener
    exit_code=$tmpstat
  else
    if [ `ps -ef | grep inherit | grep -c fndfs` -ne 0 ]
    then
      echo "################################################################"
      echo "###ERROR====>FNDFS Listener is still running                 ###"
      echo "################################################################"
      echo
      exit_code=1
    fi  
  fi
else
#status
  lsnrctl status lstnfndfs
fi

echo ""
echo "oaffsctl.sh: exiting with status $exit_code"
echo ""

exit $exit_code
