#! /usr/bin/ksh 
ps -aux|grep top|grep -v grep |grep -v "/usr/bin" > /tmp/top.out
while read li 
do
cpu_usage=`echo $li|awk '{print $3}'|cut -d. -f1`
cpu_time=`echo $li |awk '{print $10}'|cut -d: -f1`
if [ $cpu_usage -ge 25 ] || [ $cpu_time -ge 1800 ]
then 
#   echo *|mailx -s "top consuming high cpu on server  `hostname`" sumit.mondaiyka@ge.com < /tmp/top.out
$DBA_HOME/admin/notify.sh -s "top consuming high cpu on server  `hostname`" -f /tmp/top.out
else
    echo allgood 
#   echo *|mailx -s "top consuming high cpu on server  `hostname`" sumit.mondaiyka@ge.com < /tmp/top.out
fi
done </tmp/top.out
