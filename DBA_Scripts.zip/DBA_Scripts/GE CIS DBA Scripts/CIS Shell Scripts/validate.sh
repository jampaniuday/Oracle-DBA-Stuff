#!/bin/ksh
########################################################################        
##                                                                              
##  validate.sh 
##	To validate the structure of a given schema.
##	Requires valid SID and schema name as parameters.
## 	Validates the entire schema.
##	If the user does not exist or has no tables
##	the script terminates with an error condition.
##
##	Stefan Estus
##	10/10/97

# NT_MOD
OS_TYPE=`uname`
if [ "`echo $OS_TYPE | grep NT`" ]
then
    SVRMGR=svrmgr23
	SQLPLUS=plus33
	COMPRESSION=N
	COMP_EXTENTION=
	OS_TYPE=NT
else
    SVRMGR=svrmgrl
	SQLPLUS=sqlplus
	COMPRESSION=Y
	COMP_EXTENTION=.Z
	OS_TYPE=UNIX
fi

PWD=`$HOME/bin/tellme system`

echo "################################################"
echo "Starting validate.sh on `date`          "
echo "################################################"

if [ ! "$1" ]
then
    echo "#####################################################"
    echo "ERROR: No SID given."
    echo "#####################################################"
    exit 1
fi

if [ ! "$2" ]
then
    echo "#####################################################"
    echo "ERROR: No schema given."
    echo "#####################################################"
    exit 1
fi

if [ $OS_TYPE = "NT" ]
then
        $SVRMGR <<EOF > $SID_HOME/audit/up.tmp
		connect internal
	exit
EOF
    if [ "`grep -e ORA- -e idle $SID_HOME/audit/up.tmp`" ]
	then
        echo "#####################################################"
        echo "Instance $SID is not up."
        echo "#####################################################"
        exit 1
	fi
	rm $SID_HOME/audit/up.tmp 
else
	if [ ! "`ps -ef|grep pmon_$1|grep -v grep`" ]
	then
        echo "#####################################################"
        echo "Instance $SID is not up."
        echo "#####################################################"
        exit 1
	fi
fi

FOUND=`$SQLPLUS -s system/$PWD <<EOF
        set heading off
        select count(*) from dba_users
        where username = upper('$2');
EOF
`

# NT_MOD
if [ "`echo $FOUND | grep 0`" ]
then
    echo "#####################################################"
    echo "ERROR: User $2 does not exist."
    echo "#####################################################"
	exit 1 
fi

TABLES=`$SQLPLUS -s system/$PWD <<EOF
        set heading off
        select count(*) from dba_tables
        where owner = upper('$2');
EOF
`

# NT_MOD
if [ $TABLES -eq 0 ]
then
    echo "#####################################################"
    echo "ERROR: User $SCHEMA does not own any tables."
    echo "#####################################################"
    exit 1
fi     

$SQLPLUS -s SYSTEM/$PWD <<EOF 
	set heading off
`	$SQLPLUS -s SYSTEM/$PWD <<END
		spool $SID_HOME/audit/validate.$2.error	
		set recsep off
		set echo on
		set linesize 255 
		col line1 format a254
		set heading off
		set verify off
		set pagesize 9999
		select 	'select ''VALIDATING '||owner||'.'||table_name||''' from dual;' line1,	
				'ANALYZE TABLE '||owner||'.'||table_name||
				' VALIDATE STRUCTURE CASCADE;'
		from	dba_tables
		where	owner = UPPER('$2');
		spool off
		quit
END
` 
EOF

if [ "`grep -e ORA- $SID_HOME/audit/validate.$2.error`" ]
then
		echo "##############################################"
		echo "Errors were found for user $2"
		echo "##############################################"
        exit 1
else
        rm -f $SID_HOME/audit/validate.$2.error
       	exit 0 
fi

exit 0
