#!/bin/sh
# Script to manage the statspack.
# Script will enable users to run statspack.snap
# Script will run spreports given interations to run
# Script will run the purge routine
# 5/16/2006 Paul Krempa
#
#
SID=$1
# Verify sid input
if [ -z "$SID" ]
then
  echo "A sid needs to be entered"
  echo $"Usage: $0 (<sid> snapshot |<sid> purge <iterations>|<sid> report <iterations>|choose <sid>|<sid> samplecron)"
  exit 1
fi

# Set the instance environment
if [ ! -f $HOME/bin/$SID ]
then
  echo "The environment file in $HOME/bin/ does not exist"
  echo $"Usage: $0 (<sid> snapshot |<sid> purge <iterations>|<sid> report <iterations>|choose <sid>|<sid> samplecron)"
  exit 1
fi
. $HOME/bin/$SID
PERFSTATRUNERROR=$SID_HOME/audit/perf.err


# List of files needed for wrapper scrit to run
# if they don't exist then exit
SCRIPTDIR=$DBA_HOME/admin
errorcount=0
for file in gestatspack.sh ge_statsrep.sh gesss_sppurge.sql ge_spreport.sql ge_sprepins.sql delete_commit.sql gesss_sppurge.sh
do
fullfile=$SCRIPTDIR/$file
if [ ! -f "$fullfile" ]
then
 echo "A file needed is not found - $fullfile "
 errorcount=`expr $errorcount + 1`
fi
done

if [ "$errorcount" -gt 0 ]
then
echo " Check and make sure you have the needed files"
exit 1

fi

# Check if database is up, if not exit

if  [ ! "`ps -ef|grep pmon_$SID|grep -v grep`" ]
  then
     echo "#####################################################"
     echo "Instance $SID is not up."
     echo "#####################################################"
     exit 1
fi



# Run the  cases
case "$2"  in

snapshot)
# Run Statspack.snap to take a manual snapshot
echo snapshot taken at `date +%m%d%y-%H:%M`
PASSWD=`$HOME/bin/tellme perfstat`
    sqlplus perfstat/$PASSWD <<EOF >$PERFSTATRUNERROR
    execute statspack.snap;
    exit
EOF
;;
purge)

if [ -z "$3" ]
then
echo "You need to include the number of iterations...exiting"
exit 1
else 
echo  "$DBA_HOME/admin/gesss_sppurge.sh $SID $3"
$DBA_HOME/admin/gesss_sppurge.sh $SID $3

fi
;;
report)

if [ -z "$3" ]
then
echo "You need to include the number of iterations...exiting"
exit 1
else
echo "$DBA_HOME/admin/ge_statsrep.sh $SID $3"
$DBA_HOME/admin/ge_statsrep.sh $SID $3
fi

;;
choose)
# Runs the Normal Stats pack listed in the Oracle Home for the SID choosen
echo entering spreport
PASSWD=`$HOME/bin/tellme perfstat`
    sqlplus perfstat/$PASSWD @$ORACLE_HOME/rdbms/admin/spreport.sql 
echo existing spreport
;;
samplecron)
echo
echo "Here are some example cron tab entries"
echo
echo "##########################################################################################################################"
echo "0 19 * * * $DBA_HOME/admin/gestatspack.sh $SID report 8 > $SID_HOME/audit/statsrep.audit.$SID.\`date +\%m\%d\` 2>&1"
echo "0 20 * * * $DBA_HOME/admin/gestatspack.sh $SID purge 240 > $SID_HOME/audit/statspurge.audit.$SID.\`date +\%m\%d\` 2>&1"
echo "0 0-23 * * * $DBA_HOME/admin/gestatspack.sh $SID snapshot  >> $SID_HOME/audit/statssnap.audit.$SID.\`date +\%m\%d\` 2>&1"
echo "##########################################################################################################################"

;;

*)
	echo $"Usage: $0 (<sid> snapshot |<sid> purge <iterations>|<sid> report <iterations>|choose <sid>|<sid> samplecron)"
;;

esac
