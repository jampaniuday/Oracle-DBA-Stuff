#!/bin/ksh
# +============================================================================+
# | FILENAME
# |   oaentctl.sh
# |
# | DESCRIPTION
# |   Start / Stop Appworx 
# |
# | USAGE
# |   oaawxctl.sh {start|stop} 
# |
# | MODIFICATIONS
# |
# +============================================================================+

exit_status=0

echo $PATH | grep "xpg4">/dev/null
if [ $? -ne 0 ]
then
  PATH=/usr/xpg4/bin:$PATH; export PATH
fi

if [ $# -lt 1 ]
then
   echo ""
   echo "oaawxctl.sh: too few arguments specified."
   echo ""
   echo "Usage is oaawxctl.sh {start|stop|status}"
   echo ""
   exit 1
fi

control_code="$1"

if test "$control_code" != "start" -a "$control_code" != "stop" -a "$control_code" != "status"
then
   echo ""
   echo "oaawxctl.sh: You must specify either 'start' or 'stop' or 'status'"
   echo ""
   exit 1
fi

user=`id|cut -d"(" -f2|cut -d")" -f1`
if [ "$user" != "appworx" ]
then
   echo "Error: You must be appworx to run this script"
   exit 1
fi

SQLOPER_HOME=`grep '^appworx:' /etc/passwd | cut -f6 -d:`
if [ -z "$SQLOPER_HOME" ]; then
  echo ""
  echo "oaawxctl.sh: unable to determine Appworx home directory"
  echo ""
  exit 1
fi

PATH=$SQLOPER_HOME/bin:$PATH
export PATH
if [ ! -f "$SQLOPER_HOME/site/sosite" ]; then
  echo ""
  echo "oaawxctl.sh: Appworx environment script not found"
  echo ""
  exit 1
fi
. $SQLOPER_HOME/site/sosite

if [ "$control_code" = "start" ]; then
  if [`pgrep -U appworx -f '(awsrv)|(sotcpd)' |wc -l` -eq 1 ]; then
    echo "`date`: Only one process of awsrv and sotcpd is running:"
    pgrep -U appworx -f '(awsrv)|(sotcpd)' -l
    $SQLOPER_HOME/bin/awxshut.sh 2>&1 >> $SQLOPER_HOME/audit/awxshut.audit 2>&1
  fi  
  if [`pgrep -U appworx -f '(awsrv)|(sotcpd)' |wc -l` -eq 2 ]; then
    echo "`date`: Appworx is already running:"
    pgrep -U appworx -l | grep -v grep
    exit_status=0
  else
    echo "`date`: starting Appworx ..."
    $SQLOPER_HOME/bin/awxstart.sh 2>&1 >> $SQLOPER_HOME/audit/awxstart.audit 2>&1
    #cat $SQLOPER_HOME/audit/awxstart.audit 
  fi
  if [`pgrep -U appworx -f '(awsrv)|(sotcpd)' |wc -l` -ne 2 ]; then
    echo "`date`: Appworx may not be running correctly"
    ps -ef | grep appworx | grep -v grep
    echo "View $SQLOPER_HOME/audit/awxshut.audit for details"
    exit_status=1 
    else
      echo "Appworx successfully started. View $SQLOPER_HOME/audit/awxshut.audit for details"
  fi
else
  if [ "$control_code" = "stop" ]; then
    if [`pgrep -U appworx -f '(awsrv)|(sotcpd)' |wc -l` -ne 0 ]; then
      echo "`date`: Stopping Appworx ..."
      $SQLOPER_HOME/bin/awxshut.sh 2>&1 >> $SQLOPER_HOME/audit/awxshut.audit
      #cat $SQLOPER_HOME/audit/awxshut.audit 
    fi
    if [`pgrep -U appworx -f '(awsrv)|(sotcpd)' |wc -l` -ne 0 ]; then
      echo "oaawxctl.sh: Not all processes were stopped successfully"
      ps -ef | grep appworx
      exit_status=1
      echo "View $SQLOPER_HOME/audit/awxshut.audit for details"
    else
      echo "Appworx successfully stopped. View $SQLOPER_HOME/audit/awxshut.audit for details"
    fi
  else
    #status
    ps -ef | grep appworx | grep -E '(awsrv)|(sotcpd)' | grep -v grep
    echo ""
    $SQLOPER_HOME/bin/awstat
  fi
fi

echo ""
echo "oaawxctl.sh: exiting with status $exit_status"
echo ""

exit $exit_status
  
