#!/bin/ksh
FILEPATH="/tmp"

rmbackup(){

        ls -ltr $backup_location/oracle/$ORACLE_SID/data/*.Z > $backup_location/oracle/$ORACLE_SID/data/file_copied.out
        for file in `cat $backup_location/oracle/$ORACLE_SID/data/file_copied.out|awk '{print $9}'`
                do
                echo " $file File Removed"
                rm $file
                done
}

switchlogfile(){

        alter system switch logfile;
}


rmarch(){
sqlplus /nolog <<EOF >$FILEPATH/$ORACLE_SID.log

set head off
conn / as sysdba;

alter system switch logfile;
alter system switch logfile;
switchlogfile
set pagesize 100
set linesize 120

select destination value
  from v\$archive_dest
  where destination is not null
  and status='VALID'
  and target='PRIMARY'
  and rownum=1
union
select value
 from v\$parameter where name = 'log_archive_dest';
exit;
EOF
arch_destination="`cat $FILEPATH/$ORACLE_SID.log|grep $ORACLE_SID`"
cd $arch_destination
echo $arch_destination

######## Condition to check archs gone to tape or not#####

if [ -a log_to_tape.list ]
then

	cp log_to_tape.list $FILEPATH/log_to_tape.list.old
	cp log_history.lst  $FILEPATH/log_history.lst

for file in `cat log_to_tape.list`
do
 if [ -e $file ]
 then
  echo " $file Arch File Removed"
  rm $file
 fi
done

	mv $FILEPATH/log_to_tape.list.old $arch_destination/log_to_tape.list.old
	mv $FILEPATH/log_history.lst $arch_destination/log_history.lst
elif [ ! -a log_to_tape.list ]
then
        echo " Archives not gone to tape"
fi
}
######## Condition to check archs gone to tape or not End #######
if [ -z "$1" ]
        then
                echo "Error===>Required parameter is missing"
                echo "         Usage is clean_arch_backup.sh sid (backup/arch) "
                echo "         Script is terminating!"
$DBA_HOME/admin/notify.sh -s "Arch removal job failed pls check logfile " -b "Error===>Required parameter is missing" -w sid
        exit 1
                else
                ORACLE_SID=$1
                export ORACLE_SID

  # Set the instance environment
                if [ ! -f $HOME/bin/$1 ]
                        then
                echo "Error====>No environment script found for instance \"$1\""
                echo "          Script is terminating!"
$DBA_HOME/admin/notify.sh -s "Arch removal job failed pls check logfile " -b "Error====>No environment script found for instance \"$1\"" -w sid
                exit 1
        else
        ps -ef | grep pmon | grep $1 > /dev/null 2>&1
                        if [ $? -eq 0 ]
                                then
                                        ORACLE_SID=$1
                                        export ORACLE_SID
                                else
                                echo "Please check the SID, The instance must be up."
$DBA_HOME/admin/notify.sh -s "Arch removal job failed pls check logfile " -b "Please check the SID, The instance must be up" -w sid
                                exit 1
                        fi
                fi
  . $HOME/bin/$1
fi
# Verify param input
if [ -z "$2" ]
then
  echo "Error===>Required parameter is missing"
  echo "         Usage is clean_arch_backup.sh sid (backup/arch)"
  echo "         Script is terminating!"
$DBA_HOME/admin/notify.sh -s "Arch removal job failed pls check logfile " -b "Error===>Required parameter is missing" -w sid

  exit 1
else
  if [ "$2" = "backup" -o "$2" = "arch" ]
  then
    param=$2
  else
    echo "Error===>Required parameter is invalid"
    echo "         Value must be backup|arch"
    echo "         Script is terminating!"
$DBA_HOME/admin/notify.sh -s "Arch removal job failed pls check logfile " -b "Error===>Required parameter is invalid" -w sid

        exit 1
  fi
fi
backup_file=$SID_HOME/admin/backup.ctl
if [ $param = "backup" ]
then
  if [ ! -f $backup_file ]
  then
    echo "Error====>Backup control file does not exist"
    echo "          Script is terminating!"
$DBA_HOME/admin/notify.sh -s "Backup file removal job failed pls check logfile " -b "Error====>Backup control file does not exist" -w sid
  else
 backup_location="`cat $SID_HOME/admin/backup.ctl|awk -F: '{print $2}'`"
        rmbackup
   fi
   elif [ $param = "arch" ]
                then
                        rmarch
fi

