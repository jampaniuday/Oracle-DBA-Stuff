#!/usr/bin/ksh
# To monitor and get the sql for blocking locks
# name :lock_mon.sh 
# Created : Ranjit Mhatre 
###########################################
if [ $# -ne 1 ]
then
	echo "USAGE: $0 <SID>"
	exit 1
fi

. $HOME/bin/$1
oncall=`grep "all:all" $HOME/bin/notify.ctl | cut -d: -f3`
pgoncall=`grep "#$oncall" $HOME/bin/notify.ctl | cut -d: -f2`
mailme="$pgoncall GTSOHRDBA@corporate.ge.com"
stop_me=1
while [ $stop_me -ne 0 ]
do
if [ ! -f $SID_HOME/audit/stopmon1 ]
then
sqlplus -s system/`$HOME/bin/tellme system` <<EOF
set linesize 132 
set pagesize 0 linesize 80 feedback off verify off echo off termout off heading off
spool $SID_HOME/audit/lock_mon.lst
select /*+ RULE */ session_id                   
from dba_locks                         
where blocking_others = 'Blocking' and 
mode_held != 'None' and                
mode_held != 'Null'; 
EOF
lcount=`cat $SID_HOME/audit/lock_mon.lst|wc -l`
echo $lcount `date`
if [ $lcount -ge 1 ]
then
### To stop the script on first lock occurance make this to 0 
	stop_me=1
##RR	echo "please check $SID_HOME/audit/DEAD_LOCK_INFO.lst"|mailx -s "Blocking lock Found in production $1" $mailme
	echo "please check $SID_HOME/audit/DEAD_LOCK_INFO.lst"|mailx -s "Blocking lock Found in production $1" mhatrer@corporate.ge.com

##RR	echo "please check $SID_HOME/audit/DEAD_LOCK_INFO.lst"|mailx -s "Blocking lock Found in production $1 " 07659185675@paging.vodafone.net
cd $DBA_HOME/admin
sqlplus -s system/`$HOME/bin/tellme system` <<EOF >>$SID_HOME/audit/DEAD_LOCK_INFO.lst
set serveroutput on;
set echo off head off;
set linesize 132;
set long 2000;
select to_char(sysdate,'MM/DD/YYYY:HH:MI:SS') from dual;
@deadlock_info.sql
EOF
fi

else

	stop_me=0

fi
i=1
while [ $i -ne 60 ]                    
do                                      
sleep 3                                 
if [ -f $SID_HOME/audit/stopmon1 ] 
then                                    
i=60
stop_me=0
else
i=`expr $i + 1`
fi
done
done

# End of script
