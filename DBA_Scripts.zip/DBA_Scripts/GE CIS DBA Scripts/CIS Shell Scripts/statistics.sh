#!/bin/ksh
#
#==============================================================================================================#
# Program Name: statistics.sh
# 
# Purpose: 
# To gather CBO, CPU/IO statistics for a given database|schema|table|index, at a given percentage 
# at a given degree of parallelism for Oracle8i or 9i database.
# Also, this script analyzes Oracle7 & Oracle8 Database schema.
# If Exception file is given, it will be used instead of statistics_exception.ctl
# Usage:
# statistics.sh  $INSTANCE  $CBO_LEVEL  $CBO_OBJECT  $PERCENT   $DEGREE   $EXCEPTION
#   $0           $1    $2          $3           $4         $5        $6 
 
# $0          : Script Name
# $INSTANCE        : Instance Name 
# $CBO_LEVEL  : Levels can be db | schema | table | index | system
#                This script depending upon the choosen cbo level, will gather stats. 
#                Note#1:  For cbo level "db", we will exclude sys, system schema stats 
#                Note#2:  cbo level "system" is meant to gather CPU & IO Stats 
# 
#$CBO_OBJECT  : for cbo_level = db      ; cbo_object = full
#                for cbo_level = schema  ; cbo_object = schema name
#                for cbo_level = table   ; cbo_object = table name
#                for cbo_level = index   ; cbo_object = index_name 
#                for cbo_level = system  ; cbo_object = cpuio
#
# Examples:
#   Syntax        : statistics.sh $INSTANCE  $CBO_OBJECT $PERCENT $CBO_LEVEL $DEGREE $EXCEPTION 
#
#For utility.ctl
# statistics:wwwwwddddddd:$INSTANCE:$CBO_OBJECT:$PERCENT 
#
# statistics:111111111111:MONI:sysadm:40
#
# Note: Init.ora parameter job_queue_processes must be above 0.
# Note: Temporary TableSpace must have sufficient Storage Space
#
# Modified 3/22/2007 - Rajesh Aialavajjala - Include logic for 10g processing
#==============================================================================================================#
####### Notify function for autosys#
notify() {
  parent_pid=`ps -o ppid -p $$ |tail -1`
  parent_program=`ps -o args -p ${parent_pid}|tail -1`
  echo $parent_program |grep utility.sh
  if [ "$?" != 0 ]
  then
    current_prog=`echo $0|sed -e 's/.*\///'`
    $DBA_HOME/admin/notify.sh -s "$current_prog ABEND" -b "$current_prog failure: Please look at audit file" -w sid
    $DBA_HOME/admin/notify.sh -p "$current_prog ABEND" -w sid
   fi
}
##################################
# Logical Functions Section

#dbms_stats function to process overall CBO Options
#--------------------------------------------------

function_dbms_stats() {

 echo " Entered into DBMS_STATS"

 echo $CBO_LEVEL
 CBO_LEVEL=`echo ${CBO_LEVEL} | tr "[:upper:]" "[:lower:]"` 
 echo " CBO_LEVEL is $CBO_LEVEL"

 if [ "${CBO_LEVEL}" = "db" ] & [ "${CBO_OBJECT}" = "FULL" ]; then

  echo " Entering the DB Stats Code"

 ${ORACLE_HOME}/bin/sqlplus -S system/$PASS <<EOF
DECLARE
cursor db_cbo_cur is select username from dba_users where username not in ('SYS','SYSTEM');
dbcbo db_cbo_cur%rowtype;
BEGIN
open db_cbo_cur;
loop
fetch db_cbo_cur into dbcbo;
exit when db_cbo_cur%notfound;
dbms_stats.gather_schema_stats(ownname=>dbcbo.username,ESTIMATE_PERCENT=>$PERCENT,degree =>$DEGREE,cascade=>TRUE);
end loop;
close db_cbo_cur;
END;
/
exit
EOF

echo " Done Gathering DB stats"
 
 elif [ "${CBO_LEVEL}" = "schema" ];then

  SCHEMA=`echo $CBO_OBJECT`
  export SCHEMA

FOUND=`$ORACLE_HOME/bin/sqlplus -S $LOGON <<BUGGY
set heading off
select count(*) from dba_users where username = upper('$SCHEMA');
exit
BUGGY
`
  if [ "$FOUND" = "0" ]; then
   echo "User $SCHEMA does not exist."
   notify ; exit 1
  fi

TABLES=`$ORACLE_HOME/bin/$SQLPLUS -S system/$PASS <<EOF
set heading off
select count(*) from dba_tables where owner =upper('$SCHEMA');
exit
EOF
`
  if [  "${TABLES}" != "0"  ]; then
    echo " Found Objects for the Given Schema"
    echo " Entering into the schema Stats"

schemastat=`${ORACLE_HOME}/bin/sqlplus -S system/$PASS <<BOF
set serveroutput on
set head off term off echo off feedback off show off trim off trims off verify off escape on
exec dbms_stats.gather_schema_stats(ownname => '$CBO_OBJECT', ESTIMATE_PERCENT=> $PERCENT,degree => $DEGREE, cascade => TRUE);
exec dbms_output.put_line( 'Completed the Schema Analysis for $CBO_OBJECT' );
 exit
BOF
`
echo " Performed the Schema Stats for $CBO_OBJECT "

else
 echo "No Objects in the Given Schema"
fi
 
 elif [ "${CBO_LEVEL}" = "table" ]; then
$ORACLE_HOME/bin/sqlplus -S "/ as sysdba" <<EOF
set serveroutput on
set heading off
set feed off
declare
v_owner dba_tables.owner%TYPE;
v_last_analyzed dba_tables.last_analyzed%TYPE;
begin
select owner into v_owner from dba_tables where table_name='$CBO_OBJECT';
dbms_stats.gather_table_stats(ownname=>v_owner, tabname => '$CBO_OBJECT',estimate_percent=>$PERCENT,degree=>$DEGREE,cascade=>true);
select last_analyzed into v_last_analyzed from dba_tables where table_name='$CBO_OBJECT';
dbms_output.put_line('Table $CBO_OBJECT last analyzed on '||v_last_analyzed);
end;
/
exit
EOF

 elif [ "${CBO_LEVEL}" = "index" ]; then
$ORACLE_HOME/bin/sqlplus -S "/ as sysdba" <<EOF
set feed off
set heading off
set serveroutput on
declare
v_owner all_indexes.owner%TYPE;
v_last_analyzed all_indexes.last_analyzed%TYPE;
begin
select owner into v_owner from all_indexes where index_name='$CBO_OBJECT';
dbms_stats.gather_index_stats(ownname=>v_owner,indname=>'$CBO_OBJECT');
select last_analyzed into v_last_analyzed from all_indexes where index_name='$CBO_OBJECT';
dbms_output.put_line('Index $CBO_OBJECT Last Analyzed On '||v_last_analyzed);
end;
/
exit
EOF
 
 elif [ "$CBO_LEVEL"  =  "system" ]; then 


if [ "$RDBMS_VER" = "9.0" ] || [ "$RDBMS_VER" = "9.2" ] ; then

$ORACLE_HOME/bin/sqlplus -S "/ as SYSDBA" <<EOF
DECLARE
v_check number;
cursor c1 is select COUNT(*) from dba_objects where object_name='CPU_IO_STATS';
begin
open c1;
fetch c1 into v_check;
if v_check = 0  then
DBMS_STATS.CREATE_STAT_TABLE ('SYS','CPU_IO_STATS','SYSTEM');
dbms_output.put_line('executing the CPU IO Stats');
dbms_stats.gather_system_stats(gathering_mode=>'INTERVAL', interval => $PERCENT, stattab =>'CPU_IO_STATS',statown => 'SYS', statid=>'day');
else
dbms_stats.gather_system_stats(gathering_mode =>'INTERVAL',interval =>$PERCENT, stattab =>'CPU_IO_STATS', statid=>'day', statown => 'SYS');
dbms_output.put_line('Executed CPU, IO Stats Sucessfully');
end if;
END;
/
--close c1;
exit
EOF

  echo " CPUIO Stats Completed"

else
  echo " This Oracle Version is Not Supported"
  notify ; exit 1
fi
 
# the following else is for main dbms_stats IF Condition
 else
   echo " CBO Levels can only be: db or schema or table or index or system"
  notify ; exit 1
 fi
}

#-------------------------------------------#
#Analyze Oracle Version 7/8 database schemas#
#-------------------------------------------#

function_rdbms_7_8_analyze() {

 SCHEMA=`echo $CBO_OBJECT` 


INPUT_TYPE=NONE
DEFAULT=$SID_HOME/admin/statistics_exception.ctl


if [ "$OS_TYPE" = "NT" ] ; then
        $SVRMGR <<EOF > $SID_HOME/audit/up.tmp
        connect internal
        exit
EOF

    if [ "`grep -e ORA- -e idle $SID_HOME/audit/up.tmp`" ]
        then
        echo "#####################################################"
        echo "Instance $SID is not up."
        echo "#####################################################"
        notify ; exit 1
        fi
        rm $SID_HOME/audit/up.tmp
else
    if  [ ! "`ps -ef|grep pmon_$SID|grep -v grep`" ]
    then
        echo "#####################################################"
        echo "Instance $SID is not up."
        echo "#####################################################"
        notify ; exit 1
    fi
fi

echo " SCHEMA is $SCHEMA"

FOUND=`$SQLPLUS -s system/$PASS <<EOF
        set heading off
        select count(*) from dba_users
        where username = upper('$SCHEMA');
EOF
`

# NT_MOD

if [ "`echo $FOUND | grep 0`" ]
then
    echo "#####################################################"
    echo "User $SCHEMA does not exist."
    echo "#####################################################"
    notify ; exit 1
fi

TABLES=`$SQLPLUS -s system/$PASS <<EOF
        set heading off
        select count(*) from dba_tables
        where owner = upper('$SCHEMA');
EOF
`
# NT_MOD
if [ $TABLES -eq 0 ]
then
    echo "#####################################################"
    echo "User $SCHEMA does not own any tables."
    echo "#####################################################"
    exit 0
fi

if test -f $DEFAULT
then
        INPUT_TYPE=$DEFAULT
fi

if [ $EXCEPTION ]
then
        EXCEPTION=$SID_HOME/admin/$EXCEPTION
        if test -f $EXCEPTION
        then
                INPUT_TYPE=$EXCEPTION
        else
                echo "#####################################################"
                echo "User supplied exception control file does not exist."
                echo "#####################################################"
                notify ; exit 1
        fi
fi

rm -f $SID_HOME/audit/$SCHEMA.not.sql

touch $SID_HOME/audit/$SCHEMA.not.sql
echo "spool $SID_HOME/audit/$SCHEMA.not.err" >>$SID_HOME/audit/$SCHEMA.not.sql
echo "set recsep off" >>$SID_HOME/audit/$SCHEMA.not.sql
echo "set heading off" >>$SID_HOME/audit/$SCHEMA.not.sql

# Depending on the % given, compute or estimate
if [ $PERCENT -gt 50 ]
then
        CLAUSE="COMPUTE STATISTICS;"
else
        CLAUSE="ESTIMATE STATISTICS SAMPLE $PERCENT PERCENT;"
fi

# Setup default ANALYZE statement
echo "set pagesize 9999 linesize 250 show off echo off" >$SID_HOME/audit/$SCHEMA.sql
echo "set heading off" >>$SID_HOME/audit/$SCHEMA.sql
echo "set recsep off" >>$SID_HOME/audit/$SCHEMA.sql
echo "col line1 format a250" >>$SID_HOME/audit/$SCHEMA.sql
echo "spool $SID_HOME/audit/$SCHEMA.err" >>$SID_HOME/audit/$SCHEMA.sql
echo "SELECT 'select ''PROCESSING TABLE '||owner||'.'||table_name||''' from dual;' line1, " >>$SID_HOME/audit/$SCHEMA.sql
echo " ' ANALYZE TABLE '||owner||'.'||table_name||' '||'$CLAUSE'" >>$SID_HOME/audit/$SCHEMA.sql
echo "FROM DBA_TABLES" >>$SID_HOME/audit/$SCHEMA.sql
echo "WHERE OWNER = UPPER('$SCHEMA')" >>$SID_HOME/audit/$SCHEMA.sql

# Parse the input file
# Create the exception ANALYZE statements
if  [ ! $INPUT_TYPE = "NONE" ]
then
while read RECORD
do
    REC_SCHEMA=`echo $RECORD | awk -F$SEP '{print $1}'`
        if [ $REC_SCHEMA = $SCHEMA ]
        then
                REC_TABLE=`echo $RECORD | awk -F$SEP '{print $2}'`
                REC_PERCENT=`echo $RECORD | awk -F$SEP '{print $3}'`

                if [ $REC_PERCENT -gt 50 ]
                then
                        RES_CLAUSE="COMPUTE STATISTICS;"
                else
                        REC_CLAUSE="ESTIMATE STATISTICS SAMPLE $REC_PERCENT PERCENT;"
                fi
                echo "SELECT 'ANALYZE TABLE $REC_SCHEMA.$REC_TABLE $REC_CLAUSE' FROM DUAL;" >> $SID_HOME/audit/$SCHEMA.not.sql
                echo "ANALYZE TABLE $REC_SCHEMA.$REC_TABLE $REC_CLAUSE" >> $SID_HOME/audit/$SCHEMA.not.sql
                echo "AND TABLE_NAME != UPPER('$REC_TABLE')" >> $SID_HOME/audit/$SCHEMA.sql
        fi
done <$INPUT_TYPE
fi

echo ";" >>$SID_HOME/audit/$SCHEMA.sql
echo "spool off" >>$SID_HOME/audit/$SCHEMA.sql
echo "quit" >>$SID_HOME/audit/$SCHEMA.sql
echo "spool off" >>$SID_HOME/audit/$SCHEMA.not.sql
echo "quit" >>$SID_HOME/audit/$SCHEMA.not.sql

# Execute the default ANALYZE table statements
$SQLPLUS -s SYSTEM/$PASS <<EOF
set heading off
set recsep off
`               $SQLPLUS -s SYSTEM/$PASS @$SID_HOME/audit/$SCHEMA.sql`
EOF

# Execute the exception ANALYZE statements
$SQLPLUS -s SYSTEM/$PASS @$SID_HOME/audit/$SCHEMA.not.sql

#Determine if schema has indexes
INDEXES=`$SQLPLUS -s system/$PASS <<EOF
        set heading off
        select count(*) from dba_indexes
        where owner = upper('$SCHEMA');
EOF
`
if [ $INDEXES -eq 0 ]
then
    echo "User $SCHEMA does not own any indexes."
    echo "User $SCHEMA does not own any indexes." >$SID_HOME/audit/$SCHEMA.index.err
else

# Analyze the INDEXES at 100%
$SQLPLUS -s SYSTEM/$PASS <<EOF
set heading off
set recsep off
`$SQLPLUS -s SYSTEM/$PASS <<END
        spool $SID_HOME/audit/$SCHEMA.index.err
        set pagesize 9999 linesize 250 heading off show off
        col line1 format a250
        SELECT  'SELECT ''ANALYZING INDEX '||owner||'.'||index_name||''' FROM DUAL;' line1,
                'ANALYZE INDEX '||owner||'.'||index_name||' '||'COMPUTE STATISTICS;'
        FROM DBA_INDEXES
        WHERE OWNER = UPPER('$SCHEMA');
        spool off
        quit
END
`
EOF
fi

cat $SID_HOME/audit/$SCHEMA.err > $SID_HOME/audit/$SCHEMA.all
cat $SID_HOME/audit/$SCHEMA.not.err >> $SID_HOME/audit/$SCHEMA.all
cat $SID_HOME/audit/$SCHEMA.index.err >> $SID_HOME/audit/$SCHEMA.all

# Check for errors produced by any of the SQLs
if [ "`grep -e ORA- $SID_HOME/audit/$SCHEMA.all`" ]
then
        echo "###############################################"
        echo "Errors where found in $SCHEMA log files."
        echo "###############################################"
        notify ; exit 1
else
        rm -f $SID_HOME/audit/$SCHEMA.not.sql
                rm -f $SID_HOME/audit/$SCHEMA.all
                rm -f $SID_HOME/audit/$SCHEMA.sql
                rm -f $SID_HOME/audit/$SCHEMA.err
                rm -f $SID_HOME/audit/$SCHEMA.not.err
                rm -f $SID_HOME/audit/$SCHEMA.index.err
                exit 0
fi
#exit 0

}


################################# Main Section Begins #########################

 INSTANCE=$1
 CBO_LEVEL=$4
 CBO_OBJECT=$2
 PERCENT=$3
 DEGREE=$5
 EXCEPTION=$6
 GREP=/usr/xpg4/bin/grep
 DEFAULT=$SID_HOME/admin/statistics_exception.ctl
 #ORATAB=/var/opt/oracle/oratab
 INPUT_TYPE=NONE
 export INSTANCE 
 export CBO_LEVEL 
 export CBO_OBJECT 
 export PERCENT 
 export DEGREE 
 export EXCEPTION 
 export GREP 
 export DEFAULT 
 #export ORATAB

echo $CBO_OBJECT
CBO_OBJECT=`echo ${CBO_OBJECT} | tr "[:lower:]" "[:upper:]"`
echo " CBO_OBJECT is $CBO_OBJECT"

OS_TYPE=`uname`

 if [ "$OS_TYPE" = "SunOS" ] || [ "$OS_TYPE" = "OSF1" ] || [ "$OS_TYPE" = "Linux" ] || [ "$OS_TYPE" = "HP-UX" ]; then
     . $HOME/bin/$INSTANCE
      PASS=`$HOME/bin/tellme system`
      export PASS
     
      SVRMGR=svrmgrl
      SQLPLUS=sqlplus
      COMPRESSION=Y
      COMP_EXTENTION=.Z
     # OS_TYPE=SunOS
      SEP=:
      LOGON='"/ as sysdba"'
      export LOGON
      ORATAB=/var/opt/oracle/oratab
      export ORATAB
      if [ "$OS_TYPE" = "Linux" ] || [ "$OS_TYPE" = "HP-UX" ]; then
       ORATAB=/etc/oratab
       export ORATAB
      fi

     if  [ ! "`ps -ef|grep pmon_$INSTANCE|grep -v grep`" ]; then
        echo "Instance $ORACLE_SID is Down."
        notify ; exit 1
     else
        echo " Instance is Active "
     fi

 elif [ "`echo $OS_TYPE | grep NT`" ]; then
     SVRMGR=svrmgr23
     SQLPLUS=sqlplus
     COMPRESSION=N
     COMP_EXTENTION=
     #OS_TYPE=NT
     SEP=,
     HOME='O:/Oracle/dba01'
     $HOME/bin/$INSTANCE.bat
    
     env  

     WHO=system
     CHARM=`cat $HOME/bin/charm.file | awk -F, '{print $1}'`
     POS=`cat $HOME/bin/charm.file | awk -F, '{print $2}'`
  
PASS=`awk -F, '{ if ($1 == "'$ORACLE_SID'" && $2 == "'$WHO'")
  {print substr($3,1,"'$POS'"-1) "'$CHARM'" substr($3,"'$POS'",length($3))}
}' $HOME/bin/oratask.lst`

     LOGON="system/$PASS" 
     export LOGON

 else
   echo " Script Not Ported for this OS"
fi


#Parse the Values in Variables 
echo "Parsing the Variable"

if [ "$INSTANCE" = "" ] || [ "$CBO_OBJECT"  = "" ] ; then
   echo "Instance Name, cbo object are mandatory Inputs. Exiting the Shell"
notify ; exit 1
fi

if [ "$CBO_LEVEL"  = "" ] ; then
   echo " cbo level is NULL. Defaulting it to SCHEMA"
   CBO_LEVEL=SCHEMA
   export CBO_LEVEL
fi


 if [ "$PERCENT" = "" ] || [ "$PERCENT" = "0" ]; then
  PERCENT=10
  export PERCENT
 echo " Setting default percent to 10"
 fi

 if [ "$DEGREE" = "" ] || [ "$DEGREE" = "0" ]; then
  DEGREE=4
  export DEGREE
  echo "Setting Default Degree to 4."
 fi


 if test -f $DEFAULT ; then
	INPUT_TYPE=$DEFAULT
 fi	


if [ $EXCEPTION ]; then
  EXCEPTION=$SID_HOME/admin/$EXCEPTION
    if test -f $EXCEPTION ; then
            INPUT_TYPE=$EXCEPTION
    else
   	echo "#####################################################"
    	echo "User supplied exception control file does not exist."
    	echo "#####################################################"
        notify ; exit 1
   fi
fi


# RDBMS Version Check

echo $ORACLE_HOME 

RDBMS_VER=`$ORACLE_HOME/bin/sqlplus -S "/ as sysdba" <<EOF
set heading off 
set echo off
set verify off
select value\$ from sys.props\$ where name='NLS_RDBMS_VERSION';
exit 
EOF
` 
sleep 2
echo $RDBMS_VER

 RDBMS_VER=`echo $RDBMS_VER |cut -d'.' -f1,2` 
 export RDBMS_VER
echo $RDBMS_VER

   echo "Executing Statistics.sh on `date` " 

case $RDBMS_VER in
 

  7.2)
    function_rdbms_7_8_analyze
    ;;
  7.3) 
    function_rdbms_7_8_analyze
    ;; 
  8.0) 
    function_rdbms_7_8_analyze
    ;;
  8.1) 
    function_dbms_stats 
    ;;
  9.0)
    function_dbms_stats
    ;; 
  9.2)
    function_dbms_stats
    ;; 
  10.2)
    function_dbms_stats
    ;;
   * ) 
      echo " Sorry. Only Oracle Version from 7.3 thru 9.2 are Valid" ;;
 esac

 
# End of statistics.sh Script

echo "Completed Statistics.sh on `date` "
exit 0
