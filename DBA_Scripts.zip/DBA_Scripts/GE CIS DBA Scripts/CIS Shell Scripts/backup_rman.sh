#!/bin/ksh
#set -x
################################################################################
## backup_rman.sh
##
## PURPOSE: To execute either a closed or online backup of an oracle database
## supplied as input including controlfile and archivelogs when applicable.
##
## USAGE: This script is called either standalone or by the utility.sh script 
## when a scheduled backup entry exists in utility control file, (i.e
## $SID_HOME/admin/utility.ctl).
##	
##     The command line submitted by utility.sh is:
##          backup_rman.sh sid backup_type [AlternateBackupCtl]
##          >$SID_HOME/audit/backup_${ORACLE_SID}.auditMMDD[_HHMM] 2>&1
##     The required utility.ctl record format is:
##          backup_rman:ddddddd[:AlternateBackupCtl]
##          where d(day)=0(skip),c(cold),h(hot)
##     The required utility_arch.ctl record format is:
##          backup_rman:ddddddd
##          where d(day)=0(skip),a(arch)
##
##     A default rman.ctl file must exist under $SID_HOME/admin
##       rman.ctl records must be formatted as:
##          BACKUP_HOME:BackupControlfile+init.oraPath
##          DEVICE_TYPE:BackupMediaType
##	    CATALOG_DB:BackupCatalogDatabaseName         
##          CATALOG_SCHEMA:BackupCatalogSchemaName
##          TARGET_SCHEMA:BackupTargetSchemaName
##          CHANNELS:NumberofChannelsforBackup
##	    INCREMENTAL_FLAG:[Y|N]
##	    INCREMENTAL_LEVEL:tltltltltltltl
##	    where t(type)=C(Cumulative), D(Deferential);
##	          l(level)=( Incremental Level 0 or 1)
##	    DELETE_OBSOLETE:ddddddd 
##	    where d(day)=0(skip),1(run)
##
##   SCRIPT PROCESS FLOW:
##     1) Verify validity of the parameters supplied in backup controlfile
##     2) Check database state shutdown abort - startup restrict - shutdown
##        immediate and startup mount for RMAN closed database backups
##     3) Perform open/closed (i.e hot/cold) full/incremental backup of the
##        requested SID using RMAN utility from the target database $ORACLE_HOME
##     4) If the database is in archivelog mode, perform backup of the archivelogs
##        and delete from log_archive_dest
##     5) Execute an Oracle backup controlfile command to a file under the
##        default backup directory
##     6) Copy the instance parameter file to the default backup directory
##     7) Generate a generic RMAN recovery script in the default backup directory
##     8) Force delete obsolete backup files from disk/tape
##
##   RESTART: All restarts should be performed using the restart capabilities
##        of the utility.sh script. If you choose to restart the backup_rman.sh
##        script itself, you will loose the email notification and audit trail
##        formatting provided by the utility.sh script.
##   OUTPUTS: In addition to the rman backups themselves, this script will
##        produce a full recovery script, a controlfile trace, an instance
##        parameter file copy, and a full audit trail of script results under
##        the default backup directory. This should guarantee that everything
##        needed for disaster recovery to the backup time has been sent to tape
##        for offsite storage.
##   NOTIFICATION: Email notification of abends will be directed to the oncall
##        Oracle DBA; email notification for successful and failed executions
##        will always be directed to the responsible DBA for this instance.
##        This script MUST be initiated by script utility.sh to activate this
##        notification process. $HOME/bin/notify.ctl must contain the proper
##        notification names.
##   MODIFICATIONS:
##        Date        Name         	Description
##        ----------  --------------	--------------------------------------
##        03/06/2006  Ashish Trivedi	Created
##	  12/12/2006  Ashish Trivedi	Updated with 10g enhancements
##
################################################################################

################################################################################
##  ------------------------------------------------------------------------  ##
##			Notification Function for Autosys		      ##
##  ------------------------------------------------------------------------  ##
################################################################################
notify()
{
if [ -z "$addl_msg" ]; then
  page_msg="abended"
else
  page_msg="$addl_msg"
fi
parent_pid=`ps -o ppid -p $$ |tail -1`
parent_program=`ps -o args -p ${parent_pid}|tail -1`
echo $parent_program |grep utility.sh
if [ "$?" != 0 ]; then
  current_prog=`echo $0|sed -e 's/.*\///'`
  if [ -f $RMAN_LOG_FILE ]; then
     $DBA_HOME/admin/notify.sh -s "$current_prog $page_msg" -b "$msg_body" -f $RMAN_LOG_FILE -w sid
  else
     $DBA_HOME/admin/notify.sh -s "$current_prog $page_msg" -b "$msg_body" -w sid
  fi
     $DBA_HOME/admin/notify.sh -p "$current_prog $page_msg" -w sid
fi
run_cleanup
exit 1
}

echo "*************************************************************************"
echo "====>Script backup_rman.sh Starting on" `date`
echo "*************************************************************************"

################################################################################
##  ------------------------------------------------------------------------  ##
##         Process inputs and set the instance and script environment         ##
##  ------------------------------------------------------------------------  ##
################################################################################
# Verify sid input
if [ -z "$1" ]; then
  echo "Error====>Required parameter is missing"
  echo "          Usage is backup_rman.sh sid backup_type"
  echo "          Script is terminating!"
  notify
fi

# Set the instance environment
if [ ! -f $HOME/bin/$1 ]; then
  echo "Error====>No environment script found for instance \"$1\""
  echo "          Script is terminating!"
  notify
fi

. $HOME/bin/$1

backup_file=$SID_HOME/admin/rman.ctl

if [ ! -z "$3" ]; then
    backup_file=$SID_HOME/admin/$3
fi

if [ ! -f $backup_file ]; then
  echo "Error====>Backup control file does not exist"
  echo "          Script is terminating!"
  notify
fi

# Capture oracle version 
ora_version=`echo "exit" | sqlplus | awk '
  /Release/ {for (x=1; x<=NF; x++)
    { if ( $x == "Release" ) {x++; split($x,rel,"."); print rel[1]; break}
  }}'`

# Verify backup type input
if [ -z "$2" ]; then
  echo "Error====>Required parameter is missing"
  echo "          Usage is backup_rman.sh sid backup_type"
  echo "          Script is terminating!"
  notify
fi
backup_type=$2; export backup_type
if [ ${backup_type} != "cold" -a ${backup_type} != "hot" -a ${backup_type} != "arch" ]; then
  echo "Error====>Backup type parameter is invalid"
  echo "          Value must be hot or cold or arch"
  echo "          Script is terminating!"
  notify
fi

################################################################################
##  ------------------------------------------------------------------------  ##
##       Process script variables and gather settings from controlfile        ##
##  ------------------------------------------------------------------------  ##
################################################################################

###########
#Locations
###########
scripts_path=$DBA_HOME/admin
audit_path=$SID_HOME/audit
default_dir=`grep "^BACKUP_HOME" ${backup_file}|grep -v "#BACKUP_HOME"|awk -F: '{print $2}'`

###########
#Connections
###########
PASSWD=`$HOME/bin/tellme system`
RMAN=$ORACLE_HOME/bin/rman
TARGET_DB=$ORACLE_SID
TARGET_SCHEMA=`grep TARGET_SCHEMA ${backup_file}|grep -v "#TARGET_SCHEMA"|awk -F: '{print $2}'`
TARGET_PASSWD=`ORACLE_SID=$TARGET_DB;$HOME/bin/tellme $TARGET_SCHEMA`
TARGET=${TARGET_SCHEMA}/${TARGET_PASSWD}
CATALOG_DB=`grep CATALOG_DB ${backup_file}|grep -v "#CATALOG_DB"|awk -F: '{print $2}'`
CATALOG_TWOTASK=`grep CATALOG_TWOTASK ${backup_file}|grep -v "#CATALOG_TWOTASK"|awk -F: '{print $2}'`
CATALOG_SCHEMA=`grep CATALOG_SCHEMA ${backup_file}|grep -v "#CATALOG_SCHEMA"|awk -F: '{print $2}'`
CATALOG_PASSWD=`ORACLE_SID=$CATALOG_DB;$HOME/bin/tellme $CATALOG_SCHEMA` 
CATALOG=${CATALOG_SCHEMA}/${CATALOG_PASSWD}

##############
#RMAN specific 
##############
DEVICE_TYPE=`grep DEVICE_TYPE ${backup_file}|grep -v "#DEVICE_TYPE"|awk -F: '{print $2}'`
CHANNELS=`grep CHANNELS ${backup_file}|grep -v "#CHANNELS"|awk -F: '{print $2}'`
ENCRYPTION_FLAG=`grep ENCRYPTION_FLAG ${backup_file}|grep -v "#ENCRYPTION_FLAG"|awk -F: '{print $2}'`
TAPECOPY_ACTIVE=`grep TAPECOPY_ACTIVE ${backup_file}|grep -v "#TAPECOPY_ACTIVE"|awk -F: '{print $2}'`
INCREMENTAL_FLAG=`grep INCREMENTAL_FLAG ${backup_file}|grep -v "#INCREMENTAL_FLAG"|awk -F: '{print $2}'`
INCREMENTAL_LEVEL=`grep INCREMENTAL_LEVEL ${backup_file}|grep -v "#INCREMENTAL_LEVEL"|awk -F: '{print $2}'`
DELETE_OBSOLETE=`grep DELETE_OBSOLETE ${backup_file}|grep -v "#DELETE_OBSOLETE"|awk -F: '{print $2}'`
TAG_STAMP=`date +%m%d_%H''%M`

#####################
#Log and Audit files
#####################
RMAN_LOG_FILE=$audit_path/${ORACLE_SID}_${backup_type}_`date '+%m%d_%H''%M''%S'`.audit
cmd_file=$SID_HOME/audit/${ORACLE_SID}_${backup_type}_$$.rman
arch_cmd_file=$SID_HOME/audit/${ORACLE_SID}_arch_$$.rman
rec_cmd_file=${default_dir}/recover_${ORACLE_SID}.rman
cln_cmd_file=$SID_HOME/audit/${ORACLE_SID}_cln_$$.rman
obs_cmd_file=$SID_HOME/audit/${ORACLE_SID}_obs_$$.rman
tcopy_lock_file=$SID_HOME/audit/tcopy_rman.lk
rman_lock_file=$SID_HOME/audit/backup_rman.lk

################################################################################
##  ------------------------------------------------------------------------  ##
##                      Cleanup Cleanup Everybody Cleanup                     ##
##  ------------------------------------------------------------------------  ##
################################################################################
run_cleanup () 
{
##########################################################
# run_cleanup()
# This function performs cleanup of files 
##########################################################
rm ${audit_path}/ora.error.$$ > /dev/null 2>&1
rm ${audit_path}/bkdest.list.$$ > /dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.arc.status.$$ > /dev/null 2>&1
rm ${audit_path}/arch_dest.list.$$ >/dev/null 2>&1
rm ${audit_path}/arch_fmt.list.$$ >/dev/null 2>&1
rm $RMAN_LOG_FILE > /dev/null 2>&1
rm $cmd_file > /dev/null 2>&1
rm $arch_cmd_file > /dev/null 2>&1
rm $cln_cmd_file > /dev/null 2>&1
rm $obs_cmd_file > /dev/null 2>&1 
}

############
#Debug
############
error_switch=0

################################################################################
##  ------------------------------------------------------------------------  ##
##                  Pre-processing and parameter validation                   ##
##  ------------------------------------------------------------------------  ##
################################################################################

if [ "$ora_version" -lt 10 ]; then
  if [ ${DEVICE_TYPE} !=  "SBT" ]; then
    echo "====>Oracle Version is" $ora_version
    echo 
    echo "Error====>Only TAPE Backups are allowed at this time !!"
    echo "          Device type must be SBT"
    echo "          Script is terminating!"
    notify
  fi
fi

if [ "$ora_version" -gt 9 ]; then
  if [ ${DEVICE_TYPE} != "DISK" -a ${DEVICE_TYPE} != "SBT" ]; then
    echo "Error====>Device type must be either DISK or SBT"
    echo "          Script is terminating!"
    notify
  fi
  echo 
  echo "====>Oracle version is $ora_version"
  echo "Compressed backup sets will be used."
  echo
else
  echo
  echo "====>Oracle version is $ora_version"
  echo "Compressed backup sets will NOT be used."
  echo 
fi

if [ -z "$CATALOG_TWOTASK" ]; then
       echo "Error====>Missing TWO_TASK entry for the Catalog Database "
       echo "Script is terminating!                                    "
       notify
fi

if [ -f $ORACLE_HOME/dbs/spfile$ORACLE_SID.ora ]; then
  init_file=$ORACLE_HOME/dbs/spfile$ORACLE_SID.ora
elif [ -f $ORACLE_HOME/dbs/init$ORACLE_SID.ora ]; then
  init_file=$ORACLE_HOME/dbs/init$ORACLE_SID.ora
else
  echo "Error====>Oracle (s)pfile do not exist"
  echo "          Script is terminating!"
  notify
fi

if [ ! -d "$default_dir" ]; then
  echo "Error====>Missing or invalid BACKUP_HOME entry in the backup control file"
  echo "          Script is terminating!"
  notify
fi
export default_dir

if [ -d ${default_dir}/oracle/${ORACLE_SID}/control ]; then
  ctl_dir=${default_dir}/oracle/${ORACLE_SID}/control
  export ctl_dir
else
  echo "Error====>Missing control directory " ${default_dir}/oracle/${ORACLE_SID}/control
  echo "          Script is terminating!"
  notify
fi
if [ -n "$ENCRYPTION_FLAG" ]; then
        if [ "$ENCRYPTION_FLAG" != "Y" -a "$ENCRYPTION_FLAG" != "N" ]; then
                echo "Error====>Invalid ENCRYPTION_FLAG in the backup controlfile"
                echo "Script is terminating!                                      "
                notify
        fi
fi

if [ "$INCREMENTAL_FLAG" = "Y" ]; then
  if [ -d ${default_dir}/oracle/${ORACLE_SID}/incr ]; then
    bkup_dir=${default_dir}/oracle/${ORACLE_SID}/incr
    export bkup_dir
  else
    echo "Error====>Missing backup directory " ${default_dir}/oracle/${ORACLE_SID}/incr
    echo "          Script is terminating!"
    notify
  fi
else
  if [ -d ${default_dir}/oracle/${ORACLE_SID}/full ]; then
    bkup_dir=${default_dir}/oracle/${ORACLE_SID}/full
    export bkup_dir
  else
    echo "Error====>Missing backup directory " ${default_dir}/oracle/${ORACLE_SID}/full
    echo "          Script is terminating!"
    notify
  fi
fi


#########################
#Calculate MM/DD/YY/FW/FD
#########################

if [ -z "$date_parm" ]; then
  month=`date +%m`
  day=`date +%d`
  year=`date +%y`
else
  month=`echo $date_parm | cut -d/ -f1`
  day=`echo $date_parm | cut -d/ -f2`
  year=`echo $date_parm | cut -d/ -f3`
fi
export month day year

$DBA_HOME/admin/fiscal.sh
fiscal_week=`awk '{print $1}' $SID_HOME/audit/fiscal.out`
fiscal_day=`awk '{print $2}' $SID_HOME/audit/fiscal.out`
rm $SID_HOME/audit/fiscal.out

if [ -n "$INCREMENTAL_FLAG" ]; then
	if [ "$INCREMENTAL_FLAG" != "Y" -a "$INCREMENTAL_FLAG" != "N" ]; then
		echo "Error====>Invalid INCREMENTAL_FLAG in the backup controlfile"
	        echo "Script is terminating!                                      "
	        notify
	fi
fi

if [ "$INCREMENTAL_FLAG" = "Y" ]; then
   if [ -z "$INCREMENTAL_LEVEL" ]; then
	echo "Error====>Missing incremental level for incremental backup"
	echo "Script is terminating!                                    "
	notify
   elif [ ${#INCREMENTAL_LEVEL} != 14 ]; then
	echo "Error====>Invalid Entry for INCREMENTAL_LEVEL"
	echo "Script is terminating!                       "
	notify
   else
	echo $INCREMENTAL_LEVEL | awk '{ print $1 }' | grep -q 0
	if [ $? -ne 0 ]; then
        	echo "Error====>No level 0 backup defined in INCREMENTAL_LEVEL"
	        echo "Script is terminating!                                  "
        	notify
	fi
	   let v_incr_type="($fiscal_day * 2) + 1"
           let v_incr_level="($fiscal_day * 2) + 2"
	   itype=`echo $INCREMENTAL_LEVEL | cut -c$v_incr_type`
	   ilevel=`echo $INCREMENTAL_LEVEL | cut -c$v_incr_level`
	   export itype ilevel
	if [ ${itype} != "C" -a ${itype} != "D" ]; then
			echo "Error====>Incremental Backup Type should be either C or D"
			echo "Script is terminating!				       "
			notify
		elif 	[ ${ilevel} -ne 0 -a ${ilevel} -ne 1 ]; then
			echo "Error====>Incremental Backup Level should be either 0 or 1"
			echo "Script is terminating!					"
			notify
	fi
   fi
fi

if [ -n "$DELETE_OBSOLETE" ]; then
   if [ ${#DELETE_OBSOLETE} != 7 ]; then
        echo "Error====>Invalid Entry for DELETE OBSOLETE"
        echo "Script is terminating!                     "
        notify
   else
                let v_do_day="$fiscal_day + 1"
		do_day=`echo $DELETE_OBSOLETE | cut -c$v_do_day`
                export do_day
   fi
fi


if [ -z "$CHANNELS" ]; then
       echo "Error====>Missing channels entry in the backup controlfile"
       echo "Script is terminating!				       "
       notify
elif   [ ${CHANNELS} -lt 1  -o  ${CHANNELS} -gt 14 ]; then
       echo "Error====>Number of channels should be between 1-14"
       echo "Script is terminating!                             "
       notify
fi

if [ -z "$TAPECOPY_ACTIVE" ]; then
       echo "Error====>Missing TAPECOPY_ACTIVE entry in the backup controlfile"
       echo "Script is terminating!                                           "
       notify
elif   [ ${TAPECOPY_ACTIVE} != "Y" -a ${TAPECOPY_ACTIVE} != "N" ]; then
       echo "Error====>Invalid TAPECOPY_ACTIVE entry in the backup controlfile"
       echo "Script is terminating! 					      "
       notify
fi

################################################################################
##  ------------------------------------------------------------------------  ##
##     Function to set/unset lock file to prevent simultaneous executions     ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# lock_unlock()
# This function manages lock file to prevent simultaneous executions of a script
# perl should be in $PATH for this function to operate -- non-version specific
# sample usage:
# lock_unlock action=lock name=/some/where/my_lock [other options]
# do your operations
# lock_unlock action=unlock name=/some/where/my_lock  # optional
################################################################################
lock_unlock ()
{
  typeset PATH=$(PATH=/bin:/usr/bin getconf PATH)
  typeset action psid inode name pid ppid time ttl abba id
  typeset expire=99999999 wait=99999999 T0

  eval "$@"
  function epoch { perl -e 'print time'; }
  abba=$(function t { trap 'printf "%s" a' EXIT; }; t; printf "%s" b)

  function lock_stat {
    typeset inode lsout name=$1
    [[ -L ${name} ]] || { printf "%s\n" "inode=" && return 0; }
    set -- $(ls -il ${name})
    printf "%s\n" "inode=${1} ${12} ${13} ${14} ${15}"
  }

  function ps_iden {
    set -- $(ps -o user= -o group= -o ppid= -o pgid= -p $1 2>/dev/null)
    echo $1.$2.$3.$4
    return 0
  }

  case ${action} in
    lock)
      (( T0 = SECONDS ))
      while (( SECONDS - T0 <= wait )); do
        ln -s "pid=$$ ppid=$PPID time=$(epoch) ttl=${expire} psid=$(ps_iden $$) id=$id" ${name} && {
          case $abba in
            ab) trap "trap \"rm -f ${name}\" EXIT" EXIT;;
             *) trap "rm -f ${name}" EXIT;;
          esac
          rm -f ${name}.+([0-9]).+([0-9])
          return 0
        }

        eval $(lock_stat ${name})

        [[ -n ${inode} ]] && {
          ps -p ${pid} 2>/dev/null          &&
          [[ $(ps_iden ${pid}) = "$psid" ]] &&
          (( $(epoch) < time + ttl ))       ||
          find ${name} -inum ${inode} -exec mv -f {} ${name}.$$.${RANDOM} \;
        }

        sleep 3
      done;;
    unlock)
      eval $(lock_stat ${name})

      [[ -n ${inode} ]]                             &&
      find ${name} -inum ${inode} -exec rm -f {} \; &&
      case $abba in
        ab) trap "trap - EXIT" EXIT;;
         *) trap - EXIT;;
      esac                                          &&
      return 0;;
  esac
  return 1
}

################################################################################
##  ------------------------------------------------------------------------  ##
##           Function to check and set the state of a database                ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# check_db_state()
# This function checks and sets an appropriate state of a database for which a 
# backup is being requested. This happens before performing any type of backup.
# It will also call the function to clean up prior disk backups if required. 
# If the backup type is closed it will perform the following steps in order.
# SHUTDOWN ABORT; STARTUP RESTRICT; SHUTDOWN IMMEDIATE; STARTUP MOUNT
################################################################################

check_db_state ()
{
################################################################################
##  ------------------------------------------------------------------------  ##
##             Abort ANY type of backup if the database is down               ##
##  ------------------------------------------------------------------------  ##
################################################################################
sqlplus -s $TARGET@$TARGET_DB << EOF > /dev/null
exit 255;
EOF
   if [ $? != 255 ]; then
     echo "#####################################################"
     echo "## ERROR ====> Target database NOT available!      ##"
     echo "##       ====> Backup processing cannot continue   ##"
     echo "#####################################################"
     msg_body="Target database NOT available!"
   notify
   fi

sqlplus -s $CATALOG@$CATALOG_DB << EOF > /dev/null
exit 255;
EOF
   if [ $? != 255 ]; then
     echo "#####################################################"
     echo "## ERROR ====> Catalog database NOT available !    ##"
     echo "##       ====> Backup processing cannot continue   ##"
     echo "#####################################################"
     msg_body="Catalog database NOT available!"
   notify
   fi

################################################################################
##  ------------------------------------------------------------------------  ##
##             For closed backups, first shutdown Oracle abort                ##
##  ------------------------------------------------------------------------  ##
################################################################################
if [ ${backup_type} = "cold" ]; then
  echo
  echo "====>Shutting down instance $ORACLE_SID to kill any active users"
  echo
  if [ "$ora_version" -gt 7 ]; then 
    sqlplus /nolog <<EOF >${audit_path}/ora.error.$$
    connect / as sysdba
    shutdown abort
    exit
EOF
  else
    svrmgrl <<EOF >${audit_path}/ora.error.$$
    connect internal
    shutdown abort
    exit
EOF
  fi
  grep "ORA-" ${audit_path}/ora.error.$$
  if [ $? -eq 0 ]; then
    echo "#####################################################"
    echo "## ERROR ====> Shutdown abort of Oracle failed     ##"
    echo "##       ====> Backup processing cannot continue   ##"
    cat ${audit_path}/ora.error.$$ | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    notify
  fi
fi


################################################################################
##  ------------------------------------------------------------------------  ##
##    startup open for online backups; startup restrict for closed backups    ##
##  ------------------------------------------------------------------------  ##
################################################################################
#sleep 120
ps_cnt=`ps -ef|grep ora_pmon_${ORACLE_SID}|grep -v grep|wc -l`
if [ $ps_cnt -eq 0 ]; then
  if [ $backup_type = "cold" ]; then
    db_mode=restrict;export db_mode
  else
    db_mode=open;export db_mode
  fi
  echo
  echo "====>Starting instance $ORACLE_SID in $db_mode mode"
  echo
  if [ "$ora_version" -gt 7 ]; then 
    sqlplus /nolog <<EOF >${audit_path}/ora.error.$$
    connect / as sysdba
    startup $db_mode
    exit
EOF
  else
    svrmgrl <<EOF >${audit_path}/ora.error.$$
    connect internal
    startup $db_mode
    exit
EOF
  fi
  grep "ORA-" ${audit_path}/ora.error.$$
  if [ $? -eq 0 ]; then
    echo "#####################################################"
    echo "## ERROR ====> Startup of Oracle failed       	 ##"
    echo "##       ====> Backup processing cannot continue   ##"
    cat ${audit_path}/ora.error.$$ | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    notify
  fi
fi

################################################################################
##  ------------------------------------------------------------------------  ##
##             Determine if database is in archivelog mode                    ##
##             & Capture location of archivelog destination                   ##
##  ------------------------------------------------------------------------  ##
################################################################################
sqlplus -s system/${PASSWD} << END > ${audit_path}/backup.${ORACLE_SID}.arc.status.$$
set pagesize 0 feedback off verify off echo off termout off heading off
select log_mode from v\$database;
END
grep -q "NO" ${audit_path}/backup.${ORACLE_SID}.arc.status.$$
if [ $? -eq 0 ]; then
  archivelog_sw=0
else
  archivelog_sw=1
fi

sqlplus -s system/${PASSWD} <<END >/dev/null
set pagesize 0 feedback off verify off echo off termout off heading off
spool ${audit_path}/arch_dest.list.$$
/* Added for Standby Database */
select destination value
   from v\$archive_dest
   where destination is not null
   and status='VALID'
   and target='PRIMARY'
   and rownum=1
union
select value
  from v\$parameter where name = 'log_archive_dest';
spool off
spool ${audit_path}/arch_fmt.list.$$
select value
  from v\$parameter where name = 'log_archive_format';
spool off
END
arch_dir=`cat ${audit_path}/arch_dest.list.$$`
arch_dir=`echo ${arch_dir} | awk '{
  if (substr($1,length($1),1) == "/") {print substr($1,1,length($1)-1)} else {print $1}}'`

################################################################################
##  ------------------------------------------------------------------------  ##
##            Call function backup_cleanup() prior to final recycle           ##
##  ------------------------------------------------------------------------  ##
################################################################################

if [ ${backup_type} != "arch" ]; then
   if [ ${DEVICE_TYPE} ==  "DISK" ]; then
     if [ ${INCREMENTAL_FLAG} == "N" ]; then
     backup_cleanup
     elif  [ ${INCREMENTAL_FLAG} == "Y" ] &&  [ "$ilevel" -eq "0" ]; then
     backup_cleanup
     fi
   fi
fi

################################################################################
##  ------------------------------------------------------------------------  ##
##            For closed(consistent) backups SHUTDOWN IMMEDIATE               ##
##  ------------------------------------------------------------------------  ##
################################################################################
if [ ${backup_type} = "cold" ]; then
  echo
  echo "====>Shutting down instance $ORACLE_SID for a closed backup"
  echo
  if [ "$ora_version" -gt 7 ]; then 
    sqlplus /nolog <<EOF >${audit_path}/ora.error.$$
    connect / as sysdba
    shutdown immediate
    exit
EOF
  else
    svrmgrl <<EOF >${audit_path}/ora.error.$$
    connect internal
    shutdown immediate
    exit
EOF
  fi
  grep "ORA-" ${audit_path}/ora.error.$$
  if [ $? -eq 0 ]; then
    cat ${audit_path}/ora.error.$$
    echo "#####################################################"
    echo "## ERROR ====> Shutdown  of Oracle failed          ##"
    echo "##       ====> Backup processing cannot continue   ##"
    cat ${audit_path}/ora.error.$$ | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    notify
  fi
fi

################################################################################
##  ------------------------------------------------------------------------  ##
##            For closed(consistent) backups STARTUP MOUNT                    ##
##  ------------------------------------------------------------------------  ##
################################################################################
if [ ${backup_type} = "cold" ]
then
  echo
  echo "====>Starting instance $ORACLE_SID for RMAN closed backup"
  echo
    if [ "$ora_version" -gt 7 ]; then 
    sqlplus /nolog <<EOF >${audit_path}/ora.error.$$
    connect / as sysdba
    startup mount
    exit
EOF
  else
    svrmgrl <<EOF >${audit_path}/ora.error.$$
    connect internal
    startup mount
    exit
EOF
  fi
  grep "ORA-" ${audit_path}/ora.error.$$
  if [ $? -eq 0 ]; then
    cat ${audit_path}/ora.error.$$
    echo "#####################################################"
    echo "## ERROR ====> Startup of Oracle failed            ##"
    echo "##       ====> Backup processing cannot continue   ##"
    cat ${audit_path}/ora.error.$$ | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    notify
  fi
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##       Function to perform a full online backup of the database             ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# online_backup ()
# This function performs online backup of database as follows
# 1. It will invoke function to clean disk backups
# 2. It will generate an RMAN commands script (.rman) based on the parameters
# 3. Invoke RMAN and execute the generated command script
# 4. Perform controlfile backup at the completion of the backup command
################################################################################

online_backup ()
{
echo
echo "====>Performing online backup of "$TARGET_DB
echo
if [ "$ENCRYPTION_FLAG" = "Y" ]; then
echo "SET ENCRYPTION ON IDENTIFIED BY "$PASSWD" ONLY;"                	>> $cmd_file
chmod 640 $cmd_file
fi
echo "RUN"								>> $cmd_file
echo "{"								>> $cmd_file
echo "sql 'alter session set optimizer_mode=RULE';"                     >> $cmd_file
cnt=1
while [ ${cnt} -le ${CHANNELS} ]
do
  echo "ALLOCATE CHANNEL CH"$cnt" DEVICE TYPE "$DEVICE_TYPE" "		>> $cmd_file
if [ ${DEVICE_TYPE} !=  "SBT" ]; then
  echo "FORMAT ""'"${bkup_dir}/%d_HOT_%M""%D""%Y_%p_%s"'"		>> $cmd_file
else
  echo "FORMAT ""'"%d_HOT_%M""%D""%Y_%p_%s"'"               		>> $cmd_file
fi
echo ";"								>> $cmd_file
  cnt=`expr ${cnt} + 1`
done
echo "BACKUP"							        >> $cmd_file
if [ "$ora_version" -gt 9 ]; then
echo "AS COMPRESSED BACKUPSET"	                                        >> $cmd_file
fi
echo "FULL"								>> $cmd_file
echo "DATABASE"								>> $cmd_file
echo "TAG" ${ORACLE_SID}_HOT_${TAG_STAMP}				>> $cmd_file
echo ";"								>> $cmd_file
###############################################################################
## Backup current controlfile and resync catalog after every backup       #####
if [ ${DEVICE_TYPE} !=  "SBT" ]; then
  echo "BACKUP FORMAT ""'"${ctl_dir}/%d_%M_%D_%Y_%t.ctl"'"		>> $cmd_file
  echo "CURRENT CONTROLFILE" 						>> $cmd_file
  echo "TAG" ${ORACLE_SID}_CONTROLFILE_${TAG_STAMP}                     >> $cmd_file
  echo ";"								>> $cmd_file
else
  echo "BACKUP"                                                         >> $cmd_file
  echo "FORMAT '%d_%M_%D_%Y_%t.ctl' CURRENT CONTROLFILE"  		>> $cmd_file
  echo "TAG" ${ORACLE_SID}_CONTROLFILE_${TAG_STAMP}                     >> $cmd_file
  echo ";"                                                              >> $cmd_file
fi
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
echo "RESYNC CATALOG;"                                                  >> $cmd_file
fi
##                                                                        #####
###############################################################################
echo "}"								>> $cmd_file
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $cmd_file | tee $RMAN_LOG_FILE
check_rman_errors 
else
			echo "#####################################################"
			echo "== ERROR !!====> Catalog DB must be backed up closed "
			echo "== ERROR !!====> Backup Processing can not continue  "
			echo "#####################################################"
  notify
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##       Function to perform a full closed backup of the database             ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# closed_backup ()
# This function performs closed backup of database as follows
# 1. It will invoke function to clean disk backups 
# 2. It will generate an RMAN commands script (.rman) based on the parameters
# 3. Invoke RMAN and execute the generated command script
# 4. Will do a nocatalog backup if TARGET DB = CATALOG DB
# 5. Perform controlfile backup at the completion of the backup command
################################################################################

closed_backup ()
{
echo
echo "====>Performing closed backup of "$TARGET_DB
echo
if [ "$ENCRYPTION_FLAG" = "Y" ]; then
echo "SET ENCRYPTION ON IDENTIFIED BY "$PASSWD" ONLY;"                	>> $cmd_file
chmod 640 $cmd_file
fi
echo "RUN"                                                              >> $cmd_file
echo "{"                                                                >> $cmd_file
echo "sql 'alter session set optimizer_mode=RULE';"                     >> $cmd_file
cnt=1
while [ ${cnt} -le ${CHANNELS} ]
do
  echo "ALLOCATE CHANNEL CH"$cnt" DEVICE TYPE "$DEVICE_TYPE" "          >> $cmd_file
if [ ${DEVICE_TYPE} !=  "SBT" ]; then
  echo "FORMAT ""'"${bkup_dir}/%d_COLD_%M""%D""%Y_%p_%s"'"              >> $cmd_file
else
  echo "FORMAT ""'"%d_COLD_%M""%D""%Y_%p_%s"'"               		>> $cmd_file
fi
echo ";"                                                                >> $cmd_file
  cnt=`expr ${cnt} + 1`
done
echo "BACKUP"                                                           >> $cmd_file
if [ "$ora_version" -gt 9 ]; then
echo "AS COMPRESSED BACKUPSET"                                          >> $cmd_file
fi
echo "FULL"                                                             >> $cmd_file
echo "DATABASE"                                                         >> $cmd_file
echo "TAG" ${ORACLE_SID}_COLD_${TAG_STAMP}                              >> $cmd_file
echo ";"                                                                >> $cmd_file
###############################################################################
## Backup current controlfile and resync catalog after every backup       #####
if [ ${DEVICE_TYPE} !=  "SBT" ]; then
  echo "BACKUP FORMAT ""'"${ctl_dir}/%d_%M_%D_%Y_%t.ctl"'"              >> $cmd_file
  echo "CURRENT CONTROLFILE"                                            >> $cmd_file
  echo "TAG" ${ORACLE_SID}_CONTROLFILE_${TAG_STAMP}                     >> $cmd_file
  echo ";"                                                              >> $cmd_file
else
  echo "BACKUP"                                                         >> $cmd_file
  echo "FORMAT '%d_%M_%D_%Y_%t.ctl' CURRENT CONTROLFILE"                >> $cmd_file
  echo "TAG" ${ORACLE_SID}_CONTROLFILE_${TAG_STAMP}                     >> $cmd_file
  echo ";"                                                              >> $cmd_file
fi
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
echo "RESYNC CATALOG;"                                                  >> $cmd_file
fi
##                                                                        #####
###############################################################################
echo "}"                                                                >> $cmd_file
echo "sql 'alter database open';"					>> $cmd_file
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then 
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
else
$RMAN target /  nocatalog cmdfile $cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##      Function to perform an online incremental backup of the database      ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# online_incr_backup ()
# This function performs an online incremental backup of database as follows
# 1. It will invoke function to clean disk backups 
# 2. It will generate an RMAN commands script (.rman) based on the parameters
# 3. Invoke RMAN and execute the generated command script
# 4. Perform controlfile backup at the completion of the backup command
################################################################################

online_incr_backup ()
{
echo
echo "====>Performing online incremental backup of "$TARGET_DB
echo
if [ ${itype} == "C" ]; then
echo "====>Incremental Backup Type is Cummulative"
echo "====>Incremental Backup Level is "$ilevel
echo
else
echo "====>Incremental Backup Type is Differential"
echo "====>Incremental Backup Level is "$ilevel
echo
fi
if [ "$ENCRYPTION_FLAG" = "Y" ]; then
echo "SET ENCRYPTION ON IDENTIFIED BY "$PASSWD" ONLY;"                	>> $cmd_file
chmod 640 $cmd_file
fi
echo "RUN"								>> $cmd_file
echo "{"								>> $cmd_file
echo "sql 'alter session set optimizer_mode=RULE';"                     >> $cmd_file
cnt=1
while [ ${cnt} -le ${CHANNELS} ]
do
  echo "ALLOCATE CHANNEL CH"$cnt" DEVICE TYPE "$DEVICE_TYPE" "		>> $cmd_file
if [ ${DEVICE_TYPE} !=  "SBT" ]; then
  echo "FORMAT ""'"${bkup_dir}/%d_HOT_%M""%D""%Y_%p_%s"'"               >> $cmd_file
else
  echo "FORMAT ""'"%d_HOT_%M""%D""%Y_%p_%s"'"                           >> $cmd_file
fi
echo ";"                                                                >> $cmd_file
  cnt=`expr ${cnt} + 1`
done
echo "BACKUP"                                                           >> $cmd_file
if [ "$ora_version" -gt 9 ]; then
echo "AS COMPRESSED BACKUPSET"                                          >> $cmd_file
fi
echo "INCREMENTAL LEVEL = "$ilevel					>> $cmd_file
if [ ${itype} == "C" ]; then
echo "CUMULATIVE"							>> $cmd_file
fi
echo "DATABASE"								>> $cmd_file
echo "TAG" ${ORACLE_SID}_HOTINCR_${TAG_STAMP}				>> $cmd_file
echo ";"								>> $cmd_file
###############################################################################
## Backup current controlfile and resync catalog after every backup       #####
if [ ${DEVICE_TYPE} !=  "SBT" ]; then
  echo "BACKUP FORMAT ""'"${ctl_dir}/%d_%M_%D_%Y_%t.ctl"'"              >> $cmd_file
  echo "CURRENT CONTROLFILE"                                            >> $cmd_file
  echo "TAG" ${ORACLE_SID}_CONTROLFILE_${TAG_STAMP}                     >> $cmd_file
  echo ";"                                                              >> $cmd_file
else
  echo "BACKUP"                                                         >> $cmd_file
  echo "FORMAT '%d_%M_%D_%Y_%t.ctl' CURRENT CONTROLFILE"                >> $cmd_file
  echo "TAG" ${ORACLE_SID}_CONTROLFILE_${TAG_STAMP}                     >> $cmd_file
  echo ";"                                                              >> $cmd_file
fi
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
echo "RESYNC CATALOG;"                                                  >> $cmd_file
fi
##                                                                        #####
###############################################################################
echo "}"								>> $cmd_file
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then 
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
else
			echo "#####################################################"
			echo "== ERROR !!====> Catalog DB must be backed up closed "
			echo "== ERROR !!====> Backup Processing can not continue  "
			echo "#####################################################"
  notify
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##      Function to perform a closed incremental backup of the database       ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# closed_incr_backup ()
# This function performs closed incremental backup of database as follows
# 1. It will invoke function to clean disk backups 
# 2. It will generate an RMAN commands script (.rman) based on the parameters
# 3. Invoke RMAN and execute the generated command script
# 4. Will do a nocatalog backup if TARGET DB = CATALOG DB
# 5. Perform controlfile backup at the completion of the backup command
################################################################################

closed_incr_backup ()
{
echo
echo "====>Performing closed incremental backup of "$TARGET_DB
echo
if [ ${itype} == "C" ]; then
echo "====>Incremental Backup Type is Cummulative"
echo "====>Incremental Backup Level is "$ilevel
echo
else
echo "====>Incremental Backup Type is Differential"
echo "====>Incremental Backup Level is "$ilevel
echo
fi
if [ "$ENCRYPTION_FLAG" = "Y" ]; then
echo "SET ENCRYPTION ON IDENTIFIED BY "$PASSWD" ONLY;"                	>> $cmd_file
chmod 640 $cmd_file
fi
echo "RUN"                                                              >> $cmd_file
echo "{"                                                                >> $cmd_file
echo "sql 'alter session set optimizer_mode=RULE';"                     >> $cmd_file
cnt=1
while [ ${cnt} -le ${CHANNELS} ]
do
  echo "ALLOCATE CHANNEL CH"$cnt" DEVICE TYPE "$DEVICE_TYPE" "          >> $cmd_file
if [ ${DEVICE_TYPE} !=  "SBT" ]; then
  echo "FORMAT ""'"${bkup_dir}/%d_COLD_%M""%D""%Y_%p_%s"'"              >> $cmd_file
else
  echo "FORMAT ""'"%d_COLD_%M""%D""%Y_%p_%s"'"                          >> $cmd_file
fi
echo ";"                                                                >> $cmd_file
  cnt=`expr ${cnt} + 1`
done
echo "BACKUP"                                                           >> $cmd_file
if [ "$ora_version" -gt 9 ]; then
echo "AS COMPRESSED BACKUPSET"                                          >> $cmd_file
fi
echo "INCREMENTAL LEVEL = "$ilevel                                      >> $cmd_file
if [ ${itype} == "C" ]; then
echo "CUMULATIVE"                                                       >> $cmd_file
fi
echo "DATABASE"                                                         >> $cmd_file
echo "TAG" ${ORACLE_SID}_COLDINCR_${TAG_STAMP}                          >> $cmd_file
echo ";"                                                                >> $cmd_file
###############################################################################
## Backup current controlfile and resync catalog after every backup       #####
if [ ${DEVICE_TYPE} !=  "SBT" ]; then
  echo "BACKUP FORMAT ""'"${ctl_dir}/%d_%M_%D_%Y_%t.ctl"'"              >> $cmd_file
  echo "CURRENT CONTROLFILE"                                            >> $cmd_file
  echo "TAG" ${ORACLE_SID}_CONTROLFILE_${TAG_STAMP}                     >> $cmd_file
  echo ";"                                                              >> $cmd_file
else
  echo "BACKUP"                                                         >> $cmd_file
  echo "FORMAT '%d_%M_%D_%Y_%t.ctl' CURRENT CONTROLFILE"                >> $cmd_file
  echo "TAG" ${ORACLE_SID}_CONTROLFILE_${TAG_STAMP}                     >> $cmd_file
  echo ";"                                                              >> $cmd_file
fi
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
echo "RESYNC CATALOG;"                                                  >> $cmd_file
fi
##                                                                        #####
###############################################################################
echo "}"                                                                >> $cmd_file
echo "sql 'alter database open';"					>> $cmd_file
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then 
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
else
$RMAN target /  nocatalog cmdfile $cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##          Function to perform backup of archivelogs of the database         ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# arch_backup ()
# This is a standalone function which will backup archivelogs of a database
# 1. It will generate an RMAN commands script (.rman) based on the parameters
# 2. Invoke RMAN and execute the generated command script
# 3. It will delete the archivelogs for which the backup has been completed
# 4. It will perform a manual RESYNC of the catalog to keep it up-to-date 
################################################################################

arch_backup ()
{
echo
echo "====>Backing up Archivelogs of "$TARGET_DB
echo
if [ "$ENCRYPTION_FLAG" = "Y" ]; then
echo "SET ENCRYPTION ON IDENTIFIED BY "$PASSWD" ONLY;"                	>> $arch_cmd_file
chmod 640 $arch_cmd_file
fi
echo "RUN"								>> $arch_cmd_file
echo "{"								>> $arch_cmd_file
echo "sql 'alter session set optimizer_mode=RULE';"                     >> $arch_cmd_file
echo "sql 'alter system archive log current';"				>> $arch_cmd_file
cnt=1
while [ ${cnt} -le ${CHANNELS} ]
do
  echo "ALLOCATE CHANNEL CH"$cnt" DEVICE TYPE "$DEVICE_TYPE" "		>> $arch_cmd_file
if [ ${DEVICE_TYPE} !=  "SBT" ]; then
  echo "FORMAT ""'"${arch_dir}/%d_ARCH_%M""%D""%Y_%p_%s"'"              >> $arch_cmd_file
else
  echo "FORMAT ""'"%d_ARCH_%M""%D""%Y_%p_%s"'"                          >> $arch_cmd_file
fi
echo ";"								>> $arch_cmd_file
  cnt=`expr ${cnt} + 1`
done
echo "BACKUP"                                                           >> $arch_cmd_file
if [ "$ora_version" -gt 9 ]; then
echo "AS COMPRESSED BACKUPSET"                                          >> $arch_cmd_file
fi
echo "ARCHIVELOG"							>> $arch_cmd_file
echo "ALL"								>> $arch_cmd_file
echo "TAG" ${ORACLE_SID}_ARCH_${TAG_STAMP}				>> $arch_cmd_file
echo "DELETE INPUT"							>> $arch_cmd_file
echo ";"								>> $arch_cmd_file
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
  echo "RESYNC CATALOG;"                                                >> $arch_cmd_file
fi
echo "}"								>> $arch_cmd_file

if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $arch_cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
else
$RMAN target /  nocatalog cmdfile $arch_cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
fi

}

################################################################################
##  ------------------------------------------------------------------------  ##
##            Function to create a generic RMAN recovery script               ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# generate_recovery_script()
# This is a standalone function which will generate a generic recovery script 
# to completely restore and recover a database.
# THIS SCRIPT IS ONLY A GUIDELINE recovery scenarios are different based on the
# type of failure and many other factors.
################################################################################

generate_recovery_script ()
{
rm $rec_cmd_file > /dev/null 2>&1
echo
echo "====>Generating recovery script for" $TARGET_DB
echo
echo "#############################################################"	>> $rec_cmd_file
echo "# Before performing any type of recovery using RMAN, you 	   "	>> $rec_cmd_file
echo "# MUST identify the conditions under which you will perform  "	>> $rec_cmd_file
echo "# the recovery					  	   "	>> $rec_cmd_file
echo "#                                                            "    >> $rec_cmd_file
echo "# The recovery procedure differs depending on whether:	   "	>> $rec_cmd_file
echo "#								   "	>> $rec_cmd_file
echo "# -- Current control file is available 		  	   "	>> $rec_cmd_file
echo "# -- You are using a recovery catalog 			   "	>> $rec_cmd_file
echo "# -- Restore host is the same as the target host		   "	>> $rec_cmd_file
echo "# -- Restored DB files are named same as target DB files	   "	>> $rec_cmd_file
echo "# -- Target DB is running  in a RAC configuration		   "	>> $rec_cmd_file
echo "# -- Time you wish to recover to current/non-current 	   "	>> $rec_cmd_file
echo "# -- Recovering the whole/partial database 		   "	>> $rec_cmd_file
echo "# -- You have a backup made after the most recent RESETLOGS  "	>> $rec_cmd_file
echo "# -- Recovering entire datafiles rather than a limited 	   "	>> $rec_cmd_file
echo "#    number of corrupt data blocks 			   "	>> $rec_cmd_file
echo "#								   "	>> $rec_cmd_file
echo "# Please refer to RMAN Users Guide for more information	   "	>> $rec_cmd_file
echo "#############################################################"	>> $rec_cmd_file
echo "								   "	>> $rec_cmd_file
echo "STARTUP NOMOUNT;						   "	>> $rec_cmd_file
echo "RESTORE CONTROLFILE;					   "	>> $rec_cmd_file
echo "ALTER DATABASE MOUNT;					   "	>> $rec_cmd_file
echo "								   "	>> $rec_cmd_file
echo "RUN							   "	>> $rec_cmd_file
echo "{								   "	>> $rec_cmd_file
cnt=1
while [ ${cnt} -le ${CHANNELS} ]
do
  echo "ALLOCATE CHANNEL CH"$cnt" DEVICE TYPE "$DEVICE_TYPE" ;     "	>> $rec_cmd_file
  cnt=`expr ${cnt} + 1`
done
echo "RESTORE DATABASE;						   "	>> $rec_cmd_file
echo "RECOVER DATABASE;                                            "    >> $rec_cmd_file
echo "}								   "	>> $rec_cmd_file
}

################################################################################
##  ------------------------------------------------------------------------  ##
##            Function to check and report errors generated by RMAN           ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# check_rman_errors()
# This is a standalone function which will trap RMAN specific errors when a RMAN
# block gets run. It will also cat the $RMAN_LOG_FILE to standard output
################################################################################

check_rman_errors ()
{
grep -e RMAN- -e ORA-  $RMAN_LOG_FILE
  if [ $? -eq 0 ]; then
   notify
  fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##        Function to perform post processing - init.ora / ctlfile copy       ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# post_processing()
# This function performs following actions at the successful completion of a
# backup.
# 1. copies init<sid>.ora to location provided as BACKUP_HOME
# 2. copies controlfile to location provided as BACKUP_HOME
################################################################################

post_processing ()
{
sqlplus -s system/${PASSWD} <<END
set pagesize 1000 linesize 200 heading on feedback on
/*##############################################################################
##                       Backup control file to trace                         ##   
##############################################################################*/
prompt
prompt ====>Backup controlfile to trace
alter database backup controlfile to trace;
END
sqlplus -s system/${PASSWD} <<END >/dev/null
set pagesize 0 feedback off verify off echo off termout off heading off
/*##############################################################################
##         query the oracle catalog for the name of the user dump dir         ##
##############################################################################*/
spool ${audit_path}/bkdest.list.$$
select value
  from v\$parameter where name = 'user_dump_dest';
spool off
END
################################################################################
##      copy the latest control file trace to the default backup directory    ##
################################################################################
echo "====>Copy the controlfile trace to ${default_dir}/control.create"
dump_dest=`cat ${audit_path}/bkdest.list.$$ | awk '{
  if (substr($1,length($1),1) == "/") {print $1} else {print $1 "/"}}'`
cd ${dump_dest}
trc_count=`ls -t *ora* | wc -l | awk '{print $NF}'`
if [ ${trc_count} -gt 1 ]; then
  last_trc=`ls -t *ora* | sed -e 2,${trc_count}d`
else
  last_trc=`ls -t *ora*`
fi
echo 
cp ${last_trc} ${default_dir}/control.create
################################################################################
##        copy the latest parameter file to the default backup directory      ##
################################################################################
echo
echo "====>Copy the instance parameter file to the default backup directory"
echo
init_filename=`echo $init_file|awk -F/ '{print $NF}'`
echo "Copying ${init_file} to ${default_dir}/${init_filename}"
cp ${init_file} ${default_dir}/${init_filename}
}

################################################################################
##  ------------------------------------------------------------------------  ##
##          Function to cleanup disk backups of the database                  ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# backup_cleanup ()
# This is a standalone function which will delete backups existing on disk which
# have already been copied to tape prior to taking another backup.
# 1. It will generate an RMAN commands script (.rman)
# 2. Invoke RMAN and execute the generated command script
################################################################################

backup_cleanup ()
{
if [ ${TAPECOPY_ACTIVE} ==  "N" ]; then
     echo
     echo "====>Deleting all disk backups of "$TARGET_DB" "
     echo
     echo "sql 'alter session set optimizer_mode=RULE';"                     >> $cln_cmd_file
     echo "ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE DISK;"               >> $cln_cmd_file
     echo "DELETE NOPROMPT BACKUP;"			 		     >> $cln_cmd_file
elif [ ${TAPECOPY_ACTIVE} ==  "Y" ]; then
     sqlplus -s system/${PASSWD} << END                                      >> $cln_cmd_file
     set pagesize 0 feedback off verify off echo off termout off heading off
     SELECT ' sql ''' || 'alter session set optimizer_mode=RULE'';'
       FROM DUAL
     UNION
     SELECT 'ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE DISK;'
       FROM DUAL
     UNION
     SELECT DISTINCT 'DELETE NOPROMPT BACKUPSET TAG ' || tag || ';'
                FROM v\$backup_piece
               WHERE device_type = 'DISK'
                 AND deleted = 'NO'
                 AND set_count IN (SELECT set_count
                                     FROM v\$backup_piece
                                    WHERE device_type = 'SBT_TAPE');
END
fi
if [ $(wc -l < $cln_cmd_file) -gt 2 ]; then
     echo
     echo "====>Deleting backups of "$TARGET_DB" copied to tape"
     echo
     	if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $cln_cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
	else
$RMAN target /  nocatalog cmdfile $cln_cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
	fi
else
     echo
     echo "====>No purgable backups of "$TARGET_DB" found in "$default_dir
     echo
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##          Function to delete obsolete backups of the database               ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# delete_obsolete()
# This is a standalone function which will delete the obsolete backups of a
# database on disk/tape based on the retention period specified in configuration
# 1. It will generate an RMAN commands script (.rman)
# 2. Invoke RMAN and execute the generated command script
# 3. It will delete the obsolete backups
################################################################################

delete_obsolete()
{
echo
echo "====>Deleting obsolete backups for " $TARGET_DB
echo
echo "sql 'alter session set optimizer_mode=RULE';"                     >> $obs_cmd_file
echo "ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE SBT;"		>> $obs_cmd_file
echo "ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE DISK;"		>> $obs_cmd_file
echo "DELETE FORCE OBSOLETE;"						>> $obs_cmd_file
if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $obs_cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
else
$RMAN target /  nocatalog cmdfile $obs_cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##  			FUNCTION TO RUN BACKUPS				      ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# run_backup() 
# This function establishes the path to backup processing based on parameters
# 1. It will check for the type of backup requested based on the parameters and
# run the appropriate function to perform the actual backup to be performed.
# 2. It will also process deleting the obsolete backup if requested 
################################################################################

run_backup () 
{
if   [ "$backup_type" = "hot" ]; then
		check_db_state
	if [ "$archivelog_sw" = 1 ]; then
		if [ "$INCREMENTAL_FLAG" = "Y" ]; then
     			online_incr_backup
			arch_backup
     			post_processing
			generate_recovery_script
		elif [ "$INCREMENTAL_FLAG" = "N" ]; then
     			online_backup
			arch_backup
     			post_processing
			generate_recovery_script
     		fi
	else
			echo "#####################################################"
			echo "== ERROR !!====> Database is in NOARCHIVELOG mode    "
			echo "== ERROR !!====> Backup Processing can not continue  "
			echo "#####################################################"
			notify
	fi
elif [ "$backup_type" = "cold" ]; then
		check_db_state
	if [ "$archivelog_sw" = 1 ]; then
		# Do arch_backup if db is in archivelogmode #
	     	if [ "$INCREMENTAL_FLAG" = "Y" ]; then
			closed_incr_backup
			arch_backup
			post_processing
			generate_recovery_script
		elif [ "$INCREMENTAL_FLAG" = "N" ]; then
			closed_backup
			arch_backup
			post_processing
			generate_recovery_script
		fi
	else
		# Do not arch_backup because db is in noarchivelog mode #
		if [ "$INCREMENTAL_FLAG" = "Y" ]; then
                        closed_incr_backup
                        post_processing
                        generate_recovery_script
                elif [ "$INCREMENTAL_FLAG" = "N" ]; then
                        closed_backup
                        post_processing
                        generate_recovery_script
                fi
	fi
elif [ "$backup_type" = "arch" ]; then
     		check_db_state
	if [ "$archivelog_sw" = 1 ]; then
		arch_backup
	else
			echo "#####################################################"
			echo "== ERROR !!====> Database is in NOARCHIVELOG mode    "
			echo "== ERROR !!====> Backup Processing can not continue  "
			echo "#####################################################"
			notify
	fi

fi

################################################################################
##        		delete obsolete processing       		      ##
################################################################################
if [ ${backup_type} != "arch" ]; then
  if [ "$do_day" = "0" ]; then
	echo
	echo "====>Delete obsolete is not scheduled to run for " $TARGET_DB
	echo
  else
        delete_obsolete
  fi
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##                        MAIN SCRIPT EXECUTION                               ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# These are the high level instructions that drive the processing of the script.
# 1. If there is a backup already in progress then the script will exit
# 2. If there was a failure encountered on earlier run, it will exit with 
# instructions to clear the message and restart the script
# 3. Run cleanup done for pre/post-processing
# 4. Generate lock files before starting the backup processing
# 5. Remove the lock files after the backup processing has been completed
################################################################################

if [ -h $rman_lock_file ]; then
   last_pid=`ls -l $rman_lock_file | awk '{print substr($11,5)}'`
   last_ppid=`ls -l $rman_lock_file | awk '{print substr($12,6)}'`
   alive_pid=`ps -o pid -p "$last_pid" | tail -1`
   alive_ppid=`ps -o ppid -p "$last_pid" | tail -1`

   if [ "$alive_pid" = "  PID" ]; then
        alive_pid=0
   fi
   if [ "$alive_ppid" = " PPID" ]; then
        alive_ppid=0
   fi

     if [ "$last_pid" -eq "$alive_pid" ] && [ "$last_ppid" -eq "$alive_ppid" ]; then
	echo "====>backup_rman.sh is already running for $TARGET_DB on pid "$last_pid
        echo "====>Script is terminating!!                                   "
	addl_msg="cancelled due to a conflicting process"
	msg_body="backup_rman.sh is already running for $TARGET_DB on pid "$last_pid
        notify
     elif [ "$last_pid" -ne "$alive_pid" ] && [ "$last_ppid" -ne "$alive_ppid" ]; then
    	echo "====>Previous run of backup_rman.sh did not complete successfully"
	echo
        echo "====>Cleaning up lock file from the previous run		   "
	echo 
	lock_unlock action=unlock name=$rman_lock_file
	echo "====>Continuing execution of backup_rman.sh"
	lock_unlock action=lock name=$rman_lock_file expire=86400 id=oracle.rman
	run_cleanup
	run_backup
	run_cleanup
	lock_unlock action=unlock name=$rman_lock_file
     fi
else
	lock_unlock action=lock name=$rman_lock_file expire=86400 id=oracle.rman
        run_cleanup
        run_backup
        run_cleanup
        lock_unlock action=unlock name=$rman_lock_file
fi

echo "************************************************************************"
echo "====>Script backup_rman.sh Ending on" `date`
echo "************************************************************************"
