#!/usr/bin/ksh
. /p078/oracle50/bin/hrp1
oncall=`grep "all:all" $HOME/bin/notify.ctl | cut -d: -f3`
pgoncall=`grep "#$oncall" $HOME/bin/notify.ctl | cut -d: -f2`
mailme="$pgoncall GTSOHRDBA@corporate.ge.com cis.ohrtcscontrs@corporate.ge.com"
stop_me=1
while [ $stop_me -ne 0 ]
do
if [ ! -f /p078/dba50/oracle50/audit/stopmon1 ]
then
sqlplus -s system/`/p078/oracle50/bin/tellme system` <<EOF
set linesize 132 
set pagesize 0 linesize 80 feedback off verify off echo off termout off heading off
spool /p078/dba50/oracle50/audit/lock_mon.lst
select /*+ RULE */ session_id                   
from dba_locks                         
where blocking_others = 'Blocking' and 
mode_held != 'None' and                
mode_held != 'Null'; 
EOF
lcount=`cat /p078/dba50/oracle50/audit/lock_mon.lst|wc -l`
echo $lcount `date`
if [ $lcount -gt 1 ]
then
### To stop the script on first lock occurance make this to 0 
 stop_me=1
 echo "please check $DBA_HOME/audit/DEAD_LOCK_WAITERS.LST"|mailx -s "Blocking lock Found in production hrp1" $mailme

 echo "please check $DBA_HOME/audit/DEAD_LOCK_WAITERS.LST"|mailx -s "Blocking lock Found in production hrp1 " 07659185675@paging.vodafone.net

cd $DBA_HOME/audit
sqlplus -s system/`/p078/oracle50/bin/tellme system` <<EOF
@$DBA_HOME/admin/deadlock.sql
EOF
fi

else
 stop_me=0
fi

i=1
while [ $i -ne 60 ]                    
do                                      
sleep 3                                 
if [ -f /p078/dba50/oracle50/audit/stopmon1 ] 
then                                    
i=60
stop_me=0
else
i=`expr $i + 1`
fi
done
done
