#!/bin/ksh
########################################################################
## tape_coldbackup.sh
##
##   PURPOSE: To execute a cold Oracle backup directly to tape for the sid
##     supplied as input. The applicable tape archive system for the current
##     host is supplied by environment variable $TAPE.
##   USAGE: This script is called by the utility.sh script when a scheduled
##          tape_coldbackup entry exists in control file,
##          $SID_HOME/admin/utility.ctl.
##     The command line submitted by utility.sh is:
##          tape_coldbackup.sh sid [AltInitFile] [AltMgmtClass] 
##          >$SID_HOME/audit/tape_coldbackup_${ORACLE_SID}.auditMMDD[_HHMM] 2>&1
##     The required utility.ctl record format is:
##          tape_coldbackup:wwwwwddddddd[:AlternatePfile]
##          where w(fiscal week)=0(skip),1(run); d(day)=0(skip),1(run)
##   SCRIPT PROCESS FLOW:
##     1) Stop any Oracle concurrent managers for instances running Oracle
##        Applications
##     2) Shutdown Oracle abort to kill any active users
##     3) Startup Oracle in restrict mode 
##     4) Query the Oracle catalog for a list of data, log, and control files
##        to backup
##     5) Shutdown Oracle immediate
##     6) Issue a tape save command for each unique directory level extracted
##        from the Oracle datafile list created in 4)
##     7) Restart Oracle for user access using the alternate pfile if input
##     8) Restart Oracle concurrent managers for instances using Oracle
##        Applications
##     9) Create an Oracle controlfile trace and save trace to tape
##    10) Copy the instance parameter file to tape
##   RESTART: All restarts should be performed using the restart capabilities
##        of the utility.sh script. If you choose to restart the
##        tape_coldbackup.sh script itself, you will loose the email
##        notification and audit trail formatting provided by utility.sh.
##   NOTIFICATION: Email notification of abends will be directed to the oncall
##        Oracle DBA; email notification for successful and failed executions 
##        will always be directed to the responsible DBA for this instance.  
##        This script MUST be initiated by script utility.sh to activate this
##        notification process. $HOME/bin/notify.ctl must contain the proper 
##        notification names.
##   MODIFICATIONS:
##        Date        Name         Description
##        ----------  -----------  --------------------------------------------
##        02/25/1998  S Kalkowski  Removed the logic to stop/start the Oracle
##                                 Applications Concurrent Manager;  this
##                                 functionality was moved to a new utility
##                                 process;  ccmgr.sh
##        04/20/1998  L Slyer      Add logic to support adsm tape backups
##
########################################################################
## ------------------------------------------------------------------------ ##
##         check_adsm - function to parse ADSM log                          ##
## ------------------------------------------------------------------------ ##
check_adsm() {
  save_rc=$1
  if [ "$TAPE" != "adsm" ]; then
    # honor actual return code
    return $save_rc
  fi
  if [ -z "$dsm_log" ]; then
    echo "Internal errror: ADSM temporary log file not defined"
    return 1
  fi
  if [ -s "$dsm_log" ]; then
    cat $dsm_log
    failures=`awk '/^Total number of objects failed:/ {failures += $6} END{print failures}' $dsm_log`
    if [ -z "$failures" ]; then
      # expected line not found --- assume abend
      return 1
    else
      return $failures
    fi
  else
    # empty log file
    echo "ADSM temporary log file is empty."
    return 1
  fi
}

## ------------------------------------------------------------------------ ##
##         Process inputs and set the instance and script environment       ##
## ------------------------------------------------------------------------ ##
# Verify sid input
if [ -z "$1" ]
then
  echo "Error====>Required parameter is missing"
  echo "          Usage is tape_coldbackup.sh sid"
  echo "          Script is terminating!"
  exit 1
fi
# Set the instance environment
if [ ! -f $HOME/bin/$1 ]
then
  echo "Error====>No environment script found for instance \"$1\""
  echo "          Script is terminating!"
  exit 1
fi
. $HOME/bin/$1
scripts_path=$DBA_HOME/admin
audit_path=$SID_HOME/audit
cntl_path=$SID_HOME/admin
# Set the Oracle init file and the adsm management class to parameter
# input or to the default value if not supplied
init_file=$ORACLE_HOME/dbs/init${ORACLE_SID}.ora
mgmt_class=cis35day
if [ ! -z "$3" ]
then
  if [ "`echo $3|cut -c1-3`" = "cis" ]
  then
    mgmt_class=$3
    if [ ! -z "$4" ]
    then
      init_file=$ORACLE_HOME/dbs/$4
    fi
  else
    init_file=$ORACLE_HOME/dbs/$3
    if [ ! -z "$4" ]
    then
      mgmt_class=$4
    fi
  fi
fi
if [ ! -f $init_file ]
then
  echo "Error====>Oracle pfile does not exist"
  echo "          Script is terminating!"
  exit 1
fi
# Verify that variable $TAPE is defined
if [ -z "$TAPE" ]
then
  echo 'Error====>Environment variable $TAPE is not defined'
  echo "          Script is terminating!"
  exit 1
fi
if [ "$TAPE" = "adsm" ]
then
  dsm_log=$audit_path/adsm.log.$$
  save_command="dsmc archive -archmc=$mgmt_class -subdir=y -quiet"
  #save_command="dsmc archive -archmc=$mgmt_class -subdir=y -q"  
  save_redir=">$dsm_log 2>&1" 
else
   if [ "$TAPE" = "nsr" ]
   then
     save_command="save -q -N `hostname`$ORACLE_SID"  
     if [ ! -z "$TAPE_SERVER" ]
     then
       save_command="$save_command -s $TAPE_SERVER"
     fi
   else  
     echo "Error====>Tape_coldbackup.sh does not support $TAPE tape archiving"
     echo "          Script is terminating!"
     exit 1
   fi
fi
echo "************************************************************************"
echo "====>Script tape_coldbackup.sh starting on" `date`
echo "************************************************************************"
echo
PASSWD=`$HOME/bin/tellme system`
# Remove any files from previous executions of the backup script
rm ${audit_path}/backup.${ORACLE_SID}.list >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.sort >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.lvl >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.control >/dev/null 2>&1
rm ${audit_path}/bkdest.list > /dev/null 2>&1
rm ${audit_path}/ora.error > /dev/null 2>&1
error_switch=0
cd ${scripts_path}
## ------------------------------------------------------------------------ ##
##         For Oracle App instances,                                        ##
##         stop any concurrent managers before shutting down Oracle         ##
## ------------------------------------------------------------------------ ##
if [ ! -z "${APPL_TOP}" ]
then
  $DBA_HOME/admin/ccmgr.sh $ORACLE_SID stop
fi
## ------------------------------------------------------------------------ ##
##         Shutdown Oracle abort                                            ##
## ------------------------------------------------------------------------ ##
echo
echo "====>Shutting down instance $ORACLE_SID to kill any active users"
# Added by David DeClercq
  if [ "`echo exit|sqlplus /nolog|grep 'Release [8-9]'`" ]
  then
    sqlplus /nolog <<EOF >${audit_path}/ora.error
    connect / as sysdba
    shutdown abort
    exit
EOF
  else
    svrmgrl <<EOF >${audit_path}/ora.error
    connect internal
    shutdown abort
    exit
EOF
  fi
grep "ORA-" ${audit_path}/ora.error
if [ $? -eq 0 ]
then
  echo "#####################################################"
  echo "## ERROR ====> Shutdown abort of Oracle failed"
  echo "##       ====> Backup processing cannot continue"
  cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
  echo "#####################################################"
  error_switch=1
  exit 1
fi
## ------------------------------------------------------------------------ ##
##         Start up Oracle restrict                                         ##
## ------------------------------------------------------------------------ ##
echo
echo "====>Starting instance $ORACLE_SID in restrict mode"
# Added by David DeClercq
  if [ "`echo exit|sqlplus /nolog|grep 'Release [8-9]'`" ]
  then
    sqlplus /nolog <<EOF >${audit_path}/ora.error
    connect / as sysdba
    startup restrict
    exit
EOF
  else
    svrmgrl <<EOF >${audit_path}/ora.error
    connect internal
    startup restrict
    exit
EOF
  fi
grep "ORA-" ${audit_path}/ora.error
if [ $? -eq 0 ]
then
  echo "#####################################################"
  echo "## ERROR ====> Startup of Oracle failed"
  echo "##       ====> Backup processing cannot continue"
  cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
  echo "#####################################################"
  error_switch=1
  exit 1
fi
echo
echo "====>Query the oracle catalog for a list of datafiles to backup"
sqlplus -s system/${PASSWD} <<END >${audit_path}/ora.error
/* ------------------------------------------------------------------------ */
/*      obtain a list of data and log files to backup for this ORACLE_SID   */
/* ------------------------------------------------------------------------ */
set pagesize 0 linesize 80 feedback off verify off echo off termout off heading off
spool ${audit_path}/backup.${ORACLE_SID}.list
/* ====>  select all tablespace names and associated datafiles        <==== */
select substr(file_name,1,80)
  from dba_data_files;
/* ====>  select all log group member names                           <==== */
select member from v\$logfile;
spool off
END
grep "ORA-" ${audit_path}/ora.error
if [ $? -eq 0 ]
then
  echo "############################################################"
  echo "## ERROR ====> Failed to produce list of datafiles to backup"
  echo "##       ====> Backup processing cannot continue"
  cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
  echo "############################################################"
  error_switch=1
# attempt to disable restricted session before exiting
# Added by David DeClercq
  if [ "`echo exit|sqlplus /nolog|grep 'Release [8-9]'`" ]
  then
    sqlplus /nolog <<EOF >/dev/null
    connect / as sysdba
    alter system disable restricted session;
    exit
EOF
  else
    svrmgrl <<EOF >/dev/null
    connect internal
    alter system disable restricted session;
    exit
EOF
  fi
  exit 1
fi
sqlplus -s system/$PASSWD <<END >/dev/null
/* ------------------------------------------------------------------------ */
/*         obtain a list of control files to backup for this ORACLE_SID     */
/* ------------------------------------------------------------------------ */
set pagesize 0 linesize 512 feedback off verify off echo off termout off heading off
spool ${audit_path}/backup.${ORACLE_SID}.control
select value
 from v\$parameter where name = 'control_files';
spool off
END
awk -F",[ ]*|[ ]+" '{
for (i = 1; i <= NF; i++) if ($i != "") {print $i}
}' ${audit_path}/backup.${ORACLE_SID}.control >>${audit_path}/backup.${ORACLE_SID}.list
echo
echo ${ORACLE_SID} oracle database file count is `cat ${audit_path}/backup.${ORACLE_SID}.list|wc -l`
## ------------------------------------------------------------------------ ##
##         Shutdown Oracle immediate                                        ##
## ------------------------------------------------------------------------ ##
echo
echo "====>Shutting down instance $ORACLE_SID for a cold backup"
# Added by David DeClercq
  if [ "`echo exit|sqlplus /nolog|grep 'Release [8-9]'`" ]
  then
    sqlplus /nolog <<EOF >${audit_path}/ora.error
    connect / as sysdba
    shutdown immediate
    exit
EOF
  else
    svrmgrl <<EOF >${audit_path}/ora.error
    connect internal
    shutdown immediate
    exit
EOF
  fi
grep "ORA-" ${audit_path}/ora.error
if [ $? -eq 0 ]
then
  cat ${audit_path}/ora.error
  echo "#####################################################"
  echo "## ERROR ====> Shutdown  of Oracle failed"
  echo "##       ====> Backup processing cannot continue"
  cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
  echo "#####################################################"
  error_switch=1
  exit $error_switch
fi
echo
echo "====>Starting tape backup of $ORACLE_SID database files on" `date`
echo
## ------------------------------------------------------------------------ ##
# Loop over the data, log, and control file list previously created from the 
# Oracle catalog  to create a new file list that eliminates duplicate
# directory levels.
## ------------------------------------------------------------------------ ##
sort -o ${audit_path}/backup.${ORACLE_SID}.sort ${audit_path}/backup.${ORACLE_SID}.list
awk -F"/" '
BEGIN {
last_lvl=""
}
{lvl=""
 for (i = 2; i < NF; i++) lvl = lvl "/" $i
 if ( lvl != last_lvl)
  {print lvl
   last_lvl=lvl
  }
}' ${audit_path}/backup.${ORACLE_SID}.sort > ${audit_path}/backup.${ORACLE_SID}.lvl
echo "====>Offload Oracle datafiles, logs and controlfiles to tape"
## ------------------------------------------------------------------------ ##
# Loop over the unique directory level list and issue a tape save command
# for each level identified.  
## ------------------------------------------------------------------------ ##
while read backup_lvl
do
  echo
  echo ">>> Offload $backup_lvl <<<"
  echo
  if [ -d $backup_lvl ]
  then
    slash_sw=`echo $backup_lvl | awk '{
      if (substr($1,length($1),length($1)) == "/")
      {print "0"} else {print "1"}}'`
    if [ $slash_sw -eq 1 ]
    then
      backup_lvl=${backup_lvl}"/"
    fi
  fi
  eval $save_command $backup_lvl $save_redir
  save_status=$?
  echo ADSM return_code=$save_status
  check_adsm $save_status
  if [ $? -ne 0 ]
  then
    echo
    echo "##########################################################"
    echo "## ERROR ====> Offload of $backup_lvl abended"
    echo "##       ====> Script is terminating"
    echo "##########################################################"
    error_switch=1
  fi
done<${audit_path}/backup.${ORACLE_SID}.lvl
echo
# If any errors were detected while backing up any Oracle directory then
# terminate processing now with a nonzero return code
if [ ${error_switch} -eq 1 ]
then
  echo "====>Tape backup of ${ORACLE_SID} abended on" `date`
  exit 1
else
  echo "====>Tape backup of ${ORACLE_SID} completed on" `date`
fi
## ------------------------------------------------------------------------ ##
##         Startup Oracle                                                   ##
## ------------------------------------------------------------------------ ##
echo
echo "====>Starting instance $ORACLE_SID for user access"
echo
echo "Using pfile $init_file"
echo
# Added by David DeClercq
  if [ "`echo exit|sqlplus /nolog|grep 'Release [8-9]'`" ]
  then
    sqlplus /nolog <<EOF >${audit_path}/ora.error
    connect / as sysdba
    startup open pfile=$init_file
    exit
EOF
  else
    svrmgrl <<EOF >${audit_path}/ora.error
    connect internal
    startup open pfile=$init_file
    exit
EOF
  fi
grep "ORA-" ${audit_path}/ora.error
if [ $? -eq 0 ]
then
  cat ${audit_path}/ora.error
  echo "#####################################################"
  echo "## ERROR ====> Startup of Oracle failed"
  echo "##       ====> Backup processing cannot continue"
  cat ${audit_path}/ora.error | grep ORA- | awk '{print "##", $0}'
  echo "#####################################################"
  error_switch=1
  exit $error_switch
fi
## ------------------------------------------------------------------------ ##
##         For Oracle App instances,                                        ##
##         start any concurrent managers after starting Oracle              ##
## ------------------------------------------------------------------------ ##
if [ ! -z "${APPL_TOP}" ]
then
  $DBA_HOME/admin/ccmgr.sh $ORACLE_SID start
fi
sqlplus -s system/${PASSWD} <<END
set pagesize 1000 linesize 200 heading on feedback on
/* ------------------------------------------------------------------------ */
/*     backup control file to trace                                         */
/* ------------------------------------------------------------------------ */
prompt ====>backup controlfile to trace
alter database backup controlfile to trace noresetlogs;
END
echo "====>query the oracle catalog for the name of the user dump dir"
sqlplus -s system/${PASSWD} <<END >/dev/null
set pagesize 0 feedback off verify off echo off termout off heading off
/* ------------------------------------------------------------------------ */
/*     query the oracle catalog for the name of the user dump dir           */
/* ------------------------------------------------------------------------ */
spool ${audit_path}/bkdest.list
select value
  from v\$parameter where name = 'user_dump_dest';
spool off
END
## ------------------------------------------------------------------------ ##
##     Offload the latest control file trace to tape                        ##
## ------------------------------------------------------------------------ ##
echo
echo "====>Offload the controlfile trace to tape"
echo
dump_dest=`cat ${audit_path}/bkdest.list | awk '{
  if (substr($1,length($1),1) == "/") {print $1} else {print $1 "/"}}'`
cd ${dump_dest}
trc_count=`ls -t *ora* | wc -l | awk '{print $NF}'`
if [ ${trc_count} -gt 1 ]
then
  last_trc=`ls -t *ora* | sed -e 2,${trc_count}d`
else
  last_trc=`ls -t *ora*`
fi
eval $save_command $last_trc $save_redir
save_status=$?
echo ADSM return_code=$save_status
check_adsm $save_status
## ------------------------------------------------------------------------ ##
##     Offload the instance parameter file to tape                          ##
## ------------------------------------------------------------------------ ##
echo
echo "====>Offload the instance parameter file to tape"
echo
$save_command $init_file 
## ------------------------------------------------------------------------ ##
##     script wrapup processing                                             ##
## ------------------------------------------------------------------------ ##
echo
echo "************************************************************************"
echo "====>Script tape_coldbackup.sh ending on" `date`
echo "************************************************************************"
rm ${audit_path}/backup.${ORACLE_SID}.list >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.sort >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.lvl >/dev/null 2>&1
rm ${audit_path}/backup.${ORACLE_SID}.control >/dev/null 2>&1
rm ${audit_path}/bkdest.list > /dev/null 2>&1
rm ${audit_path}/ora.error > /dev/null 2>&1
exit $error_switch
