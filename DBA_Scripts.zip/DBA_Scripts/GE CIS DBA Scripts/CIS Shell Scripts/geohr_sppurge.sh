#!/bin/ksh
################################################################################
# geohr_sppurge.sh 
# This script is used to  purge the statspack tables 
#
#  Arguments: ORACLE_SID 
#  Arguments: Number of snap ids to keep
#  Usage    : geohr_sppurge.sh <sid> <1000>
#   
###############################################################################


function checkconnect {
######################################
# checkconnect()
#   Ensure that we can connect to the database
# Arguments: $1, user
#            $2, password
# Returns: 0, if we can connect
#          1, if we cannot connect
#
sqlplus -s $1/$2 << EOF > /dev/null
exit 255;
EOF
   if [ $? -ne 255 ]; then
    return 1
   else
    return 0
   fi
} ################## checkconnect() ##

######################################################
# Source the correct environment set variables
#####################################################
. $HOME/bin/$1
USERNAME=perfstat
PASSWD=`$HOME/bin/tellme $USERNAME`
echo $PASSWD
MAXSNAPIDS=$2
echo $MAXSNAPIDS

######################################################
# Set the mailer list
#####################################################
#MAILLIST="David.Bates@corporate.ge.com David.Declercq@corporate.ge.com Linda.Slyer@corporate.ge.com Carl.Infiesto@corporate.ge.com Rajesh.Natarajan@corporate.ge.com SSSHelpDesk@corporate.ge.com Matt.Mullin@coporate.ge.com"

########################################################
# Check for database availabilty and if available 
# check for username and password combination
########################################################## 
SMON=`ps -ef | grep ora_smon_"$SID" | grep -v grep | awk '{print $1}'|uniq`
if [ ! -z "$SMON" ];then
    checkconnect $USERNAME $PASSWD 
    if [ "$?" -eq 0 ] ;then
    HIGHSNAPID=`sqlplus -s $USERNAME/$PASSWD  <<EOF
    set heading off
    select max(snap_id) - $MAXSNAPIDS
    from statssnapshot;
EOF`
    echo $HIGHSNAPID
sqlplus -s $USERNAME/$PASSWD @$DBA_HOME/admin/geohr_sppurge.sql 0 $HIGHSNAPID <<EOF
EOF
    fi
fi
###############################################################################
# End of geohr_sppurge.sh
###############################################################################
