#!/bin/ksh

## Script Name: refresh.sh
## Author: Satyen Jadia
## Purpose: Refresh database
## Usage: refresh.sh <SID>
##      : This script should always be run on the server
##      : hosting the database to be refreshed.
##      : One can also specify range of file system be
##      : used for that refresh instance.
## Parameter Files:  1. refresh_<SID>  -  Refresh control File
##                :  2. dbinfo.ctl - Database Information Control File 
##                :  3. getpswd - Get's password for specified schema
##                :               for specific instance. Should be on 
##                :               source database server under $HOME/bin.
##                :  4. getbkuploc - Get's backup location for the source
##                :                  source database. Should be on source
##                :                  database server under $HOME/bin.
## Refresh repository: Script uses "dbr1" as repository. It uses this 
##                   : database to store information like freespace,
##                   : filename, filesize etc.
##                   : There should be an entry for "dbr1" database in
##                   : dbinfo.ctl file on the server hosting target database.
##                   : Scirpt won't run if the entry is not there in 
##                   : dbinfo.ctl file.
## Audit directory: Script creates audit directory, refresh, under $SID_HOME
##                : for the database being refreshed.
## For FNDCPASS: Set Oracle Home & LD_LIBRARY_PATH to 806.
##             : /t030/oracle50/product/8.0.6/lib:/usr/dt/lib:/usr/openwin/lib

## 1. Set host name, path prefix and target db

hname=`hostname`
pathpre=`hostname|cut -c5-8`

if [ -z "$1" ]
then
  echo "Invalid usage."
  echo "Correct usage: refresh <target db>"
  echo "Try again !!!!!"
  exit 1
fi

trgtdb=$1

if [ -z "$2" ]
then
  bktype="cold"
else
  bktype="hot"
fi

## 2. Get Source & Target Database

if [ ! -f $HOME/bin/$trgtdb ]
then
  echo "Set environment script does not exists for $trgtdb."
  echo "Verify script is run on right server."
  exit 1
fi

. $HOME/bin/$trgtdb

## Set PATROL_HOME
PATROL_HOME=/usr/gemaint/patrol

## Set location of control file
cntlbase="$CNTLPATH"
cntlloc="$cntlbase/refresh/cntl"

if [ ! -f $cntlloc/${trgtdb}_refresh ]
then
  echo "Control file does not exists."
  echo "Setup control file for target database."
  echo "Control file should be created under, $cntlloc."
  echo "Look for sample control file, sampledb_refresh."
  exit 1
fi

while read refinfo ; do
  trgtdb_temp=`echo $refinfo|awk -F":" '{print $2}'`
  srcdb=`echo $refinfo|awk -F":" '{print $1}'`
  if [ "$trgtdb" = "$trgtdb_temp" ]
  then
    echo "Target db specified in control file matches."
  else
    echo "Target db specified in control file does not match."
    echo "Verify control file or check parameter passed at command line."
    exit 1
  fi

  ## Get Host for Target & Source databases - $HOME/bin/dbinfo.ctl
  trgthost=`grep "$trgtdb" $HOME/bin/dbinfo.ctl | awk -F":" '{print $3}'`
  srchost=`grep "$srcdb" $HOME/bin/dbinfo.ctl | awk -F":" '{print $3}'`

  ## Get connect string for Source database
  srcconnstr=`grep "$srcdb" $HOME/bin/dbinfo.ctl | awk -F":" '{print $2}'`
  if [ -z "$srcconnstr" ]
  then
    echo "Please update control file, $HOME/bin/dbinfo.ctl."
    echo "2nd parameter in the file is Connect String."
    exit 1
  fi

  ## Verify whether target database can be refreshed 
  trgtrefflag=`grep "$trgtdb" $HOME/bin/dbinfo.ctl | awk -F":" '{print $4}'`
  if [ -z "$trgtrefflag" ]
  then
    echo "Refresh flag not set for the database."
    echo "Please update file, $HOME/bin/dbinfo.ctl (4th parameter in line)."
    exit 1
  fi

  if [ "trgtrefflag" = "N" ]
  then
    echo "Target database, $trgtdb, cannot be refreshed."
    echo "Please confirm and update control file, $HOME/bin/dbinfo.ctl."
    exit 1
  fi

  break
done < $cntlloc/${trgtdb}_refresh

if [ "$trgtdb" = "hrp1" ]
then
  echo "HRP1 IS PRODUCTION DATABASE."
  echo "CANNOT REFRESH."
  exit 1
fi

## Create refresh directory under $SID_HOME

if [ ! -d "$SID_HOME/refresh" ]
then
  mkdir $SID_HOME/refresh
  echo "Directory $SID_HOME/refresh created."
else
  rm $SID_HOME/refresh/refll*.sh
  rm $SID_HOME/refresh/refcp*.sh
  rm $SID_HOME/refresh/refunc*.sh
  rm $SID_HOME/refresh/*.audit
  rm $SID_HOME/refresh/refresh_rm.sh
  rm $SID_HOME/refresh/shutdown.err
  rm $SID_HOME/refresh/filescopied
  rm $SID_HOME/refresh/create_$trgtdb.sql
fi

## Set audit path

audit_path=$SID_HOME/refresh

echo "Successfully completed step 2."
 
## 3. Get System Password for both databases

## Verify Target DB is refreshed from server it resides

if [ "$trgthost" != "`hostname`" ]
then
  echo "Database refresh can be started from the server hosting db."
  echo "Please start database refresh from host."
  exit 1
fi

trgtsystem=`$HOME/bin/tellme system`
srcsystem=`remsh $srchost bin/getpswd $srcdb system`

echo "Successfully completed step 3."

## 4. Test connection to both Source & Target databases

## Tnsping Source Database

$ORACLE_HOME/bin/tnsping $srcconnstr > $SID_HOME/refresh/tnsping.err
tnspingerr=`grep "TNS-03505" $SID_HOME/refresh/tnsping.err`
if [ ! -z "$tnspingerr" ]
then
  echo "TNSPING not successful."
  echo "Please update entry to TNSNAMES file for source database, $srcconnstr."
  exit 1
fi
 
sqlplus -s system/$trgtsystem << EOF > $audit_path/testtrgtconn.err
set pages 0 heading off feedback off echo off
select 'Got connected to '||name||' successfully.' from v\$database ;
exit
EOF

sqlplus -s system/$srcsystem@$srcconnstr << EOF > $audit_path/testsrcconn.err
set pages 0 heading off feedback off echo off
select 'Got connected to '||name||' successfully.' from v\$database ;
exit
EOF

dbconnerr=`grep "ORA-12154" $audit_path/testtrgtconn.err`
if [ ! -z "$dbconnerr" ]
then
  echo "Cannot connect to the database, $trgtdb."
  echo "Error: ORA-12154"
  exit 1
fi

dbconnerr=`grep "ORA-12154" $audit_path/testsrcconn.err`
if [ ! -z "$dbconnerr" ]
then
  echo "Cannot connect to the database, $srcdb."
  echo "Error: ORA-12154"
  exit 1
fi

## Remove ".err" files
rm $audit_path/tnsping.err
rm $audit_path/testtrgtconn.err
rm $audit_path/testsrcconn.err

echo "Successfully completed step 4."

## 5. Get connect string for Refresh Schema 

dbrconnstr=`grep "dbr1" $HOME/bin/dbinfo.ctl | awk -F":" '{print $2}'`

## 6. Test connection to Refresh Schema

$ORACLE_HOME/bin/tnsping $dbrconnstr > $audit_path/tnsping.err
tnspingerr=`grep "TNS-03505" $audit_path/tnsping.err`
if [ ! -z "$tnspingerr" ]
then
  echo "TNSPING not successful."
  echo "Please update entry to TNSNAMES file for dbr1 database."
  exit 1
fi

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/testdbrconn.err
set pages 0 heading off feedback off echo off
select 'Got connected to '||name||' successfully.' from v\$database ;
exit
EOF

dbconnerr=`grep "ORA-" $audit_path/testdbrconn.err`
if [ ! -z "$dbconnerr" ]
then
  echo "Cannot connect to the database, dbr1."
  echo "Error: ORA-12154"
  exit 1
fi

## Remove ".err" files
rm $audit_path/tnsping.err
rm $audit_path/testdbrconn.err

echo "Successfully completed step 5 & 6."

## 7. Select datafiles information from Source DB

## A. Get free available space on Target Server

filesysno=`grep "$trgtdb" $HOME/bin/dbinfo.ctl | awk -F":" '{print $5}'`
maxfilesysno=`grep "$SID" $HOME/bin/dbinfo.ctl | awk -F":" '{print $6}'`

if [ $filesysno -eq 0 ]
then
  echo "Error: Cannot refresh this database."
  echo "       Or correct information in control file."
  exit 1
fi

if [ -z "$maxfilesysno" ]
then
  maxfilesysno=99
fi

if [ $maxfilesysno -lt 0 ]
then
  echo "Error: Cannot refresh this database."
  echo "       Or correct information in control file."
  exit 1
fi

if [ $maxfilesysno -lt $filesysno ]
then
  echo "Error: Invalid range for filesystem."
  echo "       Please check parameter number 5 & 6 seperated by \":\""
  echo "       in $HOME/bin/dbinfo.ctl file for database $SID."
  exit 1
fi

df -k | grep "/u" | awk -F" " '{print $NF}' | awk -F"/" '{
if (substr($NF,2,1) >= $filesysno) if (substr($NF,1,1) == "u") 
print $NF"-"substr($NF,2,2)}'|
grep -v "usr" | sort > $SID_HOME/refresh/afs.lst

let crfssql=1
while read afsno ; do
  fsys=`echo $afsno | awk -F"-" '{print $1}'`
  fsysno=`echo $afsno | awk -F"-" '{print $NF}'`
  if [ $fsysno -ge $filesysno -a $fsysno -le $maxfilesysno ]
  then
    if [ $crfssql -eq 1 ]
    then
      let crfssql=crfssql+1 
      echo "Creating sql script to insert data."
      echo "REM SQL script to insert data." > $audit_path/fs.sql
    fi
    filesystem=`df -k | grep $fsys | awk -F" " '{print $NF}'`
    freespace=`df -k | grep $fsys | awk -F" " '{print $(NF-2)}'`
    echo "insert into freespace" >> $audit_path/fs.sql
    echo "values ('$hname', '$filesystem', $freespace*1024);" >> $audit_path/fs.sql
  fi
done < $SID_HOME/refresh/afs.lst

## Verify refresh is currently not running on same database server

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/refrun.err
set pages 0 heading off feedback off echo off
select dbname from refstatus where end_time is null
and    hostname = '$hname' ;
exit
EOF

err=`grep "ORA-" $audit_path/refrun.err`

if [ ! -z "$err" ]
then
  echo "Error selecting refresh status information."
  echo "Check audit file refrun.err."
  exit 1
fi

refstat=`cat $audit_path/refrun.err`

if [ ! -z "$refstat" ]
then
  echo "Refresh is currently running on server, $hname, for DB, $refstat."
  echo "Cannot run multiple refresh on same server."
  exit 1
fi

## Rename refresh control file

mv $cntlloc/${trgtdb}_refresh $cntlloc/${trgtdb}_refresh.done

## Clear data from FILEINFO & FREESPACE tables

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/upddbr1.err
set pages 0 heading off feedback off echo off
delete from fileinfo where dbname = '$trgtdb' and hostname = '$hname';
delete from freespace where hostname = '$hname' ;
commit ;
exit
EOF

err=`grep "ORA-" $audit_path/upddbr1.err`

if [ ! -z "$err" ]
then
  echo "Error deleting data from FILEINFO & FREESPACE in DBR1 database."
  echo "Check audit file for more errors, $audit_path/upddbr1.err."
  exit 1
fi

rm $audit_path/upddbr1.err

## Update database with refresh information

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/refstat.err
set pages 0 heading off feedback off echo off
insert into refstatus values('$hname', '$trgtdb', sysdate, null, 'R');
delete from freespace where hostname='$hname';
delete from fileinfo  where dbname='$trgtdb';
commit;
exit
EOF

err=`grep "ORA-" $audit_path/refstat.err`

if [ ! -z "$err" ]
then
  echo "Error inserting refresh information to table, refstatus."
  echo "Check audit file refstat.err."
  exit 1
fi

## Set script location

scriptloc=$DBA_HOME/admin

## Update FREESPACE table for available free space

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/freespace.err
set pages 0 heading off feedback off echo off
set numf 9999999999999999
@$audit_path/fs.sql
commit;
exit
EOF

err=`grep "ORA-" $audit_path/freespace.err`

if [ ! -z "$err" ]
then
  echo "Error inserting freespace data into table, freespace."
  echo "Check audit file freespace.err."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/fs.sql
rm $audit_path/afs.lst
rm $audit_path/freespace.err
rm $audit_path/refstat.err
rm $audit_path/refrun.err

## B. Get space occupied by Target DB

sqlplus -s system/$trgtsystem << EOF > $audit_path/updfs.err
set pages 0 heading off feedback off echo off
set numf 9999999999999999
spool $audit_path/updfs.lst
select substr(file_name, 1, 9), sum(bytes) 
from   dba_Data_files
where  file_name not like '%MISSING%'
and    substr(file_name, 7, 1) = 'u'
group  by substr(file_name, 1, 9) ;
spool off
exit
EOF

err=`grep "ORA-" $audit_path/updfs.err`

if [ ! -z "$err" ]
then
  echo "Error selecting space occupied by target DB, $trgtdb."
  echo "Check audit file updfs.err."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/updfs.err

## Select file system with free space on host

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/freelist.err
set heading off pages 0 echo off feedback off
spool $audit_path/freelist.lst
select filesystem from freespace where hostname='$hname';
spool off
exit
EOF

err=`grep "ORA-" $audit_path/freelist.err`

if [ ! -z "$err" ]
then
  ehco "Error selecting freelist from refresh database, dbr1."
  echo "Check audit file freelist.err."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

## Create update free space script

echo "REM SQL script to update free space" > $audit_path/updfs.sql

while read updfs ; do
  filesystem=`echo $updfs | awk -F" " '{print $1}'`
  availspace=`echo $updfs | awk -F" " '{print $2}'`
  ## Check file system exists in database
  checkfsys=`grep "$filesystem" $audit_path/freelist.lst`
  if [ -z "$checkfsys" ]
  then
    echo "insert into freespace" >> $audit_path/updfs.sql
    echo "values('$hname','$filesystem',$availspace);" >> $audit_path/updfs.sql
  else
    echo "update freespace" >> $audit_path/updfs.sql
    echo "set    freespace=freespace+$availspace" >> $audit_path/updfs.sql
    echo "where  hostname='$hname'">> $audit_path/updfs.sql
    echo "and    filesystem='$filesystem' ;" >> $audit_path/updfs.sql
  fi
done < $audit_path/updfs.lst

## Update space occupied by Target DB

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/updfs.err
set numf 9999999999999999
@$audit_path/updfs.sql
exit
EOF

err=`grep "ORA-" $audit_path/updfs.err`

if [ ! -z "$err" ]
then
  echo "Error updating free space occupied by Target DB, $trgtdb."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

## Set 300M reserve for big data files

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/setres.err
set numf 9999999999999999
update freespace set freespace=freespace-(300*1024*1024)
where  hostname='$hname'
and    freespace >= (300*1024*1024);
commit;
exit
EOF

err=`grep "ORA-" $audit_path/setres.err`

if [ ! -z "$err" ]
then
  echo "Error updating FREESPACE table to set reserve space."
  echo "Check audit file, $audit_path/setres.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/setres.err
rm $audit_path/updfs.err
rm $audit_path/updfs.lst
rm $audit_path/updfs.sql
rm $audit_path/freelist.err
rm $audit_path/freelist.lst

## C. Get space required by Source DB to refresh Target DB

sqlplus -s system/$srcsystem@$srcconnstr << EOF > $audit_path/totspacereq.err
set heading off pages 0 echo off feedback off
set numf 9999999999999999
select sum(bytes) from dba_data_files
where  tablespace_name not in ('RBS', 'TEMP', 'GEHRD_ARCH', 
       'GEHRX_ARCH', 'GECNVD');
exit
EOF

err=`grep "ORA-" $audit_path/totspacereq.err`

if [ ! -z "$err" ]
then
  echo "Error selecting Total Space Required."
  echo "Check audit file, totspacereq.err."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

sqlplus -s system/$srcsystem@$srcconnstr << EOF > $audit_path/maxfilesize.err
set heading off pages 0 echo off feedback off
set numf 9999999999999999
select max(bytes) from dba_data_files
where  tablespace_name not in ('RBS', 'TEMP', 'GEHRD_ARCH', 
       'GEHRX_ARCH', 'GECNVD');
exit
EOF

err=`grep "ORA-" $audit_path/maxfilesize.err`

if [ ! -z "$err" ]
then
  echo "Error selecting Maximum Space Required for a datafile."
  echo "Check audit file, maxfilesize.err."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

## Validate space requirement for refresh

totspacereq=`cat $audit_path/totspacereq.err`
maxfilesize=`cat $audit_path/maxfilesize.err`

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/valspace.err
set heading off pages 0 echo off feedback off
set numf 9999999999999999
select 'Total Space Available for refresh - TSA.' from dual
where  $totspacereq <= (select sum(freespace) from freespace
                       where  hostname = '$hname'); 
select 'Filesystem available with Max File Size - MFS.' from dual
where  $maxfilesize <= (select max(freespace) from freespace
                       where hostname  = '$hname');
exit
EOF

err=`grep "ORA-" $audit_path/valspace.err`

if [ ! -z "$err" ]
then
  echo "Error validating free space in refresh database, dbr1."
  echo "Check audit file, valspace.err."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

checktsa=`grep "TSA" $audit_path/valspace.err`
if [ -z "$checktsa" ]
then
  echo "Total space required is not available for the refresh."
  echo "Free space and start refresh again."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

checkmfs=`grep "MFS" $audit_path/valspace.err`
if [ -z "$checkmfs" ]
then
  echo "Max file space required on single file system is not available."
  echo "Free space and start refresh again."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/valspace.err
rm $audit_path/totspacereq.err
rm $audit_path/maxfilesize.err

## D. Get list of datafiles to be copied from Source DB

sqlplus -s system/$srcsystem@$srcconnstr << EOF > $audit_path/srcfiles.err
set heading off pages 0 echo off feedback off linesize 200
set numf 9999999999999999
spool  $audit_path/srcfiles.lst
select substr(file_name,1,80)||','|| bytes from dba_data_files
where  tablespace_name not in ('RBS', 'TEMP', 'GEHRD_ARCH', 
       'GEHRX_ARCH', 'GECNVD')
order  by tablespace_name;
spool  off
exit
EOF

err=`grep "ORA-" $audit_path/srcfiles.err`

if [ ! -z "$err" ]
then
  echo "Error selecting list of datafiles to be copied from source, $srcdb."
  echo "Check audit file, srcfiles.err."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/srcfiles.err

## Update database with source datafiles & size

## Create script to update database

echo "REM Script to update database with Filename & Size" > $audit_path/finfo.sql

while read files ; do
  fnamebytes=`echo $files | awk -F"/" '{print $NF}'`
  fname=`echo $fnamebytes | awk -F"," '{print $1}'`
  fbytes=`echo $fnamebytes | awk -F"," '{print $2}'`

  echo "insert into fileinfo" >> $audit_path/finfo.sql
  echo "values('$hname','$trgtdb','$fname','$fbytes',null)" >> $audit_path/finfo.sql
  echo ";" >> $audit_path/finfo.sql
done < $audit_path/srcfiles.lst

rm $audit_path/srcfiles.lst

## Update database

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/updfinfo.err
@$audit_path/finfo.sql
exit
EOF

err=`grep "ORA-" $audit_path/updfinfo.err`

if [ ! -z "$err" ]
then
  echo "Error updating database with data file information."
  echo "Check audit file, updfinfo.err, for errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/updfinfo.err
rm $audit_path/finfo.sql

echo "Successfully executed step 7."

## 8. Assign file systems to datafiles

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/allfilesys.err
set numf 9999999999999999
exec allfilesys('$hname','$trgtdb') ;
exit
EOF

err=`grep "ORA-" $audit_path/allfilesys.err`

if [ ! -z "$err" ]
then
  echo "Error allocating filesystem to data file."
  echo "Check audit file, allfilesys.err, for errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/allfilesys.err

## Verify all files has been assigned filesystem

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/verifyfs.err
set heading off pages 0 echo off feedback off linesize 200
spool  $audit_path/verifyfs.lst
select 'Problems allocating file systems to datafiles.'
from   fileinfo
where  filesystem is null
and    hostname='$hname'
and    dbname='$trgtdb'
having count(*) > 0;
spool  off
exit
EOF

err=`grep "ORA-" $audit_path/verifyfs.err`

if [ ! -z "$err" ]
then
  echo "Error verifying file allocation."
  echo "Check audit file, verifyfs.err, for errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

verifyalloc=`grep "Problems allocating file systems to datafiles." $audit_path/verifyfs.lst`

if [ ! -z "$verifyalloc" ]
then
  echo "Error allocating filesystems to datafiles."
  echo "Free some disk space and re-run refresh."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

## Set Oracle ID

oracleid=`id | awk -F")" '{print $1}' | awk -F"(" '{print $NF}'`

## Get location for log files

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/logloc.err
set heading off pages 0 echo off feedback off linesize 200
spool $audit_path/logloc.lst
select distinct filesystem from fileinfo 
where  hostname = '$hname'
and    dbname = '$trgtdb' ;
spool off
exit
EOF

err=`grep "ORA-" $audit_path/logloc.err`

if [ ! -z "$err" ]
then
  echo "Error selecting location for log files."
  echo "Check audit file, logloc.err, for errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

logloc=`cat $audit_path/logloc.lst`

logloc1=`echo $logloc | awk -F" " '{print $1}'`
logloc2=`echo $logloc | awk -F" " '{print $2}'`


if [ -z "$logloc1" -o -z "$logloc2" ]
then
  echo "No log location set."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

logloc1=$logloc1"/$oracleid/$trgtdb/log"
logloc2=$logloc2"/$oracleid/$trgtdb/log"

rm $audit_path/logloc.err
rm $audit_path/logloc.lst
rm $audit_path/verifyfs.err
rm $audit_path/verifyfs.lst

## Verify/Create data/log directory on assigned filesystem

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/fslist.err
set heading off pages 0 echo off feedback off
spool $audit_path/fslist.lst
select distinct filesystem from fileinfo 
where  hostname = '$hname'
and    dbname = '$trgtdb' ;
spool off
exit
EOF

err=`grep "ORA-" $audit_path/fslist.err`

if [ ! -z "$err" ]
then
  echo "Error selecting distinct filesystems assigned for dir verification."
  echo "Check audit file, $audit_path/fslist.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

while read fsname ; do
  if [ ! -d "$fsname/$oracleid/$trgtdb/data" ]
  then
    if [ ! -d "$fsname/$oracleid/$trgtdb" ]
    then
      if [ ! -d "$fsname/$oracleid" ]
      then
        echo "Directory $fsname/$oracleid does not exists."
        echo "Create directory $fsname/$oracleid under all U filesystems."
        $scriptloc/refstatus.sh $trgtdb E
        exit 1
      else
        mkdir $fsname/$oracleid/$trgtdb
        mkdir $fsname/$oracleid/$trgtdb/data
      fi
    else
      mkdir $fsname/$oracleid/$trgtdb/data
    fi
  fi
done < $audit_path/fslist.lst

if [ ! -d "$logloc1" ]
then
  mkdir $logloc1
  echo "Log directory created, $logloc1."
fi

if [ ! -d "$logloc2" ]
then
  mkdir $logloc2
  echo "Log directory created, $logloc2."
fi

rm $audit_path/fslist.lst
rm $audit_path/fslist.err

## Create spool file for copying & uncompress datafiles

if [ "$srchost" == "$hname" ]
then
  copycmd="/usr/bin/cp "
else
  copycmd="/usr/bin/rcp $srchost:"
fi

uncompresscmd="/usr/bin/uncompress "

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/crunixscr.err
set heading off pages 0 echo off feedback off
spool $audit_path/files.lst
select filesystem||'/'||'$oracleid'||'/'||dbname||'/data/'||filename
from   fileinfo
where  hostname='$hname'
and    dbname='$trgtdb'
order  by filesize desc;
spool  off
exit
EOF

err=`grep "ORA-" $audit_path/crunixscr.err`

if [ ! -z "$err" ]
then
  echo "Error creating list of datafiles to be copied from, dbr1."
  echo "Check audit file, crunixscr.err, for errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/crunixscr.err

echo "Successfully executed step 8."

## 9. Create refresh streams

## Get backup location

remsh $srchost bin/getbkuploc $srcdb $bktype > $audit_path/filesystem.lst

echo "## Location of backup files for database, $srcdb, on server, $srchost." > $audit_path/backuploc.lst

backuploc="remsh $srchost ls -lrt "

while read filesystem ; do
      backuploc="$backuploc$filesystem/$oracleid/$srcdb/data/*.Z "
done < $audit_path/filesystem.lst

$backuploc | awk -F" " '{print $NF}' | sort -u >> $audit_path/backuploc.lst

echo "## Copy files from source database - Stream 1" > $audit_path/refcp1.sh
echo "## Copy files from source database - Stream 2" > $audit_path/refcp2.sh
echo "## Copy files from source database - Stream 3" > $audit_path/refcp3.sh
echo "## Copy files from source database - Stream 4" > $audit_path/refcp4.sh
echo "## Copy files from source database - Stream 5" > $audit_path/refcp5.sh

echo "## Uncompress data files - Stream 1" > $audit_path/refunc1.sh
echo "## Uncompress data files - Stream 2" > $audit_path/refunc2.sh
echo "## Uncompress data files - Stream 3" > $audit_path/refunc3.sh
echo "## Uncompress data files - Stream 4" > $audit_path/refunc4.sh
echo "## Uncompress data files - Stream 5" > $audit_path/refunc5.sh

## Set stream counter, strmcnt

let strmcnt=1

while read files ; do

      ## Get backup location for datafile

      fname=`echo $files | awk -F"/" '{print $NF}'`
      fnameloc=`grep "/$fname" $audit_path/backuploc.lst`

      if [ -z "$fnameloc" ]
      then
        echo "Cannot find backup location for datafile, $fname."
        $scriptloc/refstatus.sh $trgtdb E
        exit 1
      fi

      if [ $strmcnt -eq 6 ]
      then
        let strmcnt=1
      fi

      echo "ls -lrt $files" >> $audit_path/refll.sh
      echo "ls -lrt $files.Z" >> $audit_path/refllz.sh

      if [ $strmcnt -eq 1 ]
      then
        echo "$copycmd$fnameloc $files.Z" >> $audit_path/refcp1.sh
        echo "$uncompresscmd$files.Z" >> $audit_path/refunc1.sh
      fi

      if [ $strmcnt -eq 2 ]
      then
        echo "$copycmd$fnameloc $files.Z" >> $audit_path/refcp2.sh
        echo "$uncompresscmd$files.Z" >> $audit_path/refunc2.sh
      fi

      if [ $strmcnt -eq 3 ]
      then
        echo "$copycmd$fnameloc $files.Z" >> $audit_path/refcp3.sh
        echo "$uncompresscmd$files.Z" >> $audit_path/refunc3.sh
      fi

      if [ $strmcnt -eq 4 ]
      then
        echo "$copycmd$fnameloc $files.Z" >> $audit_path/refcp4.sh
        echo "$uncompresscmd $files.Z" >> $audit_path/refunc4.sh
      fi

      if [ $strmcnt -eq 5 ]
      then
        echo "$copycmd$fnameloc $files.Z" >> $audit_path/refcp5.sh
        echo "$uncompresscmd$files.Z" >> $audit_path/refunc5.sh
      fi

      let strmcnt=strmcnt+1

done < $audit_path/files.lst

## Create temp init.ora file to start db using _corrupted_rollback_segments

cat $ORACLE_HOME/dbs/init$trgtdb.ora | sed -e "s/rollback/_corrupted_rollback/" > $audit_path/temp$trgtdb.ora

## Create script to create database

echo "STARTUP NOMOUNT PFILE=$audit_path/temp$trgtdb.ora" > $audit_path/create_$trgtdb.sql
echo "CREATE CONTROLFILE SET DATABASE \"$trgtdb\" RESETLOGS NOARCHIVELOG" >> $audit_path/create_$trgtdb.sql
echo "  MAXLOGFILES 16" >> $audit_path/create_$trgtdb.sql
echo "  MAXLOGMEMBERS 2" >> $audit_path/create_$trgtdb.sql
echo "  MAXDATAFILES 400" >> $audit_path/create_$trgtdb.sql
echo "  MAXINSTANCES 1" >> $audit_path/create_$trgtdb.sql
echo "  MAXLOGHISTORY 2495" >> $audit_path/create_$trgtdb.sql
echo "LOGFILE" >> $audit_path/create_$trgtdb.sql
echo "  GROUP 1 (" >> $audit_path/create_$trgtdb.sql
echo "    '$logloc1/redo01g1.log'," >> $audit_path/create_$trgtdb.sql
echo "    '$logloc2/redo02g1.log') SIZE 25M," >> $audit_path/create_$trgtdb.sql
echo "  GROUP 2 (" >> $audit_path/create_$trgtdb.sql
echo "    '$logloc1/redo01g2.log'," >> $audit_path/create_$trgtdb.sql
echo "    '$logloc2/redo02g2.log') SIZE 25M," >> $audit_path/create_$trgtdb.sql
echo "  GROUP 3 (" >> $audit_path/create_$trgtdb.sql
echo "    '$logloc1/redo01g3.log'," >> $audit_path/create_$trgtdb.sql
echo "    '$logloc2/redo02g3.log') SIZE 25M" >> $audit_path/create_$trgtdb.sql
echo "DATAFILE" >> $audit_path/create_$trgtdb.sql

let filescnt=1
totfiles=`wc -l $audit_path/refll.sh | awk -F" " '{print $1}'`
while read files ; do
   if [ $filescnt -lt $totfiles ]
   then
     echo "'$files'," >> $audit_path/create_$trgtdb.sql
   else
     echo "'$files'" >> $audit_path/create_$trgtdb.sql
   fi
   let filescnt=filescnt+1
done < $audit_path/files.lst

echo ";" >> $audit_path/create_$trgtdb.sql
echo "alter database open resetlogs ;" >> $audit_path/create_$trgtdb.sql
echo "alter database rename global_name to $trgtdb ;" >> $audit_path/create_$trgtdb.sql

rm $audit_path/files.lst
rm $audit_path/filesystem.lst
rm $audit_path/backuploc.lst

echo "Successfully executed step 9."

## 10. Create script to delete existing datafiles for target database

sqlplus -s system/$trgtsystem << EOF > $audit_path/rmtrgtfiles.err
set heading off pages 0 echo off feedback off
spool  $audit_path/refresh_rm.sh
select 'rm '||file_name from dba_data_files ;
select 'rm '||file_name from dba_temp_files ;
select 'rm '||member from v\$logfile ;
spool  off
set lines 200
spool  $audit_path/cntlfiles.lst
select value from v\$parameter where  name='control_files' ;
spool  off
exit
EOF

err=`grep "ORA-" $audit_path/rmtrgtfiles.err`

if [ ! -z "$err" ]
then
  echo "Error selecting files from target database."
  echo "Check audit file, rmtrgtfiles.err, for errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

cntlfiles=`cat $audit_path/cntlfiles.lst`

echo $cntlfiles | awk -F"," '{print "rm "$1}' >> $audit_path/refresh_rm.sh
echo $cntlfiles | awk -F"," '{print "rm "$2}' >> $audit_path/refresh_rm.sh
echo $cntlfiles | awk -F"," '{print "rm "$3}' >> $audit_path/refresh_rm.sh

rm $audit_path/cntlfiles.lst
rm $audit_path/rmtrgtfiles.err

echo "Successfully executed step 10."

## 11. Shutdown database

echo "Shutting down database, $trgtdb."

sqlplus -s /nolog << EOF > $audit_path/shutdown.err
connect / as sysdba
shutdown abort
exit 
EOF

err=`grep "ORA-" $audit_path/shutdown.err`

if [ ! -z "$err" ]
then
  echo "Error shutting down target database, $trgtdb."
  echo "Check audit file, $shutdown.err, for errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

echo "Database, $trgtdb, successfully shutdown."

## 12. Set execute mode for all refresh scripts

/usr/bin/chmod 700 $audit_path/refll.sh
/usr/bin/chmod 700 $audit_path/refllz.sh
/usr/bin/chmod 700 $audit_path/refcp*.sh
/usr/bin/chmod 700 $audit_path/refunc*.sh
/usr/bin/chmod 700 $audit_path/refresh_rm.sh

## Remove existing files for target database

$audit_path/refresh_rm.sh

## 13. Execute Copy Streams

echo "Starting copy streams."

$audit_path/refcp1.sh > $audit_path/refcp1.audit 2>&1 &
$audit_path/refcp2.sh > $audit_path/refcp2.audit 2>&1 &
$audit_path/refcp3.sh > $audit_path/refcp3.audit 2>&1 &
$audit_path/refcp4.sh > $audit_path/refcp4.audit 2>&1 &
$audit_path/refcp5.sh > $audit_path/refcp5.audit 2>&1 &

wait

$audit_path/refllz.sh | wc > $audit_path/filescopied 2>&1
fctemp=`cat $audit_path/filescopied`
filescopied=`echo $fctemp | awk -F" " '{print $1}'`
totalfiles=`wc -l $audit_path/refllz.sh | awk -F" " '{print $1}'`

if [ $filescopied -eq $totalfiles ]
then
  echo "Files copied successfully."
else
  echo "Error coping files, check audit files."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/filescopied

## 14. Execute Uncompress Streams

echo "Starting uncompress streams."

$audit_path/refunc1.sh > $audit_path/refunc1.audit 2>&1 &
$audit_path/refunc2.sh > $audit_path/refunc2.audit 2>&1 &
$audit_path/refunc3.sh > $audit_path/refunc3.audit 2>&1 &
$audit_path/refunc4.sh > $audit_path/refunc4.audit 2>&1 &
$audit_path/refunc5.sh > $audit_path/refunc5.audit 2>&1 &

wait

$audit_path/refll.sh | wc > $audit_path/filesunc 2>&1
futemp=`cat $audit_path/filesunc`
filesunc=`echo $futemp | awk -F" " '{print $1}'`
totalfiles=`wc -l $audit_path/refll.sh | awk -F" " '{print $1}'`

if [ $filesunc -eq $totalfiles ]
then
  echo "Files uncompressed successfully."
else
  echo "Error uncompressing files, check audit files."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/filesunc

## 12. Start database with Create Controlfile using Pfile option

sqlplus /nolog << EOF > $audit_path/create_$trgtdb.err
connect /as sysdba
@$audit_path/create_$trgtdb.sql
exit
EOF

err=`grep "ORA-" $audit_path/create_$trgtdb.err`

if [ ! -z "$err" ]
then
  echo "Error creating database, $trgtdb."
  echo "Check audit file, $audit_path/create_$trgtdb.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

echo "Database, $trgtdb, successfully created."

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/updrefstat.err
update refstatus 
set    end_time=sysdate, 
       refstatus='C'
where  end_time is null
and    hostname='$hname'
and    dbname='$trgtdb';
commit ;
exit
EOF

err=`grep "ORA-" $audit_path/updrefstat.err`

if [ ! -z "$err" ]
then
  echo "Error updating database, dbr1, with refresh status."
  echo "Check audit file, $audit_path/updrefstat.err, for more errors."
  echo "Update DBR1 database with proper status information."
  echo "If you skip this step refresh for another database,"
  echo "won't start on the same server."
  exit 1
fi

rm $audit_path/updrefstat.err

## Select filesystem for TEMP & ROLLBACK tablespaces

sqlplus -s dbrefresh/dbrefresh@$dbrconnstr << EOF > $audit_path/selfs.err
set pages 0 heading off feedback off echo off
set numf 9999999999999999
spool  $audit_path/selfs.lst
select filesystem from freespace
where  hostname = '$hname'
and    freespace > (1024 * 1024 * 1024) ;
spool  off
exit
EOF

err=`grep "ORA-" $audit_path/selfs.err`

if [ ! -z "$err" ]
then
  echo "Error selecting filesystem to create TEMP & ROLLBACK tablespaces."
  echo "Check audit file, $audit_path/selfs.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

let recordno=1
while read fsname ; do
  if [ ! -d "$fsname/$oracleid/$trgtdb/data" ]
  then
    if [ ! -d "$fsname/$oracleid/$trgtdb" ]
    then
      if [ ! -d "$fsname/$oracleid" ]
      then
        echo "Directory $fsname/$oracleid does not exists."
        echo "Create directory $fsname/$oracleid under all U filesystems."
        $scriptloc/refstatus.sh $trgtdb E
        exit 1
      else
        mkdir $fsname/$oracleid/$trgtdb
        mkdir $fsname/$oracleid/$trgtdb/data
      fi
    else
      mkdir $fsname/$oracleid/$trgtdb/data
    fi
  fi
  if [ $recordno -eq 1 ]
  then
    temploc="$fsname/$oracleid/$trgtdb/data"
  fi
  if [ $recordno -eq 2 ]
  then
    rbsloc="$fsname/$oracleid/$trgtdb/data"
  fi

  let recordno=recordno+1

  if [ $recordno -gt 2 ]
  then
    break
  fi
done < $audit_path/selfs.lst

rm $audit_path/selfs.err
rm $audit_path/selfs.lst

if [ -z "$temploc" ]
then
  echo "Error selecting filesystem of size 1GB to create TEMP tablespace."
  echo "Select filesystem & add tempfile to TEMP tablespace." 
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

sqlplus -s system/$srcsystem << EOF > $audit_path/addtemp.err
alter tablespace temp
add tempfile '$temploc/temp01.dbf' size 1024M ;
exit
EOF

err=`grep "ORA-" $audit_path/addtemp.err`

if [ ! -z "$err" ]
then
  echo "Error adding TEMPFILE for TEMP tablespace."
  echo "Check audit file, $audit_path/addtemp.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/addtemp.err

echo "Successfully added TEMPFILE for TEMP tablespace."

if [ -z "$rbsloc" ]
then
  echo "Error selecting filesystem of size 1GB to create ROLLBACK tablespace."
  echo "Select filesystem & create ROLLBACK tablespace." 
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

## Create script to drop existing rollback segments

sqlplus -s system/$srcsystem << EOF > $audit_path/selrbs.err
set pages 0 heading off feedback off echo off
set numf 9999999999999999
spool  $audit_path/droprbs.sql
select 'drop rollback segment '||segment_name||' ;'
from   dba_rollback_segs 
where  segment_name not like 'SYSTEM%';
spool  off
exit
EOF

err=`grep "ORA-" $audit_path/selrbs.err`

if [ ! -z "$err" ]
then
  echo "Error selecting existing rollback segments."
  echo "Check audit file, $audit_path/selrbs.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/selrbs.err

## Drop existing rollback segments

sqlplus -s system/$srcsystem << EOF > $audit_path/droprbs.err
set pages 0 heading off feedback off echo off
set numf 9999999999999999
create rollback segment sys02 tablespace system
storage (initial 128k next 128k minextents 2 maxextents unlimited);
alter rollback segment sys02 online;
@$audit_path/droprbs.sql
exit
EOF

err=`grep "ORA-" $audit_path/droprbs.err`

if [ ! -z "$err" ]
then
  echo "Error dropping existing rollback segments."
  echo "Check audit file, $audit_path/droprbs.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/droprbs.err
rm $audit_path/droprbs.sql

## Create rollback tablespace

sqlplus -s system/$srcsystem << EOF > $audit_path/addrbt.err
create tablespace rollback
   datafile '$rbsloc/rollback01.dbf' size 1024M autoextend off
   extent management dictionary
   logging
   minimum extent 65536
   default storage (initial 64k next 1m minextents 1 maxextents unlimited
   pctincrease 0);
exit
EOF

err=`grep "ORA-" $audit_path/addrbt.err`

if [ ! -z "$err" ]
then
  echo "Error creating ROLLBACK tablespace."
  echo "Check audit file, $audit_path/addrbt.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/addrbt.err

echo "Rollback tablespace has been successfully created."

## Create rollback segments

sqlplus -s system/$srcsystem << EOF > $audit_path/crrbs.err
create rollback segment rbs01 tablespace rollback
storage (initial 4m next 4m minextents 2 maxextents unlimited optimal 8m);
create rollback segment rbs02 tablespace rollback
storage (initial 4m next 4m minextents 2 maxextents unlimited optimal 8m);
create rollback segment rbs03 tablespace rollback
storage (initial 4m next 4m minextents 2 maxextents unlimited optimal 8m);
create rollback segment rbs04 tablespace rollback
storage (initial 4m next 4m minextents 2 maxextents unlimited optimal 8m);
create rollback segment rbs05 tablespace rollback
storage (initial 4m next 4m minextents 2 maxextents unlimited optimal 8m);
create rollback segment rbs06 tablespace rollback
storage (initial 4m next 4m minextents 2 maxextents unlimited optimal 8m);
create rollback segment rbs07 tablespace rollback
storage (initial 4m next 4m minextents 2 maxextents unlimited optimal 8m);
create rollback segment rbsload tablespace rollback
storage (initial 8m next 8m minextents 2 maxextents unlimited optimal 16m);
alter rollback segment rbs01 online ;
alter rollback segment rbs02 online ;
alter rollback segment rbs03 online ;
alter rollback segment rbs04 online ;
alter rollback segment rbs05 online ;
alter rollback segment rbs06 online ;
alter rollback segment rbs07 online ;
alter rollback segment rbsload online ;
alter rollback segment sys02 offline ;
drop rollback segment sys02 ;
exit
EOF

err=`grep "ORA-" $audit_path/crrbs.err`

if [ ! -z "$err" ]
then
  echo "Error creating rollback segments."
  echo "Check audit file, $audit_path/crrbs.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/crrbs.err

echo "Rollback segments created successfully."

## Change APPLSYS, APPS & HR Passwords, same for all three Schemas

trgtapps=`$HOME/bin/tellme apps`
srcapps=`remsh $srchost bin/getpswd $srcdb apps`
apps_owner=`grep $trgtdb:ccm $HOME/bin/oraapp.ctl | cut -d: -f3`

if [ -z "$trgtapps" ]
then
  echo "Error getting APPS password for target database, $trgtdb."
  echo "Change APPLSYS, APPS & HR passwords manually."
  echo "Update $HOME/bin/oratask.lst file."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

if [ -z "$srcapps" ]
then
  echo "Error getting APPS password for source database, $srcdb."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

if [ -z "$apps_owner" ]
then
  echo "Error identifying applmgr id for target database, $trgtdb."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

. $APPL_TOP/APPS${trgtdb}_${hname}.env

/usr/bin/pbrun -l su $apps_owner -c ". $APPL_TOP/APPS${trgtdb}_${hname}.env; cd $APPL_TOP;$FND_TOP/bin/FNDCPASS apps/$srcapps 0 Y system/$srcsystem SYSTEM APPLSYS $trgtapps"

## Validate APPS password change

sqlplus -s apps/$trgtapps << EOF > $audit_path/valapps.err
select * from global_name;
exit
EOF

err=`grep "ORA-" $audit_path/valapps.err`

if [ ! -z "$err" ]
then
  echo "APPS password change is not successful."
  echo "Check audit file, $audit_path/valapps.err & log file from FNDCPASS."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/valapps.err

echo "Password for APPLSYS & APPS users have been restored."

/usr/bin/pbrun -l su $apps_owner -c ". $APPL_TOP/APPS${trgtdb}_${hname}.env; cd $APPL_TOP;$FND_TOP/bin/FNDCPASS apps/$trgtapps 0 Y system/$srcsystem ORACLE HR $trgtapps"

## Validate HR Password change

sqlplus -s hr/$trgtapps << EOF > $audit_path/valhr.err
select * from global_name;
exit
EOF

err=`grep "ORA-" $audit_path/valhr.err`

if [ ! -z "$err" ]
then
  echo "HR password change is not successful."
  echo "Check audit file, $audit_path/valhr.err & log file from FNDCPASS."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/valhr.err

echo "Password for HR user has been restored."

. $HOME/bin/$trgtdb

## Change SYS & SYSTEM users password

sqlplus -s system/$srcsystem << EOF > $audit_path/chgsys.err
alter user sys identified by $trgtsystem ;
alter user system identified by $trgtsystem ;
exit
EOF

err=`grep "ORA-" $audit_path/chgsys.err`

if [ ! -z "$err" ]
then
  echo "Error changing SYS & SYSTEM users password."
  echo "Check audit file, $audit_path/chgsys.err, for more errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

rm $audit_path/chgsys.err

echo "Password for SYS & SYSTEM users has been restored."

## Change Oracle HR Applications profile using script, ohr_profile_change.sh

$DBA_HOME/admin/ohr_profile_change.sh $trgtdb

echo "Profile has been restored to $trgtdb database."
echo "Validate profile using script $DBA_HOME/admin/valprofile.sql."

echo "Drop tablespaces with Missing DataFiles."
echo "Database, $trgtdb, has been successfully refreshed."

## Bouncing the database after the refresh

echo "Bouncing the database $trgtdb ."

sqlplus -s /nolog << EOF > $audit_path/bounce.err
connect / as sysdba
shutdown immediate
exit 
EOF

err=`grep "ORA-" $audit_path/bounce.err`

if [ ! -z "$err" ]
then
  echo "Error bouncing the target database, $trgtdb after the refresh"
  echo "Check audit file, $audit_path/bounce.err, for errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

sqlplus -s /nolog << EOF > $audit_path/bounce.err
connect / as sysdba
startup
exit 
EOF

err=`grep "ORA-" $audit_path/bounce.err`

if [ ! -z "$err" ]
then
  echo "Error bouncing the target database, $trgtdb after the refresh"
  echo "Check audit file, $audit_path/bounce.err, for errors."
  $scriptloc/refstatus.sh $trgtdb E
  exit 1
fi

echo "Bounce of the database, $trgtdb , has been completed."
echo "Please start all the application services for $trgtdb."

exit 0
