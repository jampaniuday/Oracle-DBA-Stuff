#!/bin/ksh
# Usage   : profile_by_value.sh <ORACLE_SID> <Profile_Value>
#
if [ $# -ne 2 ]
then
   echo "Usage : $0 <ORACLE_SID> <Profile value>"
   exit 1
fi
Oracle_Sid=$1
if [ ! -f $HOME/bin/$Oracle_Sid ]
then
   echo "Invalid ORACLE_SID. Try again"
   exit 1
fi
. $HOME/bin/${Oracle_Sid}
Profn=$2
#Profn=`echo $2 | tr [:lower:] [:upper:] `
pwd1=`tellme apps`
echo $pwd1
audit_path=$SID_HOME/audit
#audit_path=/t030/oracle50/ravi
rm ${audit_path}/profile_check.error
sqlplus -s apps/$pwd1@$1 <<EOF  >${audit_path}/profile_check.error
EOF
  grep "ORA-01017" ${audit_path}/profile_check.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> invalid username/password; logon denied"
    echo "##       ====>  cannot continue"
    cat ${audit_path}/profile_check.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi

  grep " ORA-12541:" ${audit_path}/profile_check.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "## ERROR ====> TNS:no listener"
    echo "##       ====>  cannot continue"
    cat ${audit_path}/profile_check.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi

grep "ORA-" ${audit_path}/profile_check.error
  if [ $? -eq 0 ]
  then
    echo "#####################################################"
    echo "##       ====> cannot continue"
    cat ${audit_path}/profile_check.error | grep ORA- | awk '{print "##", $0}'
    echo "#####################################################"
    error_switch=1
    exit 1
  fi
Uname=apps
Passwd=`tellme apps`
sqlplus -s $Uname/$Passwd <<EOF
col Id for 9999
col Name for a26
col Value for a66
set linesize 140
select o.profile_option_id Id,
       o.profile_option_name Name,
       nvl(v.profile_option_value,'Not Found') Value
  from fnd_profile_option_values v, fnd_profile_options o
 where v.profile_option_value like '%$Profn%'
   and o.profile_option_id = v.profile_option_id (+);

