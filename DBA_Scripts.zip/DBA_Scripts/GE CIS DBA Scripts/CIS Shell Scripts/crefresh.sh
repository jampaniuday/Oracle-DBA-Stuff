#!/bin/ksh
ref_start_time=`date +%R`
## Verify parameters

if [ -z "$1" ]
then
  echo "Invalid usage, parameter not supplied."
  echo "Script is terminating."
  exit 1
fi

## Set environment

. /user/oracle/bin/$1

## Set control file name & path

control_path="/user/hrapp/refresh/cntl"

#control_file_temp=`ll $control_path/*.ctl | awk -F" " '{print $NF}' | awk -F"/" '{print $NF}'`
#control_file=`echo $control_file_temp | awk -F" " '{print $1}'`
control_file=$1"_refresh"

if [ -z "$control_path/$control_file" ]
then
  echo "No database scheduled for refresh."
  exit 0
fi

## Set source & target database

source_db=`cat $control_path/$control_file | awk -F":" '{print $2}'`
target_db=`cat $control_path/$control_file | awk -F":" '{print $4}'`
no_of_para=`cat $control_path/$control_file | awk -F":" '{print NF}'`

if [ $no_of_para -ge 6 ]
then
  alt_backup_base=`cat $control_path/$control_file | awk -F":" '{print $6}'`
fi

if [ $no_of_para = 8 ]
then
  alt_hostname=`cat $control_path/$control_file | awk -F":" '{print $8}'`
fi

db_prefix=`echo $control_file | awk -F"_" '{print $1}'`

if [ "$db_prefix" != "$target_db" ]
then
  echo "Error : Control file not setup correctly."
  echo "Control file has been renamed to "$refresh_ctl".err."

  mv $control_path/$refresh_ctl $control_path/$refresh_ctl.err

  echo "Script is Terminating."

  exit 1
fi

## Verify entries in dbinstance.ctl file for both instances

to_sid=$target_db
from_sid=$source_db

for sid in $from_sid $to_sid
do
  dbinfo=`grep "$sid" $HOME/bin/dbinstance.ctl`
  if [ $? -ne 0 ]
  then
    echo "Error : Cannot find instance name, $sid in dbinstance.ctl file."
    echo "Script is terminating."

    exit 1
  fi

  ## Verify whether target instance specified can be refreshed
  if [ "$sid" = "$to_sid" ]
  then
    refresh_val=`echo $dbinfo | awk -F" " '{print $5}'`
    if [ -z "$refresh_val" ]
    then
      echo "Error : No value specified for refresh, please check dbinstance.ctl"
      echo "Script is terminating."

      exit 1
    fi

    if [ "$refresh_val" != "Y" ]
    then
      echo "Error : Specified target instance cannot be refreshed."
      echo "Script is terminating."

      exit 1
    fi
  fi

  dbhname=`echo $dbinfo | awk -F" " '{print $3}'`
  if [ -z "$dbhname" ]
  then
    echo "Error : Unable to find hostname for instance, $sid."
    echo "Script is terminating."

    exit 1
  fi

  ## Verify db hostname with the host server executing the script
  if [ "$dbhname" = "`hostname`" ]
  then
    ## db instance host is same the server executing the script
    ## set initflag to 0 to specify atleast one instance is on local host
    initflag=0
  else
    initflag=1
  fi

  ## Set instance environment
  if [ $initflag -eq 0 ]
  then
    ## Verify instance initialization script exists
    if [ ! -f $HOME/bin/$sid ]
    then
      echo "Error : Initialization script for $sid on $dbhname does not exists."
      echo "Script is terminating."

      exit 1
    fi
    ## Setup environment
    . $HOME/bin/$sid
  fi
done

## Check initflag

if [ $initflag -eq 1 ]
then
  echo "Error : None of the instance specified exists on local host."
  echo "Script is terminating."

##  exit 1
fi

## Move refresh control file to done

mv $control_path/$control_file $control_path/$control_file.done

## Set hostname & connect string

dbcontrol=`grep -i $source_db $HOME/bin/dbinstance.ctl`
hostname=`echo $dbcontrol | awk -F" " '{print $3}'`
connect_string=`echo $dbcontrol | awk -F" " '{print $2}'`

## Set backup path

backup_base="/user/copy01"
backup_path="$backup_base/$source_db/oracle/$source_db"
if [ ! -z "$alt_backup_base" ]
then
  backup_base=$alt_backup_base
  backup_path="$backup_base/oracle/$source_db"
fi

## Set copy type, remote copy or local copy

if [ -z "$alt_hostname" ]
then
  if [ "`hostname`" = "$hostname" ]
  then
    copy_type="cp "
  else
    copy_type="rcp $hostname:"
  fi
else
  if [ "`hostname`" = "$alt_hostname" ]
  then
    copy_type="cp "
  else
    copy_type="rcp $alt_hostname:"
  fi
fi

## Verify environment file exists for target database

if [ ! -f "$HOME/bin/$target_db" ]
then
  echo "Environment file does not exists for $target_db."
  echo "Script is terminating."

  exit 1
fi

## Set environment

. $HOME/bin/$target_db

## Set SYSTEM password

passwd=`/user/oracle/bin/tellme system`

if [ -z "$passwd" ]
then
  echo "SYSTEM password not defined for $target_db database."
  echo "Script is terminating."

  exit 1
fi

## Set audit path

audit_path=$SID_HOME/audit

## Create table AVAIL_SPACE

sqlplus system/$passwd << EOF > $audit_path/avail_space.err
create table avail_space
(avail_fs  varchar2(10),
 avail_fs_size number(15));
exit
EOF

err=`grep "ORA" $audit_path/avail_space.err`

if [ ! -z "$err" ]
then
  table_exists=`echo $err | grep "ORA-00955:"`
  if [ -z "$table_exists" ]
  then
    echo "Error creating table."
    echo $err
    echo "Script is terminating."

    exit 1
  fi
fi

## Create table SOURCE_FILES

sqlplus system/$passwd << EOF > $audit_path/source_files.err
create table source_files
(fname     varchar2(30),
 fsize     number(15),
 fsystem   varchar2(10));
exit
EOF

err=`grep "ORA" $audit_path/source_files.err`

if [ ! -z "$err" ]
then
  table_exists=`echo $err | grep "ORA-00955:"`
  if [ -z "$table_exists" ]
  then
    echo "Error creating table."
    echo $err
    echo "Script is terminating."

    exit 1
  fi
fi

## Create list of available file systems

bdf | awk -F" " '{print $6" "$4}' > $audit_path/fspace

## Sort file

sort $audit_path/fspace > $audit_path/file_space

## Create script to insert file system info in db

echo "REM File to insert records." > $audit_path/insrecords.sql
echo " " >> $audit_path/insrecords.sql

while read fsys fsize ; do
  fsys_temp=`echo $fsys | awk -F"/" '{print substr($3,1,1)}'`
  if [ "$fsys_temp" = "u" ]
  then
    echo "insert into avail_space values('$fsys',$fsize*1024);" >> $audit_path/insrecords.sql
  fi
done < $audit_path/file_space

## Insert records

sqlplus -s system/$passwd << EOF > $audit_path/insert_records.err
truncate table avail_space;
@$audit_path/insrecords.sql
exit
EOF

err=`grep "ORA-" $audit_path/insert_records.err`

if [ ! -z "$err" ]
then
  echo "Error insert records in table, avail_space."
  echo $err
  echo "Script is terminating."

  exit 1
fi

## Update avail space information with space currently occupied

sqlplus -s system/$passwd << EOF > $audit_path/used_space.err
set pagesize 0 linesize 200 feedback off verify off echo off termout off heading off
spool $audit_path/used_space.lst
select substr(file_name,1,9), sum(bytes) from dba_data_files
group  by substr(file_name,1,9);
spool off
exit
EOF

err=`grep "ORA-" $audit_path/used_space.err`

if [ ! -z "$err" ]
then
  echo "Error selecting currently used space."
  echo "Script is terminating."

  exit 1
fi

echo "REM Script to update space currently used." > $audit_path/updspace.sql
echo " " >> $audit_path/updspace.sql

while read fsys fspace ; do
  echo "update avail_space " >> $audit_path/updspace.sql
  echo "       set avail_fs_size=avail_fs_size+$fspace" >> $audit_path/updspace.sql
  echo "where  avail_fs = '$fsys';" >> $audit_path/updspace.sql
  echo " " >> $audit_path/updspace.sql
done < $audit_path/used_space.lst
echo "commit;" >> $audit_path/updspace.sql

sqlplus -s system/$passwd << EOF > $audit_path/updspace.err
@$audit_path/updspace.sql
exit
EOF

err=`grep "ORA-" $audit_path/updspace.err`

if [ ! -z "$err" ]
then
  echo "Error updating avail_space table."
  echo "Script is terminating."

  exit 1
fi

## Create list of source files to be copied

sqlplus -s system/$passwd@$connect_string << EOF > $audit_path/select_source.err
set pagesize 0 linesize 200 feedback off verify off echo off termout off heading
 off
/* =====> Select tablespace datafiles */
spool $audit_path/refresh.data
select substr(file_name,1,80), bytes
from   dba_data_files
where tablespace_name not in ('GEHRD_ARCH','GEHRX_ARCH')
order  by tablespace_name, file_id ;
spool  off
/* =====> Select log group members */
spool $audit_path/logs.groups
select DISTINCT GROUP# from v\$logfile ;
spool  off
/* =====> Select all control file names */
spool $audit_path/refresh.ctltmp
select value from v\$parameter where name = 'control_files' ;
spool  off       
exit
EOF

err=`grep "ORA-" $audit_path/select_source.err`

if [ ! -z "$err" ]
then
  echo "Error selecting source files."
  echo $err
  echo "Script is terminating."

  exit 1
fi

## Select log files from database

while read groupno ; do

sqlplus -s system/$passwd@$connect_string << EOF > $audit_path/select_logs.err
set pagesize 0 linesize 200 feedback off verify off echo off termout off heading off    
/* =====> Select log group members */
spool $audit_path/refresh.logs.grp$groupno
select substr(member,1,80), bytes, f.GROUP#, rownum
from   v\$logfile f, v\$log g
where  f.GROUP# = $groupno
and    f.GROUP# = g.GROUP#
order  by f.GROUP# ;
spool  off
exit
EOF

done < $audit_path/logs.groups

## Create script to insert source file information

echo "REM File to insert records in SOURCE_FILES." > $audit_path/insrecords.sql
echo " " >> $audit_path/insrecords.sql

while read fpath fspace ; do
  fname=`echo $fpath | awk -F"/" '{print $NF}'`
  echo "insert into source_files values('$fname',$fspace, 0);" >> $audit_path/insrecords.sql
done < $audit_path/refresh.data

## Insert records

sqlplus -s system/$passwd << EOF > $audit_path/insert_records.err
truncate table source_files;
@$audit_path/insrecords.sql
exit
EOF

err=`grep "ORA-" $audit_path/insert_records.err`

if [ ! -z "$err" ]
then
  echo "Error insert records in table, source_files."
  echo $err
  echo "Script is terminating."

  exit 1
fi

## Create script to remove target files

sqlplus -s system/$passwd << EOF > $audit_path/refresh_rm.err
set pagesize 0 feedback off verify off echo off termout off heading off
spool $audit_path/refresh_rm.sh
select 'rm '||rtrim(file_name) from dba_data_files ;
select 'rm '||rtrim(member) from v\$logfile ;
spool off
spool $audit_path/logsdir.temp
select distinct substr(member,1,9)
from   v\$logfile ;
spool off
set linesize 200
spool $audit_path/refresh.ctltmp
select value from v\$parameter where name = 'control_files' ;
spool  off       
exit
EOF

echo `cat $audit_path/refresh.ctltmp | awk -F"," '{print "rm "$1}'` >> $audit_path/refresh_rm.sh
echo `cat $audit_path/refresh.ctltmp | awk -F"," '{print "rm "$2}'` >> $audit_path/refresh_rm.sh
echo `cat $audit_path/refresh.ctltmp | awk -F"," '{print "rm "$3}'` >> $audit_path/refresh_rm.sh

## Allocate file system to source files

sqlplus -s system/$passwd << EOF > $audit_path/alloc_files.err
@$DBA_HOME/admin/upd_source_files
exit
EOF

err=`grep "ORA-" $audit_path/alloc_files.err`

if [ ! -z "$err" ]
then
  echo "Error allocating file system to source files."
  echo $err
  echo "Script is terminating."

  exit 1
fi

## Create temp file for copy script

sqlplus -s system/$passwd << EOF > $audit_path/copy_script.err
set pagesize 0 linesize 80 feedback off verify off echo off termout off heading off
spool $audit_path/alloc_files
select fsystem, fname from source_files ;
spool off
exit
EOF

##

## Verify data directory exists

while read fsys fname ; do
  if [ ! -d "$fsys/oracle/$ORACLE_SID/data" ]
  then
     ## Base directory for ORACLE_SID
     if [ -d "$fsys/oracle/$ORACLE_SID" ]
     then
       ## Create data diretory
       mkdir $fsys/oracle/$ORACLE_SID/data
     else
       ## Create base & data directory
       mkdir $fsys/oracle/$ORACLE_SID
       mkdir $fsys/oracle/$ORACLE_SID/data
     fi
  fi
done < $audit_path/alloc_files.lst

##

let i=1
echo "" > $audit_path/logs.dir
while read logdir ; do
  echo $logdir" DIR"$i >> $audit_path/logs.dir
  let i=i+1
done < $audit_path/logsdir.temp

let i=1
while read groupno ; do
  if [ $i = 1 ]
  then
    cat $audit_path/refresh.logs.grp$i > $audit_path/refresh.logs
  else
    cat $audit_path/refresh.logs.grp$i >> $audit_path/refresh.logs
  fi
  let i=i+1
done < $audit_path/logs.groups

## Set max group number

maxlog=`wc -l $audit_path/logs.groups | awk -F" " '{print $1}'`

#cat $audit_path/refresh.logs.grp1 $audit_path/refresh.logs.grp2 $audit_path/refresh.logs.grp3 > $audit_path/refresh.logs

echo "# Script to copy files" > $audit_path/refresh_cp.sh
echo " " >> $audit_path/refresh_cp.sh

echo "# Script to list files copied" > $audit_path/refresh_ll.sh
echo " " >> $audit_path/refresh_ll.sh

echo "# Script to uncompress files copied" > $audit_path/refresh_uncompress.sh
echo " " >> $audit_path/refresh_uncompress.sh

echo "REM Script to start database using create control file." > $audit_path/newcntl.sql
echo " " >> $audit_path/newcntl.sql

echo "STARTUP NOMOUNT" >> $audit_path/newcntl.sql
echo "CREATE CONTROLFILE SET DATABASE \"${to_sid}\" RESETLOGS NOARCHIVELOG" >> $audit_path/newcntl.sql
echo "MAXLOGFILES 30" >> $audit_path/newcntl.sql
echo "MAXLOGMEMBERS 5" >> $audit_path/newcntl.sql
echo "MAXDATAFILES 400" >> $audit_path/newcntl.sql
echo "MAXINSTANCES 4" >> $audit_path/newcntl.sql
echo "LOGFILE " >> $audit_path/newcntl.sql 

while read groupno ; do

echo "GROUP $groupno (" >> $audit_path/newcntl.sql
i=1
while read fpath fsize fgroup frow ; do
  fname=`echo $fpath | awk -F"/" '{print $NF}'`
  fdir=`grep "DIR$frow" $audit_path/logs.dir|awk -F" " '{print $1}'`
  if [ ! -z "$fdir" ]
  then
    if [ $i = 1 ]
    then
      echo "'$fdir/oracle/$target_db/log/$fname'," >> $audit_path/newcntl.sql
    else
      if [ $maxlog = $groupno ]
      then
        echo "'$fdir/oracle/$target_db/log/$fname') SIZE $fsize" >> $audit_path/newcntl.sql
      else
        echo "'$fdir/oracle/$target_db/log/$fname') SIZE $fsize," >> $audit_path/newcntl.sql
      fi
    fi
    let i=i+1
  fi
done < $audit_path/refresh.logs.grp$groupno

done < $audit_path/logs.groups

echo "DATAFILE" >> $audit_path/newcntl.sql

while read fpath fsize fgroup frow ; do
  fname=`echo $fpath | awk -F"/" '{print $NF}'`
  fdir=`grep "DIR$frow" $audit_path/logs.dir|awk -F" " '{print $1}'`
  if [ ! -z "$fdir" ]
  then
    echo "$copy_type$backup_path/log/$fname.Z $fdir/oracle/$target_db/log/." >> $audit_path/refresh_cp.sh
    echo "ll $fdir/oracle/$target_db/log/$fname.Z" >> $audit_path/refresh_ll.sh
    echo "uncompress $fdir/oracle/$target_db/log/$fname.Z" >> $audit_path/refresh_uncompress.sh
  fi
done < $audit_path/refresh.logs

## No. of data files

total_files=`wc -l $audit_path/alloc_files.lst | awk -F" " '{print $1}'`

## Create script to copy files

i=1
while read fsystem fname ; do
  echo "$copy_type$backup_path/data/$fname.Z $fsystem/oracle/$target_db/data/." >> $audit_path/refresh_cp.sh
  echo "ll $fsystem/oracle/$target_db/data/$fname.Z" >> $audit_path/refresh_ll.sh
  echo "uncompress $fsystem/oracle/$target_db/data/$fname.Z" >> $audit_path/refresh_uncompress.sh
  if [ $i -lt $total_files ]
  then
    echo "'$fsystem/oracle/$target_db/data/$fname'," >> $audit_path/newcntl.sql
    let i=i+1
  else
    echo "'$fsystem/oracle/$target_db/data/$fname'" >> $audit_path/newcntl.sql
    echo ";" >> $audit_path/newcntl.sql
  fi
done < $audit_path/alloc_files.lst

echo "alter database open resetlogs;" >> $audit_path/newcntl.sql
echo "alter database rename global_name to ${to_sid}.corporate.ge.com;" >> $audit_path/newcntl.sql
echo "update applsys.fnd_concurrent_requests set hold_flag = 'Y'" >> $audit_path/newcntl.sql
echo "       where  phase_code = 'P' and hold_flag = 'N' ; " >> $audit_path/newcntl.sql
echo "update applsys.fnd_profile_option_values set profile_option_value = UPPER('${to_sid}') " >> $audit_path/newcntl.sql
echo "    where profile_option_id = 125; " >> $audit_path/newcntl.sql

### Added By Ranjit On 8-May-02 to Create the DB Links ### 
CrDblinkPRS()
{
echo "connect apps/happ7day;" >>$audit_path/newcntl.sql
echo "drop  database link DBL_SERVER1.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link DBL_SERVER2.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link DBL_SERVER3.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link DBL_SERVER4.CORPORATE.GE.COM;"  >> $audit_path/newcntl.sql
echo "drop  database link USPROD.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link UKPROD.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql 
echo "drop  database link ASPROD.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql 
echo "create database link dbl_Server1.CORPORATE.GE.COM connect to apps identified by redba11 using 'd1uprss';" >> $audit_path/newcntl.sql
echo "create database link dbl_Server2.CORPORATE.GE.COM connect to apps identified by redba11 using 'd1eprss';" >> $audit_path/newcntl.sql
echo "create database link dbl_Server3.CORPORATE.GE.COM connect to apps identified by redba11 using 'd1aprss';" >> $audit_path/newcntl.sql
echo "create database link dbl_Server4.CORPORATE.GE.COM connect to apps identified by ap8ps using 'd1jprss';" >> $audit_path/newcntl.sql

}

CrDblinkTRN()
{
echo "connect apps/happ7day;" >>$audit_path/newcntl.sql
echo "drop  database link DBL_SERVER1.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link DBL_SERVER2.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link DBL_SERVER3.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link DBL_SERVER4.CORPORATE.GE.COM;"  >> $audit_path/newcntl.sql
echo "drop  database link USPROD.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link UKPROD.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql 
echo "drop  database link ASPROD.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql 
echo "create database link dbl_Server1.CORPORATE.GE.COM connect to apps identified by redba11 using 'd1utrns';" >> $audit_path/newcntl.sql
echo "create database link dbl_Server2.CORPORATE.GE.COM connect to apps identified by redba11 using 'd1etrns';" >> $audit_path/newcntl.sql
echo "create database link dbl_Server3.CORPORATE.GE.COM connect to apps identified by redba11 using 'd1atrns';" >> $audit_path/newcntl.sql

}
CrDblinkTST()
{
echo "connect apps/happ7day;" >>$audit_path/newcntl.sql
echo "drop  database link DBL_SERVER1.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link DBL_SERVER2.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link DBL_SERVER3.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link DBL_SERVER4.CORPORATE.GE.COM;"  >> $audit_path/newcntl.sql
echo "drop  database link USPROD.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql
echo "drop  database link UKPROD.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql 
echo "drop  database link ASPROD.CORPORATE.GE.COM;" >> $audit_path/newcntl.sql 
echo "create database link dbl_Server1.CORPORATE.GE.COM connect to apps identified by redba11 using 'd1utsts';" >> $audit_path/newcntl.sql
echo "create database link dbl_Server2.CORPORATE.GE.COM connect to apps identified by redba11 using 'd1etsts';" >> $audit_path/newcntl.sql
echo "create database link dbl_Server3.CORPORATE.GE.COM connect to apps identified by redba11 using 'd1atsts';" >> $audit_path/newcntl.sql

}
case $1 in 
	uprs|aprs|eprs)CrDblinkPRS;;
	utrn|atrn|etrn)CrDblinkTRN;;
	utst|atst|etst)CrDblinkTST;;
	*)CrDblinkTST;;
esac

#### Done Dblink 8-May-02  


##########################################
POST REFRESH SCRIPT 
##########################################

cat <<! >$SID_HOME/audit/post_ref.sql

rem   Description
rem   ===========
rem   This script scrambles the Salary information of the employees
rem   
rem   This script is intended for GE to scramble Officer's details
rem   on databases they provide to KPMG as test databases, for security
rem   purposes.
rem   
rem   Rows are committed in batches of 1000 for Employees  
rem   
rem   
rem   
rem   for any row which raises an exception on update.
rem
rem   This procedure should be run in SQL*Plus from the APPS account.
rem
rem Version Date       Author    		Description of Change
rem -------+---------+---------+-------+-------------------------------
rem 1.0    10-Feb-2002 Tata Consultancy		Created
rem                    Services                 
rem -------+---------+---------+-------+-------------------------------
rem 


CREATE OR REPLACE PROCEDURE ge_officers_update(p_business_group_id per_all_people_f.business_group_id%TYPE DEFAULT 550) AS

l_temp_count NUMBER;
l_rowcount	NUMBER;
--
l_national_identifier   per_all_people_f.national_identifier%TYPE;

l_person_id            per_all_people_f.person_id%TYPE;
l_assignment_id per_all_assignments_f.assignment_id%TYPE;
l_grade_id per_all_assignments_f.grade_id%TYPE;
l_pay_basis_id per_all_assignments_f.pay_basis_id%TYPE;
l_screen_entry_value pay_element_entry_values_f.screen_entry_value%TYPE;
l_pay_annualization_factor per_pay_bases.pay_annualization_factor%TYPE;
l_old_assignment_id per_all_assignments_f.assignment_id%TYPE;
--

CURSOR get_person IS
SELECT DISTINCT papf.national_identifier,papf.person_id,paaf.assignment_id,paaf.pay_basis_id
FROM   per_all_people_f papf,
       per_all_assignments_f paaf
WHERE paaf.person_id = papf.person_id
AND papf.business_group_id = p_business_group_id;


--

/* Extra Declaration Block 
l_grade_rule_id pay_grade_rules.grade_rule_id%type;
l_minimum  pay_grade_rules.minimum%type;
l_mid_value pay_grade_rules.mid_value%type;
l_maximum pay_grade_rules.maximum%type;
*/



BEGIN

   dbms_output.put_line('Procedure Started');
 
   -- Initialization 

   l_rowcount            :=0;
   l_national_identifier := NULL;
   l_person_id           := NULL;
   l_assignment_id       := NULL;
   l_old_assignment_id   := NULL;
   l_pay_basis_id        := NULL;
   l_grade_id            := NULL;
   l_screen_entry_value  := 20000;


   SELECT grade_id INTO l_grade_id
   FROM per_grades
   WHERE business_group_id = p_business_group_id
   AND ROWNUM<2;

   FOR per_rec IN get_person LOOP
   BEGIN

     l_national_identifier := per_rec.national_identifier;
     l_person_id           := per_rec.person_id;
     l_assignment_id       := per_rec.assignment_id;
     l_pay_basis_id        := per_rec.pay_basis_id;


     
   IF(l_old_assignment_id <> l_assignment_id) THEN
     BEGIN 

     -- Flat Grade Updates 

     UPDATE per_all_assignments_f
     SET grade_id = l_grade_id
     WHERE person_id = l_person_id
     AND grade_id IS NOT NULL;
  
  
     l_rowcount:=l_rowcount+1;
     
    
    -- update the element entry values
   
     
     UPDATE pay_element_entry_values_f
     SET screen_entry_value = l_screen_entry_value
     WHERE element_entry_id IN (SELECT peef.element_entry_id
				FROM pay_element_entries_f peef,
				pay_element_entry_values_F peev,
			        pay_input_values_f pivf
				WHERE assignment_id = l_assignment_id
				AND peef.element_entry_id = peev.element_Entry_id
				AND peef.effective_start_date = peev.effective_start_date
				AND peef.effective_end_date = peev.effective_end_date
				AND peev.input_value_id = pivf.input_value_id
                                AND peef.creator_type <> 'SP'   
				AND pivf.uom = 'M');

    -- Address Updates 

     UPDATE per_addresses
     SET address_line1 = '1 River Road',
     town_or_city = 'Schenectady',
     region_2 = 'NY',
     country = 'US',
     postal_code = '12345',
     region_1 = NULL,
     region_3 = NULL,
     address_line2 = NULL,
     address_line3 = NULL
     WHERE person_id = l_person_id;
     
	END; 
   END IF;
 
     -- update the salary proposals and Salary Elements
        
     SELECT NVL(pay_annualization_factor,1) INTO l_pay_annualization_factor
     FROM per_pay_bases 
     WHERE pay_basis_id = l_pay_basis_id;
          
     UPDATE per_pay_proposals
     SET proposed_salary = (l_screen_entry_value/l_pay_annualization_factor)
     WHERE assignment_id = l_assignment_id;


     UPDATE pay_element_entry_values_f
     SET screen_entry_value = (l_screen_entry_value/l_pay_annualization_factor)
     WHERE element_entry_id IN (SELECT peef.element_entry_id
				FROM pay_element_entries_f peef,
				pay_element_entry_values_F peev,
			        pay_input_values_f pivf
				WHERE assignment_id = l_assignment_id
				AND peef.element_entry_id = peev.element_Entry_id
				AND peef.effective_start_date = peev.effective_start_date
				AND peef.effective_end_date = peev.effective_end_date
				AND peev.input_value_id = pivf.input_value_id
                                AND peef.creator_type = 'SP'   
				AND pivf.uom = 'M');
   
     l_old_assignment_id := l_assignment_id;         

     IF((l_rowcount MOD 1000)=0) THEN
       dbms_output.put_line(l_national_identifier||' -  '||l_assignment_id);
       dbms_output.put_line('Commit Point Reached ');
       COMMIT;
	 ELSE
	    dbms_output.put_line('National Identifier  '||l_national_identifier||'  -  '||'  Updated  ');
     END IF;
	 
	 

EXCEPTION
    WHEN OTHERS THEN
       dbms_output.put_line
		('Error UPDATING assignment OR salary OR element ENTRY screen value ' || 
				TO_CHAR (l_rowcount) ||
				' FOR person id ' || l_person_id); 
END;
END LOOP; 

dbms_output.put_line('Total Employees Updated   '||l_rowcount);

commit;
dbms_output.put_line('Procedure Completed Successfully ');
 
END ge_officers_update;
/
exec ge_officers_update;
!
cat <<! >>$SID_HOME/audit/post_ref.sql
CREATE OR REPLACE PROCEDURE Developer_Responsibility_SetUp
IS

BEGIN

-- Remove the Responsibility end dates for given group of users

UPDATE fnd_user_responsibility
SET end_date = '31-DEC-4712'
WHERE USER_ID IN (SELECT USER_ID FROM FND_USER
		  WHERE USER_NAME IN ('KPMGHR', 'VISHISTV', 'PARANJAPEM', 'DECROSTAJ', 'TCSHR'));

COMMIT;

EXCEPTION
WHEN OTHERS THEN
dbms_output.put_line('Set Up Failed  '|| SQLERRM);
END Developer_Responsibility_SetUp;
/
exec Developer_Responsibility_SetUp;
!
cat <<! >>$SID_HOME/audit/post_ref.sql 
drop Procedure ge_officers_update;
drop Procedure Developer_Responsibility_SetUp; 
!

#########################
END POST REFRESH
#########################


## Drop staging tables

sqlplus -s system/$passwd << EOF > $audit_path/drop_staging.err
REM drop table avail_space ;
REM drop table source_files ;
exit
EOF

err=`grep "ORA-" $audit_path/drop_staging.err`

if [ ! -z "$err" ]
then
  echo "Error dropping staging tables."
  echo "Continue with the refresh script."
fi

## Remove temporary files

rm $audit_path/*.lst
rm $audit_path/*.err
rm $audit_path/logs*.*
rm $audit_path/fspace
rm $audit_path/file_space
rm $audit_path/insrecords.sql
rm $audit_path/updspace.sql
rm $audit_path/refresh.data
rm $audit_path/refresh.logs*
rm $audit_path/refresh.ctltmp

## Scripts created.

echo "Scripts created."

## View refresh_rm.sh file

. $HOME/bin/$target_db

#vi $audit_path/refresh_rm.sh

## Ask whether to continue or abort

#echo "Want to continue with the refresh ? "
yes_no="y"

if [ "$yes_no" = "n" -o "$yes_no" = "N" ]
then
  echo "Aborting the refresh."
  echo "Script is terminating."

  exit 1
fi

## Shutdown target database

echo "Shutting down database "$target_db"."

## Shutdown target database

svrmgrl <<EOF >$audit_path/ora.error
connect internal
shutdown abort
exit
EOF

err=`grep "ORA-" $audit_path/ora.error`

if [ ! -z "$err" ]
then
  echo "Errors shutting down database "$target_db"."
  echo "Script is terminating."

  exit 1
fi

## Set permissions to execute refresh_rm.sh

chmod 700 $audit_path/refresh_rm.sh

## Remove files, execute refresh_rm.sh

echo "Removing data files."

$audit_path/refresh_rm.sh

## Set permissions to execute refresh_cp.sh

chmod 700 $audit_path/refresh_cp.sh

## Copy files from source database

echo "Copying data files from source database."

$audit_path/refresh_cp.sh 2> $audit_path/refresh_cp.err

cperr1=`grep -i "space" $audit_path/refresh_cp.err`

if [ ! -z "$cperr1" ]
then
  echo "Error copying files, please make sure all files are copied."
  echo "And then run following files, "
  echo "    $SID_HOME/audit/refresh_uncompress.sh"
  echo "Start the database connecting as internal & executing "
  echo "newcntl.sql from $SID_HOME/audit directory."

  echo "Script is terminating."
  exit 1
fi

cperr2=`grep -i ": No such file or directory" $audit_path/refresh_cp.err`

if [ ! -z "$cperr2" ]
then
  echo "Error copying files, please make sure all files are copied."
  echo "And then run following files, "
  echo "    $SID_HOME/audit/refresh_uncompress.sh"
  echo "Start the database connecting as internal & executing "
  echo "newcntl.sql from $SID_HOME/audit directory."

  echo "Script is terminating."
  exit 1
fi

## Set permissions to execute refresh_uncompress.sh

chmod 700 $audit_path/refresh_uncompress.sh

## Uncompress datafiles

echo "Uncompressing data files."

$audit_path/refresh_uncompress.sh 2> $audit_path/refresh_uncompress.err

uncerr=`grep -i "space" $audit_path/refresh_uncompress.err`

if [ ! -z "$uncerr" ]
then
  echo "Error uncompressing files, please make sure all files are uncompressed."
  echo "Then, start the database connecting as internal & executing "
  echo "newcntl.sql from $SID_HOME/audit directory."

  echo "Script is terminating."
  exit 1
fi

echo "Starting database."

## Start database

svrmgrl <<EOF >${audit_path}/ora.error
connect internal
@$audit_path/newcntl.sql
exit
EOF

## Check for errors

err=`grep "ORA-" $audit_path/ora.error|grep -v "ORA-02024"`

if [ ! -z "$err" ]
then
  echo "Error starting database."
  echo "Script is terminating."

  exit 1
fi

svrmgrl <<EOF >${audit_path}/ora.error
connect internal
drop tablespace GEHRD_ARCH including contents;
drop tablespace GEHRX_ARCH including contents;
exit
EOF


echo "Database "$target_db" has been successfully refreshed."

echo "Database "$target_db" has been successfully refreshed." > $audit_path/mail_body.txt
mailx -s "Database $target_db has been successfully refreshed." richard.alexander@corporate.ge.com < $audit_path/mail_body.txt
mailx -s "Database $target_db has been successfully refreshed." jadia.satyen@corporate.ge.com < $audit_path/mail_body.txt
rm $audit_path/mail_body.txt

## Update db profile for APPS_WEB_AGENT

web_agent=`grep "$target_db" /user/oracle/bin/db_urls.ctl | awk -F" " '{print $2}'`

if [ ! -z "$web_agent" ]
then
sqlplus system/$passwd << EOF > $audit_path/web_agent.err
update applsys.fnd_profile_option_values
set    profile_option_value='$web_agent'
where  profile_option_id=2353;
commit;
exit
EOF
fi

### RUN POST Refresh Script ##

if [ -f "$SID_HOME/audit/post_ref.sql" ]
then
sqlplus -s apps/happ7day <<EOF >$SID_HOME/audit/post_ref.err
@$SID_HOME/audit/post_ref.sql;
EOF
fi


err=`grep "ORA-" $SID_HOME/audit/post_ref.err`

if [ ! -z "$err" ]
then
  echo "Error Running Post Install Script Please run $SID_HOME/audit/post_ref.sql as a APPS user "
fi



###############
#END RUN POST REFRESH SCRIPT
########################

## Create DBC file on webserver

db_hosts=`grep "$target_db" /user/oracle/bin/db_urls.ctl | awk -F" " '{print $3}'`

if [ ! -z "$db_hosts" ]
then
rexec $db_hosts /user/dba01/oracle/admin/fnd_secure.sh $target_db
fi
#
# Updating the refresh info 
#


#
PASSWD=`remsh corpp014 -l oracle "(cd \$HOME/bin;. uhrp;tellme system)"`
sqlplus -s system/${PASSWD}@USPROD <<EOF >$SID_HOME/audit/ora.err
set pagesize 0 linesize 80 feedback off verify off echo off termout off heading off
spool $SID_HOME/audit/tabinfo.lst
select 1 from user_tables where table_name='REFRESH_INFO';
spool off
EOF

te=`cat $SID_HOME/audit/tabinfo.lst|awk '{print 1}'`
if [ -z "$te" ]
then
te=0
fi
if [ $te -eq 1 ]
then
echo table_exists
else
echo table_does_not_exists
echo Creating Table REFRESH_INFO
sqlplus -s system/${PASSWD}@USPROD <<EOF >$SID_HOME/audit/ora.err
set pagesize 0 linesize 80 feedback off verify off echo off termout off heading off
create table refresh_info
(
ref_date date DEFAULT sysdate,
source_db varchar2 (30),
target_db varchar2 (30),
ref_start_time varchar2 (10),
ref_end_time varchar2 (10),
target_dbserver varchar2 (15),
target_db_appltop varchar2 (30),
target_sid_lstnport number (10),
target_webserver varchar2 (15),
target_web_appltop varchar2 (30),
target_sid_webport number (10),
target_sid_appslink varchar2 (30)
);
EOF
grep 'ORA-' $SID_HOME/audit/ora.err
if [ $? -eq 0 ]
then 
cat $SID_HOME/audit/ora.err
echo "Error creating table refresh_info"
exit 1
fi
fi

#
# Getting the Information 
#

target_dbserver=`hostname`
target_db_appltop=`cat $HOME/bin/${target_db}|grep "^APPL_TOP="|awk -F";" '{print $1}'|awk -F= '{print $2}`
# selecting lstn port#
lstn_file=`lsnrctl status lstn${target_db}|grep "Listener Parameter File"|awk '{print $4}'`
#echo $lstn_file
linecp=1
linecount=10
rm $SID_HOME/audit/aa.txt
while read line 
do
lnstr=`echo $line |grep lstn"${target_db}"|awk -F"=" '{print $1}'|awk '{print $1}'`
if [ -z "$lnstr" ]
then
lnstr="no"
fi
#echo lnstr $lnstr
if [ "${lnstr}" = "lstn${target_db}" ]
then
#	echo found
	linecp=0
fi
if [ $linecp -eq 0 ]
then
if  [ $linecount -ne 0 ]
then
echo $line >>$SID_HOME/audit/aa.txt
linecount=`expr $linecount - 1`
else
continue 
fi
fi
done <$lstn_file
target_sid_lstnport=`cat $SID_HOME/audit/aa.txt|grep '[p|P][o|O][r|R][t|T]'|awk -F'[p|P][o|O][r|R][t|T]' '{print $2}'|awk -F= '{print $2}'|awk -F")" '{print $1}'|xargs echo`
# done selecting lstn port
target_webserver=`cat $HOME/bin/db_urls.ctl|grep $target_db|awk '{print $3}'`
#
if [ ! -z "$target_webserver" ]
then
webadm=`remsh $target_webserver -l oracle "(cd \\$HOME/bin;cat owsenv|grep ORAWEB_ADMIN)"|awk -F= '{print $2}'|awk -F";" '{print $1}'`
target_sid_webport=`remsh $target_webserver -l oracle "(cd $webadm;find . -name sv${target_db}.cfg -print |xargs cat)"|grep ANY|awk '{print $2}'|head -1`
target_web_appltop=`remsh $target_webserver -l oracle "(cd $webadm;find . -name sv${target_db}.cfg -print |xargs cat)"|grep "/OA_HTML/"|awk '{print $1}'|head -1|awk -F"/" '{print "/"$2"/"$3"/"$4}'`
target_sid_appslink1=`cat $HOME/bin/db_urls.ctl|grep $target_db|awk '{print $2}'|awk -F"/" '{print $1"//"$3"/OA_HTML/US/logon_"}'`
target_sid_appslink=`echo "${target_sid_appslink1}${target_db}.htm"`
fi
ref_end_time=`date +%R`
today=`date +%d-%b-%y`

echo source_db= $source_db
echo target_db= $target_db
echo ref_start_time=    $ref_start_time
echo ref_end_time=      $ref_end_time
echo target_dbserver=   $target_dbserver
echo target_db_appltop= $target_db_appltop
echo target_sid_lstnport=       $target_sid_lstnport
echo target_webserver=  $target_webserver
echo target_web_appltop=        $target_web_appltop
echo target_sid_webport=        $target_sid_webport
echo target_sid_appslink=       $target_sid_appslink
#Updating in  file refresh_info.lst On corpp014 (/user/oracle/bin) 
remsh corpp014 -l oracle "(
cd /user/oracle/bin;
echo "${today},${source_db},${target_db},${ref_start_time},${ref_end_time},${target_dbserver},${target_db_appltop},${target_sid_lstnport},${target_webserver},${target_web_appltop},${target_sid_webport},${target_sid_appslink}" >>refresh_info.lst;
)"

exit 0
