#!/bin/ksh
#set -x
################################################################################
## tcopy_rman.sh
##
## PURPOSE: To move disk backups performed via backup_rman.sh to tape storage.
##
## USAGE: This script is called either standalone or by the utility.sh script 
## when a scheduled backup entry exists in utility control file, (i.e
## $SID_HOME/admin/utility.ctl).
##	
##     The command line submitted by utility.sh is:
##          tcopy_rman.sh sid [AlternateBackupCtl] [Optional Archivelog backup] 
##          >$SID_HOME/audit/tcopy_${ORACLE_SID}.auditMMDD[_HHMM] 2>&1
##     The required utility.ctl record format is:
##          tcopy_rman:ddddddd where d(day)=0(skip),1(run)
##
##     A default rman.ctl file must exist under $SID_HOME/admin
##     rman.ctl records must be formatted as per backup_rman.sh requirements
##
##   SCRIPT PROCESS FLOW:
##
##   RESTART: All restarts should be performed using the restart capabilities
##        of the utility.sh script. If you choose to restart the tcopy_rman.sh
##        script itself, you will loose the email notification and audit trail
##        formatting provided by the utility.sh script.
##
##   OUTPUTS:
##
##   NOTIFICATION: Email notification of abends will be directed to the oncall
##        Oracle DBA; email notification for successful and failed executions
##        will always be directed to the responsible DBA for this instance.
##        This script MUST be initiated by script utility.sh to activate this
##        notification process. $HOME/bin/notify.ctl must contain the proper
##        notification names.
##
##   MODIFICATIONS:
##        Date        Name         	Description
##        ----------  --------------	--------------------------------------
##        12/01/2006  Ashish Trivedi	Created
##	  01/07/2006  Ashish Trivedi	Added archivelog cleanup capabilities
##
################################################################################

################################################################################
##  ------------------------------------------------------------------------  ##
##                      Notification Function for Autosys                     ##
##  ------------------------------------------------------------------------  ##
################################################################################
notify()
{
if [ -z "$addl_msg" ]; then
  page_msg="abended"
else
  page_msg="$addl_msg"
fi
parent_pid=`ps -o ppid -p $$ |tail -1`
parent_program=`ps -o args -p ${parent_pid}|tail -1`
echo $parent_program |grep utility.sh
if [ "$?" != 0 ]; then
  current_prog=`echo $0|sed -e 's/.*\///'`
  if [ -f $RMAN_LOG_FILE ]; then
     $DBA_HOME/admin/notify.sh -s "$current_prog $page_msg" -b "$msg_body" -f $RMAN_LOG_FILE -w sid
  else
     $DBA_HOME/admin/notify.sh -s "$current_prog $page_msg" -b "$msg_body" -w sid
  fi
     $DBA_HOME/admin/notify.sh -p "$current_prog $page_msg" -w sid
fi
run_cleanup
exit 1
}

echo "*************************************************************************"
echo "====>Script tcopy_rman.sh Starting on" `date`
echo "*************************************************************************"

################################################################################
##  ------------------------------------------------------------------------  ##
##         Process inputs and set the instance and script environment         ##
##  ------------------------------------------------------------------------  ##
################################################################################
# Verify sid input
if [ -z "$1" ]; then
  echo "Error====>Required parameter is missing"
  echo "          Usage is tcopy_rman.sh sid "
  echo "          Script is terminating!"
  notify
fi

# Set the instance environment
if [ ! -f $HOME/bin/$1 ]; then
  echo "Error====>No environment script found for instance \"$1\""
  echo "          Script is terminating!"
  notify
fi

. $HOME/bin/$1

backup_file=$SID_HOME/admin/rman.ctl

if [ ! -z "$2" ]; then
  echo $2 | grep ctl >/dev/null 2>&1
  if [ $? -eq 0 ]; then
    backup_file=$SID_HOME/admin/$2
  else
    backup_mode=arch
    if [ "$2" != ${backup_mode} ]; then
          echo "Error====>Invalid parameter for tape copying archivelogs"
          echo "          Usage is tcopy_rman.sh sid arch"
          echo "          Script is terminating!"
          notify
    fi
  fi
fi

if [ ! -z "$3" ]; then
  echo $3 | grep ctl >/dev/null 2>&1
  if [ $? -eq 0 ]; then
    backup_file=$SID_HOME/admin/$3
  else
          echo "Error====>Invalid parameter for tape copying archivelogs"
          echo "          Usage is tcopy_rman.sh sid arch ctlfile "
          echo "          Script is terminating!"
          notify
  fi
fi

if [ ! -f $backup_file ]; then
  echo "Error====>Backup control file does not exist"
  echo "          Script is terminating!"
  notify
fi

# Capture oracle version 
ora_version=`echo "exit" | sqlplus | awk '
  /Release/ {for (x=1; x<=NF; x++)
    { if ( $x == "Release" ) {x++; split($x,rel,"."); print rel[1]; break}
  }}'`

#echo VERSION is $ora_version

################################################################################
##  ------------------------------------------------------------------------  ##
##       Process script variables and gather settings from controlfile        ##
##  ------------------------------------------------------------------------  ##
################################################################################

###########
#Locations
###########
scripts_path=$DBA_HOME/admin
audit_path=$SID_HOME/audit
default_dir=`grep "^BACKUP_HOME" ${backup_file}|grep -v "#BACKUP_HOME"|awk -F: '{print $2}'`

###########
#Connections
###########
PASSWD=`$HOME/bin/tellme system`
RMAN=$ORACLE_HOME/bin/rman
TARGET_DB=$ORACLE_SID
TARGET_SCHEMA=`grep TARGET_SCHEMA ${backup_file}|grep -v "#TARGET_SCHEMA"|awk -F: '{print $2}'`
TARGET_PASSWD=`ORACLE_SID=$TARGET_DB;$HOME/bin/tellme $TARGET_SCHEMA`
TARGET=${TARGET_SCHEMA}/${TARGET_PASSWD}
CATALOG_DB=`grep CATALOG_DB ${backup_file}|grep -v "#CATALOG_DB"|awk -F: '{print $2}'`
CATALOG_TWOTASK=`grep CATALOG_TWOTASK ${backup_file}|grep -v "#CATALOG_TWOTASK"|awk -F: '{print $2}'`
CATALOG_SCHEMA=`grep CATALOG_SCHEMA ${backup_file}|grep -v "#CATALOG_SCHEMA"|awk -F: '{print $2}'`
CATALOG_PASSWD=`ORACLE_SID=$CATALOG_DB;$HOME/bin/tellme $CATALOG_SCHEMA` 
CATALOG=${CATALOG_SCHEMA}/${CATALOG_PASSWD}

##############
#RMAN specific 
##############
CHANNELS=`grep CHANNELS ${backup_file}|grep -v "#CHANNELS"|awk -F: '{print $2}'`
TAG_STAMP=`date +%m%d_%H''%M`

#####################
#Log and Audit files
#####################
RMAN_LOG_FILE=$audit_path/${ORACLE_SID}_tcopy_`date '+%m%d_%H''%M''%S'`.audit
arch_cmd_file=$SID_HOME/audit/${ORACLE_SID}_arch_$$.rman
cln_cmd_file=$SID_HOME/audit/${ORACLE_SID}_cln_$$.rman
cmd_file=$SID_HOME/audit/${ORACLE_SID}_tcopy_$$.rman
rman_lock_file=$SID_HOME/audit/backup_rman.lk
tcopy_lock_file=$SID_HOME/audit/tcopy_rman.lk

################################################################################
##  ------------------------------------------------------------------------  ##
##                      Cleanup Cleanup Everybody Cleanup                     ##
##  ------------------------------------------------------------------------  ##
################################################################################
run_cleanup () 
{
###########################################################
# run_cleanup()
# This function performs cleanup of files 
##########################################################
rm ${audit_path}/backup.${ORACLE_SID}.arc.status.$$ > /dev/null 2>&1
rm ${audit_path}/arch_dest.list.$$ >/dev/null 2>&1
rm ${audit_path}/arch_fmt.list.$$ >/dev/null 2>&1
rm $RMAN_LOG_FILE > /dev/null 2>&1
rm $cmd_file > /dev/null 2>&1
rm $arch_cmd_file > /dev/null 2>&1
rm $cln_cmd_file > /dev/null 2>&1
rm $obs_cmd_file > /dev/null 2>&1
rm $cmd_file > /dev/null 2>&1
}

############
#Debug
############
error_switch=0

################################################################################
##  ------------------------------------------------------------------------  ##
##                  Pre-processing and parameter validation                   ##
##  ------------------------------------------------------------------------  ##
################################################################################

if [ -z "$CATALOG_TWOTASK" ]; then
       echo "Error====>Missing TWO_TASK entry for the Catalog Database "
       echo "Script is terminating!                                    "
       notify
fi

if [ ! -f $backup_file ]; then
  echo "Error====>Backup control file does not exist"
  echo "          Script is terminating!"
  notify
fi

if [ -z "$CHANNELS" ]; then
       echo "Error====>Missing channels entry in the backup controlfile"
       echo "Script is terminating!				       "
       notify
elif   [ ${CHANNELS} -lt 1  -o  ${CHANNELS} -gt 14 ]; then
       echo "Error====>Number of channels should be between 1-14"
       echo "Script is terminating!                            "
       notify
fi

################################################################################
##  ------------------------------------------------------------------------  ##
##     Function to set/unset lock file to prevent simultaneous executions     ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# lock_unlock()
# This function manages lock file to prevent simultaneous executions of a script
# perl should be in $PATH for this function to operate -- non-version specific
# sample usage:
# lock_unlock action=lock name=/some/where/my_lock [other options]
# do your operations
# lock_unlock action=unlock name=/some/where/my_lock  # optional
################################################################################
lock_unlock ()
{
  typeset PATH=$(PATH=/bin:/usr/bin getconf PATH)
  typeset action psid inode name pid ppid time ttl abba id
  typeset expire=99999999 wait=99999999 T0

  eval "$@"

  function epoch { perl -e 'print time'; }
  abba=$(function t { trap 'printf "%s" a' EXIT; }; t; printf "%s" b)

  function lock_stat {
    typeset inode lsout name=$1
    [[ -L ${name} ]] || { printf "%s\n" "inode=" && return 0; }
    set -- $(ls -il ${name})
    printf "%s\n" "inode=${1} ${12} ${13} ${14} ${15}"
  }

  function ps_iden {
    set -- $(ps -o user= -o group= -o ppid= -o pgid= -p $1 2>/dev/null)
    echo $1.$2.$3.$4
    return 0
  }

  case ${action} in
    lock)
      (( T0 = SECONDS ))
      while (( SECONDS - T0 <= wait )); do
        ln -s "pid=$$ ppid=$PPID time=$(epoch) ttl=${expire} psid=$(ps_iden $$) id=$id" ${name} && {
          case $abba in
            ab) trap "trap \"rm -f ${name}\" EXIT" EXIT;;
             *) trap "rm -f ${name}" EXIT;;
          esac
          rm -f ${name}.+([0-9]).+([0-9])
          return 0
        }

        eval $(lock_stat ${name})

        [[ -n ${inode} ]] && {
          ps -p ${pid} 2>/dev/null          &&
          [[ $(ps_iden ${pid}) = "$psid" ]] &&
          (( $(epoch) < time + ttl ))       ||
          find ${name} -inum ${inode} -exec mv -f {} ${name}.$$.${RANDOM} \;
        }

        sleep 3
      done;;
    unlock)
      eval $(lock_stat ${name})

      [[ -n ${inode} ]]                             &&
      find ${name} -inum ${inode} -exec rm -f {} \; &&
      case $abba in
        ab) trap "trap - EXIT" EXIT;;
         *) trap - EXIT;;
      esac                                          &&
      return 0;;
  esac
  return 1
}

################################################################################
##  ------------------------------------------------------------------------  ##
##           Function to check and set the state of a database                ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# check_db_state()
# This function verifies that target and catalog databases are up and running 
# before starting the tape copy of the rman backup taken. 
################################################################################

check_db_state ()
{
sqlplus -s $TARGET@$TARGET_DB << EOF > /dev/null
exit 255;
EOF
   if [ $? != 255 ]; then
     echo "#####################################################"
     echo "## ERROR ====> Target database NOT available!      ##"
     echo "##       ====> Backup processing cannot continue   ##"
     echo "#####################################################"
     msg_body="Target database NOT available!"
   notify
   fi

sqlplus -s $CATALOG@$CATALOG_DB << EOF > /dev/null
exit 255;
EOF
   if [ $? != 255 ]; then
     echo "#####################################################"
     echo "## ERROR ====> Catalog database NOT available !    ##"
     echo "##       ====> Backup processing cannot continue   ##"
     echo "#####################################################"
     msg_body="Catalog database NOT available!"
   notify
   fi

################################################################################
##  ------------------------------------------------------------------------  ##
##             Determine if database is in archivelog mode                    ##
##             & Capture location of archivelog destination                   ##
##  ------------------------------------------------------------------------  ##
################################################################################
sqlplus -s system/${PASSWD} << END > ${audit_path}/backup.${ORACLE_SID}.arc.status.$$
set pagesize 0 feedback off verify off echo off termout off heading off
select log_mode from v\$database;
END
grep -q "NO" ${audit_path}/backup.${ORACLE_SID}.arc.status.$$
if [ $? -eq 0 ]; then
  archivelog_sw=0
else
  archivelog_sw=1
fi

sqlplus -s system/${PASSWD} <<END >/dev/null
set pagesize 0 feedback off verify off echo off termout off heading off
spool ${audit_path}/arch_dest.list.$$
/* Added for Standby Database */
select destination value
   from v\$archive_dest
   where destination is not null
   and status='VALID'
   and target='PRIMARY'
   and rownum=1
union
select value
  from v\$parameter where name = 'log_archive_dest';
spool off
spool ${audit_path}/arch_fmt.list.$$
select value
  from v\$parameter where name = 'log_archive_format';
spool off
END
arch_dir=`cat ${audit_path}/arch_dest.list.$$`
arch_dir=`echo ${arch_dir} | awk '{
  if (substr($1,length($1),1) == "/") {print substr($1,1,length($1)-1)} else {print $1}}'`

}

################################################################################
# arch_backup_cleanup ()
# This is a standalone function which will delete archivelog backupsets existing
# on disk which have already been copied to tape prior to taking another backup.
# 1. It will generate an RMAN commands script (.rman)
# 2. Invoke RMAN and execute the generated command script
################################################################################

arch_backup_cleanup ()
{
     sqlplus -s system/${PASSWD} as sysdba << END                                      >> $cln_cmd_file
     set pagesize 0 feedback off verify off echo off termout off heading off
     SELECT ' sql ''' || 'alter session set optimizer_mode=RULE'';'
       FROM DUAL
     UNION
     SELECT 'ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE DISK;'
       FROM DUAL
     UNION
     SELECT DISTINCT 'DELETE NOPROMPT BACKUPSET TAG ' || c.tag || ';'
           FROM v\$backup_set_details a, v\$backup_piece_details b, v\$backup_piece c
          WHERE a.bs_key = b.bs_key
	    AND b.set_count = c.set_count       
	    AND b.deleted = 'NO'
            AND b.device_type = 'DISK'
	    AND c.device_type = 'SBT_TAPE'
            AND a.backup_type = 'L';
END
if [ $(wc -l < $cln_cmd_file) -gt 2 ]; then
     echo
     echo "====>Deleting archivelog backupsets of "$TARGET_DB" copied to tape"
     echo
        if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $cln_cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
else
                        echo "#####################################################"
                        echo "== ERROR !!====> Catalog Database must be backed up  "
                        echo "== ERROR !!====> on tape via backup_rman.sh          "
                        echo "#####################################################"
  notify
	fi
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##            Function to perform copy backupset from disk to tape            ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# tape_copy ()
# This function will copy rman backup set(s) from disk to tape
# 1. It will generate an RMAN commands script (.rman) based on the parameters
# 2. Invoke RMAN and execute the generated command script
################################################################################

tape_copy ()
{
echo "====>Performing Tape Copy of "$TARGET_DB	 			>> $RMAN_LOG_FILE
echo "RUN"								>> $cmd_file
echo "{"								>> $cmd_file
echo "sql 'alter session set optimizer_mode=RULE';"                     >> $cmd_file
cnt=1
while [ ${cnt} -le ${CHANNELS} ]
do
  echo "ALLOCATE CHANNEL CH"$cnt" DEVICE TYPE "SBT" "			>> $cmd_file
echo ";"								>> $cmd_file
  cnt=`expr ${cnt} + 1`
done
echo "BACKUP "								>> $cmd_file
echo "FORMAT ""'"%d_TAPECOPY_%M""%D""%Y_%p_%s"'"                        >> $cmd_file
echo "BACKUPSET ALL;"                                            	>> $cmd_file
echo "BACKUP FORMAT '%d_%M_%D_%Y_%t.ctl' CURRENT CONTROLFILE" 		>> $cmd_file
echo "TAG" ${ORACLE_SID}_CONTROLFILE_${TAG_STAMP}                       >> $cmd_file
echo ";"                                                                >> $cmd_file
echo "}"								>> $cmd_file

if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $cmd_file | tee $RMAN_LOG_FILE
check_rman_errors 
else
			echo "#####################################################"
			echo "== ERROR !!====> Catalog Database must be backed up  "
			echo "== ERROR !!====> on tape via backup_rman.sh 	   "
			echo "#####################################################"
  notify
fi
}

################################################################################
# arch_backup ()
# This is a standalone function which will backup archivelogs of a database
# 1. It will generate an RMAN commands script (.rman) based on the parameters
# 2. Invoke RMAN and execute the generated command script
# 3. It will delete the archivelogs for which the backup has been completed
# 4. It will perform a manual RESYNC of the catalog to keep it up-to-date
################################################################################

arch_backup ()
{
echo
echo "====>Backing up current Archivelogs of "$TARGET_DB" to tape"
echo
echo "RUN"                                                              >> $arch_cmd_file
echo "{"                                                                >> $arch_cmd_file
echo "sql 'alter session set optimizer_mode=RULE';"                     >> $arch_cmd_file
echo "sql 'alter system archive log current';"                          >> $arch_cmd_file
cnt=1
while [ ${cnt} -le ${CHANNELS} ]
do
  echo "ALLOCATE CHANNEL CH"$cnt" DEVICE TYPE "SBT" "          		>> $arch_cmd_file
  echo "FORMAT ""'"%d_ARCH_%M""%D""%Y_%p_%s"'"                          >> $arch_cmd_file
echo ";"                                                                >> $arch_cmd_file
  cnt=`expr ${cnt} + 1`
done
echo "BACKUP"                                                           >> $arch_cmd_file
if [ "$ora_version" -gt 9 ]; then
echo "AS COMPRESSED BACKUPSET"                                          >> $arch_cmd_file
fi
echo "ARCHIVELOG"                                                       >> $arch_cmd_file
echo "ALL"                                                              >> $arch_cmd_file
echo "TAG" ${ORACLE_SID}_ARCH_${TAG_STAMP}                              >> $arch_cmd_file
echo "DELETE INPUT"                                                     >> $arch_cmd_file
echo ";"                                                                >> $arch_cmd_file
echo "RESYNC CATALOG;"                                                  >> $arch_cmd_file
echo "}"                                                                >> $arch_cmd_file

if [[ ${TARGET_DB} != ${CATALOG_DB} ]]; then
$RMAN target ${TARGET} catalog ${CATALOG}@${CATALOG_TWOTASK} cmdfile $arch_cmd_file | tee $RMAN_LOG_FILE
check_rman_errors
else
                        echo "#####################################################"
                        echo "== ERROR !!====> Catalog Database must be backed up  "
                        echo "== ERROR !!====> on tape via backup_rman.sh          "
                        echo "#####################################################"
  notify
fi

}

################################################################################
##  ------------------------------------------------------------------------  ##
##            Function to check and report errors generated by RMAN           ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# check_rman_errors()
# This is a standalone function which will trap RMAN specific errors when a RMAN
# block gets run. It will also cat the $RMAN_LOG_FILE to standard output
################################################################################

check_rman_errors ()
{
grep -e RMAN- -e ORA-  $RMAN_LOG_FILE
  if [ $? -eq 0 ]; then
   notify
  fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##  			FUNCTION TO RUN BACKUPS 		              ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# run_backup() 
# This function establishes the path to backup processing based on parameters
# 1. It will check for the type of backup requested based on the parameters and
# run the appropriate function to perform the actual backup to be performed.
# 2. It will also process deleting the obsolete backup if requested 
################################################################################

run_backup()
{
if [ "$backup_mode" = "arch" ]; then
	check_db_state
	  if [ "$archivelog_sw" = 1 ]; then
		  arch_backup_cleanup
		  tape_copy
	  else
		  echo "#####################################################"
                  echo "== ERROR !!====> Database is in NOARCHIVELOG mode    "
                  echo "== ERROR !!====> Backup Processing can not continue  "
                  echo "#####################################################"
                  notify
	  fi
elif [ "$backup_mode" = "" ]; then
	check_db_state
	tape_copy
fi
}

################################################################################
##  ------------------------------------------------------------------------  ##
##                        MAIN SCRIPT EXECUTION                               ##
##  ------------------------------------------------------------------------  ##
################################################################################

################################################################################
# These are the high level instructions that drive the processing of the script.
# 1. If there is a backup already in progress then the script will exit
# 2. If there was a failure encountered on earlier run, it will exit with
# instructions to clear the message and restart the script
# 3. Run cleanup done for pre/post-processing
# 4. Generate lock files before starting the backup processing
# 5. Remove the lock files after the backup processing has been completed
################################################################################

if [ -h $tcopy_lock_file ]; then
   last_pid=`ls -l $tcopy_lock_file | awk '{print substr($11,5)}'`
   last_ppid=`ls -l $tcopy_lock_file | awk '{print substr($12,6)}'`
   alive_pid=`ps -o pid -p "$last_pid" | tail -1`
   alive_ppid=`ps -o ppid -p "$last_pid" | tail -1`

   if [ "$alive_pid" = "  PID" ]; then
        alive_pid=0
   fi
   if [ "$alive_ppid" = " PPID" ]; then
        alive_ppid=0
   fi
     if [ "$last_pid" -eq "$alive_pid" ] && [ "$last_ppid" -eq "$alive_ppid" ]; then
        echo "====>tcopy_rman.sh is already running for $TARGET_DB on pid "$last_pid
        echo "====>Script is terminating!!                                 "
        addl_msg="cancelled due to a conflicting process"
        msg_body="tcopy_rman.sh is already running for $TARGET_DB on pid "$last_pid
        notify
     elif [ "$last_pid" -ne "$alive_pid" ] && [ "$last_ppid" -ne "$alive_ppid" ]; then
	echo "====>Previous run of tcopy_rman.sh did not complete successfully"
	echo
	echo "====>Cleaning up lock file from the previous run                 "
	echo
        lock_unlock action=unlock name=$tcopy_lock_file
	echo "====>Continuing execution of tcopy_rman.sh"
        lock_unlock action=lock name=$tcopy_lock_file expire=86400 id=oracle.rman
        run_cleanup
	run_backup
        run_cleanup
        lock_unlock action=unlock name=$tcopy_lock_file
     fi
else
        lock_unlock action=lock name=$tcopy_lock_file expire=86400 id=oracle.rman
        run_cleanup
	run_backup
	run_cleanup
        lock_unlock action=unlock name=$tcopy_lock_file
fi

echo "************************************************************************"
echo "====>Script tcopy_rman.sh Ending on" `date`
echo "************************************************************************"
