create or replace procedure df_resize as

blocksize number;
filesize number;
extsize number;
re_filesize number;
freespace number;
tot_freespace number;
act_filesize number;
hwatermark number;
v_sid varchar2(10);

cursor c_dbfile is
        select tablespace_name,
                file_name,
                file_id,
                bytes
from sys.dba_data_files
where status !='INVALID'
and tablespace_name not like '%SYSTEM%'
and tablespace_name not like '%RBS%'
and tablespace_name not like '%UNDO%'
and tablespace_name not like '%TEMP%'
and bytes/1024/1024 > 100
order by tablespace_name,file_id;

cursor c_space(v_file_id in number) is
        select block_id,blocks
        from sys.dba_free_space
        where file_id=v_file_id
        order by block_id desc;


begin
select value
        into blocksize
from v$parameter
where name = 'db_block_size';

select instance_name into v_sid 
from v$instance;

tot_freespace:=0;

for c_rec1 in c_dbfile
loop
        freespace:=0;
        filesize:= c_rec1.bytes;
	act_filesize:=round(c_rec1.bytes/(1024*1024));
        <<outer>>
        for c_rec2 in c_space(c_rec1.file_id)
        loop
                extsize := ((c_rec2.block_id - 1)*blocksize + c_rec2.blocks*blocksize);
                if extsize = filesize
                then
                        filesize := (c_rec2.block_id - 1)*blocksize;
                else
                        exit outer;
                end if;
        end loop outer;
        if (filesize < c_rec1.bytes)
        then
                re_filesize:=round((filesize+(c_rec1.bytes*(10/100)))/1024/1024);
                freespace:=round(((c_rec1.bytes)/1024/1024)-re_filesize);
		hwatermark:=round(filesize/1024/1024);
                if (freespace > 100) then
                        dbms_output.put_line('alter database datafile '''||c_rec1.file_name||''' resize '||re_filesize||'M;');
			dbms_output.put_line('-- Actual File Size:'||act_filesize||' High watermark:'||hwatermark||' Resize Df to:'||re_filesize||' Freespace:'||freespace);
	                tot_freespace:=tot_freespace+freespace;
                end if;
        end if;
end loop;
dbms_output.put_line('-- Total Space That can be released from '||v_sid||' instance is:'||tot_freespace);
end;
/


set feedback off
set termout off
set head off
set lines 120
spool $DBA_HOME/admin/resize/instance.sql
select 'spool $DBA_HOME/admin/resize/'||instance_name||'.sql' from v$instance;
spool off
set serveroutput on
set termout on
exec dbms_output.enable(2000000);
@$DBA_HOME/admin/resize/instance.sql
exec df_resize;
drop procedure df_resize;
spool off
