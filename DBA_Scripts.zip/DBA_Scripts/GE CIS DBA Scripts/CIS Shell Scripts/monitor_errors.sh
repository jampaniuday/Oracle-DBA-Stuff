#!/bin/ksh 

# 
# parse args
# 


while [ $# -gt 0 ]; do
  nxtarg=$1
  if [ "$nxtarg" = "-v" ]; then
    verbose=true
  else
    if [ -f "$HOME/bin/${nxtarg}" ] ; then
      sid=$nxtarg
      . $HOME/bin/$sid
    else
      echo "usage: monitor_errors.sh [-v] sid"
    fi
  fi
  shift
done

rm -f $SID_HOME/audit/monitor_errors.tmp*
tmpfile=$SID_HOME/audit/monitor_errors.tmp.$$
err_file=$SID_HOME/audit/monitor_errors.log.`date +%m%d%Y`
sqlplus -s '/as sysdba'<<EOF
set pagesize 0 feedback off verify off echo off termout off heading off
spool $SID_HOME/audit/background_dump.list
select ltrim(rtrim(value)) from v\$parameter
where name like 'background_dump_dest';
spool off
EOF

MOUNT=`cat $SID_HOME/audit/background_dump.list`
export MOUNT
MOUNT=`echo $MOUNT|cut -d= -f2`

date >> $tmpfile
# look for new errors in alert log
if [ ! -s $SID_HOME/audit/alert_${ORACLE_SID}.log.sz ]; then
  if [ -f $SID_HOME/audit/alert_${ORACLE_SID}.log.copy ]; then
    wc -l $SID_HOME/audit/alert_${ORACLE_SID}.log.copy | awk '{print $1}' > $SID_HOME/audit/alert_${ORACLE_SID}.log.sz 
    if [ $? -ne 0 ]; then
      echo 0 > $SID_HOME/audit/alert_${ORACLE_SID}.log.sz 
    fi
    rm -f $SID_HOME/audit/alert_${ORACLE_SID}.log.copy 
  else
      echo 1 > $SID_HOME/audit/alert_${ORACLE_SID}.log.sz 
  fi
fi
old_log_sz=1
if [ -s $SID_HOME/audit/alert_${ORACLE_SID}.log.sz ]; then
  old_log_sz=`cat $SID_HOME/audit/alert_${ORACLE_SID}.log.sz` 
fi
curr_log_sz=`wc -l $MOUNT/alert_${ORACLE_SID}.log | awk '{print $1}'`
if [ $old_log_sz -gt $curr_log_sz ]; then
  old_log_sz=1
fi
   
if [ -f $SID_HOME/audit/new_alerts.lst ]; then
  rm -f $SID_HOME/audit/new_alerts.lst 
fi

if [ $old_log_sz -ne $curr_log_sz ]; then
sed -n "$old_log_sz,$ p" \
  ${MOUNT}/alert_${ORACLE_SID}.log | 
  grep 'Can not allocate log, archival required' >> $SID_HOME/audit/new_alerts.lst
# Commented by Sumit due to 10G issues
#sed -n "$old_log_sz,$ p" \
#  ${MOUNT}/alert_${ORACLE_SID}.log | 
#  grep 'cannot allocate new log' >> $SID_HOME/audit/new_alerts.lst
# Connect ended
sed -n "$old_log_sz,$ p" \
  ${MOUNT}/alert_${ORACLE_SID}.log | 
  grep '^ORA-' >> $SID_HOME/audit/new_alerts.lst
fi
echo $curr_log_sz > $SID_HOME/audit/alert_${ORACLE_SID}.log.sz 2>> $tmpfile

if [ $? != 0 ]; then
  mailit=true
fi
if [ -s $SID_HOME/audit/new_alerts.lst ]; then
  echo 'New errors in Alert Log:' >>$tmpfile
  cat $SID_HOME/audit/new_alerts.lst >>$tmpfile
  echo "" >> $tmpfile
  mailit=true
fi

if [ "$mailit" = "true" ]; then
  #mailx -s "${ORACLE_SID} alert log monitor output" $maillist < $tmpfile
   $DBA_HOME/admin/notify.sh -s "${ORACLE_SID} alert log monitor output" -f $tmpfile -w sid
else
  if [ "$verbose" = "true" ]; then
#    echo "No errors detected" | mailx -s "${ORACLE_SID} monitor output: no errors" $maillist
    $DBA_HOME/admin/notify.sh -s "${ORACLE_SID} monitor output: no errors" -b " no errors"
  fi
fi
#rm -f $tmpfile
