allsid=`cat instance.lst|awk -F: {'print$1}'`
for sid in $allsid
do
echo $sid
. ${sid}
sqlplus '/as sysdba' <<EOF
set head off
set echo off
set term off
select name from v\$database;
select username||':'||account_status from dba_users where username in('OUTLN','CSMIG','CTXSYS','MDSYS','ORDLPLUNGINS','ORDSYS');
exit
EOF
done

