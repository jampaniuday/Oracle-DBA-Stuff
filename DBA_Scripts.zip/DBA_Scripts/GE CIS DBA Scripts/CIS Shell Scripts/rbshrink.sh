#!/bin/ksh

##
## Purpose    : Dynamically generate SQL script to shrink rollback
##              segments for specified instance.
## Usage      : rbshrink.sh <ORACLE_SID>
## Inputs     : Oracle SID
## Created by : Satyen Jadia
##

notify_who="Mugunthan.Bala"

if [ $# -lt 1 ]
then
  echo "Required parameter is missing."
  echo "Usage : rbshrink.sh <ORACLE_SID>"
  echo "Script is terminating."

  notify_host=`hostname`
  notify_sid=$ORACLE_SID
  notify_type="RBSHRINK"

  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/rbshrink.audit

  exit 1
fi

## Check environment script exists.

if [ ! -f $HOME/bin/${1} ]
then
  echo "Environment script does not exist for \"${1}\"."
  echo "Script is terminating."
  exit 1
fi

## Set environment

. $HOME/bin/${1}

echo "###############################################################"
echo "##     Script rbshrink.sh starting on " `date` for $ORACLE_SID
echo "###############################################################"

## Check whether instance is available.

ora_inst=`ps -ef | grep ora_smon_$1 | grep -v grep`

if [ -z "$ora_inst" ]
then
  echo "Oracle instance, $1 is not available."
  echo "Script is terminating."

  notify_host=`hostname`
  notify_sid=$ORACLE_SID
  notify_type="RBSHRINK"

  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/rbshrink.audit

  exit 1
fi

## Set password for SYSTEM.

PASSWD=`$HOME/bin/tellme system`

if [ -z "$PASSWD" ]
then
  echo "Error : No password selected for SYSTEM." 
  echo "Script is termianting."

  notify_host=`hostname`
  notify_sid=$ORACLE_SID
  notify_type="RBSHRINK"

  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/rbshrink.audit

  exit 1
fi

## Select rollback segments.

sqlplus -s system/$PASSWD << EOF > $SID_HOME/audit/rb.lst
set heading off feedback off echo off pages 0
select segment_name from dba_rollback_segs
where  status = 'ONLINE'
and    tablespace_name != 'SYSTEM';
exit
EOF

err=`grep "ORA-" $SID_HOME/audit/rb.lst`
if [ ! -z "$err" ]
then
  echo "Error selecting rollback segments from the database."
  echo "Script is terminating."

  notify_host=`hostname`
  notify_sid=$ORACLE_SID
  notify_type="RBSHRINK"

  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/rbshrink.audit

  exit 1
fi

## Create SQL script to alter rollback segments.

echo "REM   SQL script to shrink rollback segments to optimal size." > $SID_HOME/admin/rbshrink.sql
echo "" >> $SID_HOME/admin/rbshrink.sql

while read rbname
do
  echo "ALTER ROLLBACK SEGMENT $rbname SHRINK TO 20M;" >> $SID_HOME/admin/rbshrink.sql
  echo "" >> $SID_HOME/admin/rbshrink.sql
done < $SID_HOME/audit/rb.lst

echo "Script RBSHRINK.SQL created." 

rm $SID_HOME/audit/rb.lst

## Alter rollback segments to shrink.

sqlplus -s system/$PASSWD << EOF > $SID_HOME/audit/rbshrink.error
set heading off feedback off echo off pages 0
@$SID_HOME/admin/rbshrink.sql
exit
EOF

## Check for errors.

err=`grep "ORA-" $SID_HOME/audit/rbshrink.error`

if [ ! -z "$err" ]
then
  echo "Error : Cannot alter rollback segments to shrink for $ORACLE_SID."
  echo "Script is terminating."
  exit 1
  notify_host=`hostname`
  notify_sid=$ORACLE_SID
  notify_type="RBSHRINK"

  mailx -s $notify_host $notify_sid $notify_type ABEND $notify_who@corporate.ge.com < $SID_HOME/audit/rbshrink.audit

fi

echo "Rollback segments altered successfully for $ORACLE_SID."
