#!/bin/ksh
# get the location of oratab           
#. /export/home/oracle/bin/apc1
if [ "`uname -a | cut -c1-3`" = "Sun" ]
then
    oratab=/var/opt/oracle/oratab      
 else
    oratab=/etc/oratab
fi
#
HNAME="`hostname`"
binst="p1apcrs"
#PASSWD=`$HOME/bin/tellme patdb01`
PASSWD="v9ision"
grep "oracle" $oratab|grep -v N|grep -v \#|grep -v \*|awk -F: '{print $1}' > /tmp/sid_list.out
touch /tmp/sid_list.out
echo "A1-A2-A3-A4-A5-A6" >/tmp/frmt.temp
#--#      
substr()
{ 
       typeset _str="$1" 
       typeset -i _strlen=${#_str}
          
       typeset -i _offset="${2:-0}"
       typeset -i _sublen="${3}"
       
       typeset -i _rlen
       ((_rlen=_strlen-_offset))  

       typeset -R${_rlen} _substr=${_str}     
       typeset -L${_sublen} _substr=${_substr}

       echo $_substr
}
#--#
whatbackup() 
{
. $HOME/bin/$1
btype=`grep "backup:" $SID_HOME/admin/utility.ctl |cut -c13-20`
 if [ `date +%a` = 'Sun' ]; then
        pos=1
 fi
 if [ `date +%a` = 'Mon' ]; then
        pos=2
 fi
 if [ `date +%a` = 'Tue' ]; then
        pos=3
 fi
 if [ `date +%a` = 'Wed' ]; then 
        pos=4
 fi
 if [ `date +%a` = 'Thu' ]; then
        pos=5
 fi
 if [ `date +%a` = 'Fri' ]; then
        pos=6
 fi
 if [ `date +%a` = 'Sat' ]; then
        pos=7
 fi
bbty=`substr $btype $pos 1`;export bbty
echo $bbty 
}
#
while read bsid ; do 

	ohome=`cat /etc/passwd | awk -F: '{if ($1 == "oracle") {print $6}}'`
unset ORACLE_HOME 
. $ohome/bin/$bsid

	wbtype=`whatbackup $bsid`
	if test "$wbtype" = "c";
	   then 
	   _btype="COLD"
	elif test "$wbtype" = "h";
	   then
	   _btype="HOT "
	else
	   _btype="NO BACKUP"
	fi
	echo $HNAME >/tmp/bkup.out
	echo $bsid >>/tmp/bkup.out
	echo $_btype >>/tmp/bkup.out
	egrep -e "TERMINATED" $SID_HOME/audit/utility.audit >> /tmp/bkup.out

	nt=0
	while read pop pname pvalue; do
        	nt=`expr $nt + 1`
		echo "s/A$nt/$pop $pname $pvalue/" >>/tmp/rao.sed
	done </tmp/bkup.out
	sed -f /tmp/rao.sed /tmp/frmt.temp >/tmp/$bsid.out
	fld1=`cat /tmp/$bsid.out |awk -F"-" '{print $1}'`;export fld1
	fld2=`cat /tmp/$bsid.out |awk -F"-" '{print $2}'`;export fld2
	fld3=`cat /tmp/$bsid.out |awk -F"-" '{print $3}'`;export fld3
	fld4=`cat /tmp/$bsid.out |awk -F"-" '{print $4}'`;export fld4
	fld5=`cat /tmp/$bsid.out |awk -F"-" '{print $5}'`;export fld5
	fld6=`cat /tmp/$bsid.out |awk -F"-" '{print $6}'`;export fld6
#
#
#esid=`sqlplus -s patdb01/${PASSWD}@$binst <<EOF
sqlplus -s patdb01/${PASSWD}@$binst <<EOF
    set heading off echo off feedback off pagesize 0 long 9
    select sid from BACKUP_DET where trim(host)=trim('$HNAME') and trim(sid)=trim('$bsid');
EOF

echo ......... $esid
#
## Check for errors                    
#err=`grep "ORA-" /tmp/update.audit`          
#if [ ! -z "$err" ]                     
#then                                   
#        echo "Error : Cannot query for SID."         
#        echo "Script is terminating."  
#fi
#
## SID Existence?
#
#sid_tf=`cat /tmp/sid_e.lst` 
#

if [ "$esid" = "" ]                  
then
sqlplus -s patdb01/${PASSWD}@${binst} << END >/tmp/bk_updt.$bsid
insert into BACKUP_DET (HOST, SID, BTYPE, BACKUP, TAPECOPY, TP1)
       values 
	('$fld1', '$fld2', '$fld3', '$fld4', '$fld5', '$fld6');
commit;
exit 1
END
else
sqlplus -s patdb01/${PASSWD}@${binst} << END >/tmp/bke_updt.$bsid
update BACKUP_det set BTYPE='$fld2', BACKUP='$fld3', 
       tapecopy='$fld4', tp1='$fld5', tp2='$fld6'  
       where SID='$bsid' and HOST='$HNAME';
commit;
exit 1
END
fi            
rm /tmp/*sed
#rm /tmp/*out
#rm /tmp/bk_updt*
done </tmp/sid_list.out
