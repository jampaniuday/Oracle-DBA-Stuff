#!/bin/bash
# 1: DB_SID; required
# 2: DB_BLK_TYPE; required: (start or stop)
# 3: DB_MAINTENANCE_TYPE; required
# 4: DB_BLK_DURATION; required

#set -x  # turn on debug
#set +x  # turn off debug

echo "start blackout!"
. $DBA_HOME/admin/blackout.sh lpind 1 2 10 
echo "end blackout!"
. $DBA_HOME/admin/blackout.sh lpind 0 2 10

