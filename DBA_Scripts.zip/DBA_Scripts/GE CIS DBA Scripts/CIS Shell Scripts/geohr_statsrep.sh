#!/bin/ksh
########################################################################        
##
##  statsrep.sh
##
##
##  This script runs the Oracle supplied statsrep.sql script delivered 
##  with STATSPACK. statsrep.sql has been modified and renamed 
##  geohr_statsrep.sql. Once the script has been run the output is 
##  E-mailed to the appropriate parties
##  
##  Associated Files
##    $DBA_HOME/admin/geohr_statsrep.sh - Unix script launched from crontab
##    $DBA_HOME/admin/geohr_statsrep.sql - SQL script that launches rpt
##    $DBA_HOME/admin/geohr_statsrep.ctl - Control file
##    /tmp/statsrpt.lst - output file which is E-mailed
##
##  Usage geohr_statsrep.sh <SID> 
##
##  Modifications
##    04/09/01 - CSI - Created 
##
##

MAILLIST="GTSOHR.LeadDBAs@corporate.ge.com cis.ohrperformance@ge.com"

if [ ! "$1" ]
then
    echo "#####################################################"
    echo "ERROR: No SID given."
    echo "#####################################################"
    exit 1
fi

if [ ! "`ps -ef|grep pmon_$1|grep -v grep`" ]
then
    echo "#####################################################"
    echo "Instance $SID is not up."
    echo "#####################################################"
    exit 1
fi

# Set the instance environment
if [ ! -f $HOME/bin/$1 ]
then
    echo "#####################################################"
    echo "ERROR: No environment script found for $1 "
    echo "#####################################################"
    exit 1
fi
. $HOME/bin/$1
USERNAME="perfstat"
PASSWD=`$HOME/bin/tellme $USERNAME`

RUNRPT=`sqlplus -s $USERNAME/$PASSWD <<EOF
            set heading off
            select rpt_end_id from geohr_statsrep where to_char(sysdate,'DD-MON-YYYY:HH24') = rpt_next_run_dt;
EOF`

if [ "`echo $RUNRPT | grep no`" ]
then
	echo Not Time yet
#	exit 1 
else
sqlplus -s $USERNAME/$PASSWD @$DBA_HOME/admin/geohr_statsrep.sql <<EOF
EOF

BEGID=`sqlplus -s $USERNAME/$PASSWD <<EOF
            set heading off
            select rpt_beg_id from geohr_statsrep;
EOF`

ENDID=`sqlplus -s $USERNAME/$PASSWD <<EOF
            set heading off
            select rpt_end_id from geohr_statsrep;
EOF`

sqlplus -s $USERNAME/$PASSWD @$DBA_HOME/admin/geohr_spreport.sql <<EOF
EOF

RPTDATE=`date '+ %m/%d/%y'`

mailx -s "Stats Report $1 - $RPTDATE" $MAILLIST < /tmp/geohr_spreport.lst
rm /tmp/geohr_spreport.lst
fi
