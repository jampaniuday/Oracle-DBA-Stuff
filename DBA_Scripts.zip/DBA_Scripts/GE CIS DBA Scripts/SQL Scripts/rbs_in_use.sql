-- this is to know active transactions and their rollback segments and table being operated on
select
       rn.usn "Rollback segment number",
       rn.name "Rollback segment name",
       sess.schemaname "User",
       o.name "Table Name"
from
       v$rollname rn,
       v$session sess,
       sys.obj$ o,
       v$lock lck1,
       v$transaction t
where
       sess.taddr = t.addr
and    lck1.sid = sess.sid
and    lck1.id1 = o.obj#
and    lck1.type = 'TM'
and    t.xidusn = rn.usn;

