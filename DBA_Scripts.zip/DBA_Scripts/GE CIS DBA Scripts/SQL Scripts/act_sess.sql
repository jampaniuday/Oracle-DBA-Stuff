set linesize 120
set pagesize 60
column pu format a5
column su format a9
column os format a9
column stat format a9
column ssid format a9
column sno format a9
column mc format a15
column sqltxt format a100
spool $ORACLE_SID.out
select '##'||substr(p.username,1,6) pu, substr(s.username,1,8) su, s.osuser os,
       substr(s.status,1,8) stat, substr(s.sid,1,6) ssid,
       substr(s.serial#,1,8) sno, substr(s.MACHINE,1,25) mc,
       lpad(p.spid,7) spid, substr(sa.sql_text,1,2000) txt
from v$process p,
     v$session s,
     v$sqlarea sa
where    p.addr=s.paddr
and      s.username='EPSUSER'
and      s.sql_address=sa.address(+)
and      s.sql_hash_value=sa.hash_value(+)
order by 1,2,7 ;
