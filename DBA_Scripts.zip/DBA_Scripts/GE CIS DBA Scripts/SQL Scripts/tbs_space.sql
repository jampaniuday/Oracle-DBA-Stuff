
rem -----------------------------------------------------------------------
rem Purpose:    this script shows the tablespace level space used and pct free available.
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on
set head on

SELECT Total.name "Tablespace_Name",
       Free_space, (total_space-Free_space) Used_space, total_space,((free_space/total_space)*100) percent_free
FROM
  (select tablespace_name, sum(bytes/1024/1024) Free_Space
     from sys.dba_free_space
    group by tablespace_name
  ) Free,
  (select b.name,  sum(bytes/1024/1024) TOTAL_SPACE
     from sys.v_$datafile a, sys.v_$tablespace B
    where a.ts# = b.ts#
    group by b.name
  ) Total
WHERE Free.Tablespace_name = Total.name order by 5 desc
/

