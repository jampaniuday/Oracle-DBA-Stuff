
rem -----------------------------------------------------------------------
rem Purpose:    To know the details of locked objects.
rem -----------------------------------------------------------------------

SET ECHO          ON
SET HEADING       ON
SET FEEDBACK      ON
SET VERIFY        OFF
SET TERMOUT       ON
SET PAGESIZE      50000
SET LINESIZE      300
SET WRAP          OFF
SET TRIMOUT       ON
SET TRIMSPOOL     ON
SET SERVEROUTPUT  OFF

COL  OB_ID    FOR  9999999
COL  TYPE     FOR  A5
COL  NAME     FOR  A25
COL  SESID    FOR  99999
COL  USER     FOR  A8
COL  OSUSER   FOR  A8
COL  PROCESS  FOR  99999
COL  MODE     FOR  99


SELECT LO.object_id "OB_ID", AO.object_type "TYPE", AO.object_name "NAME",
       LO.session_id "SESID", LO.oracle_username "USER",
       LO.os_user_name "OSUSER", LO.process "PROCESS", LO.locked_mode "MODE"
FROM   v$locked_object LO, all_objects AO
WHERE  LO.object_id = AO. object_id
ORDER BY 3
/




