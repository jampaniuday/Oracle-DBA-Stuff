
rem -----------------------------------------------------------------------
rem Purpose:     Shows the corrupted datafile details
rem 		Display the file ID numbers of datafiles
rem 		that require media recovery as well as the reason for 
rem 		recovery (if available) and the SCN and time when
rem 		recovery needs to begin.
rem -----------------------------------------------------------------------
set pagesize 100


select c.name tablespace, a.file# , b.name datafile, b.status, a.error,
a.change#, a.time from v$recover_file a, v$datafile b, v$tablespace c
where c.ts# = b.ts# and b.file# = a.file#
order by 1,2,3;

