spool $HOME/sadiq/audit/perfexit.lst
set head off
select username from dba_users where username='PERFSTAT';
spool off
spool $HOME/sadiq/audit/timed_stat.lst
set head off
select value from v$parameter where name ='timed_statistics';
spool off
