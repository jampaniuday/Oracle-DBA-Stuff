set pagesize 100
column table_name format a20
column high_value format a21
spool apcpartchk.txt
select table_name,high_value from all_tab_partitions 
where partition_position=(select max(partition_position) from all_tab_partitions where table_owner='AAPROFILE'); 
spool off;
