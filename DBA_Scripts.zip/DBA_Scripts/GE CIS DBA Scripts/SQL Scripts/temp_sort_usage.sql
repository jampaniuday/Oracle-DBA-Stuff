
rem -----------------------------------------------------------------------
rem Purpose:    This script shows the session which are currently using temp space.
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on

set linesize 400
column osuser format a20
column sid format 9999
column serial# format 99999
column username format a20
column program format a20
column vp.value format 99999999
        select s.osuser, s.sid, s.serial#,s.username, s.program,
               sum(u.blocks)*vp.value/1024 sort_size_KB
        from   sys.v_$session s, sys.v_$sort_usage u, sys.v_$parameter vp
        where  s.saddr = u.session_addr
          and  vp.name = 'db_block_size'
            group  by s.osuser, s.sid, s.serial#,s.username, s.program, vp.value;

