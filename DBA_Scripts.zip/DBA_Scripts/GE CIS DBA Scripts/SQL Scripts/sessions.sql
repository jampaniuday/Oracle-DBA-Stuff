select count(*) from v$session
/
select machine,count(sid)
from v$session
group by machine
/
