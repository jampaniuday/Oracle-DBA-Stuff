set verify off;
set termout off;
set pages 50;
set linesize 120

col T_space  format a15    
col fname    format a45  
col Use_Pct  format 999.0 heading Used%
col Total    format 999999
col Used_Mg  format 999999
col Free_Mg  format 999999
col dat noprint new_val dt
col dt for a20

tti cen 'GE SHARED SERVICES - EUROPE' skip 2 cen 'Disk Space Status Report as on ' dt skip 2
define Blk_size=8192			/* Set Oracle Block Size *

break on T_Space on report
compute sum of Total   on report
compute sum of Used_Mg on report
compute sum of Free_Mg on report

spool /tmp/$ORACLE_SID.log

select to_char(sysdate,'DD-MON-YYYY HH24:MI:SS') dat,decode(x.online$,1,x.name,
              substr(rpad(x.name,14),1,14)||' OFF')  T_Space,
       replace(replace(A.file_name,'/databases/',''),'.dbf','') Fname,
       round((f.blocks*&Blk_Size)/(1024*1024)) Total, 
       round(sum(s.length*&Blk_Size)/(1024*1024),1) Used_Mg,
       round(((f.blocks*&Blk_Size)/(1024*1024)) 
         - nvl(sum(s.length*&Blk_Size)/(1024*1024),0), 1) Free_Mg,
       round( sum(s.length*&Blk_Size)/(1024*1024)
         / ((f.blocks*&Blk_Size)/(1024*1024)) * 100, 1) Use_Pct
from   sys.dba_data_files A, sys.uet$ s, sys.file$ f, sys.ts$ X
where  x.ts#     = f.ts# 
and    x.online$ in (1,2)					/* Online !! */
and    f.status$ = 2					/* Online !! */
and    f.ts#     = s.ts# (+)
and    f.file#   = s.file# (+)
and    f.file#   = a.file_id
group  by x.name, x.online$, f.blocks, A.file_name
/

tti off
select decode(x.online$,1,x.name,
              substr(rpad(x.name,14),1,14)||' OFF') T_Space,
       'Total 'Fname,
       round(sum(distinct (f.blocks+(f.file#/1000))*&Blk_Size)
               / (1024*1024) ) Total,
       round(sum(s.length*&Blk_Size)/(1024*1024),1) Used_Mg,
       round(sum(distinct (f.blocks+(f.file#/1000))*&Blk_Size)
               / (1024*1024)
           - nvl(sum(s.length*&Blk_Size)/(1024*1024),0), 1) Free_Mg,
       round(((sum(s.length*&Blk_Size)/(1024*1024) )
          / (sum(distinct (f.blocks+(f.file#/1000))*&Blk_Size)
               / (1024*1024) )) * 100, 1) Use_Pct
from   sys.uet$ s, sys.file$ f, sys.ts$ x
where  x.ts#     = f.ts#
and    x.online$ in (1,2)					/* Online !! */
and    f.status$ = 2					/* Online !! */
and    f.ts#     = s.ts# (+)
and    f.file#   = s.file# (+)
group  by x.name, x.online$
order  by 1
/
spool off;
clear breaks
tti off
set verify on
set termout on
rem !df -k >> /tmp/$ORACLE_SID.log
rem !du -k /p068/dump01/oracle/apc1 >> /tmp/$ORACLE_SID.log
rem !du -k /p068/arch01/oracle/apc1 >> /tmp/$ORACLE_SID.log
rem exit

