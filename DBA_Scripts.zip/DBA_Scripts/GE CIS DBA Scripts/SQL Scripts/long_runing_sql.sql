
rem -----------------------------------------------------------------------
rem Purpose:    To know the details of long running sql which are more than 60 min.
rem -----------------------------------------------------------------------
set pagesize 100
set echo on
set linesize 400

column sid format 9999
column serial# format 999999
column username format a12
column osuser format a12
column machine format a12
column terminal format a12
column program format a12
column sql_text format a40

select b.sid,b.serial#,b.username,b.osuser,b.machine,b.terminal,b.program,
c.sql_text from 
(select sid,serial#,username,osuser,machine,terminal,program,sql_hash_value
from v$session  where upper(osuser) != 'ORACLE'
and status = 'ACTIVE'
and last_call_et/60 > 60 ) b,
v$sqltext c
where b.sql_hash_value = c.hash_value
order by b.sid,c.piece;

