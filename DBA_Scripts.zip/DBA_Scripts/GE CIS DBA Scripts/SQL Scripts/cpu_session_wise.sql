rem -----------------------------------------------------------------------
rem Purpose:     Shows cpu used by session level
rem -----------------------------------------------------------------------

set linesize 600
column username format a16
column Statistic format a26
column not_change_since_MIN format 99.99 
column logged_since_HR format 9999.99

set pages 1000
column username format a20
column sid format 9999
column cpu_usage format 99999999
column logon_time format a20
column sql_changed_since_min format 999999.99
select 	nvl(ss.USERNAME,'ORACLE PROCESS') username,
	se.SID,
	VALUE cpu_usage,
                logon_time,
	last_call_et/60 sql_changed_since_min
                from 	v$session ss, 
	v$sesstat se, 
	v$statname sn
where  	se.STATISTIC# = sn.STATISTIC#
and  	NAME like '%CPU used by this session%'
and  	se.SID = ss.SID
order  	by VALUE desc;

