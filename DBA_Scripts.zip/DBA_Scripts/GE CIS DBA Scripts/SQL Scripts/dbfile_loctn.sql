rem -----------------------------------------------------------------------
rem Purpose:     Shows the location of datafiles for given tablesapce
rem -----------------------------------------------------------------------
set pagesize 100

column file_name format a40
column tablespace_name format a6
column file_id format 9999
select file_id, tablespace_name TBS, file_name, (bytes)/1024/1024 MB, blocks from dba_data_files
where tablespace_name='&TBS_name'
/

