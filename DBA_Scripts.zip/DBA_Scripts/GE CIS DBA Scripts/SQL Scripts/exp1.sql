EXPLAIN plan set statement_id = 'sad' FOR
