set verify off feedback off; 
accept lsid prompt 'Enter the sid :' 
select sql_text last_sql from v$sqlarea where address in (select PREV_SQL_ADDR from v$session where sid=&lsid)
;
select sql_text current_sql from v$sqlarea where address in (select SQL_ADDRESS from v$session where sid=&lsid)
;
