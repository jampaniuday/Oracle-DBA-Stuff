---Detailed object count
set lines 132
set pages 100
COLUMN name          HEADING 'Owner'       FORMAT A12    TRUNCATE;
COLUMN tables        HEADING 'Table'       FORMAT 999,999;
COLUMN indexes       HEADING 'Index'       FORMAT 999,999;
COLUMN views         HEADING 'View'        FORMAT 999,999;
COLUMN sequen        HEADING 'Sequence'    FORMAT 999,999;
COLUMN proced        HEADING 'Procedure'   FORMAT 999,999;
COLUMN funct         HEADING 'Function'    FORMAT 999,999;
COLUMN packge        HEADING 'Package'     FORMAT 999,999;
COLUMN triger        HEADING 'Trigger'     FORMAT 999,999;
SELECT u.name,
        SUM(DECODE(o.type#, 2, 1, 0 )) tables,
         SUM(DECODE(o.type#, 1, 1, 0 )) indexes,
         SUM(DECODE(o.type#, 4, 1, 0 )) views,
         SUM(DECODE(o.type#, 6, 1, 0 )) sequen,
         SUM(DECODE(o.type#, 7, 1, 0 )) proced,
         SUM(DECODE(o.type#, 8, 1, 0 )) funct,
         SUM(DECODE(o.type#, 9, 1, 0 )) packge,
         SUM(DECODE(o.type#, 12, 1, 0 )) triger
    FROM sys.obj$ o,
         sys.user$ u
   WHERE owner# = u.user#
   GROUP BY u.name  ;
