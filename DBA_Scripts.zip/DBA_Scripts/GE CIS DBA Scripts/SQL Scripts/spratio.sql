select sum(pins) "Executions", sum(reloads) "Cache Misses", 
sum(reloads)/sum(pins) "Ratio"  from v$librarycache;

