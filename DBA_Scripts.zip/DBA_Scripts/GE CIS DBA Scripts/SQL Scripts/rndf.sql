alter database rename file '/p019/u07/oracle/patr/data/patr_part_data_1_2.dbf' to '/p019/u06/oracle/patr/data/patr_part_data_1_2.dbf'
