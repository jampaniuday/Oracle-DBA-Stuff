
rem -----------------------------------------------------------------------
rem Purpose:    To check tablesapce degragmentation.
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on


set linesize 600
ttitle 'FREESPACE_    FREESPACE_   PERCENTAGE_'
column tablespace format a16
column file_name format a50
column size_MB format 999,999.99
column beyond_last_fill format 999,999.99
column in_between format 999,999.99
column frag_to_fill format 99.9
select c.tablespace_name tablespace,
e.file_name,
e.bytes/1024/1024 size_MB,
c.bytes/1024/1024 beyond_last_fill,
nvl((f.total - c.bytes)/1024/1024,0) in_between,
(nvl((f.total - c.bytes),0)/(e.bytes-c.bytes))*100 frag_to_fill
from 
(select a.tablespace_name,a.file_id,a.bytes,a.block_id
from dba_free_space a, (select file_id,max(block_id) block_id
from dba_free_space group by file_id) b
where a.file_id = b.file_id
and a.block_id = b.block_id) c,
(select value from v$parameter where lower(name)='db_block_size') d,
(select file_name,file_id,bytes from dba_data_files) e,
(select file_id,sum(bytes) total from dba_free_space
group by file_id) f
where ((c.block_id-1)*d.value+c.bytes = e.bytes)
and c.file_id = e.file_id
and e.file_id = f.file_id
order by c.tablespace_name;

