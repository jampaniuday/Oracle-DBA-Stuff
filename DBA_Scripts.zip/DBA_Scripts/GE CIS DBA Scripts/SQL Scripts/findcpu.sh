#!/usr/bin/ksh
#name : findcpu.sh <owner_name/process_name>
for para1 in $*
do
ps -afe -o user -o pcpu -o comm -o args|grep "$para1\ " >>aa.lst
if [ "$para1" = "all" ]
then
tcpu=`ps -afe -o user -o pcpu -o comm -o args|sort -k2n|awk '{print $2}'|grep -v 0.0|sed 's/$/+/g'|xargs echo|sed 's/+$//'|xargs echo 0|bc`

else
tcpu=`ps -afe -o user -o pcpu -o comm -o args|grep "$para1\ "|grep -v grep|sort -k2n|awk '{print $2}'|grep -v 0.0|sed 's/$/+/g'|xargs echo|sed 's/+$//'|xargs echo 0|bc`
fi

echo "Total % of  Cpu consumed by $para1 = $tcpu"
done
