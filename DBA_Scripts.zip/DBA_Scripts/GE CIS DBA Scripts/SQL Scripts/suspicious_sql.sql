--This script identifies the most cache intensive
--SQL statements. Tuning these statements can 
--often make significant improvements in overall system
-- performance, particularly on CPU bound systems
-- suffering cache buffers chains latch contention and/or buffer busy waits. 

column load format a6 justify right
column executes format 9999999
break on load on executes
column load format a6 justify right
column executes format 9999999
break on buffer_gets_load executes
set pagesize 1000
 set lines 200
select
  substr(to_char(s.pct, '99.00'), 2) || '%'  buffer_gets_load,
  s.executions  executes,
  p.sql_text
from
  ( 
    select
      address,
      buffer_gets,
      executions,
      pct,
      rank() over (order by buffer_gets desc)  ranking
    from
      ( 
	select
	  address,
	  buffer_gets,
	  executions,
	  100 * ratio_to_report(buffer_gets) over ()  pct
	from
	  sys.v_$sql
	where
	  command_type != 47
      )
    where
      buffer_gets > 50 * executions
  )  s,
  sys.v_$sqltext  p
where
  s.ranking <= 5 and
  p.address = s.address
order by
  1, s.address, p.piece
/


