spool kill_sess.sh
 select 'kill -9' ||' '||p.spid spid from
 v$process p,
 v$session s,
 v$sqlarea sa
 where    p.addr=s.paddr
 and      s.username is not null
 and      s.sql_address=sa.address(+)
 and      s.sql_hash_value=sa.hash_value(+)
order by spid;
spool off;

