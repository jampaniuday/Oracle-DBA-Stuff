rem -----------------------------------------------------------------------
rem Purpose:    To know the current status in the database while import is in progress.
rem -----------------------------------------------------------------------
set serveroutput on
set pages 1000
set lines 4100
column logon_time format a20
column ssid format 9999
column osuser format a10
column username format a20
column machine format a30
column txt format a2000
set pages 100
select s.sid ssid,
        s.osuser,
        s.username,
        trim(substr(s.machine,1,30)) machine ,
to_char (s.logon_time,'DD-MON-YY HH24:MI') logon_time,
       trim(substr(sa.sql_text,1,2000)) txt
from v$process p,
     v$session s,
     v$sqlarea sa
where    p.addr=s.paddr
and      s.username is not null
and      s.sql_address=sa.address(+)
and      s.sql_hash_value=sa.hash_value(+);

rem -----------------------------------------------------------------------
rem Purpose:    Finds the rate of speed at which import happens to a particular table.
rem -----------------------------------------------------------------------

select substr(sql_text,instr(sql_text,'INTO "'),30) table_name,
         rows_processed,
         round((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60,1) minutes,
         trunc(rows_processed/((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60)) rows_per_min
  from   sys.v_$sqlarea
  where  sql_text like upper ('INSERT %INTO "%')
    and  command_type = 2
    and  open_versions > 0;

rem -----------------------------------------------------------------------
rem Purpose:   Find whether the import session is waiting for any events.
rem -----------------------------------------------------------------------


select EVENT, WAIT_TIME,SECONDS_IN_WAIT from V$SESSION_WAIT where sid=&sid;

