col OS_USER_NAME head OS_USER for a7 trunc
col ORACLE_USERNAME head ORCL_USER for a10 trunc
select ORACLE_USERNAME,OS_USER_NAME,OBJECT_NAME,locked_mode,session_id
from all_objects a ,sys.V_$LOCKED_OBJECT b
where a.OBJECT_ID=b.object_id
/
