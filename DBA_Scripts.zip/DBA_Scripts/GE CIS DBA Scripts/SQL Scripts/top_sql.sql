select rownum as rank, a.* from (
   select sql_text,elapsed_Time
   from  v$sqlarea where elapsed_time > 1000 order by elapsed_time desc) a
where rownum < 11 
/
