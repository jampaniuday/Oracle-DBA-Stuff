set linesize 120
set pagesize 60
spool $ORACLE_SID.out
select '##'||substr(p.username,1,6) pu, substr(s.username,1,8) su, s.osuser os,
       substr(s.status,1,5) stat, substr(s.sid,1,5) ssid, 
       substr(s.serial#,1,8) sser, substr(s.MACHINE,1,25) mach,
       lpad(p.spid,7) spid, substr(sa.sql_text,1,500) txt 
from v$process p,  
     v$session s, 
     v$sqlarea sa  
where    p.addr=s.paddr 
and      s.username is not null
and      s.sql_address=sa.address(+)  
and      s.sql_hash_value=sa.hash_value(+)
order by 1,2,7; 

rem and s.machine like '%WEBS51%'
rem spool kill_sess.sh
rem select 'kill -9 ||s.sid ssid from 
rem v$process p,
rem v$session s,
rem v$sqlarea sa
rem where    p.addr=s.paddr                   
rem and      s.username is not null           
rem and      s.sql_address=sa.address(+)      
rem and      s.sql_hash_value=sa.hash_value(+)
rem order by 1,2,7 ;                          
                                          
spool off
