set linesize 132
set pagesize 1000
SELECT * FROM TABLE(dbms_xplan.DISPLAY('PLAN_TABLE','sad'));
