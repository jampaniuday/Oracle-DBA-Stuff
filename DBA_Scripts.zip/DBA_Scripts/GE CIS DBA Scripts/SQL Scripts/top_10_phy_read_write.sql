--top 10 user sessions by Physical Writes
set pages 1000

select distinct c.osuser,c.username,c.sid, b.name, a.value
  from v$sesstat a,
       v$statname b,
       v$session c
 where a.statistic# = b.statistic#
  and a.sid = c.sid
  and nvl(a.value,0) > 0
  and c.username not in ('SYS','SYSTEM')
  and b.name = 'physical writes'
  and c.type <> 'BACKGROUND'
  and rownum <= 10
union all
select distinct c.osuser,c.username,c.sid, b.name, a.value
  from v$sesstat a,
       v$statname b,
       v$session c
 where a.statistic# = b.statistic#
  and a.sid = c.sid
  and nvl(a.value,0) > 0
  and c.username not in ('SYS','SYSTEM')
  and b.name = 'physical reads'
  and c.type <> 'BACKGROUND'
  and rownum <= 10 order by value;




