rem -----------------------------------------------------------------------
rem Purpose:   This  is to get PID by giving SID .Normally used to kill the
rem		 OS process after killing the session in database.
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on

select p.spid from v$process p ,v$session s where s.saddr=p.addr
 and s.sid=&sid;


