analyze index XIE1SRC_CUST_NAME estimate statistics sample 30 percent;
