set pagesize 100
SELECT a.username, b.sql_text
  FROM v$session a, v$sqlarea b, v$process c
WHERE (c.spid = '&PID' OR a.process = '&PID')
   AND a.paddr = c.addr
   AND a.sql_address = b.address
/
