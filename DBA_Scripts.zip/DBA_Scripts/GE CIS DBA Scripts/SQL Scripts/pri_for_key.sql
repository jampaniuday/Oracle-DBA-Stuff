
rem -----------------------------------------------------------------------
rem Purpose:    To know the foreign keys for a given table.
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on

column for_table format a20
column FOR_OWNER format a20
column for_col format a20
column pri_owner format a20
column pri_table format a20
column pri_col format a20

select  a.owner for_owner, a.table_name for_table, c.column_name for_col,
b.owner pri_owner, b.table_name pri_table, d.column_name pri_col
from dba_constraints a, dba_constraints b,
dba_cons_columns c, dba_cons_columns d
where  a.r_constraint_name = b.constraint_name
and    a.constraint_type = 'R'
and    b.constraint_type = 'P'
and    a.r_owner=b.owner
and    a.constraint_name = c.constraint_name
and    b.constraint_name=d.constraint_name
and    a.owner = c.owner
and    a.table_name=c.table_name
and    b.owner = d.owner
and    b.table_name=d.table_name
and b.table_name= '&table_name';

