#!/bin/ksh
## Script Name  :       apcpartchk.sh
## Purpose      :       To mail the list of new partitions added every week
## Outputs      :       Sends an email after weekly partitions additions
## Author       :       Sadiq Askari
## Date Created :       10/01/2005
## Date Modified:       

. /export/home/oracle9/bin/apcp
cd $SID_HOME/audit
rm $SID_HOME/audit/apcpartchk.txt
PASSWD=`/export/home/oracle9/bin/tellme system`
sqlplus -s system/$PASSWD  <<EOF >> $SID_HOME/audit/ora.error
@/export/home/oracle9/sadiq/apc.sql;
quit
EOF
mailx -s "APC New Partition Details- `hostname`" corpgtsgecisdba@gecis.ge.com < $SID_HOME/audit/apcpartchk.txt
