rem -----------------------------------------------------------------------
rem Purpose:    Transaction which generating more redo
rem This view contains the column BLOCK_CHANGES which indicates  how much blocks have been changed
rem by the session. High values indicate a   session generating lots of redo.
rem Run the query multiple times and examine the delta between each occurrence
rem of BLOCK_CHANGES. Large deltas indicate high redo generation by the session.
rem -----------------------------------------------------------------------

set pages 1000

SELECT s.sid, s.serial#, s.username, s.program,
 i.block_changes
 FROM v$session s, v$sess_io i
WHERE s.sid = i.sid
ORDER BY 5 desc, 1, 2, 3, 4;


rem -----------------------------------------------------------------------
rem Purpose:    Transaction which generating more redo
rem Run the query multiple times and examine the delta between each occurrence
rem of USED_UBLK and USED_UREC. Large deltas indicate high redo generation by 
rem  the session.
rem -----------------------------------------------------------------------

SELECT s.sid, s.serial#, s.username, s.program, 
        t.used_ublk, t.used_urec
       FROM v$session s, v$transaction t
       WHERE s.taddr = t.addr
       ORDER BY 5 desc, 6 desc, 1, 2, 3, 4;

