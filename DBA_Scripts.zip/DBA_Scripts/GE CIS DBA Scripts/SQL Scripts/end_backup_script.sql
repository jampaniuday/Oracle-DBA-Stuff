alter tablespace TS_POA_DATA end backup;                                        
alter tablespace TS_POA_NDX end backup;                                         
