rem -----------------------------------------------------------------------
rem Purpose:   This script shows the tablespaces which are in backup mode
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on

select a.tablespace_name
from sys.dba_data_files a, sys.v_$backup b
where b.status = 'ACTIVE'
and b.file# = a.file_id
group by a.tablespace_name;

