set pagesize 100
SELECT DECODE(request,0,'Holder: ','Waiter: ')||sid sess, id1, id2, lmode, request, type
FROM V$LOCK WHERE (id1, id2, type) IN (SELECT id1, id2, type FROM V$LOCK WHERE request>0)
ORDER BY id1, request;

select b. machine, a.sql_text from v$sqlarea a, v$session b where 
a.hash_value=b.sql_hash_value;
--b.sid='&sid' and 

select object_id, session_id, locked_mode from v$locked_object where session_id='&sid';

select object_name, object_type from dba_objects where object_id='&obj_id';

select SESSION_ID,LOCK_TYPE,MODE_HELD from dba_locks where session_id='&sid';

alter system kill session ('sid', 'serial#');
