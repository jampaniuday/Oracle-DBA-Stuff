#!/bin/ksh
########################################################################
##
## sgasiz.sh - To list the size of the SGA for each instance in oratab
##             or for NT user created list $DBA_HOME/admin/orasid.list
##
## usage     - sgasiz.sh  (DBA_HOME must be set)
##
## The script loops over each instance found in ORATAB and get the SGA
## size from v$sga.
##
## 2000-01-24  wfb  	original version
## 2003-08-25  Prateek	Made compatible to run on 9i database by replacing 
##			"svrmgrl" with "sqlplus '/as sysdba'"
## 2003-08-29  Prateek  Did Column formatting , so that text in the output 
##			does not wrap around.	
##########################################################################

# setup environment

echo `uname -a`
date
echo
rval=0
SVRMGR=svrmgrl

machtyp=`uname -a | cut -c1-3`
case "$machtyp" in
("Win")
  sysinf info -v | grep "Number of Processors"
  sysinf memory -v | grep "Total Physical"
  ORATAB=$DBA_HOME/admin/orasid.list
  SVRMGR=svrmgr30
;;
("Sun")
  dmesg | grep "^cpu.:"
  dmesg | grep "^mem = "
  ORATAB=/var/opt/oracle/oratab
;;
("HP-")
  grep "Physical:" /var/adm/syslog/syslog.log | tail -1
  ORATAB=/etc/oratab
;;
("OSF")
  grep "physical memory" /var/adm/messages | tail -1
  ORATAB=/etc/oratab
;;
("Lin")
  dmesg | grep "^cpu.:"
  dmesg | grep "^mem = "
  ORATAB=/etc/oratab
;;
esac

export ORATAB SVRMGR
echo "ORATAB = " $ORATAB
audit_path=$DBA_HOME/audit

# check environment

if [ ! $DBA_HOME ]
then
  echo "Error==> DBA_HOME not set"
  echo "script terminating"
  exit 1
fi

if [ ! -d $audit_path ]
then
  echo "Error==> $audit_path does not exist"
  echo "script terminating"
  exit 1
fi

if [ ! -f $ORATAB ]
then
  echo "Error==> $ORATAB does not exist"
  echo "script terminating"
  exit 1
fi

#####################################
# Loop over the entries in ORATAB   #
#####################################

while read ora_line
do

# filter out comment lines 
 
  char1=`echo $ora_line | cut -c1`
  if [[ "${char1}" != [A-Za-z] ]]
  then
    continue
  fi

# get sid

  ora_sid=`echo $ora_line | cut -c1-4`

#  set instance environment

  if [ ! -f $HOME/bin/$ora_sid ]
  then
    echo "Error ==> no environment script found for $ora_sid"
    rval=1
    continue
  fi

unset ORA_NLS33
. $HOME/bin/$ora_sid
# Next line changed by Prateek on 2003-Aug-25 
# Replaced svrmgrl with "sqlplus '/as sysdba'"
sqlplus '/as sysdba' << EOF > $audit_path/InstNam.txt
col Instance format a8
col name format a8
select 'Instance' Instance, name from v\$database;
exit
EOF
grep "ORA-" $audit_path/InstNam.txt >/dev/null
if [ $? -eq 0 ]
then
  echo "Error ==> $ora_sid not available"
  rval=1
  continue
fi
InstNam=`cat $audit_path/InstNam.txt | grep Instance`
export InstNam
# Next line changed by Prateek on 2003-Aug-25 
# Replaced svrmgrl with "sqlplus '/as sysdba'"
sqlplus '/as sysdba' << EOF >> $audit_path/sgalist.txt
col TotSGASize format a15
col TotSGAValue format a15
col '$InstNam' format a30
select to_char(sysdate, 'YYYY-MM-DD HH24:MI:SS') from dual;
show parameter db_name
select 'Total SGA size' TotSGASize, 
       to_char(sum(value), '99,999,999,999') TotSGAValue,
       '$InstNam'       
       from v\$sga;
select 'sgasumrow', 
       sum(value)      
       from v\$sga;
exit
EOF
done < $ORATAB
#done < /export/home/oracle/prateek/test.txt

echo " "
grep "Instance" $audit_path/sgalist.txt | sort -k 5
echo " "

# sum memory used by each instance

totmem=`grep "sgasumrow" $audit_path/sgalist.txt | awk 'BEGIN {sum=0} {sum=sum+$2} END {printf "%d", sum}'`

# insert commas and print

tmlen=`echo $totmem | awk '{ print length($0)}'`
triplets=`echo $tmlen | awk '{ print int($1/3)i}'`
rest=`echo $tmlen $triplets | awk '{ print ($1-$2*3)}'`
echo
printf "Total memory used by SGAs: "
if [ "$rest" -ne "0" ]
then
  num_grp=`echo $totmem | cut -c1-$rest`
  printf "%-s" $num_grp
fi
if [ $triplets -gt 0 ]
then
  j=`expr $rest + 1`
  i=0
  while [ i -lt $triplets ]
  do
    k=`expr $j + 2`
    num_grp=`echo $totmem | cut -c$j-$k`
    if [[ "$i" -eq "0" && "$rest" -eq "0" ]]
    then
      printf "%s" $num_grp
    else 
      printf ",%s" $num_grp
    fi
    i=`expr $i + 1`
    j=`expr $j + 3`
  done
fi
printf " bytes\n"
echo 



if [ $rval -ne 0 ]
then
  echo "Errors encountered"
  ohost=`uname -a`
  rmsg="Not all candidate instances were processed"
  echo $rmsg
fi
echo
date
echo "SGA size list terminating" 

# clean up temporary files
rm -f $audit_path/InstNam.txt >/dev/null 2>&1
rm -f $audit_path/sgalist.txt >/dev/null 2>&1

exit $rval
