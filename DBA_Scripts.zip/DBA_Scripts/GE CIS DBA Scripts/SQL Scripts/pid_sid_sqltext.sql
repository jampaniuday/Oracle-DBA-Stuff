
se:   This is to get currently runninig session spid,sid and sql text
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on

SELECT a.sid,c.spid,b.sql_text
  FROM v$session a, v$sqlarea b, v$process c
WHERE a.paddr = c.addr
   AND a.sql_address = b.address
/




