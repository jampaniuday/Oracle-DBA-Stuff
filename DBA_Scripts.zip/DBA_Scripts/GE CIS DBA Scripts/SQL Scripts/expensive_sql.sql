--This script reports the percentage of load on the instance due to
-- the most expensive few SQL statements.
-- Tuning these statements can often make huge
-- improvements in overall system performance. 

column load format a6 justify right
column executes format 9999999
break on load on executes


column load format a6 justify right
column executes format 9999999
break on disk_read_load on executes
set pages 1000
set lines 200
select
  substr(to_char(s.pct, '99.00'), 2) || '%'  disk_read_load,
  s.executions  executes,
  p.sql_text
from
  ( 
    select
      address,
      disk_reads,
      executions,
      pct,
      rank() over (order by disk_reads desc)  ranking
    from
      (
	select
	  address,
	  disk_reads,
	  executions,
	  100 * ratio_to_report(disk_reads) over ()  pct
	from
	  sys.v_$sql
	where
	  command_type != 47
      )
    where
      disk_reads > 50 * executions
  )  s,
  sys.v_$sqltext  p
where
  s.ranking <= 5 and
  p.address = s.address
order by
  1, s.address, p.piece
/

