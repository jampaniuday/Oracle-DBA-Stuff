rem Purpose:   This script shows the sql text for the PID provided
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on


set pagesize 10000
select a.sql_text,OSUSER, client_info, MACHINE,  disk_reads
      , a.buffer_gets, a.executions , b.sid,c.spid
      from v$sqlarea a, v$session b,v$process c
      where spid = &PID  and
      a.address = b.sql_address
      and c.addr=b.paddr;


