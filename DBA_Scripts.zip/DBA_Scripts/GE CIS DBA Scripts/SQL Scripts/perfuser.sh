if [ "`uname -a | cut -c1-3`" = "Sun" ]
        then
#                oratab=/var/opt/oracle/oratab
                oratab=$HOME/sadiq/oracle.oratab
        else
                oratab=/etc/oratab
fi

rm $HOME/sadiq/audit/perf_output.txt 2>&1
rm $HOME/sadiq/audit/perfexit.lst 2>&1
rm $HOME/sadiq/audit/timed_stat.lst 2>&1

export Banner='Info On Server  '`hostname`

echo $Banner >$HOME/sadiq/audit/perf_output.txt
allsid=`cat $oratab |grep -v \#|grep -v \*|awk -F: '{print $1}'|xargs echo`

for ALLS in $allsid
do
. $HOME/bin/$ALLS
if [ "$ORACLE_SID" = "$ALLS" ]
then
  ps -ef | grep pmon | grep $ALLS >\dev\null 2>&1
sqlplus -s "/as sysdba" <<EOF > /dev/null
@$HOME/sadiq/checkperf.sql
exit
EOF
  grep "no rows selected"  $HOME/sadiq/audit/perfexit.lst 2>&1
   if [ $? -eq 0 ]
    then
     echo "$ALLS Does not have perfstat user."  >> $HOME/sadiq/audit/perf_output.txt
   else
     grep "TRUE" $HOME/sadiq/audit/timed_stat.lst 2>&1
      if [ $? -ne 0 ]
      then
       echo "$ALLS Doesn't have timed stats set to true." >> $HOME/sadiq/audit/perf_output.txt
      fi
   fi
else
 echo " The instnace $ALLS is not up." >> $HOME/sadiq/audit/inst_down.txt
fi
done

if [ -f $HOME/sadiq/audit/perf_output.txt ]
then
cat $HOME/sadiq/audit/perf_output.txt | mailx -s "Perfstat Check Results." sunilkumar.shah@gecis.ge.com
fi
