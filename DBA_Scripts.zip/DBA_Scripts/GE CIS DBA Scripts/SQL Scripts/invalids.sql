SET PAGESIZE 1000
Column object_name format a35
column owner format a15
select owner,object_name,object_type,status from all_objects where status='INVALID';
