Select * from dba_2pc_pending;  
If this returns rows you should do the following:                

Select local_tran_id from dba_2pc_pending;        

Execute dbms_transaction.purge_lost_db_entry('<LOCAL_TRAN_ID>');        

Commit; 
