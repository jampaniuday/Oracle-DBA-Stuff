select rownum||' '||sql_text||' '||disk_reads as "Top SQL by IO"
from (
   select sql_text,disk_reads
   from  v$sqlarea 
   order by disk_reads desc) a
where rownum < 6 
/
