select owner,
       substr(tablespace_name,1,10)  "Tablespace",
       substr(segment_name,1,20)     "Object Name",
       substr(segment_type,1,15)     "Type",
       bytes                         "Bytes",
       extents                       "Extents",
       max_extents                   "Maximum",
       NEXT_EXTENT              "Next_size"
from   dba_segments
where  segment_type in ('TABLE','INDEX','CLUSTER','INDEX PARTITION','LOBINDEX','
LOBSEGMENT','ROLLBACK','TABLE PARTITION')
and    extents >= (40/100)*max_extents
order by tablespace_name,segment_type, segment_name ;
