
rem -----------------------------------------------------------------------
rem Purpose:   This finds the sql text for given SID number
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on


SET VERIFY OFF
SELECT a.sql_text  FROM   v$sqltext a, v$session b
	WHERE  a.address = b.sql_address
		AND    a.hash_value = b.sql_hash_value
		AND    b.sid = &SID_NO;

