ps -ef | grep plat | grep "LOCAL=NO" |grep -v grep| awk -F" " '{print "kill -9 "$2}' >kill.sh
