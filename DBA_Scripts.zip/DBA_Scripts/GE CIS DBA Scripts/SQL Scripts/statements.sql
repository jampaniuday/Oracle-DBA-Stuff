set lines 4100
column logon_time format a20
column ssid format 9999
column osuser format a10
column username format a20
column machine format a30
column txt format a2000
set pages 100
select s.sid ssid,
        s.osuser,
        s.username,
        trim(substr(s.machine,1,30)) machine ,
to_char (s.logon_time,'DD-MON-YY HH24:MI') logon_time,
       trim(substr(sa.sql_text,1,2000)) txt
from v$process p,
     v$session s,
     v$sqlarea sa
where    p.addr=s.paddr
and      s.username is not null
and      s.sql_address=sa.address(+)
and      s.sql_hash_value=sa.hash_value(+);
