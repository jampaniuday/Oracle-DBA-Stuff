rem -----------------------------------------------------------------------
rem Purpose:   This is to get SQL details which causes high disk reads
rem -----------------------------------------------------------------------
set pagesize 100
Set echo on

set pagesize 10000
select a.sql_text, a.executions, disk_reads,
      a.buffer_gets,  disk_reads/(a.executions+.01) read_per_exec,
 cpu_time/(a.executions+.01) CPU_per_exec,      b.sid, c.spid,OSUSER, client_info, MACHINE
      from v$sqlarea a, v$session b,v$process c       where users_executing > 0 and 
     a.address = b.sql_address
      and c.addr=b.paddr      ORDER BY read_per_exec;

