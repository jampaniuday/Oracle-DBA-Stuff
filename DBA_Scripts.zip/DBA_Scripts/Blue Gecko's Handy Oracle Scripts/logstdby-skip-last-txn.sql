alter database start logical standby apply immediate skip failed transaction
/
