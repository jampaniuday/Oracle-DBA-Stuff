alter database stop logical standby apply
/
